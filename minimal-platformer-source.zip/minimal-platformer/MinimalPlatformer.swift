import AppKit
import SpriteKit

struct Platform {
    let rect: CGRect
    let kind: Kind
    enum Kind { case solid, hazard }
}

struct Level {
    let name: String
    let subtitle: String
    let spawn: CGPoint
    let goal: CGRect
    let platforms: [Platform]
}

final class GameScene: SKScene {
    private let world = SKNode()
    private let player = SKShapeNode(rectOf: CGSize(width: 30, height: 30), cornerRadius: 5)
    private let levelLabel = SKLabelNode(fontNamed: "SFMono-Semibold")
    private let stateLabel = SKLabelNode(fontNamed: "SFMono-Regular")
    private let hintLabel = SKLabelNode(fontNamed: "SFProText-Regular")
    private let messageLabel = SKLabelNode(fontNamed: "SFProDisplay-Bold")
    private let messageSubLabel = SKLabelNode(fontNamed: "SFProText-Regular")

    private var currentLevel = 0
    private var activePlatforms: [Platform] = []
    private var agentPosition = CGPoint.zero
    private var velocity = CGPoint.zero
    private var heldKeys = Set<UInt16>()
    private var grounded = false
    private var coyoteTime: TimeInterval = 0
    private var jumpBuffer: TimeInterval = 0
    private var lastTime: TimeInterval = 0
    private var accumulator: TimeInterval = 0
    private var episodeSteps = 0
    private var episodeReward: Double = 0
    private var lastReward: Double = 0
    private var deaths = 0
    private var completed = false
    private var pausedForTransition = false

    private let levels: [Level] = [
        Level(
            name: "01  FIRST STEPS",
            subtitle: "Learn to move and jump",
            spawn: CGPoint(x: 90, y: 116),
            goal: CGRect(x: 858, y: 105, width: 40, height: 58),
            platforms: [
                Platform(rect: CGRect(x: 0, y: 56, width: 355, height: 30), kind: .solid),
                Platform(rect: CGRect(x: 425, y: 56, width: 535, height: 30), kind: .solid),
                Platform(rect: CGRect(x: 255, y: 145, width: 135, height: 18), kind: .solid),
                Platform(rect: CGRect(x: 475, y: 205, width: 140, height: 18), kind: .solid),
                Platform(rect: CGRect(x: 690, y: 145, width: 120, height: 18), kind: .solid)
            ]
        ),
        Level(
            name: "02  THE GAP",
            subtitle: "Build momentum across the void",
            spawn: CGPoint(x: 70, y: 116),
            goal: CGRect(x: 858, y: 371, width: 40, height: 58),
            platforms: [
                Platform(rect: CGRect(x: 0, y: 56, width: 205, height: 30), kind: .solid),
                Platform(rect: CGRect(x: 265, y: 125, width: 125, height: 18), kind: .solid),
                Platform(rect: CGRect(x: 445, y: 205, width: 115, height: 18), kind: .solid),
                Platform(rect: CGRect(x: 610, y: 285, width: 120, height: 18), kind: .solid),
                Platform(rect: CGRect(x: 780, y: 355, width: 180, height: 24), kind: .solid),
                Platform(rect: CGRect(x: 205, y: 42, width: 575, height: 14), kind: .hazard)
            ]
        ),
        Level(
            name: "03  PRECISION",
            subtitle: "Short landings, clean decisions",
            spawn: CGPoint(x: 70, y: 116),
            goal: CGRect(x: 874, y: 351, width: 40, height: 58),
            platforms: [
                Platform(rect: CGRect(x: 0, y: 56, width: 150, height: 30), kind: .solid),
                Platform(rect: CGRect(x: 205, y: 125, width: 82, height: 18), kind: .solid),
                Platform(rect: CGRect(x: 347, y: 200, width: 72, height: 18), kind: .solid),
                Platform(rect: CGRect(x: 474, y: 116, width: 76, height: 18), kind: .solid),
                Platform(rect: CGRect(x: 604, y: 218, width: 72, height: 18), kind: .solid),
                Platform(rect: CGRect(x: 731, y: 292, width: 74, height: 18), kind: .solid),
                Platform(rect: CGRect(x: 850, y: 335, width: 110, height: 24), kind: .solid),
                Platform(rect: CGRect(x: 150, y: 42, width: 700, height: 14), kind: .hazard)
            ]
        )
    ]

    override func didMove(to view: SKView) {
        backgroundColor = NSColor(calibratedWhite: 0.055, alpha: 1)
        anchorPoint = .zero
        addChild(world)
        configureHUD()
        loadLevel(0)
    }

    private func configureHUD() {
        let topRule = SKShapeNode(rect: CGRect(x: 28, y: 490, width: 904, height: 1))
        topRule.fillColor = NSColor(calibratedWhite: 0.22, alpha: 1)
        topRule.strokeColor = .clear
        addChild(topRule)

        levelLabel.fontSize = 15
        levelLabel.fontColor = NSColor(calibratedWhite: 0.92, alpha: 1)
        levelLabel.horizontalAlignmentMode = .left
        levelLabel.verticalAlignmentMode = .center
        levelLabel.position = CGPoint(x: 30, y: 510)
        addChild(levelLabel)

        stateLabel.fontSize = 12
        stateLabel.fontColor = NSColor(calibratedWhite: 0.62, alpha: 1)
        stateLabel.horizontalAlignmentMode = .right
        stateLabel.verticalAlignmentMode = .center
        stateLabel.position = CGPoint(x: 930, y: 510)
        addChild(stateLabel)

        hintLabel.text = "A D / ← →  MOVE     W / SPACE / ↑  JUMP     R  RESET"
        hintLabel.fontSize = 12
        hintLabel.fontColor = NSColor(calibratedWhite: 0.48, alpha: 1)
        hintLabel.horizontalAlignmentMode = .center
        hintLabel.position = CGPoint(x: 480, y: 20)
        addChild(hintLabel)

        messageLabel.fontSize = 36
        messageLabel.fontColor = .white
        messageLabel.horizontalAlignmentMode = .center
        messageLabel.position = CGPoint(x: 480, y: 302)
        messageLabel.zPosition = 20
        messageLabel.isHidden = true
        addChild(messageLabel)

        messageSubLabel.fontSize = 15
        messageSubLabel.fontColor = NSColor(calibratedWhite: 0.68, alpha: 1)
        messageSubLabel.horizontalAlignmentMode = .center
        messageSubLabel.position = CGPoint(x: 480, y: 268)
        messageSubLabel.zPosition = 20
        messageSubLabel.isHidden = true
        addChild(messageSubLabel)
    }

    private func loadLevel(_ index: Int) {
        world.removeAllChildren()
        currentLevel = index
        let level = levels[index]
        activePlatforms = level.platforms
        completed = false
        pausedForTransition = false
        episodeSteps = 0
        episodeReward = 0
        lastReward = 0
        velocity = .zero
        agentPosition = level.spawn
        grounded = false
        messageLabel.isHidden = true
        messageSubLabel.isHidden = true
        levelLabel.text = level.name + "  ·  " + level.subtitle.uppercased()

        for platform in level.platforms {
            let node = SKShapeNode(rect: platform.rect, cornerRadius: platform.kind == .solid ? 3 : 1)
            if platform.kind == .solid {
                node.fillColor = NSColor(calibratedWhite: 0.88, alpha: 1)
                node.strokeColor = .clear
            } else {
                node.fillColor = NSColor(calibratedRed: 1.0, green: 0.25, blue: 0.28, alpha: 0.85)
                node.strokeColor = .clear
                addHazardTeeth(to: node, rect: platform.rect)
            }
            node.zPosition = 2
            world.addChild(node)
        }

        let goalGlow = SKShapeNode(rect: level.goal.insetBy(dx: -6, dy: -6), cornerRadius: 10)
        goalGlow.fillColor = NSColor(calibratedRed: 0.25, green: 0.95, blue: 0.72, alpha: 0.12)
        goalGlow.strokeColor = .clear
        goalGlow.zPosition = 1
        world.addChild(goalGlow)

        let goal = SKShapeNode(rect: level.goal, cornerRadius: 7)
        goal.fillColor = .clear
        goal.strokeColor = NSColor(calibratedRed: 0.25, green: 0.95, blue: 0.72, alpha: 1)
        goal.lineWidth = 3
        goal.zPosition = 3
        world.addChild(goal)

        let goalMark = SKLabelNode(fontNamed: "SFMono-Bold")
        goalMark.text = "GO"
        goalMark.fontSize = 12
        goalMark.fontColor = NSColor(calibratedRed: 0.25, green: 0.95, blue: 0.72, alpha: 1)
        goalMark.position = CGPoint(x: level.goal.midX, y: level.goal.midY - 5)
        goalMark.zPosition = 4
        world.addChild(goalMark)

        player.path = CGPath(roundedRect: CGRect(x: -15, y: -15, width: 30, height: 30), cornerWidth: 5, cornerHeight: 5, transform: nil)
        player.fillColor = NSColor(calibratedRed: 0.34, green: 0.58, blue: 1.0, alpha: 1)
        player.strokeColor = .clear
        player.zPosition = 5
        world.addChild(player)
        syncPlayer()
        updateHUD()
    }

    private func addHazardTeeth(to parent: SKNode, rect: CGRect) {
        let count = max(1, Int(rect.width / 14))
        for i in 0..<count {
            let tooth = SKShapeNode(path: {
                let p = CGMutablePath()
                let x = rect.minX + CGFloat(i) * rect.width / CGFloat(count)
                let w = rect.width / CGFloat(count)
                p.move(to: CGPoint(x: x, y: rect.maxY))
                p.addLine(to: CGPoint(x: x + w / 2, y: rect.maxY + 10))
                p.addLine(to: CGPoint(x: x + w, y: rect.maxY))
                p.closeSubpath()
                return p
            }())
            tooth.fillColor = NSColor(calibratedRed: 1.0, green: 0.25, blue: 0.28, alpha: 0.85)
            tooth.strokeColor = .clear
            parent.addChild(tooth)
        }
    }

    override func keyDown(with event: NSEvent) {
        if event.keyCode == 15 { resetEpisode(penalize: false); return }
        if event.keyCode == 36 && completed { loadLevel(0); return }
        heldKeys.insert(event.keyCode)
        if [13, 49, 126].contains(event.keyCode) { jumpBuffer = 0.12 }
    }

    override func keyUp(with event: NSEvent) {
        heldKeys.remove(event.keyCode)
        if [13, 49, 126].contains(event.keyCode), velocity.y > 0 { velocity.y *= 0.50 }
    }

    override func update(_ currentTime: TimeInterval) {
        if lastTime == 0 { lastTime = currentTime; return }
        let elapsed = min(currentTime - lastTime, 0.05)
        lastTime = currentTime
        guard !completed, !pausedForTransition else { return }
        accumulator += elapsed
        let fixedStep = 1.0 / 120.0
        while accumulator >= fixedStep {
            simulate(dt: fixedStep)
            accumulator -= fixedStep
        }
        syncPlayer()
        updateHUD()
    }

    private func simulate(dt: TimeInterval) {
        episodeSteps += 1
        lastReward = -0.001
        episodeReward += lastReward

        let left = heldKeys.contains(0) || heldKeys.contains(123)
        let right = heldKeys.contains(2) || heldKeys.contains(124)
        let direction = (right ? 1.0 : 0.0) - (left ? 1.0 : 0.0)
        let acceleration = grounded ? 1850.0 : 1050.0
        let targetSpeed = direction * 270.0
        let delta = targetSpeed - velocity.x
        let maxChange = acceleration * dt
        velocity.x += max(-maxChange, min(maxChange, delta))
        if direction == 0 && grounded { velocity.x *= pow(0.0008, dt) }

        coyoteTime = grounded ? 0.09 : max(0, coyoteTime - dt)
        jumpBuffer = max(0, jumpBuffer - dt)
        if jumpBuffer > 0 && coyoteTime > 0 {
            velocity.y = 455
            grounded = false
            coyoteTime = 0
            jumpBuffer = 0
        }

        velocity.y -= 1120 * dt
        velocity.y = max(velocity.y, -680)

        moveHorizontal(CGFloat(velocity.x * dt))
        moveVertical(CGFloat(velocity.y * dt))

        agentPosition.x = max(15, min(945, agentPosition.x))
        if agentPosition.y < -40 { resetEpisode(penalize: true); return }

        let playerRect = CGRect(x: agentPosition.x - 15, y: agentPosition.y - 15, width: 30, height: 30)
        for platform in activePlatforms where platform.kind == .hazard {
            if playerRect.intersects(platform.rect.insetBy(dx: 2, dy: -7)) {
                resetEpisode(penalize: true)
                return
            }
        }
        if playerRect.intersects(levels[currentLevel].goal) { finishLevel() }
    }

    private func moveHorizontal(_ dx: CGFloat) {
        agentPosition.x += dx
        var rect = CGRect(x: agentPosition.x - 15, y: agentPosition.y - 15, width: 30, height: 30)
        for platform in activePlatforms where platform.kind == .solid && rect.intersects(platform.rect) {
            if dx > 0 { agentPosition.x = platform.rect.minX - 15 }
            else if dx < 0 { agentPosition.x = platform.rect.maxX + 15 }
            velocity.x = 0
            rect.origin.x = agentPosition.x - 15
        }
    }

    private func moveVertical(_ dy: CGFloat) {
        grounded = false
        agentPosition.y += dy
        var rect = CGRect(x: agentPosition.x - 15, y: agentPosition.y - 15, width: 30, height: 30)
        for platform in activePlatforms where platform.kind == .solid && rect.intersects(platform.rect) {
            if dy <= 0 {
                agentPosition.y = platform.rect.maxY + 15
                velocity.y = 0
                grounded = true
            } else {
                agentPosition.y = platform.rect.minY - 15
                velocity.y = 0
            }
            rect.origin.y = agentPosition.y - 15
        }
    }

    private func finishLevel() {
        lastReward = 1.0
        episodeReward += lastReward
        pausedForTransition = true
        messageLabel.isHidden = false
        messageSubLabel.isHidden = false
        if currentLevel < levels.count - 1 {
            messageLabel.text = "LEVEL CLEAR"
            messageSubLabel.text = "reward +1.000  ·  loading next level"
            let next = currentLevel + 1
            run(.sequence([.wait(forDuration: 0.9), .run { [weak self] in self?.loadLevel(next) }]))
        } else {
            completed = true
            pausedForTransition = false
            messageLabel.text = "ALL LEVELS COMPLETE"
            messageSubLabel.text = "Press Return to run again"
        }
    }

    private func resetEpisode(penalize: Bool) {
        if penalize {
            deaths += 1
            lastReward = -0.1
        }
        let level = levels[currentLevel]
        agentPosition = level.spawn
        velocity = .zero
        grounded = false
        coyoteTime = 0
        jumpBuffer = 0
        episodeSteps = 0
        episodeReward = penalize ? -0.1 : 0
        syncPlayer()
        updateHUD()
    }

    private func syncPlayer() {
        player.position = agentPosition
        let speedTilt = max(-0.10, min(0.10, CGFloat(velocity.x / 1800)))
        player.zRotation = grounded ? speedTilt : speedTilt * 2
    }

    private func updateHUD() {
        let groundedBit = grounded ? 1 : 0
        stateLabel.text = String(format: "x %03.0f  y %03.0f  vx %+04.0f  vy %+04.0f  g %d  step %05d  r %+.3f  Σ %+.3f  fails %d", agentPosition.x, agentPosition.y, velocity.x, velocity.y, groundedBit, episodeSteps, lastReward, episodeReward, deaths)
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var window: NSWindow!

    func applicationDidFinishLaunching(_ notification: Notification) {
        let size = NSSize(width: 960, height: 540)
        window = NSWindow(
            contentRect: NSRect(origin: .zero, size: size),
            styleMask: [.titled, .closable, .miniaturizable],
            backing: .buffered,
            defer: false
        )
        window.title = "Minimal Platformer"
        window.center()
        window.backgroundColor = NSColor(calibratedWhite: 0.055, alpha: 1)
        window.isReleasedWhenClosed = false

        let skView = SKView(frame: NSRect(origin: .zero, size: size))
        skView.preferredFramesPerSecond = 60
        skView.ignoresSiblingOrder = true
        let scene = GameScene(size: CGSize(width: 960, height: 540))
        scene.scaleMode = .aspectFit
        skView.presentScene(scene)
        window.contentView = skView
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
