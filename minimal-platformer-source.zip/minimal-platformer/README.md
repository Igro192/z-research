# Minimal Platformer

Original Swift platformer source. Compiled app and generated icons are excluded.

## Run

Build with Swift/Xcode on macOS.

This is a source snapshot from Z. Research. No license is granted for third-party content or trademarks.
