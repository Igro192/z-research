import AppKit

let size = NSSize(width: 1024, height: 1024)
let image = NSImage(size: size)
image.lockFocus()

let canvas = NSRect(origin: .zero, size: size)
let background = NSBezierPath(roundedRect: canvas.insetBy(dx: 42, dy: 42), xRadius: 220, yRadius: 220)
NSColor(calibratedWhite: 0.055, alpha: 1).setFill()
background.fill()

let floor = NSBezierPath(roundedRect: NSRect(x: 120, y: 180, width: 784, height: 82), xRadius: 18, yRadius: 18)
NSColor(calibratedWhite: 0.89, alpha: 1).setFill()
floor.fill()

let platform = NSBezierPath(roundedRect: NSRect(x: 400, y: 420, width: 250, height: 58), xRadius: 14, yRadius: 14)
platform.fill()

let agent = NSBezierPath(roundedRect: NSRect(x: 195, y: 262, width: 170, height: 170), xRadius: 35, yRadius: 35)
NSColor(calibratedRed: 0.34, green: 0.58, blue: 1.0, alpha: 1).setFill()
agent.fill()

let glow = NSBezierPath(roundedRect: NSRect(x: 708, y: 262, width: 126, height: 224), xRadius: 32, yRadius: 32)
NSColor(calibratedRed: 0.25, green: 0.95, blue: 0.72, alpha: 0.15).setFill()
glow.fill()

let goal = NSBezierPath(roundedRect: NSRect(x: 726, y: 280, width: 90, height: 188), xRadius: 22, yRadius: 22)
NSColor.clear.setFill()
NSColor(calibratedRed: 0.25, green: 0.95, blue: 0.72, alpha: 1).setStroke()
goal.lineWidth = 18
goal.stroke()

image.unlockFocus()

guard let tiff = image.tiffRepresentation,
      let bitmap = NSBitmapImageRep(data: tiff),
      let png = bitmap.representation(using: .png, properties: [:]) else {
    fatalError("Unable to render icon")
}
try png.write(to: URL(fileURLWithPath: CommandLine.arguments[1]))
