import XCTest
@testable import SplatStudio

final class SplatStudioTests: XCTestCase {
    func testPresetBudgetsIncreaseMonotonically() {
        XCTAssertEqual(QualityPreset.fast.title, "QUICK")
        XCTAssertEqual(QualityPreset.max.title, "ULTRA")
        XCTAssertLessThan(QualityPreset.fast.settings.maxFrames, QualityPreset.medium.settings.maxFrames)
        XCTAssertLessThan(QualityPreset.medium.settings.maxFrames, QualityPreset.high.settings.maxFrames)
        XCTAssertLessThan(QualityPreset.high.settings.maxFrames, QualityPreset.max.settings.maxFrames)
        XCTAssertLessThan(QualityPreset.fast.settings.trainingSteps, QualityPreset.medium.settings.trainingSteps)
        XCTAssertLessThan(QualityPreset.medium.settings.trainingSteps, QualityPreset.high.settings.trainingSteps)
        XCTAssertLessThan(QualityPreset.high.settings.trainingSteps, QualityPreset.max.settings.trainingSteps)
        XCTAssertGreaterThanOrEqual(QualityPreset.max.settings.maxFrames, 2_000)
        XCTAssertEqual(QualityPreset.max.settings.effortLevel, "ultra")
    }

    func testProjectMetadataRoundTrip() throws {
        let source = URL(fileURLWithPath: "/tmp/walkthrough.mov")
        let project = StudioProject.new(videoURL: source, preset: .high, analysis: nil)
        let data = try JSONEncoder.studio.encode(project)
        let decoded = try JSONDecoder.studio.decode(StudioProject.self, from: data)
        XCTAssertEqual(decoded.id, project.id)
        XCTAssertEqual(decoded.settings, QualityPreset.high.settings)
        XCTAssertEqual(decoded.originalVideoPath, source.path)
    }

    func testTimecodeFormatting() {
        XCTAssertEqual(CaptureAnalyzer.timecode(7.9), "00:07")
        XCTAssertEqual(CaptureAnalyzer.timecode(71), "01:11")
    }

    func testPipelineEventDecodesBackendShape() throws {
        let json = #"{"stage":"train","progress":0.5,"checkpoint":{"path":"/tmp/a.ply","step":500,"total_steps":1000,"gaussians":42000},"registered":83,"total_frames":100}"#.data(using: .utf8)!
        let event = try JSONDecoder().decode(PipelineEvent.self, from: json)
        XCTAssertEqual(event.checkpoint?.totalSteps, 1000)
        XCTAssertEqual(event.checkpoint?.gaussians, 42_000)
        XCTAssertEqual(event.registered, 83)
    }
}
