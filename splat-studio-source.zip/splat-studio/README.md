# Splat Studio — original Swift interface snapshot

A native SwiftUI interface for a video-to-Gaussian-splat workflow. Original Swift source and its four existing tests are included. The recovered Package.swift registers those tests; use `swift test --disable-sandbox --build-system native`. macOS 14+ and the Swift toolchain are required.

The compiled interface is not the complete reconstruction pipeline. Backend resources, Brush, ffmpeg, COLMAP, model weights, input recordings and trained scenes are excluded. The full local application integrates upstream Splat Local and other separately licensed tools. No reconstruction benchmark is claimed from these four metadata/preset/parser tests.
