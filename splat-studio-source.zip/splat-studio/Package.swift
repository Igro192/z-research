// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "SplatStudio",
    platforms: [.macOS(.v14)],
    products: [
        .executable(name: "SplatStudio", targets: ["SplatStudio"])
    ],
    targets: [
        .executableTarget(
            name: "SplatStudio",
            path: "Sources/SplatStudio",
            
            swiftSettings: [
                .swiftLanguageMode(.v5)
            ],
            linkerSettings: [
                .linkedFramework("AppKit"),
                .linkedFramework("AVFoundation"),
                .linkedFramework("AVKit"),
                .linkedFramework("Metal"),
                .linkedFramework("Network"),
                .linkedFramework("UserNotifications"),
                .linkedFramework("WebKit")
            ]
        ),
        .testTarget(name: "SplatStudioTests", dependencies: ["SplatStudio"], path: "Tests/SplatStudioTests")
    ]
)
