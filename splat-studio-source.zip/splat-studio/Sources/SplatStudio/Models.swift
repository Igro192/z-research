import Foundation

enum QualityPreset: String, CaseIterable, Codable, Identifiable {
    case fast
    case medium
    case high
    case max

    var id: String { rawValue }
    // Keep the original raw values so every existing project continues to
    // decode, while presenting the clearer four-level product vocabulary.
    var title: String {
        switch self {
        case .fast: "QUICK"
        case .medium: "MEDIUM"
        case .high: "HIGH"
        case .max: "ULTRA"
        }
    }

    var subtitle: String {
        switch self {
        case .fast: "Fast capture check"
        case .medium: "Everyday reconstruction"
        case .high: "Detailed room scan · recommended"
        case .max: "Maximum detail · leave it overnight"
        }
    }

    var timeHint: String {
        switch self {
        case .fast: "Usually minutes"
        case .medium: "About 30–60 minutes"
        case .high: "Often 1–3 hours"
        case .max: "Several hours or overnight"
        }
    }

    var settings: ReconstructionSettings {
        switch self {
        case .fast:
            ReconstructionSettings(maxFrames: 120, frameResolution: 1536, trainingSteps: 10_000,
                                   mapper: .automatic, imageScale: 1.0, minimumRegistration: 0.65,
                                   maximumBlurFraction: 0.35, effortLevel: "quick")
        case .medium:
            ReconstructionSettings(maxFrames: 400, frameResolution: 1920, trainingSteps: 30_000,
                                   mapper: .automatic, imageScale: 1.0, minimumRegistration: 0.68,
                                   maximumBlurFraction: 0.32, effortLevel: "medium")
        case .high:
            ReconstructionSettings(maxFrames: 900, frameResolution: 2304, trainingSteps: 70_000,
                                   mapper: .automatic, imageScale: 1.0, minimumRegistration: 0.72,
                                   maximumBlurFraction: 0.28, effortLevel: "high")
        case .max:
            ReconstructionSettings(maxFrames: 2_000, frameResolution: 3072, trainingSteps: 140_000,
                                   mapper: .automatic, imageScale: 1.0, minimumRegistration: 0.75,
                                   maximumBlurFraction: 0.24, effortLevel: "ultra")
        }
    }
}

enum MapperChoice: String, CaseIterable, Codable, Identifiable {
    case automatic = "auto"
    case glomap
    case incremental

    var id: String { rawValue }
    var label: String {
        switch self {
        case .automatic: "Automatic · GLOMAP with safe fallback"
        case .glomap: "GLOMAP only"
        case .incremental: "Incremental COLMAP"
        }
    }
}

struct ReconstructionSettings: Codable, Equatable {
    var maxFrames: Int
    var frameResolution: Int
    var trainingSteps: Int
    var mapper: MapperChoice
    var imageScale: Double
    var minimumRegistration: Double
    var maximumBlurFraction: Double
    // Optional keeps projects created by Splat Studio 1.0/1.1 readable.
    var effortLevel: String? = nil
}

enum CaptureRating: String, Codable, CaseIterable {
    case excellent = "Excellent capture"
    case good = "Good capture"
    case risky = "Risky capture"
    case likelyToFail = "Likely to fail"

    var symbol: String {
        switch self {
        case .excellent: "checkmark.seal.fill"
        case .good: "checkmark.circle.fill"
        case .risky: "exclamationmark.triangle.fill"
        case .likelyToFail: "xmark.octagon.fill"
        }
    }
}

struct CaptureIssue: Codable, Identifiable, Equatable {
    var id = UUID()
    var message: String
    var severity: Int
    var startTime: Double?
    var endTime: Double?
}

struct CaptureMetrics: Codable, Equatable {
    var duration: Double
    var width: Int
    var height: Int
    var fps: Double
    var candidateFrames: Int
    var blurScore: Double
    var cameraMovement: Double
    var overlap: Double
    var lowTextureFraction: Double
    var exposureInstability: Double
    var qualityScore: Int
    var rating: CaptureRating
    var issues: [CaptureIssue]
    var analyzedAt: Date = Date()
}

enum ProjectStage: String, Codable {
    case ready
    case analyzing
    case frames
    case poses
    case train
    case export
    case complete
    case failed
    case cancelled

    var title: String {
        switch self {
        case .ready: "Ready"
        case .analyzing: "Analyzing capture"
        case .frames: "Selecting frames"
        case .poses: "Reconstructing camera path"
        case .train: "Training Gaussian splats"
        case .export: "Optimizing exports"
        case .complete: "Complete"
        case .failed: "Needs attention"
        case .cancelled: "Cancelled"
        }
    }
}

struct StudioProject: Codable, Identifiable, Equatable {
    var id: UUID
    var name: String
    var createdAt: Date
    var modifiedAt: Date
    var originalVideoPath: String
    var importedVideoName: String
    var preset: QualityPreset
    var settings: ReconstructionSettings
    var analysis: CaptureMetrics?
    var stage: ProjectStage
    var statusMessage: String
    var progress: Double
    var registeredFrames: Int?
    var totalFrames: Int?
    var trainingStep: Int?
    var gaussianCount: Int?
    var finalModelPath: String?
    var thumbnailPath: String?
    var lastError: String?
    var recoveryAttempt: Int

    static func new(videoURL: URL, preset: QualityPreset, analysis: CaptureMetrics?) -> StudioProject {
        StudioProject(
            id: UUID(), name: videoURL.deletingPathExtension().lastPathComponent,
            createdAt: Date(), modifiedAt: Date(), originalVideoPath: videoURL.path,
            importedVideoName: videoURL.lastPathComponent, preset: preset, settings: preset.settings,
            analysis: analysis, stage: .ready, statusMessage: "Ready to reconstruct", progress: 0,
            registeredFrames: nil, totalFrames: nil, trainingStep: nil, gaussianCount: nil,
            finalModelPath: nil, thumbnailPath: nil, lastError: nil, recoveryAttempt: 0
        )
    }
}

struct FrameSummary: Codable, Equatable {
    var count: Int
    var sample: [String]
}

struct CheckpointSummary: Codable, Equatable {
    var path: String?
    var step: Int
    var totalSteps: Int
    var gaussians: Int?

    enum CodingKeys: String, CodingKey {
        case path
        case step
        case totalSteps = "total_steps"
        case gaussians
    }
}

struct ArtifactSummary: Codable, Identifiable, Equatable {
    var name: String
    var path: String
    var bytes: Int64
    var gaussians: Int?
    var fillRatio: Double?
    var id: String { path }

    enum CodingKeys: String, CodingKey {
        case name, path, bytes, gaussians
        case fillRatio = "fill_ratio"
    }
}

struct PipelineEvent: Codable, Equatable {
    var stage: String
    var progress: Double?
    var message: String?
    var frames: FrameSummary?
    var sparsePath: String?
    var cameras: [[String: FlexibleJSON]]?
    var checkpoint: CheckpointSummary?
    var artifacts: [ArtifactSummary]?
    var error: String?
    var registered: Int?
    var totalFrames: Int?
    var attempt: Int?

    enum CodingKeys: String, CodingKey {
        case stage, progress, message, frames, cameras, checkpoint, artifacts, error, registered, attempt
        case sparsePath = "sparse_path"
        case totalFrames = "total_frames"
    }
}

enum FlexibleJSON: Codable, Equatable {
    case string(String)
    case number(Double)
    case bool(Bool)
    case array([FlexibleJSON])
    case object([String: FlexibleJSON])
    case null

    init(from decoder: Decoder) throws {
        let box = try decoder.singleValueContainer()
        if box.decodeNil() { self = .null }
        else if let v = try? box.decode(Bool.self) { self = .bool(v) }
        else if let v = try? box.decode(Double.self) { self = .number(v) }
        else if let v = try? box.decode(String.self) { self = .string(v) }
        else if let v = try? box.decode([FlexibleJSON].self) { self = .array(v) }
        else { self = .object(try box.decode([String: FlexibleJSON].self)) }
    }

    func encode(to encoder: Encoder) throws {
        var box = encoder.singleValueContainer()
        switch self {
        case .string(let v): try box.encode(v)
        case .number(let v): try box.encode(v)
        case .bool(let v): try box.encode(v)
        case .array(let v): try box.encode(v)
        case .object(let v): try box.encode(v)
        case .null: try box.encodeNil()
        }
    }
}

struct DependencyStatus: Equatable {
    var python = false
    var ffmpeg = false
    var ffprobe = false
    var pycolmap = false
    var brush = false
    var node = false
    var da3 = false
    var metalDevice = "Checking…"

    var coreReady: Bool { python && ffmpeg && ffprobe && pycolmap && brush }
}
