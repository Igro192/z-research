import AppKit
import Combine
import SwiftUI
import UniformTypeIdentifiers

enum SidebarDestination: String, CaseIterable, Identifiable {
    case library = "Projects"
    case create = "New Scene"
    case guide = "How to Record"
    case settings = "Engine"

    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .library: "square.grid.2x2"
        case .create: "plus.circle"
        case .guide: "video.badge.checkmark"
        case .settings: "cpu"
        }
    }
}

@MainActor
final class StudioModel: ObservableObject {
    @Published var destination: SidebarDestination = .library
    @Published var selectedProject: StudioProject?
    @Published var importedVideo: URL?
    @Published var analysis: CaptureMetrics?
    @Published var isAnalyzing = false
    @Published var analysisError: String?
    @Published var preset: QualityPreset = .high {
        didSet { if !advancedWasEdited { settings = preset.settings } }
    }
    @Published var settings = QualityPreset.high.settings
    @Published var advancedWasEdited = false
    @Published var latestModelURL: URL?
    @Published var camerasJSON: String?
    @Published var sparseURL: URL?
    @Published var artifacts: [ArtifactSummary] = []
    @Published var toast: String?

    let store = ProjectStore()
    let dependencies = DependencyManager()
    let runner = BackendRunner()
    let systemMonitor = SystemMonitor()
    private var poseNotificationSent = false

    init() {
        Notifications.requestPermission()
        systemMonitor.start()
        Task {
            await dependencies.check()
            if !dependencies.status.da3 {
                await dependencies.installDepthFallback()
            }
        }
    }

    func chooseVideo() {
        let panel = NSOpenPanel()
        panel.title = "Choose a walkthrough video"
        panel.prompt = "Analyze Video"
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.allowedContentTypes = [.movie, .mpeg4Movie, .quickTimeMovie]
        guard panel.runModal() == .OK, let url = panel.url else { return }
        importVideo(url)
    }

    func importVideo(_ url: URL) {
        importedVideo = url
        destination = .create
        analysis = nil
        analysisError = nil
        isAnalyzing = true
        Task {
            do {
                let result = try await CaptureAnalyzer.analyze(url: url, preset: preset)
                analysis = result
            } catch {
                analysisError = error.localizedDescription
            }
            isAnalyzing = false
        }
    }

    func resetImport() {
        importedVideo = nil
        analysis = nil
        analysisError = nil
        advancedWasEdited = false
        settings = preset.settings
    }

    func createScene() {
        guard let importedVideo, !runner.isRunning else { return }
        do {
            var project = try store.create(videoURL: importedVideo, preset: preset, analysis: analysis)
            project.settings = settings
            project.stage = .frames
            project.statusMessage = "Starting reconstruction engine"
            store.update(project)
            open(project)
            poseNotificationSent = false
            try runner.start(project: project, directory: store.projectDirectory(for: project)) { [weak self] event in
                self?.handle(event)
            }
        } catch {
            analysisError = error.localizedDescription
        }
    }

    /// Start a new Ultra reconstruction from a saved project's local source.
    /// The existing result remains intact, so improving an older scan is one
    /// click and never destroys the only usable copy.
    func rebuildInUltra(_ source: StudioProject) {
        guard !runner.isRunning else { return }
        let sourceDirectory = store.projectDirectory(for: source)
        guard let input = try? FileManager.default.contentsOfDirectory(
            at: sourceDirectory, includingPropertiesForKeys: nil
        ).first(where: { $0.lastPathComponent.hasPrefix("input.") }) else {
            toast = "The saved source video is missing."
            return
        }
        do {
            var project = try store.create(videoURL: input, preset: .max, analysis: source.analysis)
            project.name = "\(source.name) · Ultra"
            project.settings = QualityPreset.max.settings
            project.stage = .frames
            project.statusMessage = "Preparing an Ultra reconstruction"
            store.update(project)
            open(project)
            poseNotificationSent = false
            try runner.start(project: project, directory: store.projectDirectory(for: project)) { [weak self] event in
                self?.handle(event)
            }
        } catch {
            toast = "Couldn’t start Ultra rebuild: \(error.localizedDescription)"
        }
    }

    func retryCurrentStage() {
        guard var project = selectedProject, !runner.isRunning else { return }
        project.lastError = nil
        project.statusMessage = "Retrying from saved stage data"
        store.update(project)
        selectedProject = project
        do {
            try runner.start(project: project, directory: store.projectDirectory(for: project)) { [weak self] event in
                self?.handle(event)
            }
        } catch {
            project.stage = .failed
            project.lastError = error.localizedDescription
            store.update(project)
            selectedProject = project
        }
    }

    func open(_ project: StudioProject) {
        selectedProject = project
        destination = .library
        artifacts = loadArtifacts(for: project)
        latestModelURL = resolveModel(project)
        sparseURL = nil
        camerasJSON = loadCameras(for: project)
    }

    func showNewScene() {
        resetImport()
        selectedProject = nil
        destination = .create
    }

    func cancel() { runner.cancel() }

    func revealCurrentProject() {
        if let selectedProject { store.reveal(selectedProject) }
    }

    func copyDiagnostics() {
        guard let project = selectedProject else { return }
        let dir = store.projectDirectory(for: project)
        let log = (try? String(contentsOf: dir.appendingPathComponent("logs/pipeline.log"), encoding: .utf8)) ?? "No log available."
        let tail = log.split(separator: "\n").suffix(250).joined(separator: "\n")
        let logsDirectory = dir.appendingPathComponent("logs")
        let brushLogs = ((try? FileManager.default.contentsOfDirectory(
            at: logsDirectory, includingPropertiesForKeys: nil
        )) ?? [])
            .filter { $0.lastPathComponent.hasPrefix("brush-training-attempt-") && $0.pathExtension == "log" }
            .sorted { $0.lastPathComponent < $1.lastPathComponent }
            .suffix(4)
        let brushDetails = brushLogs.map { url in
            let text = (try? String(contentsOf: url, encoding: .utf8)) ?? "Unreadable log"
            let lines = text.split(separator: "\n", omittingEmptySubsequences: false)
            let excerpt: String
            if lines.count <= 100 {
                excerpt = lines.joined(separator: "\n")
            } else {
                let selected = lines.prefix(30).map(String.init) + ["…"] + lines.suffix(70).map(String.init)
                excerpt = selected.joined(separator: "\n")
            }
            return "--- \(url.lastPathComponent) ---\n\(excerpt)"
        }.joined(separator: "\n")
        let summary = """
        Splat Studio diagnostics
        Project: \(project.name) (\(project.id))
        Stage: \(project.stage.rawValue)
        Preset: \(project.preset.rawValue)
        Metal: \(systemMonitor.metalName)
        RAM: \(String(format: "%.1f / %.1f GB", systemMonitor.memoryUsedGB, systemMonitor.memoryTotalGB))
        Error: \(project.lastError ?? "none")

        Log tail:
        \(tail)

        Brush attempt logs:
        \(brushDetails.isEmpty ? "No Brush attempt log available." : brushDetails)
        """
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(summary, forType: .string)
        toast = "Diagnostics copied"
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in self?.toast = nil }
    }

    func exportArtifact(_ artifact: ArtifactSummary) {
        let source = URL(fileURLWithPath: artifact.path)
        let panel = NSSavePanel()
        panel.nameFieldStringValue = artifact.name
        panel.title = "Export \(artifact.name)"
        guard panel.runModal() == .OK, let target = panel.url else { return }
        do {
            if FileManager.default.fileExists(atPath: target.path) { try FileManager.default.removeItem(at: target) }
            try FileManager.default.copyItem(at: source, to: target)
        } catch {
            toast = "Export failed: \(error.localizedDescription)"
        }
    }

    private func handle(_ event: PipelineEvent) {
        guard var project = selectedProject else { return }
        project.statusMessage = event.message ?? project.statusMessage
        project.progress = event.progress ?? project.progress
        if let attempt = event.attempt {
            // Attempt one is the normal pipeline, not recovery. Only surface
            // retries that actually changed strategy.
            project.recoveryAttempt = attempt > 1 ? attempt : 0
        }
        if let frames = event.frames { project.totalFrames = frames.count }
        if let registered = event.registered { project.registeredFrames = registered }
        if let total = event.totalFrames { project.totalFrames = total }
        if let checkpoint = event.checkpoint {
            project.trainingStep = checkpoint.step
            project.gaussianCount = checkpoint.gaussians
            if let path = checkpoint.path { latestModelURL = URL(fileURLWithPath: path) }
        }
        if let path = event.sparsePath { sparseURL = URL(fileURLWithPath: path) }
        if let cameras = event.cameras,
           let data = try? JSONEncoder().encode(cameras),
           let json = String(data: data, encoding: .utf8) {
            camerasJSON = json
        }
        switch event.stage {
        case "frames": project.stage = .frames
        case "poses":
            project.stage = .poses
            if event.progress == 1, !poseNotificationSent {
                poseNotificationSent = true
                Notifications.post(title: "Camera path reconstructed", body: "\(project.registeredFrames ?? 0) of \(project.totalFrames ?? 0) frames registered.")
            }
        case "train": project.stage = .train
        case "export": project.stage = .export
        case "done":
            project.stage = .complete
            project.progress = 1
            project.recoveryAttempt = 0
            project.lastError = nil
            if let first = event.artifacts?.first(where: { $0.name == "scene-view.sog" })
                ?? event.artifacts?.first(where: { $0.name == "scene.spz" })
                ?? event.artifacts?.first(where: { $0.name == "scene.ply" }) {
                project.finalModelPath = first.path
                latestModelURL = URL(fileURLWithPath: first.path)
            }
            artifacts = event.artifacts ?? artifacts
            Notifications.post(title: "Your 3D scene is ready", body: "\(project.name) finished reconstructing.")
        case "cancelled":
            project.stage = .cancelled
            project.recoveryAttempt = 0
        case "error":
            project.stage = .failed
            project.recoveryAttempt = 0
            project.lastError = event.error ?? event.message
        default: break
        }
        store.update(project)
        selectedProject = project
    }

    private func resolveModel(_ project: StudioProject) -> URL? {
        if let path = project.finalModelPath, FileManager.default.fileExists(atPath: path) {
            return URL(fileURLWithPath: path)
        }
        let dir = store.projectDirectory(for: project)
        let options = ["exports/scene-view.sog", "exports/scene.spz", "exports/scene.ply"]
        for option in options {
            let url = dir.appendingPathComponent(option)
            if FileManager.default.fileExists(atPath: url.path) { return url }
        }
        let checkpoints = ((try? FileManager.default.contentsOfDirectory(
            at: dir.appendingPathComponent("checkpoints"), includingPropertiesForKeys: nil
        )) ?? []).filter { $0.pathExtension == "ply" }.sorted { $0.lastPathComponent < $1.lastPathComponent }
        return checkpoints.last
    }

    private func loadArtifacts(for project: StudioProject) -> [ArtifactSummary] {
        let dir = store.projectDirectory(for: project).appendingPathComponent("exports")
        let items = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.fileSizeKey])) ?? []
        return items.filter { ["ply", "spz", "sog"].contains($0.pathExtension.lowercased()) }.map { url in
            let size = (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? 0
            return ArtifactSummary(name: url.lastPathComponent, path: url.path, bytes: size, gaussians: nil, fillRatio: nil)
        }
    }

    private func loadCameras(for project: StudioProject) -> String? {
        let url = store.projectDirectory(for: project).appendingPathComponent("cameras.json")
        return try? String(contentsOf: url, encoding: .utf8)
    }
}

@main
struct SplatStudioApp: App {
    @StateObject private var model: StudioModel

    init() {
        let runInPlace = CommandLine.arguments.contains("--run-in-place")
        if !runInPlace && (CommandLine.arguments.contains("--install-to-applications") || SelfInstaller.shouldInstall) {
            SelfInstaller.installAndRelaunch()
        }
        _model = StateObject(wrappedValue: StudioModel())
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(model)
                .frame(minWidth: 1120, minHeight: 720)
                .onOpenURL { model.importVideo($0) }
        }
        .defaultSize(width: 1380, height: 900)
        .windowToolbarStyle(.unifiedCompact)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("New Scene") { model.showNewScene() }
                    .keyboardShortcut("n", modifiers: .command)
                Button("Open Video…") { model.chooseVideo() }
                    .keyboardShortcut("o", modifiers: .command)
            }
        }
    }
}

private enum SelfInstaller {
    /// Packaging-only entry point used by build verification. The helper runs
    /// as the non-sandboxed, signed app itself, so it can place the final bundle
    /// in the user's Applications folder without a Terminal-facing installer.
    static var shouldInstall: Bool {
        let source = Bundle.main.bundleURL.standardizedFileURL
        guard source.pathExtension.lowercased() == "app" else { return false }
        let target = FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Applications/Splat Studio.app").standardizedFileURL
        return source != target
    }

    static func installAndRelaunch() -> Never {
        let files = FileManager.default
        let source = Bundle.main.bundleURL.standardizedFileURL
        let applications = files.homeDirectoryForCurrentUser.appendingPathComponent("Applications", isDirectory: true)
        let target = applications.appendingPathComponent("Splat Studio.app", isDirectory: true)
        let staging = applications.appendingPathComponent(".Splat Studio.installing.app", isDirectory: true)
        let backups = StudioPaths.root.appendingPathComponent("App Backups", isDirectory: true)
        do {
            try files.createDirectory(at: applications, withIntermediateDirectories: true)
            try files.createDirectory(at: backups, withIntermediateDirectories: true)
            if files.fileExists(atPath: staging.path) { try files.removeItem(at: staging) }
            try files.copyItem(at: source, to: staging)
            if files.fileExists(atPath: target.path) {
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyyMMdd-HHmmss"
                let backup = backups.appendingPathComponent("Splat Studio-\(formatter.string(from: Date())).app")
                try files.moveItem(at: target, to: backup)
            }
            try files.moveItem(at: staging, to: target)
            // Leave one physical app. The build/output location becomes a
            // lightweight pointer to the installed copy when it is writable.
            if source != target, (try? files.removeItem(at: source)) != nil {
                try? files.createSymbolicLink(at: source, withDestinationURL: target)
            }
            let configuration = NSWorkspace.OpenConfiguration()
            NSWorkspace.shared.openApplication(at: target, configuration: configuration) { _, error in
                if let error {
                    try? error.localizedDescription.write(
                        to: URL(fileURLWithPath: "/private/tmp/SplatStudio-install-error.txt"),
                        atomically: true, encoding: .utf8
                    )
                    exit(EXIT_FAILURE)
                }
                exit(EXIT_SUCCESS)
            }
            RunLoop.current.run()
            exit(EXIT_SUCCESS)
        } catch {
            try? error.localizedDescription.write(
                to: URL(fileURLWithPath: "/private/tmp/SplatStudio-install-error.txt"),
                atomically: true, encoding: .utf8
            )
            exit(EXIT_FAILURE)
        }
    }
}
