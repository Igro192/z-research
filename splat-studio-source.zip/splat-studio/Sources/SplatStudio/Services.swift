import AppKit
import AVFoundation
import Combine
import CoreGraphics
import Foundation
import Metal
import UserNotifications

enum StudioPaths {
    static let root: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("Splat Studio", isDirectory: true)
    }()
    static let projects = root.appendingPathComponent("Projects", isDirectory: true)
    static let runtime = root.appendingPathComponent("Runtime", isDirectory: true)

    static func project(_ id: UUID) -> URL { projects.appendingPathComponent(id.uuidString, isDirectory: true) }
}

@MainActor
final class ProjectStore: ObservableObject {
    @Published private(set) var projects: [StudioProject] = []

    init() {
        try? FileManager.default.createDirectory(at: StudioPaths.projects, withIntermediateDirectories: true)
        reload()
    }

    func reload() {
        let urls = (try? FileManager.default.contentsOfDirectory(
            at: StudioPaths.projects, includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        )) ?? []
        let decoder = JSONDecoder.studio
        projects = urls.compactMap { url in
            guard let data = try? Data(contentsOf: url.appendingPathComponent("project.json")) else { return nil }
            return try? decoder.decode(StudioProject.self, from: data)
        }.sorted { $0.modifiedAt > $1.modifiedAt }
    }

    func create(videoURL: URL, preset: QualityPreset, analysis: CaptureMetrics?) throws -> StudioProject {
        var project = StudioProject.new(videoURL: videoURL, preset: preset, analysis: analysis)
        let dir = StudioPaths.project(project.id)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        try FileManager.default.createDirectory(at: dir.appendingPathComponent("logs"), withIntermediateDirectories: true)
        let ext = videoURL.pathExtension.isEmpty ? "mov" : videoURL.pathExtension.lowercased()
        let stored = dir.appendingPathComponent("input.\(ext)")
        if FileManager.default.fileExists(atPath: stored.path) {
            try FileManager.default.removeItem(at: stored)
        }
        try FileManager.default.copyItem(at: videoURL, to: stored)
        project.originalVideoPath = videoURL.path
        try save(project)
        projects.insert(project, at: 0)
        return project
    }

    func update(_ project: StudioProject) {
        var value = project
        value.modifiedAt = Date()
        if let index = projects.firstIndex(where: { $0.id == value.id }) {
            projects[index] = value
        } else {
            projects.insert(value, at: 0)
        }
        projects.sort { $0.modifiedAt > $1.modifiedAt }
        try? save(value)
    }

    func save(_ project: StudioProject) throws {
        let dir = StudioPaths.project(project.id)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let data = try JSONEncoder.studio.encode(project)
        try data.write(to: dir.appendingPathComponent("project.json"), options: .atomic)
    }

    func projectDirectory(for project: StudioProject) -> URL { StudioPaths.project(project.id) }

    func reveal(_ project: StudioProject) {
        NSWorkspace.shared.activateFileViewerSelecting([StudioPaths.project(project.id)])
    }
}

extension JSONEncoder {
    static var studio: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }
}

extension JSONDecoder {
    static var studio: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}

enum CaptureAnalyzer {
    static func analyze(url: URL, preset: QualityPreset) async throws -> CaptureMetrics {
        try await Task.detached(priority: .userInitiated) {
            try analyzeSynchronously(url: url, preset: preset)
        }.value
    }

    static func analyzeSynchronously(url: URL, preset: QualityPreset) throws -> CaptureMetrics {
        let asset = AVURLAsset(url: url)
        let duration = CMTimeGetSeconds(asset.duration)
        guard duration.isFinite, duration > 0 else { throw AnalysisError.unreadableVideo }
        guard let track = asset.tracks(withMediaType: .video).first else { throw AnalysisError.noVideoTrack }

        let transformed = track.naturalSize.applying(track.preferredTransform)
        let width = Int(abs(transformed.width))
        let height = Int(abs(transformed.height))
        let fps = Double(track.nominalFrameRate)
        let sampleCount = max(12, min(48, Int(duration * 2.2)))
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 192, height: 192)
        generator.requestedTimeToleranceBefore = CMTime(seconds: 0.035, preferredTimescale: 600)
        generator.requestedTimeToleranceAfter = CMTime(seconds: 0.035, preferredTimescale: 600)

        var samples: [FrameMetrics] = []
        var priorPixels: [UInt8]?
        for index in 0..<sampleCount {
            let seconds = duration * (Double(index) + 0.5) / Double(sampleCount)
            let image = try generator.copyCGImage(at: CMTime(seconds: seconds, preferredTimescale: 600), actualTime: nil)
            let pixels = grayscalePixels(image, width: 160, height: 90)
            let frame = measure(pixels: pixels, prior: priorPixels, time: seconds)
            samples.append(frame)
            priorPixels = pixels
        }

        let sharpness = samples.map(\.sharpness)
        let medianSharpness = percentile(sharpness, 0.5)
        let blurry = samples.map { $0.sharpness < max(20, medianSharpness * 0.42) }
        let blurFraction = fraction(blurry)
        let motionValues = samples.dropFirst().map(\.motion)
        let movement = average(motionValues)
        let overlap = max(0, min(1, 1.0 - average(motionValues.map { min(1, $0 * 2.4) })))
        let lowTexture = samples.map { $0.texture < 0.075 }
        let textureFraction = fraction(lowTexture)
        let brightness = samples.map(\.brightness)
        let exposureDelta = zip(brightness, brightness.dropFirst()).map { abs($1 - $0) }
        let exposureInstability = min(1, average(exposureDelta) * 5.5)
        // Report what the capture can contribute, independently of the selected
        // reconstruction mode. The old preset cap made a five-minute 60 fps
        // clip misleadingly say "200 candidates" even when it contained well
        // over a thousand useful, spaced-apart views.
        let usefulRate: Double = duration < 30 ? 15 : duration < 120 ? 10 : 5.2
        let candidateFrames = min(3_000, max(1, Int(duration * min(max(fps, 1), usefulRate))))

        var issues: [CaptureIssue] = []
        issues += groupedIssues(flags: blurry, samples: samples, message: "Too much motion blur", severity: 2)
        issues += groupedIssues(flags: lowTexture, samples: samples, message: "Large area has too little visual texture", severity: 2)
        let tooFast = samples.map { $0.motion > 0.19 }
        issues += groupedIssues(flags: tooFast, samples: samples, message: "Camera movement is too fast", severity: 3)
        if overlap < 0.48 {
            issues.append(CaptureIssue(message: "Not enough overlapping views between frames.", severity: 3))
        }
        if movement < 0.018 {
            issues.append(CaptureIssue(message: "The camera barely moves, so depth may be ambiguous.", severity: 3))
        }
        if exposureInstability > 0.32 {
            issues.append(CaptureIssue(message: "Exposure changes noticeably during the recording.", severity: 1))
        }
        if duration < 4 {
            issues.append(CaptureIssue(message: "The walkthrough is very short; record more viewpoints.", severity: 3))
        }

        var score = 100.0
        score -= blurFraction * 34
        score -= textureFraction * 28
        score -= max(0, 0.62 - overlap) * 55
        score -= exposureInstability * 18
        if movement < 0.018 { score -= 28 }
        if movement > 0.16 { score -= min(30, (movement - 0.16) * 180) }
        if width < 1280 { score -= 8 }
        if candidateFrames < 45 { score -= 16 }
        let rounded = Int(max(0, min(100, score)).rounded())
        let rating: CaptureRating = switch rounded {
        case 86...100: .excellent
        case 70...85: .good
        case 45...69: .risky
        default: .likelyToFail
        }

        return CaptureMetrics(
            duration: duration, width: width, height: height, fps: fps,
            candidateFrames: candidateFrames, blurScore: blurFraction,
            cameraMovement: min(1, movement * 5), overlap: overlap,
            lowTextureFraction: textureFraction, exposureInstability: exposureInstability,
            qualityScore: rounded, rating: rating, issues: issues
        )
    }

    private struct FrameMetrics {
        var time: Double
        var brightness: Double
        var sharpness: Double
        var texture: Double
        var motion: Double
    }

    private static func grayscalePixels(_ image: CGImage, width: Int, height: Int) -> [UInt8] {
        var pixels = [UInt8](repeating: 0, count: width * height)
        pixels.withUnsafeMutableBytes { buffer in
            let context = CGContext(
                data: buffer.baseAddress, width: width, height: height,
                bitsPerComponent: 8, bytesPerRow: width,
                space: CGColorSpaceCreateDeviceGray(), bitmapInfo: CGImageAlphaInfo.none.rawValue
            )
            context?.interpolationQuality = .medium
            context?.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
        }
        return pixels
    }

    private static func measure(pixels: [UInt8], prior: [UInt8]?, time: Double) -> FrameMetrics {
        let width = 160, height = 90
        let brightness = average(pixels.map { Double($0) / 255 })
        var laplacians: [Double] = []
        var textured = 0
        for y in 1..<(height - 1) {
            for x in 1..<(width - 1) {
                let i = y * width + x
                let c = Int(pixels[i])
                let lap = 4 * c - Int(pixels[i - 1]) - Int(pixels[i + 1]) - Int(pixels[i - width]) - Int(pixels[i + width])
                laplacians.append(Double(lap))
                let gx = abs(Int(pixels[i + 1]) - Int(pixels[i - 1]))
                let gy = abs(Int(pixels[i + width]) - Int(pixels[i - width]))
                if gx + gy > 30 { textured += 1 }
            }
        }
        let lapMean = average(laplacians)
        let sharpness = average(laplacians.map { ($0 - lapMean) * ($0 - lapMean) })
        let texture = Double(textured) / Double((width - 2) * (height - 2))
        var motion = 0.0
        if let prior, prior.count == pixels.count {
            motion = average(zip(pixels, prior).map { Double(abs(Int($0) - Int($1))) / 255 })
        }
        return FrameMetrics(time: time, brightness: brightness, sharpness: sharpness, texture: texture, motion: motion)
    }

    private static func groupedIssues(flags: [Bool], samples: [FrameMetrics], message: String, severity: Int) -> [CaptureIssue] {
        guard flags.count == samples.count else { return [] }
        var result: [CaptureIssue] = []
        var start: Int?
        for index in 0...flags.count {
            let flagged = index < flags.count ? flags[index] : false
            if flagged, start == nil { start = index }
            if !flagged, let first = start {
                let last = max(first, index - 1)
                if last - first + 1 >= 2 {
                    result.append(CaptureIssue(
                        message: "\(message) between \(timecode(samples[first].time))–\(timecode(samples[last].time)).",
                        severity: severity, startTime: samples[first].time, endTime: samples[last].time
                    ))
                }
                start = nil
            }
        }
        return result
    }

    static func timecode(_ seconds: Double) -> String {
        String(format: "%02d:%02d", Int(seconds) / 60, Int(seconds) % 60)
    }

    private static func average<S: Sequence>(_ values: S) -> Double where S.Element == Double {
        var total = 0.0, count = 0.0
        for value in values { total += value; count += 1 }
        return count > 0 ? total / count : 0
    }

    private static func fraction(_ values: [Bool]) -> Double {
        guard !values.isEmpty else { return 0 }
        return Double(values.filter { $0 }.count) / Double(values.count)
    }

    private static func percentile(_ values: [Double], _ p: Double) -> Double {
        guard !values.isEmpty else { return 0 }
        let sorted = values.sorted()
        return sorted[min(sorted.count - 1, Int(Double(sorted.count) * p))]
    }

    enum AnalysisError: LocalizedError {
        case unreadableVideo, noVideoTrack
        var errorDescription: String? {
            switch self {
            case .unreadableVideo: "The video duration could not be read."
            case .noVideoTrack: "This file does not contain a readable video track."
            }
        }
    }
}

final class DependencyManager: ObservableObject {
    @Published var status = DependencyStatus()
    @Published var isChecking = false
    @Published var isInstallingDA3 = false
    @Published var detail = "Checking local reconstruction engine…"
    @Published var da3InstallError: String?

    static let da3Root = StudioPaths.runtime.appendingPathComponent("DepthAnything3", isDirectory: true)
    static let da3Executable = da3Root.appendingPathComponent("bin/da3")
    static let da3Python = da3Root.appendingPathComponent("bin/python")
    static let da3ReadyMarker = da3Root.appendingPathComponent("model-ready")
    static let modelCache = StudioPaths.runtime.appendingPathComponent("ModelCache", isDirectory: true)

    static func depthExecutable() -> String? {
        let bundled = backendURL.appendingPathComponent(".venv/bin/da3")
        if FileManager.default.isExecutableFile(atPath: da3Executable.path) { return da3Executable.path }
        if FileManager.default.isExecutableFile(atPath: bundled.path) { return bundled.path }
        return nil
    }

    static var resourceRoot: URL {
        let candidates = [
            Bundle.main.resourceURL?.appendingPathComponent("SplatStudio_SplatStudio.bundle/Resources"),
            Bundle.main.bundleURL.appendingPathComponent("SplatStudio_SplatStudio.bundle/Resources"),
            Bundle.main.resourceURL
        ].compactMap { $0 }
        return candidates.first(where: { FileManager.default.fileExists(atPath: $0.appendingPathComponent("Backend").path) })
            ?? Bundle.main.bundleURL
    }

    static var backendURL: URL {
        let root = resourceRoot
        let candidates = [root.appendingPathComponent("Backend"), root.appendingPathComponent("Resources/Backend")]
        return candidates.first(where: { FileManager.default.fileExists(atPath: $0.path) }) ?? candidates[0]
    }

    static var viewerURL: URL {
        let root = resourceRoot
        let candidates = [root.appendingPathComponent("Viewer"), root.appendingPathComponent("Resources/Viewer")]
        return candidates.first(where: { FileManager.default.fileExists(atPath: $0.path) }) ?? candidates[0]
    }

    static func executable(_ name: String) -> String? {
        let backend = backendURL
        let candidates: [URL]
        switch name {
        case "python":
            candidates = [backend.appendingPathComponent(".venv/bin/python"),
                          StudioPaths.runtime.appendingPathComponent(".venv/bin/python"),
                          URL(fileURLWithPath: "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3"),
                          URL(fileURLWithPath: "/opt/homebrew/bin/python3")]
        case "brush":
            candidates = [backend.appendingPathComponent("vendor/brush"),
                          StudioPaths.runtime.appendingPathComponent("vendor/brush")]
        default:
            candidates = [backend.appendingPathComponent("tools/\(name)"),
                          URL(fileURLWithPath: "/opt/homebrew/bin/\(name)"),
                          URL(fileURLWithPath: "/usr/local/bin/\(name)"),
                          URL(fileURLWithPath: "/usr/bin/\(name)")]
        }
        return candidates.first(where: { FileManager.default.isExecutableFile(atPath: $0.path) })?.path
    }

    @MainActor
    func check() async {
        isChecking = true
        detail = "Validating bundled tools…"
        var next = DependencyStatus()
        next.python = Self.executable("python") != nil
        next.ffmpeg = Self.executable("ffmpeg") != nil
        next.ffprobe = Self.executable("ffprobe") != nil
        next.brush = Self.executable("brush") != nil
        next.node = Self.executable("node") != nil
        if let device = MTLCreateSystemDefaultDevice() {
            next.metalDevice = device.name
        } else {
            next.metalDevice = "Metal unavailable"
        }
        if let python = Self.executable("python") {
            next.pycolmap = (try? await Self.runCheck(python, ["-c", "import pycolmap, numpy, PIL; print(pycolmap.__version__)"])) == true
            let bundled = Self.backendURL.appendingPathComponent(".venv/bin/da3")
            let bundledReady = FileManager.default.isExecutableFile(atPath: bundled.path)
            let runtimeReady = FileManager.default.isExecutableFile(atPath: Self.da3Executable.path)
                && FileManager.default.fileExists(atPath: Self.da3ReadyMarker.path)
            next.da3 = bundledReady || runtimeReady
        }
        status = next
        if next.coreReady {
            detail = next.da3 ? "Reconstruction engine and depth fallback ready" : "Core engine ready · preparing depth fallback"
        } else {
            detail = "Some required components are unavailable"
        }
        isChecking = false
    }

    /// Install the optional Splat Local DA3 backend without Terminal work.
    /// The large environment and model cache live in Application Support so a
    /// signed app bundle remains immutable and app upgrades do not redownload it.
    @MainActor
    func installDepthFallback() async {
        guard !isInstallingDA3, !status.da3 else { return }
        guard let uv = Self.executable("uv"), let bundledPython = Self.executable("python") else {
            da3InstallError = "The bundled Depth setup tool is unavailable."
            detail = da3InstallError!
            return
        }
        isInstallingDA3 = true
        da3InstallError = nil
        do {
            try FileManager.default.createDirectory(at: StudioPaths.runtime, withIntermediateDirectories: true)
            try FileManager.default.createDirectory(at: Self.modelCache, withIntermediateDirectories: true)
            let environment = Self.setupEnvironment()

            if !FileManager.default.isExecutableFile(atPath: Self.da3Python.path) {
                detail = "Preparing Depth Anything 3 runtime…"
                try await Self.runSetup(uv, ["venv", "--python", bundledPython, Self.da3Root.path], environment)
            }

            detail = "Installing Depth Anything 3 and MPS support…"
            try await Self.runSetup(
                uv,
                ["pip", "install", "--python", Self.da3Python.path, "awesome-depth-anything-3"],
                environment
            )

            detail = "Downloading the DA3-LARGE fallback model…"
            let prefetch = "from depth_anything_3.api import DepthAnything3; DepthAnything3.from_pretrained('depth-anything/DA3-LARGE'); print('ready')"
            try await Self.runSetup(Self.da3Python.path, ["-c", prefetch], environment)
            try Data("ready\n".utf8).write(to: Self.da3ReadyMarker, options: .atomic)
            isInstallingDA3 = false
            await check()
            Notifications.post(title: "Depth fallback ready", body: "Splat Studio can now recover difficult camera paths with Depth Anything 3 on MPS.")
        } catch {
            isInstallingDA3 = false
            let failure = error.localizedDescription
            await check()
            da3InstallError = failure
            detail = "Depth fallback setup paused: \(failure)"
        }
    }

    private static func runCheck(_ launchPath: String, _ arguments: [String]) async throws -> Bool {
        try await Task.detached {
            let process = Process()
            process.executableURL = URL(fileURLWithPath: launchPath)
            process.arguments = arguments
            process.standardOutput = FileHandle.nullDevice
            process.standardError = FileHandle.nullDevice
            try process.run()
            process.waitUntilExit()
            return process.terminationStatus == 0
        }.value
    }

    private static func setupEnvironment() -> [String: String] {
        var environment = ProcessInfo.processInfo.environment
        let cache = StudioPaths.runtime.appendingPathComponent("InstallerCache", isDirectory: true)
        environment["UV_CACHE_DIR"] = cache.path
        environment["HF_HOME"] = modelCache.path
        environment["PATH"] = [
            backendURL.appendingPathComponent("tools").path,
            da3Root.appendingPathComponent("bin").path,
            "/usr/bin", "/bin"
        ].joined(separator: ":")
        return environment
    }

    private static func runSetup(
        _ launchPath: String, _ arguments: [String], _ environment: [String: String]
    ) async throws {
        try await Task.detached {
            let process = Process()
            let pipe = Pipe()
            process.executableURL = URL(fileURLWithPath: launchPath)
            process.arguments = arguments
            process.environment = environment
            process.standardOutput = pipe
            process.standardError = pipe
            try process.run()
            let data = pipe.fileHandleForReading.readDataToEndOfFile()
            process.waitUntilExit()
            guard process.terminationStatus == 0 else {
                let text = String(decoding: data, as: UTF8.self)
                let useful = text.split(separator: "\n").suffix(12).joined(separator: " ")
                throw SetupError.failed(useful.isEmpty ? "installer exited with code \(process.terminationStatus)" : useful)
            }
        }.value
    }

    enum SetupError: LocalizedError {
        case failed(String)
        var errorDescription: String? {
            switch self { case .failed(let message): "Depth fallback setup failed: \(message)" }
        }
    }
}

@MainActor
final class BackendRunner: ObservableObject {
    @Published var isRunning = false
    @Published var latestEvent: PipelineEvent?
    @Published var elapsed: TimeInterval = 0
    @Published var estimatedRemaining: TimeInterval?

    private var process: Process?
    private var activity: NSObjectProtocol?
    private var startedAt: Date?
    private var timer: Timer?
    private var outputBuffer = Data()
    private var logHandle: FileHandle?

    func start(project: StudioProject, directory: URL, onEvent: @escaping @MainActor (PipelineEvent) -> Void) throws {
        guard !isRunning else { return }
        guard let python = DependencyManager.executable("python"),
              let ffmpeg = DependencyManager.executable("ffmpeg"),
              let brush = DependencyManager.executable("brush") else {
            throw RunnerError.missingDependencies
        }
        let backend = DependencyManager.backendURL
        let input = try findInput(in: directory)
        let configURL = directory.appendingPathComponent("training-config.json")
        try JSONEncoder.studio.encode(project.settings).write(to: configURL, options: .atomic)

        let logURL = directory.appendingPathComponent("logs/pipeline.log")
        FileManager.default.createFile(atPath: logURL.path, contents: nil)
        logHandle = try FileHandle(forWritingTo: logURL)

        let pipe = Pipe()
        let runner = Process()
        runner.executableURL = URL(fileURLWithPath: python)
        runner.arguments = [
            backend.appendingPathComponent("pipeline_cli.py").path,
            "--video", input.path,
            "--project", directory.path,
            "--config", configURL.path
        ]
        runner.currentDirectoryURL = backend
        var environment = ProcessInfo.processInfo.environment
        let tools = [URL(fileURLWithPath: ffmpeg).deletingLastPathComponent().path,
                     URL(fileURLWithPath: python).deletingLastPathComponent().path,
                     "/opt/homebrew/bin", "/usr/local/bin", "/usr/bin", "/bin"]
        environment["PATH"] = tools.joined(separator: ":")
        environment["BRUSH_BIN"] = brush
        environment["PYTHONUNBUFFERED"] = "1"
        if let da3 = DependencyManager.depthExecutable() { environment["DA3_BIN"] = da3 }
        environment["DA3_MODEL"] = "depth-anything/DA3-LARGE"
        environment["HF_HOME"] = DependencyManager.modelCache.path
        runner.environment = environment
        runner.standardOutput = pipe
        runner.standardError = pipe
        pipe.fileHandleForReading.readabilityHandler = { [weak self] handle in
            let data = handle.availableData
            guard !data.isEmpty else { return }
            Task { @MainActor [weak self] in
                self?.consume(data, onEvent: onEvent)
            }
        }
        runner.terminationHandler = { [weak self] completed in
            Task { @MainActor [weak self] in
                self?.finish(exitCode: completed.terminationStatus, onEvent: onEvent)
            }
        }

        activity = ProcessInfo.processInfo.beginActivity(
            options: [.userInitiated, .idleSystemSleepDisabled],
            reason: "Reconstructing a Splat Studio scene"
        )
        process = runner
        isRunning = true
        latestEvent = nil
        startedAt = Date()
        elapsed = 0
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in self?.updateTime() }
        }
        try runner.run()
    }

    func cancel() {
        guard let process, process.isRunning else { return }
        process.interrupt()
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak process] in
            if process?.isRunning == true { process?.terminate() }
        }
    }

    private func consume(_ data: Data, onEvent: @escaping @MainActor (PipelineEvent) -> Void) {
        try? logHandle?.write(contentsOf: data)
        outputBuffer.append(data)
        while let newline = outputBuffer.firstIndex(of: 0x0A) {
            let line = outputBuffer[..<newline]
            outputBuffer.removeSubrange(...newline)
            guard !line.isEmpty,
                  let event = try? JSONDecoder().decode(PipelineEvent.self, from: Data(line)) else { continue }
            latestEvent = event
            if let progress = event.progress, progress > 0, elapsed > 3 {
                estimatedRemaining = max(0, elapsed * (1 - progress) / progress)
            }
            onEvent(event)
        }
    }

    private func finish(exitCode: Int32, onEvent: @escaping @MainActor (PipelineEvent) -> Void) {
        guard isRunning else { return }
        isRunning = false
        timer?.invalidate()
        timer = nil
        try? logHandle?.close()
        logHandle = nil
        if let activity { ProcessInfo.processInfo.endActivity(activity) }
        activity = nil
        process = nil
        if exitCode != 0, latestEvent?.stage != "error", latestEvent?.stage != "cancelled" {
            let event = PipelineEvent(stage: "error", progress: nil,
                                      message: "Reconstruction engine exited unexpectedly (code \(exitCode)).",
                                      frames: nil, sparsePath: nil, cameras: nil, checkpoint: nil,
                                      artifacts: nil, error: "Backend process exited with code \(exitCode).",
                                      registered: nil, totalFrames: nil, attempt: nil)
            latestEvent = event
            onEvent(event)
        }
    }

    private func updateTime() {
        guard let startedAt else { return }
        elapsed = Date().timeIntervalSince(startedAt)
    }

    private func findInput(in directory: URL) throws -> URL {
        let items = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)
        if let input = items.first(where: { $0.lastPathComponent.hasPrefix("input.") }) { return input }
        throw RunnerError.missingInput
    }

    enum RunnerError: LocalizedError {
        case missingDependencies, missingInput
        var errorDescription: String? {
            switch self {
            case .missingDependencies: "The reconstruction engine is incomplete. Open Settings and run the dependency check."
            case .missingInput: "The project’s source video is missing."
            }
        }
    }
}

@MainActor
final class SystemMonitor: ObservableObject {
    @Published var memoryUsedGB = 0.0
    @Published var memoryTotalGB = Double(ProcessInfo.processInfo.physicalMemory) / 1_073_741_824
    @Published var metalName = MTLCreateSystemDefaultDevice()?.name ?? "Unavailable"
    @Published var processor = ProcessInfo.processInfo.processorCount
    private var timer: Timer?

    func start() {
        update()
        timer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in self?.update() }
        }
    }

    func stop() { timer?.invalidate(); timer = nil }

    private func update() {
        let task = Process()
        let pipe = Pipe()
        task.executableURL = URL(fileURLWithPath: "/usr/bin/vm_stat")
        task.standardOutput = pipe
        task.standardError = FileHandle.nullDevice
        do {
            try task.run(); task.waitUntilExit()
            let data = pipe.fileHandleForReading.readDataToEndOfFile()
            guard let text = String(data: data, encoding: .utf8) else { return }
            let pageSize = Double(text.firstMatch(#"page size of (\d+) bytes"#) ?? "16384") ?? 16384
            let freePages = Double(text.firstMatch(#"Pages free:\s+(\d+)"#) ?? "0") ?? 0
            let speculative = Double(text.firstMatch(#"Pages speculative:\s+(\d+)"#) ?? "0") ?? 0
            let free = (freePages + speculative) * pageSize / 1_073_741_824
            memoryUsedGB = max(0, memoryTotalGB - free)
        } catch { }
    }
}

extension String {
    fileprivate func firstMatch(_ pattern: String) -> String? {
        guard let regex = try? NSRegularExpression(pattern: pattern),
              let match = regex.firstMatch(in: self, range: NSRange(startIndex..., in: self)),
              match.numberOfRanges > 1,
              let range = Range(match.range(at: 1), in: self) else { return nil }
        return String(self[range])
    }
}

enum Notifications {
    static func requestPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }

    static func post(title: String, body: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        UNUserNotificationCenter.current().add(UNNotificationRequest(
            identifier: UUID().uuidString, content: content, trigger: nil
        ))
    }
}
