import AppKit
import Foundation
import Network
import SwiftUI
import WebKit

final class LocalViewerServer {
    static let shared = LocalViewerServer()

    private let queue = DispatchQueue(label: "studio.splat.viewer-server", qos: .userInitiated)
    private let lock = NSLock()
    private var listener: NWListener?
    private var baseURL: URL?
    private var callbacks: [(URL) -> Void] = []
    private var models: [String: URL] = [:]

    func start(_ completion: @escaping (URL) -> Void) {
        lock.lock()
        if let baseURL { lock.unlock(); completion(baseURL); return }
        callbacks.append(completion)
        if listener != nil { lock.unlock(); return }
        do {
            let listener = try NWListener(using: .tcp, on: .any)
            self.listener = listener
            lock.unlock()
            listener.newConnectionHandler = { [weak self] connection in self?.accept(connection) }
            listener.stateUpdateHandler = { [weak self] state in
                guard case .ready = state, let port = listener.port else { return }
                let url = URL(string: "http://127.0.0.1:\(port.rawValue)")!
                self?.lock.lock()
                self?.baseURL = url
                let blocks = self?.callbacks ?? []
                self?.callbacks.removeAll()
                self?.lock.unlock()
                DispatchQueue.main.async { blocks.forEach { $0(url) } }
            }
            listener.start(queue: queue)
        } catch {
            lock.unlock()
        }
    }

    func url(for file: URL) -> URL? {
        let token = UUID().uuidString
        lock.lock(); models[token] = file; let base = baseURL; lock.unlock()
        return base?.appendingPathComponent("models/\(token)/\(file.lastPathComponent)")
    }

    private func accept(_ connection: NWConnection) {
        connection.start(queue: queue)
        connection.receive(minimumIncompleteLength: 1, maximumLength: 65_536) { [weak self] data, _, _, _ in
            guard let self, let data, let request = String(data: data, encoding: .utf8) else {
                connection.cancel(); return
            }
            self.respond(connection, request: request)
        }
    }

    private func respond(_ connection: NWConnection, request: String) {
        guard let firstLine = request.split(separator: "\r\n").first,
              firstLine.hasPrefix("GET ") else { sendError(connection, 405, "Method Not Allowed"); return }
        let rawPath = firstLine.split(separator: " ").dropFirst().first.map(String.init) ?? "/"
        let path = rawPath.components(separatedBy: "?").first ?? rawPath
        let decoded = path.removingPercentEncoding ?? path
        let file: URL?
        if decoded.hasPrefix("/models/") {
            let parts = decoded.split(separator: "/")
            let token = parts.count > 1 ? String(parts[1]) : ""
            lock.lock(); file = models[token]; lock.unlock()
        } else {
            let root = DependencyManager.viewerURL.standardizedFileURL
            let relative = decoded == "/" ? "viewer-host.html" : String(decoded.dropFirst())
            let target = root.appendingPathComponent(relative).standardizedFileURL
            file = target.path.hasPrefix(root.path) ? target : nil
        }
        guard let file, FileManager.default.fileExists(atPath: file.path) else {
            sendError(connection, 404, "Not Found"); return
        }
        sendFile(connection, url: file, request: request)
    }

    private func sendFile(_ connection: NWConnection, url: URL, request: String) {
        guard let attrs = try? FileManager.default.attributesOfItem(atPath: url.path),
              let fileSize = (attrs[.size] as? NSNumber)?.uint64Value,
              let handle = try? FileHandle(forReadingFrom: url) else {
            sendError(connection, 500, "Read Error"); return
        }
        var start: UInt64 = 0
        var end = fileSize > 0 ? fileSize - 1 : 0
        var partial = false
        if let rangeLine = request.split(separator: "\r\n").first(where: { $0.lowercased().hasPrefix("range:") }),
           let spec = rangeLine.split(separator: "=").last {
            let pair = spec.split(separator: "-", omittingEmptySubsequences: false)
            if let value = pair.first, let parsed = UInt64(value) { start = min(parsed, end); partial = true }
            if pair.count > 1, let parsed = UInt64(pair[1]) { end = min(parsed, end); partial = true }
        }
        let count = fileSize == 0 ? 0 : end - start + 1
        let status = partial ? "206 Partial Content" : "200 OK"
        var headers = "HTTP/1.1 \(status)\r\nContent-Type: \(mime(url.pathExtension))\r\nContent-Length: \(count)\r\nAccept-Ranges: bytes\r\nCache-Control: no-store\r\nAccess-Control-Allow-Origin: *\r\n"
        if partial { headers += "Content-Range: bytes \(start)-\(end)/\(fileSize)\r\n" }
        headers += "Connection: close\r\n\r\n"
        try? handle.seek(toOffset: start)
        connection.send(content: headers.data(using: .utf8), completion: .contentProcessed { error in
            guard error == nil else { try? handle.close(); connection.cancel(); return }
            self.sendChunk(connection, handle: handle, remaining: count)
        })
    }

    private func sendChunk(_ connection: NWConnection, handle: FileHandle, remaining: UInt64) {
        guard remaining > 0 else { try? handle.close(); connection.cancel(); return }
        let size = Int(min(remaining, 1_048_576))
        guard let data = try? handle.read(upToCount: size), !data.isEmpty else {
            try? handle.close(); connection.cancel(); return
        }
        connection.send(content: data, completion: .contentProcessed { error in
            if error != nil { try? handle.close(); connection.cancel(); return }
            self.sendChunk(connection, handle: handle, remaining: remaining - UInt64(data.count))
        })
    }

    private func sendError(_ connection: NWConnection, _ code: Int, _ text: String) {
        let body = Data(text.utf8)
        let response = "HTTP/1.1 \(code) \(text)\r\nContent-Type: text/plain\r\nContent-Length: \(body.count)\r\nConnection: close\r\n\r\n"
        connection.send(content: response.data(using: .utf8)! + body, completion: .contentProcessed { _ in connection.cancel() })
    }

    private func mime(_ ext: String) -> String {
        switch ext.lowercased() {
        case "html": "text/html; charset=utf-8"
        case "js": "text/javascript; charset=utf-8"
        case "css": "text/css; charset=utf-8"
        case "json": "application/json"
        case "png": "image/png"
        case "jpg", "jpeg": "image/jpeg"
        case "wasm": "application/wasm"
        case "ply", "spz", "sog", "splat", "ksplat": "application/octet-stream"
        default: "application/octet-stream"
        }
    }
}

@MainActor
final class ViewerBridge: ObservableObject {
    weak var webView: WKWebView?
    var ready = false
    private var desiredModel: URL?
    private var desiredSparse: URL?
    private var desiredCameras: String?
    private var loadedModel: String?
    private var loadedSparse: String?

    func attach(_ webView: WKWebView) { self.webView = webView }

    func becameReady() {
        ready = true
        apply(model: desiredModel, sparse: desiredSparse, cameras: desiredCameras)
    }

    func apply(model: URL?, sparse: URL?, cameras: String?) {
        desiredModel = model
        desiredSparse = sparse
        desiredCameras = cameras
        guard ready else { return }
        if let sparse, sparse.path != loadedSparse, let served = LocalViewerServer.shared.url(for: sparse) {
            loadedSparse = sparse.path
            call("loadSparse", value: served.absoluteString)
        }
        if let cameras { evaluate("window.SplatStudioViewer?.setCameras(\(cameras));") }
        if let model, model.path != loadedModel, let served = LocalViewerServer.shared.url(for: model) {
            loadedModel = model.path
            call("loadModel", value: served.absoluteString)
        }
    }

    func resetCamera() { evaluate("window.SplatStudioViewer?.resetCamera();") }
    func nextCamera() { evaluate("window.SplatStudioViewer?.nextCamera();") }
    func previousCamera() { evaluate("window.SplatStudioViewer?.previousCamera();") }
    func setFrusta(_ value: Bool) { evaluate("window.SplatStudioViewer?.setFrusta(\(value ? "true" : "false"));") }
    func setFOV(_ value: Double) { evaluate("window.SplatStudioViewer?.setFOV(\(value));") }

    func setBackground(_ color: Color) {
        let ns = NSColor(color).usingColorSpace(.sRGB) ?? .black
        let hex = String(format: "#%02X%02X%02X", Int(ns.redComponent * 255), Int(ns.greenComponent * 255), Int(ns.blueComponent * 255))
        call("setBackground", value: hex)
    }

    func toggleFullscreen() { webView?.window?.toggleFullScreen(nil) }

    func takeScreenshot(projectName: String) {
        guard let webView else { return }
        webView.takeSnapshot(with: nil) { image, _ in
            guard let image, let data = image.tiffRepresentation,
                  let bitmap = NSBitmapImageRep(data: data),
                  let png = bitmap.representation(using: .png, properties: [:]) else { return }
            let panel = NSSavePanel()
            panel.allowedContentTypes = [.png]
            panel.nameFieldStringValue = "\(projectName)-screenshot.png"
            guard panel.runModal() == .OK, let url = panel.url else { return }
            try? png.write(to: url, options: .atomic)
        }
    }

    private func call(_ method: String, value: String) {
        guard let data = try? JSONEncoder().encode(value), let json = String(data: data, encoding: .utf8) else { return }
        evaluate("window.SplatStudioViewer?.\(method)(\(json));")
    }

    private func evaluate(_ javascript: String) { webView?.evaluateJavaScript(javascript) }
}

struct SplatViewerView: NSViewRepresentable {
    var modelURL: URL?
    var sparseURL: URL?
    var camerasJSON: String?
    @ObservedObject var bridge: ViewerBridge

    func makeCoordinator() -> Coordinator { Coordinator(bridge: bridge) }

    func makeNSView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.userContentController.add(context.coordinator, name: "viewer")
        configuration.preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.setValue(false, forKey: "drawsBackground")
        bridge.attach(webView)
        LocalViewerServer.shared.start { base in
            webView.load(URLRequest(url: base.appendingPathComponent("viewer-host.html")))
        }
        return webView
    }

    func updateNSView(_ webView: WKWebView, context: Context) {
        bridge.apply(model: modelURL, sparse: sparseURL, cameras: camerasJSON)
    }

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        let bridge: ViewerBridge
        init(bridge: ViewerBridge) { self.bridge = bridge }
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == "viewer" { Task { @MainActor in bridge.becameReady() } }
        }
    }
}
