import AppKit
import AVFoundation
import AVKit
import SwiftUI
import UniformTypeIdentifiers

private let studioAccent = Color(red: 0.96, green: 0.49, blue: 0.27)
private let studioViolet = Color(red: 0.55, green: 0.38, blue: 0.98)

struct ContentView: View {
    @EnvironmentObject private var model: StudioModel

    var body: some View {
        NavigationSplitView {
            StudioSidebar()
                .navigationSplitViewColumnWidth(min: 208, ideal: 230, max: 270)
        } detail: {
            Group {
                switch model.destination {
                case .library:
                    if let project = model.selectedProject {
                        ProjectDetailView(project: project)
                    } else {
                        ProjectLibraryView()
                    }
                case .create: ImportView()
                case .guide: CaptureGuideView()
                case .settings: EngineView()
                }
            }
            .overlay(alignment: .bottom) {
                if let toast = model.toast {
                    Text(toast)
                        .font(.callout.weight(.medium))
                        .padding(.horizontal, 16).padding(.vertical, 10)
                        .background(.regularMaterial, in: Capsule())
                        .shadow(radius: 10)
                        .padding(.bottom, 22)
                }
            }
        }
        .tint(studioAccent)
        .background(Color(nsColor: .windowBackgroundColor))
    }
}

struct StudioSidebar: View {
    @EnvironmentObject private var model: StudioModel

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 11) {
                Image(systemName: "sparkles.rectangle.stack.fill")
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(studioAccent, studioViolet)
                    .font(.system(size: 24, weight: .semibold))
                VStack(alignment: .leading, spacing: 1) {
                    Text("Splat Studio").font(.headline)
                    Text("LOCAL · METAL").font(.system(size: 9, weight: .bold, design: .rounded)).foregroundStyle(.secondary)
                }
                Spacer()
            }
            .padding(.horizontal, 16).padding(.top, 16).padding(.bottom, 18)

            List(selection: $model.destination) {
                Section {
                    ForEach([SidebarDestination.library, .create, .guide]) { destination in
                        Label(destination.rawValue, systemImage: destination.symbol)
                            .tag(destination)
                    }
                }
                Section("Recent") {
                    ForEach(model.store.projects.prefix(5)) { project in
                        Button {
                            model.open(project)
                        } label: {
                            HStack {
                                Circle()
                                    .fill(stageColor(project.stage))
                                    .frame(width: 7, height: 7)
                                Text(project.name).lineLimit(1)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .listStyle(.sidebar)

            Divider()
            Button {
                model.destination = .settings
                model.selectedProject = nil
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "cpu")
                    VStack(alignment: .leading, spacing: 2) {
                        Text(model.dependencies.status.coreReady ? "Engine Ready" : "Engine Needs Setup")
                            .font(.caption.weight(.semibold))
                        Text(model.systemMonitor.metalName)
                            .font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                    }
                    Spacer()
                    Circle().fill(model.dependencies.status.coreReady ? Color.green : Color.orange).frame(width: 7, height: 7)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .padding(14)
        }
    }

    private func stageColor(_ stage: ProjectStage) -> Color {
        switch stage {
        case .complete: .green
        case .failed: .red
        case .cancelled: .secondary
        case .ready: .blue
        default: studioAccent
        }
    }
}

struct ProjectLibraryView: View {
    @EnvironmentObject private var model: StudioModel
    private let columns = [GridItem(.adaptive(minimum: 260, maximum: 360), spacing: 18)]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Your Scenes").font(.system(size: 32, weight: .bold, design: .rounded))
                        Text("Every reconstruction stays on this Mac.").foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button(action: model.showNewScene) {
                        Label("New Scene", systemImage: "plus")
                            .font(.headline).padding(.horizontal, 10).padding(.vertical, 5)
                    }
                    .buttonStyle(.borderedProminent)
                }

                if model.store.projects.isEmpty {
                    EmptyLibraryCard(action: model.showNewScene)
                } else {
                    LazyVGrid(columns: columns, alignment: .leading, spacing: 18) {
                        ForEach(model.store.projects) { project in
                            ProjectCard(project: project) { model.open(project) }
                        }
                    }
                }
            }
            .padding(32)
        }
        .navigationTitle("Projects")
    }
}

private struct EmptyLibraryCard: View {
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            VStack(spacing: 18) {
                ZStack {
                    Circle().fill(studioAccent.opacity(0.12)).frame(width: 92, height: 92)
                    Image(systemName: "cube.transparent.fill").font(.system(size: 42)).foregroundStyle(studioAccent)
                }
                Text("Turn a walkthrough into a place you can revisit").font(.title2.bold())
                Text("Drop in an iPhone video. Splat Studio checks the capture, reconstructs it locally, and opens the finished 3D scene.")
                    .multilineTextAlignment(.center).foregroundStyle(.secondary).frame(maxWidth: 560)
                Label("Choose a Video", systemImage: "video.fill").font(.headline)
                    .padding(.horizontal, 18).padding(.vertical, 10)
                    .background(studioAccent, in: Capsule()).foregroundStyle(.white)
            }
            .frame(maxWidth: .infinity, minHeight: 390)
            .padding(28)
            .background(
                LinearGradient(colors: [studioViolet.opacity(0.10), studioAccent.opacity(0.06)], startPoint: .topLeading, endPoint: .bottomTrailing),
                in: RoundedRectangle(cornerRadius: 24, style: .continuous)
            )
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(.quaternary))
        }
        .buttonStyle(.plain)
    }
}

private struct ProjectCard: View {
    let project: StudioProject
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 0) {
                ZStack(alignment: .bottomLeading) {
                    LinearGradient(colors: [studioViolet.opacity(0.55), studioAccent.opacity(0.48), .black.opacity(0.78)], startPoint: .topTrailing, endPoint: .bottomLeading)
                    ParticleMark()
                    Text(project.stage.title.uppercased())
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .padding(.horizontal, 9).padding(.vertical, 5)
                        .background(.ultraThinMaterial, in: Capsule()).padding(12)
                }
                .frame(height: 154)
                VStack(alignment: .leading, spacing: 7) {
                    Text(project.name).font(.headline).lineLimit(1)
                    HStack {
                        Text(project.preset.title)
                        Text("·")
                        Text(project.modifiedAt, style: .relative)
                    }
                    .font(.caption).foregroundStyle(.secondary)
                    if project.stage != .complete && project.stage != .failed && project.stage != .ready {
                        ProgressView(value: project.progress).tint(studioAccent)
                    }
                }
                .padding(14)
            }
            .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
            .clipShape(RoundedRectangle(cornerRadius: 17, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 17).stroke(.quaternary))
        }
        .buttonStyle(.plain)
    }
}

private struct ParticleMark: View {
    var body: some View {
        Canvas { context, size in
            for index in 0..<90 {
                let a = Double(index) * 2.399
                let r = sqrt(Double(index) / 90) * min(size.width, size.height) * 0.42
                let x = size.width * 0.56 + cos(a) * r * 1.35
                let y = size.height * 0.48 + sin(a) * r * 0.72
                let d = 1.5 + Double(index % 5) * 0.55
                let hue = 0.04 + Double(index % 18) / 90
                context.fill(Path(ellipseIn: CGRect(x: x, y: y, width: d, height: d)), with: .color(Color(hue: hue, saturation: 0.72, brightness: 1).opacity(0.85)))
            }
        }
    }
}

struct ImportView: View {
    @EnvironmentObject private var model: StudioModel
    @State private var dropActive = false
    @State private var showAdvanced = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Create a 3D Scene").font(.system(size: 32, weight: .bold, design: .rounded))
                    Text("Your video stays on this Mac from first frame to final splat.").foregroundStyle(.secondary)
                }
                if let url = model.importedVideo {
                    ImportedVideoView(url: url)
                    if model.isAnalyzing {
                        AnalyzingCard()
                    } else if let result = model.analysis {
                        AnalysisCard(metrics: result)
                        QualitySelector(showAdvanced: $showAdvanced)
                        createButton(result)
                    } else if let error = model.analysisError {
                        ErrorCard(title: "Couldn’t analyze this video", message: error)
                    }
                } else {
                    DropVideoCard(isTargeted: $dropActive)
                }
            }
            .frame(maxWidth: 980, alignment: .leading)
            .padding(32)
            .frame(maxWidth: .infinity)
        }
        .navigationTitle("New Scene")
    }

    @ViewBuilder
    private func createButton(_ result: CaptureMetrics) -> some View {
        HStack {
            if !model.dependencies.status.coreReady {
                Label("Reconstruction engine needs attention", systemImage: "exclamationmark.triangle")
                    .font(.callout).foregroundStyle(.orange)
            } else {
                Label("Runs privately with \(model.systemMonitor.metalName)", systemImage: "lock.fill")
                    .font(.callout).foregroundStyle(.secondary)
            }
            Spacer()
            Button {
                model.createScene()
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "sparkles")
                    Text(result.rating == .likelyToFail ? "Create Anyway" : "Create 3D Scene")
                }
                .font(.headline).padding(.horizontal, 14).padding(.vertical, 7)
            }
            .buttonStyle(.borderedProminent)
            .disabled(!model.dependencies.status.coreReady)
        }
        .padding(.top, 4)
    }
}

private struct DropVideoCard: View {
    @EnvironmentObject private var model: StudioModel
    @Binding var isTargeted: Bool

    var body: some View {
        VStack(spacing: 20) {
            ZStack {
                RoundedRectangle(cornerRadius: 18).fill(studioAccent.opacity(0.11)).frame(width: 92, height: 76)
                Image(systemName: "video.fill").font(.system(size: 32)).foregroundStyle(studioAccent)
            }
            VStack(spacing: 6) {
                Text("Drop your walkthrough here").font(.title2.bold())
                Text("MOV, MP4, M4V, or another video format supported by macOS").foregroundStyle(.secondary)
            }
            Button("Choose Video…", action: model.chooseVideo).buttonStyle(.borderedProminent).controlSize(.large)
            Text("Nothing is uploaded.").font(.caption).foregroundStyle(.tertiary)
        }
        .frame(maxWidth: .infinity, minHeight: 420)
        .padding(30)
        .background(isTargeted ? studioAccent.opacity(0.12) : Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(isTargeted ? studioAccent : Color.secondary.opacity(0.25), style: StrokeStyle(lineWidth: isTargeted ? 2 : 1, dash: [8])))
        .dropDestination(for: URL.self) { urls, _ in
            guard let url = urls.first else { return false }
            model.importVideo(url)
            return true
        } isTargeted: { isTargeted = $0 }
    }
}

private struct ImportedVideoView: View {
    @EnvironmentObject private var model: StudioModel
    let url: URL
    @State private var player: AVPlayer

    init(url: URL) {
        self.url = url
        _player = State(initialValue: AVPlayer(url: url))
    }

    var body: some View {
        HStack(spacing: 18) {
            VideoPlayer(player: player)
                .frame(width: 320, height: 180).background(.black)
                .clipShape(RoundedRectangle(cornerRadius: 13))
                .onDisappear { player.pause() }
            VStack(alignment: .leading, spacing: 9) {
                Label("VIDEO SELECTED", systemImage: "checkmark.circle.fill")
                    .font(.caption.bold()).foregroundStyle(.green)
                Text(url.lastPathComponent).font(.title3.bold()).lineLimit(2)
                Text(url.deletingLastPathComponent().path).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                Button("Choose a Different Video", action: model.chooseVideo).buttonStyle(.link)
            }
            Spacer()
        }
        .padding(16)
        .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 18))
    }
}

private struct AnalyzingCard: View {
    @State private var phase = 0.0
    var body: some View {
        HStack(spacing: 18) {
            ProgressView().controlSize(.large)
            VStack(alignment: .leading, spacing: 4) {
                Text("Checking the capture").font(.headline)
                Text("Measuring sharpness, movement, overlap, texture, and exposure…").foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(22).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))
    }
}

private struct AnalysisCard: View {
    let metrics: CaptureMetrics
    private var color: Color {
        switch metrics.rating {
        case .excellent: .green
        case .good: .blue
        case .risky: .orange
        case .likelyToFail: .red
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(spacing: 14) {
                Image(systemName: metrics.rating.symbol).font(.system(size: 30)).foregroundStyle(color)
                VStack(alignment: .leading, spacing: 3) {
                    Text(metrics.rating.rawValue).font(.title2.bold())
                    Text("Estimated reconstruction quality · \(metrics.qualityScore)/100").foregroundStyle(.secondary)
                }
                Spacer()
                ProgressView(value: Double(metrics.qualityScore), total: 100)
                    .progressViewStyle(.linear).tint(color).frame(width: 150)
            }
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 10) {
                MetricTile(label: "DURATION", value: durationString(metrics.duration), detail: "\(metrics.candidateFrames) candidates")
                MetricTile(label: "VIDEO", value: "\(metrics.width) × \(metrics.height)", detail: String(format: "%.1f fps", metrics.fps))
                MetricTile(label: "SHARPNESS", value: percent(1 - metrics.blurScore), detail: "\(percent(metrics.blurScore)) blurry")
                MetricTile(label: "OVERLAP", value: percent(metrics.overlap), detail: overlapLabel(metrics.overlap))
                MetricTile(label: "MOVEMENT", value: percent(metrics.cameraMovement), detail: movementLabel(metrics.cameraMovement))
                MetricTile(label: "TEXTURE", value: percent(1 - metrics.lowTextureFraction), detail: "feature coverage")
                MetricTile(label: "EXPOSURE", value: percent(1 - metrics.exposureInstability), detail: "stability")
                MetricTile(label: "FRAMES", value: "~\(metrics.candidateFrames)", detail: "usable views")
            }
            if !metrics.issues.isEmpty {
                Divider()
                VStack(alignment: .leading, spacing: 9) {
                    Text("What to watch").font(.headline)
                    ForEach(metrics.issues) { issue in
                        Label(issue.message, systemImage: issue.severity >= 3 ? "exclamationmark.triangle.fill" : "info.circle.fill")
                            .font(.callout).foregroundStyle(issue.severity >= 3 ? Color.orange : Color.secondary)
                    }
                    Text("You can continue anyway. Automatic recovery will try alternate frame spacing and mapper strategies before giving up.")
                        .font(.caption).foregroundStyle(.secondary).padding(.top, 3)
                }
            }
        }
        .padding(20)
        .background(color.opacity(0.055), in: RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(color.opacity(0.25)))
    }

    private func percent(_ value: Double) -> String { "\(Int((value * 100).rounded()))%" }
    private func durationString(_ duration: Double) -> String { String(format: "%d:%02d", Int(duration) / 60, Int(duration) % 60) }
    private func overlapLabel(_ value: Double) -> String { value > 0.7 ? "strong" : value > 0.48 ? "workable" : "too low" }
    private func movementLabel(_ value: Double) -> String { value < 0.1 ? "too little" : value > 0.75 ? "very fast" : "steady" }
}

private struct MetricTile: View {
    let label: String, value: String, detail: String
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label).font(.system(size: 9, weight: .bold, design: .rounded)).foregroundStyle(.tertiary)
            Text(value).font(.system(.body, design: .rounded).weight(.semibold)).lineLimit(1).minimumScaleFactor(0.75)
            Text(detail).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading).padding(11)
        .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 10))
    }
}

private struct QualitySelector: View {
    @EnvironmentObject private var model: StudioModel
    @Binding var showAdvanced: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Quality").font(.headline)
            HStack(spacing: 10) {
                ForEach(QualityPreset.allCases) { preset in
                    Button {
                        model.advancedWasEdited = false
                        model.preset = preset
                        model.settings = preset.settings
                    } label: {
                        VStack(alignment: .leading, spacing: 5) {
                            HStack {
                                Text(preset.title).font(.headline)
                                if preset == .high { Text("DEFAULT").font(.system(size: 8, weight: .bold)).padding(.horizontal, 5).padding(.vertical, 2).background(studioAccent.opacity(0.15), in: Capsule()) }
                            }
                            Text(preset.subtitle).font(.caption).foregroundStyle(.secondary)
                            Text("\(preset.settings.maxFrames) frames · \(preset.settings.trainingSteps / 1000)k steps")
                                .font(.caption2.monospacedDigit()).foregroundStyle(.tertiary)
                            Text(preset.timeHint).font(.caption2).foregroundStyle(.tertiary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading).padding(13)
                        .background(model.preset == preset ? studioAccent.opacity(0.10) : Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 12))
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(model.preset == preset ? studioAccent : Color.secondary.opacity(0.2)))
                    }
                    .buttonStyle(.plain)
                }
            }
            if model.preset == .max {
                Label(
                    "Ultra uses up to 2,000 sharp views, long densification, and a 7-million-splat ceiling. It is designed for unattended overnight runs; final fidelity still depends on what the camera actually saw.",
                    systemImage: "moon.stars.fill"
                )
                .font(.caption).foregroundStyle(.secondary)
            }
            DisclosureGroup("Advanced", isExpanded: $showAdvanced) {
                Grid(alignment: .leading, horizontalSpacing: 20, verticalSpacing: 12) {
                    GridRow {
                        LabeledContent("Maximum frames") { TextField("", value: $model.settings.maxFrames, format: .number).frame(width: 90) }
                        LabeledContent("Frame resolution") { TextField("", value: $model.settings.frameResolution, format: .number).frame(width: 90) }
                    }
                    GridRow {
                        LabeledContent("Training steps") { TextField("", value: $model.settings.trainingSteps, format: .number).frame(width: 90) }
                        LabeledContent("Image scale") { TextField("", value: $model.settings.imageScale, format: .number.precision(.fractionLength(2))).frame(width: 90) }
                    }
                    GridRow {
                        LabeledContent("Mapper") { Picker("", selection: $model.settings.mapper) { ForEach(MapperChoice.allCases) { Text($0.label).tag($0) } }.labelsHidden().frame(width: 230) }
                        LabeledContent("Min. registered") { TextField("", value: $model.settings.minimumRegistration, format: .percent).frame(width: 90) }
                    }
                    GridRow {
                        LabeledContent("Max blur fraction") { TextField("", value: $model.settings.maximumBlurFraction, format: .percent).frame(width: 90) }
                        Color.clear.frame(height: 1)
                    }
                }
                .textFieldStyle(.roundedBorder).padding(.top, 12)
                .onChange(of: model.settings) { _ in model.advancedWasEdited = true }
            }
        }
        .padding(20).background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 18))
    }
}

struct ProjectDetailView: View {
    @EnvironmentObject private var model: StudioModel
    let project: StudioProject

    var body: some View {
        Group {
            if project.stage == .complete {
                FinishedProjectView(project: project)
            } else {
                ReconstructionView(project: project)
            }
        }
        .navigationTitle(project.name)
    }
}

struct ReconstructionView: View {
    @EnvironmentObject private var model: StudioModel
    @StateObject private var viewer = ViewerBridge()
    let project: StudioProject

    var body: some View {
        HSplitView {
            ZStack(alignment: .bottom) {
                SplatViewerView(modelURL: model.latestModelURL, sparseURL: model.sparseURL, camerasJSON: model.camerasJSON, bridge: viewer)
                    .frame(minWidth: 600)
                ViewerHint()
            }
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    StageHeader(project: project)
                    StageTimeline(project: project)
                    if project.stage == .train { TrainingStats(project: project) }
                    ResourceStats()
                    if project.recoveryAttempt > 1 {
                        Label("Recovering automatically · attempt \(project.recoveryAttempt)", systemImage: "arrow.triangle.2.circlepath")
                            .font(.callout.weight(.medium)).foregroundStyle(.orange).padding(12)
                            .background(.orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
                    }
                    if project.stage == .failed {
                        ErrorCard(title: "This stage stopped", message: project.lastError ?? project.statusMessage)
                        Button("Retry Failed Stage", action: model.retryCurrentStage).buttonStyle(.borderedProminent)
                        Button("Copy Diagnostics", action: model.copyDiagnostics)
                    } else if project.stage == .cancelled {
                        Button("Resume Reconstruction", action: model.retryCurrentStage).buttonStyle(.borderedProminent)
                    } else if model.runner.isRunning {
                        Button(role: .destructive, action: model.cancel) { Label("Cancel Reconstruction", systemImage: "stop.fill") }
                    }
                }
                .padding(22)
            }
            .frame(minWidth: 310, idealWidth: 350, maxWidth: 400)
        }
    }
}

private struct StageHeader: View {
    @EnvironmentObject private var model: StudioModel
    let project: StudioProject
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(project.stage.title).font(.title2.bold())
            Text(project.statusMessage).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            ProgressView(value: project.progress).tint(studioAccent)
            HStack {
                Text("\(Int(project.progress * 100))%").monospacedDigit()
                Spacer()
                Text(elapsed(model.runner.elapsed))
                if let eta = model.runner.estimatedRemaining, project.stage == .train {
                    Text("· ~\(elapsed(eta)) left")
                }
            }.font(.caption).foregroundStyle(.secondary)
        }
    }

    private func elapsed(_ value: TimeInterval) -> String {
        let total = Int(value)
        return total >= 3600 ? String(format: "%d:%02d:%02d", total / 3600, total / 60 % 60, total % 60) : String(format: "%d:%02d", total / 60, total % 60)
    }
}

private struct StageTimeline: View {
    let project: StudioProject
    private let stages: [(ProjectStage, String, String)] = [
        (.frames, "Frames", "Sharp-frame selection"), (.poses, "Camera path", "GLOMAP + COLMAP recovery"),
        (.train, "Gaussian training", "Metal-native Brush"), (.export, "Export", "PLY · SPZ · viewer scene")
    ]
    var body: some View {
        VStack(spacing: 0) {
            ForEach(Array(stages.enumerated()), id: \.offset) { index, item in
                HStack(alignment: .top, spacing: 12) {
                    VStack(spacing: 0) {
                        ZStack {
                            Circle().fill(color(for: item.0)).frame(width: 22, height: 22)
                            if isDone(item.0) { Image(systemName: "checkmark").font(.system(size: 10, weight: .bold)).foregroundStyle(.white) }
                            else if project.stage == item.0 { ProgressView().controlSize(.mini).tint(.white) }
                        }
                        if index < stages.count - 1 { Rectangle().fill(.quaternary).frame(width: 1, height: 38) }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(item.1).font(.callout.weight(.semibold))
                        Text(detail(for: item.0, fallback: item.2)).font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                }
            }
        }
    }

    private func rank(_ stage: ProjectStage) -> Int {
        [.ready, .analyzing, .frames, .poses, .train, .export, .complete].firstIndex(of: stage) ?? -1
    }
    private func isDone(_ stage: ProjectStage) -> Bool { rank(project.stage) > rank(stage) }
    private func color(for stage: ProjectStage) -> Color { isDone(stage) ? .green : project.stage == stage ? studioAccent : .secondary.opacity(0.25) }
    private func detail(for stage: ProjectStage, fallback: String) -> String {
        if stage == .poses, let registered = project.registeredFrames, let total = project.totalFrames {
            return "\(registered) / \(total) frames registered — \(String(format: "%.1f", Double(registered) / Double(max(total, 1)) * 100))%"
        }
        if stage == .train, let step = project.trainingStep { return "Step \(step.formatted()) / \(project.settings.trainingSteps.formatted())" }
        return fallback
    }
}

private struct TrainingStats: View {
    let project: StudioProject
    var body: some View {
        VStack(alignment: .leading, spacing: 11) {
            Text("LIVE TRAINING").font(.system(size: 10, weight: .bold, design: .rounded)).foregroundStyle(.secondary)
            HStack {
                Stat(label: "STEP", value: (project.trainingStep ?? 0).formatted())
                Stat(label: "GAUSSIANS", value: project.gaussianCount?.formatted() ?? "—")
            }
            HStack {
                Stat(label: "RESOLUTION", value: "\(project.settings.frameResolution) px")
                Stat(label: "REGISTERED", value: "\(project.registeredFrames ?? 0) / \(project.totalFrames ?? 0)")
            }
        }
        .padding(14).background(studioAccent.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
    }
}

private struct Stat: View {
    let label: String, value: String
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label).font(.system(size: 8, weight: .bold, design: .rounded)).foregroundStyle(.tertiary)
            Text(value).font(.system(.body, design: .monospaced).weight(.semibold))
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}

private struct ResourceStats: View {
    @EnvironmentObject private var model: StudioModel
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Label("\(model.systemMonitor.metalName) · Metal active", systemImage: "memorychip.fill")
            Label(String(format: "%.1f / %.0f GB memory in use", model.systemMonitor.memoryUsedGB, model.systemMonitor.memoryTotalGB), systemImage: "chart.bar.fill")
            Label("\(model.systemMonitor.processor) CPU cores available", systemImage: "cpu.fill")
        }.font(.caption).foregroundStyle(.secondary)
    }
}

struct FinishedProjectView: View {
    @EnvironmentObject private var model: StudioModel
    @StateObject private var viewer = ViewerBridge()
    @State private var background = Color.black
    @State private var fov = 50.0
    @State private var showFrusta = false
    let project: StudioProject

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Button { viewer.resetCamera() } label: { Label("Reset", systemImage: "viewfinder") }
                Button { viewer.previousCamera() } label: { Image(systemName: "chevron.left") }
                Button { viewer.nextCamera() } label: { Label("Viewpoints", systemImage: "video") }
                Toggle(isOn: $showFrusta) { Label("Cameras", systemImage: "pyramid") }
                    .toggleStyle(.button).onChange(of: showFrusta) { viewer.setFrusta($0) }
                Divider().frame(height: 20)
                Text("FOV").font(.caption).foregroundStyle(.secondary)
                Slider(value: $fov, in: 28...95).frame(width: 110).onChange(of: fov) { viewer.setFOV($0) }
                ColorPicker("Background", selection: $background, supportsOpacity: false)
                    .labelsHidden().onChange(of: background) { viewer.setBackground($0) }
                Spacer()
                if project.settings.effortLevel != "ultra" || project.settings.trainingSteps < QualityPreset.max.settings.trainingSteps {
                    Button { model.rebuildInUltra(project) } label: {
                        Label("Rebuild in Ultra", systemImage: "wand.and.stars")
                    }
                    .help("Create a new overnight-quality reconstruction from the saved source video; this result is preserved.")
                    .disabled(model.runner.isRunning)
                }
                Button { viewer.takeScreenshot(projectName: project.name) } label: { Label("Screenshot", systemImage: "camera") }
                Menu("Export") {
                    ForEach(model.artifacts) { artifact in
                        Button("\(artifact.name) · \(byteString(artifact.bytes))") { model.exportArtifact(artifact) }
                    }
                    Divider()
                    Button("Reveal in Finder", action: model.revealCurrentProject)
                }
                Button { viewer.toggleFullscreen() } label: { Image(systemName: "arrow.up.left.and.arrow.down.right") }
            }
            .buttonStyle(.bordered).controlSize(.small).padding(10)
            .background(.bar)
            ZStack(alignment: .bottom) {
                SplatViewerView(modelURL: model.latestModelURL, sparseURL: nil, camerasJSON: model.camerasJSON, bridge: viewer)
                ViewerHint()
            }
        }
    }

    private func byteString(_ bytes: Int64) -> String { ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file) }
}

private struct ViewerHint: View {
    var body: some View {
        Text("WASD move  ·  drag / trackpad look  ·  Shift faster  ·  Space up  ·  Control down")
            .font(.caption2.monospaced()).foregroundStyle(.white.opacity(0.76))
            .padding(.horizontal, 11).padding(.vertical, 7)
            .background(.black.opacity(0.46), in: Capsule()).padding(.bottom, 14)
            .allowsHitTesting(false)
    }
}

struct CaptureGuideView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("How to Record").font(.system(size: 32, weight: .bold, design: .rounded))
                    Text("Good geometry starts with calm, connected movement.").foregroundStyle(.secondary)
                }
                CaptureOrbitAnimation().frame(height: 320)
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 14) {
                    GuideTip(icon: "figure.walk.motion", title: "Move slowly", text: "Walk at a steady pace. Avoid whip pans and sudden turns.", good: true)
                    GuideTip(icon: "arrow.triangle.2.circlepath", title: "Walk in arcs", text: "Circle objects and keep familiar parts of the scene visible.", good: true)
                    GuideTip(icon: "circle.hexagongrid.fill", title: "Include detail", text: "Textured furniture, art, plants, and corners help the camera path lock in.", good: true)
                    GuideTip(icon: "arrow.uturn.backward.circle", title: "Close the loop", text: "If practical, finish near where you started.", good: true)
                    GuideTip(icon: "person.2.slash", title: "Keep things still", text: "Avoid moving people, pets, screens, and reflective motion.", good: false)
                    GuideTip(icon: "rectangle.dashed", title: "Not just blank walls", text: "Textureless walls and sky give reconstruction nothing to follow.", good: false)
                }
                Text("A simple rule: every moment of the video should share something recognizable with the moment before it.")
                    .font(.title3.weight(.medium)).padding(20).frame(maxWidth: .infinity)
                    .background(studioAccent.opacity(0.09), in: RoundedRectangle(cornerRadius: 16))
            }
            .frame(maxWidth: 900, alignment: .leading).padding(32).frame(maxWidth: .infinity)
        }
    }
}

private struct CaptureOrbitAnimation: View {
    var body: some View {
        TimelineView(.animation) { context in
            let t = context.date.timeIntervalSinceReferenceDate
            Canvas { canvas, size in
                let center = CGPoint(x: size.width * 0.5, y: size.height * 0.5)
                let room = CGRect(x: center.x - 100, y: center.y - 72, width: 200, height: 144)
                canvas.fill(Path(roundedRect: room, cornerRadius: 20), with: .linearGradient(
                    Gradient(colors: [studioViolet.opacity(0.5), studioAccent.opacity(0.65)]),
                    startPoint: CGPoint(x: room.minX, y: room.minY), endPoint: CGPoint(x: room.maxX, y: room.maxY)))
                var orbit = Path()
                orbit.addEllipse(in: CGRect(x: center.x - 230, y: center.y - 125, width: 460, height: 250))
                canvas.stroke(orbit, with: .color(.secondary.opacity(0.35)), style: StrokeStyle(lineWidth: 2, dash: [8, 8]))
                for index in 0..<18 {
                    let angle = Double(index) / 18 * .pi * 2
                    let p = CGPoint(x: center.x + cos(angle) * 230, y: center.y + sin(angle) * 125)
                    canvas.fill(Path(ellipseIn: CGRect(x: p.x - 3, y: p.y - 3, width: 6, height: 6)), with: .color(studioAccent.opacity(0.5)))
                }
                let angle = t.truncatingRemainder(dividingBy: 6) / 6 * .pi * 2
                let camera = CGPoint(x: center.x + cos(angle) * 230, y: center.y + sin(angle) * 125)
                canvas.fill(Path(ellipseIn: CGRect(x: camera.x - 12, y: camera.y - 12, width: 24, height: 24)), with: .color(studioAccent))
                var line = Path(); line.move(to: camera); line.addLine(to: center)
                canvas.stroke(line, with: .color(studioAccent.opacity(0.45)), lineWidth: 2)
            }
        }
        .background(LinearGradient(colors: [studioViolet.opacity(0.08), studioAccent.opacity(0.06)], startPoint: .top, endPoint: .bottom), in: RoundedRectangle(cornerRadius: 22))
        .overlay(alignment: .bottom) { Text("Walk a smooth arc. Keep looking at shared features.").font(.callout.weight(.medium)).padding(18) }
    }
}

private struct GuideTip: View {
    let icon: String, title: String, text: String, good: Bool
    var body: some View {
        HStack(alignment: .top, spacing: 13) {
            Image(systemName: icon).font(.title2).foregroundStyle(good ? Color.green : Color.orange).frame(width: 32)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline)
                Text(text).font(.callout).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            }
            Spacer()
        }
        .padding(16).background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 14))
    }
}

struct EngineView: View {
    @EnvironmentObject private var model: StudioModel
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Reconstruction Engine").font(.system(size: 32, weight: .bold, design: .rounded))
                    Text("Everything required for local reconstruction is checked before a run.").foregroundStyle(.secondary)
                }
                VStack(spacing: 0) {
                    DependencyRow(name: "Apple GPU", detail: model.dependencies.status.metalDevice, ready: model.dependencies.status.metalDevice != "Metal unavailable")
                    Divider()
                    DependencyRow(name: "Video tools", detail: "ffmpeg + ffprobe", ready: model.dependencies.status.ffmpeg && model.dependencies.status.ffprobe)
                    Divider()
                    DependencyRow(name: "Camera poses", detail: "pycolmap + GLOMAP / incremental", ready: model.dependencies.status.pycolmap)
                    Divider()
                    DependencyRow(name: "Gaussian trainer", detail: "Brush · Metal", ready: model.dependencies.status.brush)
                    Divider()
                    DependencyRow(name: "Optimized export", detail: "Node + splat-transform", ready: model.dependencies.status.node, optional: true)
                    Divider()
                    DependencyRow(
                        name: "Depth fallback",
                        detail: model.dependencies.isInstallingDA3 ? "Installing Depth Anything 3 + DA3-LARGE model…" : "Depth Anything 3 · MPS",
                        ready: model.dependencies.status.da3,
                        optional: true
                    )
                }
                .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 16))
                if model.dependencies.isInstallingDA3 {
                    VStack(alignment: .leading, spacing: 8) {
                        ProgressView()
                        Text("This one-time setup is automatic and can continue while you use the app. The large model is stored in Application Support, not inside your projects.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                } else if !model.dependencies.status.da3 {
                    HStack {
                        if let error = model.dependencies.da3InstallError {
                            Text(error).font(.caption).foregroundStyle(.secondary).lineLimit(3)
                        } else {
                            Text("Core reconstruction remains available while the fallback is offline.")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button("Install Depth Fallback") {
                            Task { await model.dependencies.installDepthFallback() }
                        }
                    }
                }
                HStack {
                    Text(model.dependencies.detail).foregroundStyle(.secondary)
                    Spacer()
                    Button { Task { await model.dependencies.check() } } label: {
                        if model.dependencies.isChecking { ProgressView().controlSize(.small) }
                        else { Label("Check Again", systemImage: "arrow.clockwise") }
                    }.disabled(model.dependencies.isChecking)
                }
                VStack(alignment: .leading, spacing: 8) {
                    Label("Private by design", systemImage: "lock.shield.fill").font(.headline)
                    Text("Videos, camera poses, frames, training checkpoints, and final scenes remain in your local Splat Studio project folder. The app uses no reconstruction cloud service and includes no analytics.")
                        .foregroundStyle(.secondary)
                }.padding(18).background(.green.opacity(0.06), in: RoundedRectangle(cornerRadius: 14))
            }
            .frame(maxWidth: 760, alignment: .leading).padding(32).frame(maxWidth: .infinity)
        }
    }
}

private struct DependencyRow: View {
    let name: String, detail: String, ready: Bool
    var optional = false
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: ready ? "checkmark.circle.fill" : optional ? "minus.circle.fill" : "xmark.circle.fill")
                .foregroundStyle(ready ? Color.green : optional ? Color.secondary : Color.red)
            VStack(alignment: .leading, spacing: 2) {
                HStack { Text(name).font(.headline); if optional { Text("OPTIONAL").font(.system(size: 8, weight: .bold)).foregroundStyle(.secondary) } }
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Text(ready ? "READY" : optional ? "NOT INSTALLED" : "MISSING").font(.system(size: 10, weight: .bold, design: .rounded)).foregroundStyle(.secondary)
        }.padding(15)
    }
}

struct ErrorCard: View {
    let title: String, message: String
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(title, systemImage: "exclamationmark.triangle.fill").font(.headline).foregroundStyle(.red)
            Text(message).font(.callout).foregroundStyle(.secondary).textSelection(.enabled)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(16)
            .background(.red.opacity(0.07), in: RoundedRectangle(cornerRadius: 13))
    }
}
