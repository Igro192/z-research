# Third-party notices

MineMind uses or adapts the following open-source projects:

- **AutoClef 1.21 fork** (`3ndetz/autoclef`, pinned commit `c98a3b7`), MIT
  License, Copyright (c) 2020 Adris Jautakas. This is the production
  dedicated-client task library and includes the original AltoClef resource,
  crafting, smelting, survival, portal, Nether, stronghold, and game-completion
  task implementation.
- **Baritone** (embedded by that AutoClef build as
  `baritone-unoptimized-fabric:1.21-beta1`), GNU Lesser General Public License
  3.0. It is loaded inside and controls only the dedicated `MineMind_AI`
  Minecraft client.
- **Mineflayer** and **mineflayer-pathfinder**, MIT License, Copyright (c)
  PrismarineJS contributors. They remain as an explicit migration/diagnostic
  fallback and are not the production executor when dedicated-client mode is
  enabled.

The exact upstream revision and build coordinates are recorded in
`dedicated-client/upstream.lock.json`; MineMind's complete bridge patch is
distributed as corresponding source in `dedicated-client/patches/`.
