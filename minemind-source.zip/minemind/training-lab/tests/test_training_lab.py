import asyncio
import tempfile
import unittest
from pathlib import Path

from minemind_training_lab import (
    AttemptResult,
    CurriculumManager,
    PracticeCandidate,
    ResourceBudget,
    TrainingLab,
    WorldHandle,
    WorldProvisioner,
)


class Backend:
    def __init__(self):
        self.stopped = False

    async def start(self, scenario):
        return WorldHandle("world", "local")

    async def stop(self, handle):
        self.stopped = True


class Agent:
    async def attempt(self, objective, handle, budget):
        return AttemptResult(True, {"done": True}, ({"event": "done"},), 3, 1, 20, 0, 1.0)


def candidates(estimates):
    return [PracticeCandidate("discover a way to satisfy the contract", ("interaction",), 0.3, {}, {"done": True})]


class TrainingLabTest(unittest.TestCase):
    def test_disposable_provisioner_is_scoped(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "lab"
            provisioner = WorldProvisioner(root)
            scenario = CurriculumManager(candidates).propose()
            world = provisioner.create(scenario)
            self.assertTrue(world.exists())
            provisioner.destroy(world)
            self.assertFalse(world.exists())
            with self.assertRaises(ValueError):
                provisioner.destroy(root)

    def test_episode_is_verified_recorded_and_disposed(self):
        with tempfile.TemporaryDirectory() as directory:
            backend = Backend()
            curriculum = CurriculumManager(candidates)
            lab = TrainingLab(
                backend,
                Agent(),
                lambda scenario, attempt: attempt.final_observation.get("done") is True,
                curriculum,
                Path(directory) / "results.sqlite3",
            )
            result = asyncio.run(lab.practice_once(ResourceBudget(wall_seconds=2)))
            self.assertTrue(result.verified_success)
            self.assertTrue(backend.stopped)
            self.assertEqual(curriculum.estimates()[0].successes, 1)
            lab.close()


if __name__ == "__main__":
    unittest.main()
