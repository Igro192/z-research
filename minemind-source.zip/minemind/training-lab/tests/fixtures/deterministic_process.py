"""Offline process fixture for lifecycle tests. It is not Minecraft."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path


def _properties(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            result[key] = value
    return result


def server() -> int:
    root = Path.cwd()
    properties = _properties(root / "server.properties")
    journal = root / "minemind" / "evaluation-events.jsonl"
    journal.parent.mkdir(parents=True, exist_ok=True)
    world_id = os.environ.get("MINEMIND_EVALUATION_WORLD_ID", "fixture-world")
    session_id = f"fixture-session-{world_id}"
    bot_id = f"fixture-bot-{world_id}"
    provenance = {
        "world_id": world_id,
        "world_session_id": session_id,
        "player_id": bot_id,
    }
    entries = [
        {
            "protocol_version": "1.0.0",
            "source": "fabric_server",
            "event_id": "fixture-started",
            "event_type": "minemind:server_started",
            "game_tick": 0,
            "payload": {
                **provenance,
                "fixture": True,
                "seed": properties["level-seed"],
            },
        },
        {
            "protocol_version": "1.0.0",
            "source": "fabric_server",
            "event_id": "fixture-snapshot",
            "event_type": "minemind:authoritative_snapshot",
            "game_tick": 1,
            "payload": {
                **provenance,
                "state": {
                    "evaluated_player_id": bot_id,
                    "evaluated_player_role": "minemind_ai",
                    "embodiment_mode": "SEPARATE_LOCAL_PLAYER",
                    "bot_uuid": bot_id,
                    "dragon_fight": {
                        "previously_killed": False,
                        "exit_portal_active": False,
                    },
                    "evaluation_metrics": {"deaths": 0, "resources_wasted": 0.0},
                }
            },
        },
    ]
    journal.write_text(
        "".join(json.dumps(entry, sort_keys=True) + "\n" for entry in entries),
        encoding="utf-8",
    )
    print("Done (offline fixture)", flush=True)
    for line in sys.stdin:
        if line.strip() == "stop":
            return 0
    return 0


def client(endpoint: str, world_id: str) -> int:
    Path("client-attached.json").write_text(
        json.dumps({"endpoint": endpoint, "world_id": world_id}, sort_keys=True),
        encoding="utf-8",
    )
    print("MINEMIND_CLIENT_READY", flush=True)
    for line in sys.stdin:
        if line.strip() == "quit":
            return 0
    return 0


if __name__ == "__main__":
    if len(sys.argv) >= 2 and sys.argv[1] == "server":
        raise SystemExit(server())
    if len(sys.argv) == 4 and sys.argv[1] == "client":
        raise SystemExit(client(sys.argv[2], sys.argv[3]))
    raise SystemExit("usage: deterministic_process.py server|client ENDPOINT WORLD_ID")
