import unittest

from minemind_training_lab import RuntimeBridgeClient


class RuntimeBridgeTest(unittest.TestCase):
    def test_rejects_non_loopback_runtime(self):
        with self.assertRaises(ValueError):
            RuntimeBridgeClient("http://example.com:8765")

    def test_decodes_metrics_without_accepting_world_evidence(self):
        result = RuntimeBridgeClient._decode({
            "claimed_success": True,
            "elapsed_seconds": 1,
            "deaths": 0,
            "unrecoverable_failure": False,
            "model_calls": 2,
            "tokens": 30,
            "resources_wasted": 0,
            "replans": 1,
            "new_skills": [],
            "transferred_skills_used": [],
            "actions": 4,
            "events": [{"fabricated": True}],
            "final_state": {"fabricated": True},
        })
        self.assertTrue(result.claimed_success)
        self.assertFalse(hasattr(result, "events"))

    def test_accepts_null_for_uninstrumented_costs(self):
        result = RuntimeBridgeClient._decode({
            "claimed_success": False,
            "elapsed_seconds": 1,
            "deaths": None,
            "unrecoverable_failure": False,
            "model_calls": 0,
            "tokens": None,
            "resources_wasted": None,
            "replans": None,
            "new_skills": [],
            "transferred_skills_used": [],
            "actions": 0,
        })
        self.assertIsNone(result.tokens)
        self.assertIsNone(result.deaths)
        self.assertIsNone(result.resources_wasted)
        self.assertIsNone(result.replans)


if __name__ == "__main__":
    unittest.main()
