from __future__ import annotations

import asyncio
import ipaddress
import json
import math
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass
from typing import Any, Mapping

from .models import ResourceBudget, WorldHandle


@dataclass(frozen=True, slots=True)
class RuntimeAttempt:
    claimed_success: bool
    elapsed_seconds: float
    deaths: int | None
    unrecoverable_failure: bool
    model_calls: int
    tokens: int | None
    resources_wasted: float | None
    replans: int | None
    new_skills: tuple[str, ...]
    transferred_skills_used: tuple[str, ...]
    actions: int
    failure: str | None = None


class RuntimeBridgeClient:
    """Calls the local agent runtime; world evidence is intentionally not accepted."""

    def __init__(self, base_url: str, *, timeout_seconds: float = 30.0) -> None:
        parsed = urllib.parse.urlparse(base_url)
        if parsed.scheme != "http" or not parsed.hostname:
            raise ValueError("agent runtime URL must be a local HTTP endpoint")
        try:
            address = ipaddress.ip_address(parsed.hostname)
        except ValueError as error:
            if parsed.hostname != "localhost":
                raise ValueError("agent runtime must use localhost or a loopback IP") from error
        else:
            if not address.is_loopback:
                raise ValueError("agent runtime endpoint must be loopback-only")
        self.url = base_url.rstrip("/") + "/v1/evaluation/attempt"
        self.timeout_seconds = timeout_seconds

    async def attempt(
        self,
        objective: str,
        handle: WorldHandle,
        budget: ResourceBudget,
    ) -> RuntimeAttempt:
        body = {
            "protocol_version": "1.0.0",
            "objective": objective,
            "minecraft_endpoint": handle.endpoint,
            "world_id": handle.world_id,
            "budget": asdict(budget),
        }
        raw = await asyncio.to_thread(self._post, body, budget.wall_seconds + self.timeout_seconds)
        return self._decode(raw)

    def _post(self, body: Mapping[str, Any], timeout: float) -> Mapping[str, Any]:
        request = urllib.request.Request(
            self.url,
            data=json.dumps(body, sort_keys=True).encode("utf-8"),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310 - loopback validated
            if response.status != 200:
                raise RuntimeError(f"agent runtime returned HTTP {response.status}")
            encoded = response.read(4 * 1024 * 1024 + 1)
            if len(encoded) > 4 * 1024 * 1024:
                raise ValueError("agent runtime response exceeds 4 MiB")
            payload = json.loads(encoded)
        if not isinstance(payload, dict):
            raise ValueError("agent runtime response is not an object")
        return payload

    @staticmethod
    def _decode(raw: Mapping[str, Any]) -> RuntimeAttempt:
        required = {
            "claimed_success",
            "elapsed_seconds",
            "deaths",
            "unrecoverable_failure",
            "model_calls",
            "tokens",
            "resources_wasted",
            "replans",
            "new_skills",
            "transferred_skills_used",
            "actions",
        }
        missing = required - set(raw)
        if missing:
            raise ValueError(f"agent runtime response is missing fields: {sorted(missing)}")
        return RuntimeAttempt(
            claimed_success=_boolean(raw["claimed_success"], "claimed_success"),
            elapsed_seconds=_number(raw["elapsed_seconds"], "elapsed_seconds"),
            deaths=_optional_counter(raw["deaths"], "deaths"),
            unrecoverable_failure=_boolean(raw["unrecoverable_failure"], "unrecoverable_failure"),
            model_calls=_counter(raw["model_calls"], "model_calls"),
            tokens=_optional_counter(raw["tokens"], "tokens"),
            resources_wasted=_optional_number(raw["resources_wasted"], "resources_wasted"),
            replans=_optional_counter(raw["replans"], "replans"),
            new_skills=_strings(raw["new_skills"], "new_skills"),
            transferred_skills_used=_strings(
                raw["transferred_skills_used"], "transferred_skills_used"
            ),
            actions=_counter(raw["actions"], "actions"),
            failure=str(raw["failure"]) if raw.get("failure") is not None else None,
        )


def _boolean(value: Any, field: str) -> bool:
    if not isinstance(value, bool):
        raise ValueError(f"{field} must be boolean")
    return value


def _counter(value: Any, field: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{field} must be a non-negative integer")
    return value


def _number(value: Any, field: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise ValueError(f"{field} must be numeric")
    result = float(value)
    if not math.isfinite(result) or result < 0:
        raise ValueError(f"{field} must be finite and non-negative")
    return result


def _optional_counter(value: Any, field: str) -> int | None:
    return None if value is None else _counter(value, field)


def _optional_number(value: Any, field: str) -> float | None:
    return None if value is None else _number(value, field)


def _strings(value: Any, field: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise ValueError(f"{field} must be an array of strings")
    return tuple(value)
