from __future__ import annotations

import asyncio
import json
import os
import shutil
import signal
import tempfile
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from .models import Scenario, WorldHandle


class WorldProvisioner:
    """Creates and removes worlds only underneath an explicit training root."""

    def __init__(self, training_root: str | Path, template_world: str | Path | None = None) -> None:
        self.training_root = Path(training_root).resolve()
        self.template_world = Path(template_world).resolve() if template_world else None
        self.training_root.mkdir(parents=True, exist_ok=True)
        try:
            self.training_root.chmod(0o700)
        except OSError:
            pass
        if self.template_world and not self.template_world.is_dir():
            raise ValueError("world template does not exist")
        if self.template_world:
            self._validate_template(self.template_world)

    def create(self, scenario: Scenario) -> Path:
        world = Path(tempfile.mkdtemp(prefix="minemind-training-", dir=self.training_root)).resolve()
        self._assert_owned(world)
        try:
            if self.template_world:
                shutil.copytree(self.template_world, world, dirs_exist_ok=True)
            metadata = {
                "scenario_id": scenario.scenario_id,
                "seed": scenario.seed,
                "difficulty": scenario.difficulty,
                "world_options": scenario.world_options,
                "adversarial_modifiers": scenario.adversarial_modifiers,
                "disposable": True,
            }
            (world / "minemind-training.json").write_text(json.dumps(metadata, sort_keys=True), encoding="utf-8")
            return world
        except Exception:
            shutil.rmtree(world, ignore_errors=True)
            raise

    def destroy(self, world: str | Path) -> None:
        target = Path(world).resolve()
        self._assert_owned(target)
        if not target.name.startswith("minemind-training-"):
            raise ValueError("refusing to delete a non-training directory")
        if target.exists():
            shutil.rmtree(target)

    def _assert_owned(self, target: Path) -> None:
        if target == self.training_root or self.training_root not in target.parents:
            raise ValueError("world path escapes the configured training root")

    @staticmethod
    def _validate_template(template: Path) -> None:
        forbidden_roots = {"world", "world_nether", "world_the_end"}
        for entry in template.rglob("*"):
            if entry.is_symlink():
                raise ValueError(f"server template cannot contain symbolic links: {entry}")
            relative = entry.relative_to(template)
            if relative.parts and relative.parts[0].casefold() in forbidden_roots:
                raise ValueError("server template contains a persisted Minecraft world")
            if entry.name.casefold() in {"level.dat", "level.dat_old", "session.lock"}:
                raise ValueError("server template contains world-specific save state")


@dataclass(frozen=True, slots=True)
class JavaServerConfig:
    command: tuple[str, ...]
    endpoint: str
    ready_text: str = "Done ("
    startup_timeout_seconds: float = 120.0
    stop_timeout_seconds: float = 30.0
    eula_accepted: bool = False
    environment: Mapping[str, str] | None = None
    required_artifacts: tuple[str, ...] = ()
    client_command: tuple[str, ...] = ()
    client_ready_text: str = "MINEMIND_CLIENT_READY"
    client_stop_command: str | None = None
    require_client: bool = False


@dataclass(slots=True)
class _RunningWorld:
    server: asyncio.subprocess.Process
    world: Path
    server_output: asyncio.Task[None]
    client: asyncio.subprocess.Process | None = None
    client_output: asyncio.Task[None] | None = None
    client_profile: Path | None = None


class JavaServerBackend:
    """Concrete disposable-world backend for a configured Fabric server command.

    The command is executed without a shell, in a fresh world directory, with a
    minimal environment. The Minecraft seed is available to the server process but
    is deliberately absent from the public WorldHandle given to the agent.
    """

    def __init__(self, provisioner: WorldProvisioner, config: JavaServerConfig) -> None:
        if not config.command:
            raise ValueError("server command is required")
        if not config.eula_accepted:
            raise PermissionError("Minecraft EULA acceptance must be explicit")
        if config.require_client and not config.client_command:
            raise ValueError(
                "real Fabric evaluation requires a client driver; server-only runs are not measured"
            )
        self._endpoint_host, self._endpoint_port = self._parse_endpoint(config.endpoint)
        self.provisioner = provisioner
        self.config = config
        self._processes: dict[str, _RunningWorld] = {}

    async def start(self, scenario: Scenario) -> WorldHandle:
        world = self.provisioner.create(scenario)
        world_id = str(uuid.uuid4())
        environment = {"PATH": os.environ.get("PATH", "")}
        if self.config.environment:
            environment.update(self.config.environment)
        environment.update({
            "MINEMIND_EVALUATION_WORLD_ID": world_id,
            "MINEMIND_SERVER_ENDPOINT": self.config.endpoint,
        })
        try:
            (world / "eula.txt").write_text("eula=true\n", encoding="ascii")
            self._write_server_properties(world, scenario.seed)
            self._validate_artifacts(world)
            server, server_output = await self._start_process(
                self.config.command,
                world,
                environment,
                self.config.ready_text,
                "Minecraft server",
            )
            running = _RunningWorld(server, world, server_output)
            self._processes[world_id] = running
            if self.config.client_command:
                profile = world / "minemind-client-profile"
                profile.mkdir(mode=0o700)
                substitutions = {
                    "server_host": self._endpoint_host,
                    "server_port": str(self._endpoint_port),
                    "server_endpoint": self.config.endpoint,
                    "world_id": world_id,
                    "server_dir": str(world),
                    "profile_dir": str(profile),
                }
                client_command = self._format_command(self.config.client_command, substitutions)
                client, client_output = await self._start_process(
                    client_command,
                    profile,
                    environment,
                    self.config.client_ready_text,
                    "Minecraft client driver",
                )
                running.client = client
                running.client_output = client_output
                running.client_profile = profile
        except Exception:
            running = self._processes.pop(world_id, None)
            if running:
                await self._stop_running(running)
            else:
                self.provisioner.destroy(world)
            raise
        running = self._processes[world_id]
        return WorldHandle(
            world_id,
            self.config.endpoint,
            running.server.pid,
            client_attached=running.client is not None,
            client_process_id=running.client.pid if running.client else None,
        )

    async def stop(self, handle: WorldHandle) -> None:
        running = self._processes.pop(handle.world_id, None)
        if not running:
            return
        await self._stop_running(running)

    def read_trusted_journal(
        self,
        handle: WorldHandle,
        *,
        relative_path: str = "minemind/evaluation-events.jsonl",
        maximum_bytes: int = 64 * 1024 * 1024,
    ) -> tuple[Mapping[str, object], ...]:
        """Read the server-mod journal while the disposable world is still alive."""
        running = self._processes.get(handle.world_id)
        if not running:
            raise KeyError(f"unknown live world {handle.world_id}")
        world = running.world
        relative = Path(relative_path)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("trusted journal path must be relative and cannot traverse parents")
        candidate = world / relative
        if candidate.is_symlink():
            raise ValueError("trusted journal cannot be a symbolic link")
        journal = candidate.resolve()
        if world not in journal.parents:
            raise ValueError("trusted journal path escapes the disposable world")
        if not journal.exists():
            return ()
        if journal.stat().st_size > maximum_bytes:
            raise ValueError("trusted journal exceeds configured size limit")
        entries: list[Mapping[str, object]] = []
        with journal.open("r", encoding="utf-8") as handle_file:
            for number, line in enumerate(handle_file, start=1):
                if not line.strip():
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError as error:
                    raise ValueError(f"invalid trusted journal JSON at line {number}") from error
                if not isinstance(entry, dict):
                    raise ValueError(f"trusted journal line {number} is not an object")
                entries.append(entry)
        return tuple(entries)

    async def _start_process(
        self,
        command: tuple[str, ...],
        cwd: Path,
        environment: Mapping[str, str],
        ready_text: str,
        label: str,
    ) -> tuple[asyncio.subprocess.Process, asyncio.Task[None]]:
        process = await asyncio.create_subprocess_exec(
            *command,
            cwd=cwd,
            env=environment,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            start_new_session=True,
        )
        ready: asyncio.Future[None] = asyncio.get_running_loop().create_future()
        output = asyncio.create_task(self._drain_output(process, ready, ready_text, label))
        try:
            await asyncio.wait_for(asyncio.shield(ready), self.config.startup_timeout_seconds)
        except Exception:
            await self._terminate(process)
            await output
            raise
        return process, output

    async def _drain_output(
        self,
        process: asyncio.subprocess.Process,
        ready: asyncio.Future[None],
        ready_text: str,
        label: str,
    ) -> None:
        if not process.stdout:
            if not ready.done():
                ready.set_exception(RuntimeError(f"{label} output unavailable"))
            return
        while True:
            line = await process.stdout.readline()
            if not line:
                if not ready.done():
                    ready.set_exception(
                        RuntimeError(f"{label} exited before ready: {process.returncode}")
                    )
                return
            if ready_text in line.decode(errors="replace") and not ready.done():
                ready.set_result(None)

    async def _stop_running(self, running: _RunningWorld) -> None:
        try:
            if running.client:
                await self._stop_process(
                    running.client,
                    running.client_output,
                    self.config.client_stop_command,
                )
            await self._stop_process(running.server, running.server_output, "stop")
        finally:
            self.provisioner.destroy(running.world)

    async def _stop_process(
        self,
        process: asyncio.subprocess.Process,
        output: asyncio.Task[None] | None,
        command: str | None,
    ) -> None:
        if process.returncode is None and command and process.stdin:
            process.stdin.write((command + "\n").encode("utf-8"))
            await process.stdin.drain()
            try:
                await asyncio.wait_for(process.wait(), self.config.stop_timeout_seconds)
            except asyncio.TimeoutError:
                await self._terminate(process)
        elif process.returncode is None:
            await self._terminate(process)
        if output:
            await output

    def _write_server_properties(self, world: Path, seed: int) -> None:
        path = world / "server.properties"
        preserved: dict[str, str] = {}
        if path.is_file():
            for line in path.read_text(encoding="utf-8").splitlines():
                if line and not line.lstrip().startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    preserved[key.strip()] = value.strip()
        preserved.update({
            "level-seed": str(seed),
            "level-name": "world",
            "server-ip": "127.0.0.1",
            "server-port": str(self._endpoint_port),
            "online-mode": "false",
            "enable-command-block": "false",
            "enable-query": "false",
            "enable-rcon": "false",
            "spawn-protection": "0",
        })
        path.write_text("".join(f"{key}={value}\n" for key, value in sorted(preserved.items())), encoding="utf-8")

    def _validate_artifacts(self, world: Path) -> None:
        for pattern in self.config.required_artifacts:
            relative = Path(pattern)
            if relative.is_absolute() or ".." in relative.parts:
                raise ValueError(f"required artifact pattern must stay inside template: {pattern}")
            matches = list(world.glob(pattern))
            if not matches or not all(item.is_file() and not item.is_symlink() for item in matches):
                raise FileNotFoundError(f"server template is missing required artifact: {pattern}")
        try:
            jar_index = self.config.command.index("-jar")
        except ValueError:
            return
        if jar_index + 1 >= len(self.config.command):
            raise ValueError("server command -jar requires a path")
        jar = Path(self.config.command[jar_index + 1])
        target = jar if jar.is_absolute() else world / jar
        if not target.is_file():
            raise FileNotFoundError(f"server launcher jar does not exist: {target}")

    @staticmethod
    def _format_command(command: tuple[str, ...], substitutions: Mapping[str, str]) -> tuple[str, ...]:
        try:
            return tuple(part.format_map(substitutions) for part in command)
        except KeyError as error:
            raise ValueError(f"unknown client command placeholder: {error.args[0]}") from error

    @staticmethod
    def _parse_endpoint(endpoint: str) -> tuple[str, int]:
        host, separator, port_text = endpoint.rpartition(":")
        if not separator or host not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError("Minecraft endpoint must be loopback host:port")
        try:
            port = int(port_text)
        except ValueError as error:
            raise ValueError("Minecraft endpoint port must be an integer") from error
        if not 1 <= port <= 65535:
            raise ValueError("Minecraft endpoint port is outside 1..65535")
        return host, port

    async def _terminate(self, process: asyncio.subprocess.Process) -> None:
        if process.returncode is not None:
            return
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            return
        try:
            await asyncio.wait_for(process.wait(), 10.0)
        except asyncio.TimeoutError:
            os.killpg(process.pid, signal.SIGKILL)
            await process.wait()
