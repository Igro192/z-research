from __future__ import annotations

import asyncio
import json
import sqlite3
import time
from pathlib import Path
from typing import Awaitable, Callable, Protocol

from .curriculum import CurriculumManager
from .models import AttemptResult, EpisodeResult, ResourceBudget, Scenario, WorldHandle


class WorldBackend(Protocol):
    async def start(self, scenario: Scenario) -> WorldHandle: ...
    async def stop(self, handle: WorldHandle) -> None: ...


class TrainingAgent(Protocol):
    async def attempt(self, objective: str, handle: WorldHandle, budget: ResourceBudget) -> AttemptResult: ...


Verifier = Callable[[Scenario, AttemptResult], bool]


class TrainingLab:
    """Runs attempts with hard wall-clock limits and guaranteed world disposal."""

    def __init__(
        self,
        backend: WorldBackend,
        agent: TrainingAgent,
        verifier: Verifier,
        curriculum: CurriculumManager,
        results_database: str | Path,
    ) -> None:
        self.backend = backend
        self.agent = agent
        self.verifier = verifier
        self.curriculum = curriculum
        self.database = sqlite3.connect(results_database, isolation_level=None)
        self.database.execute("PRAGMA journal_mode=WAL")
        self.database.executescript(
            """
            CREATE TABLE IF NOT EXISTS training_episodes(
              scenario_id TEXT PRIMARY KEY,
              objective TEXT NOT NULL,
              seed INTEGER NOT NULL,
              difficulty REAL NOT NULL,
              capability_tags_json TEXT NOT NULL,
              success INTEGER NOT NULL,
              budget_exhausted INTEGER NOT NULL,
              reward REAL NOT NULL,
              actions INTEGER NOT NULL,
              model_calls INTEGER NOT NULL,
              tokens INTEGER NOT NULL,
              deaths INTEGER NOT NULL,
              skills_created_json TEXT NOT NULL,
              failure TEXT,
              started_at REAL NOT NULL,
              finished_at REAL NOT NULL
            );
            """
        )

    async def practice_once(self, budget: ResourceBudget = ResourceBudget()) -> EpisodeResult:
        scenario = self.curriculum.propose()
        return await self.run(scenario, budget)

    async def run(self, scenario: Scenario, budget: ResourceBudget = ResourceBudget()) -> EpisodeResult:
        started = time.time()
        handle = await self.backend.start(scenario)
        exhausted = False
        try:
            try:
                attempt = await asyncio.wait_for(
                    self.agent.attempt(scenario.objective, handle, budget), timeout=budget.wall_seconds
                )
            except asyncio.TimeoutError:
                exhausted = True
                attempt = AttemptResult(
                    False, {}, (), budget.max_actions, budget.max_model_calls, budget.max_tokens,
                    budget.max_deaths, -1.0, failure="wall-clock budget exhausted",
                )
            exhausted = exhausted or (
                attempt.actions > budget.max_actions
                or attempt.model_calls > budget.max_model_calls
                or attempt.tokens > budget.max_tokens
                or attempt.deaths > budget.max_deaths
            )
            verified = False if exhausted else bool(self.verifier(scenario, attempt))
            episode = EpisodeResult(scenario, attempt, verified, exhausted, started)
            self._record(episode)
            self.curriculum.record(episode)
            return episode
        finally:
            await self.backend.stop(handle)

    def _record(self, episode: EpisodeResult) -> None:
        self.database.execute(
            "INSERT OR REPLACE INTO training_episodes VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                episode.scenario.scenario_id,
                episode.scenario.objective,
                episode.scenario.seed,
                episode.scenario.difficulty,
                json.dumps(episode.scenario.capability_tags),
                int(episode.verified_success),
                int(episode.budget_exhausted),
                episode.attempt.reward,
                episode.attempt.actions,
                episode.attempt.model_calls,
                episode.attempt.tokens,
                episode.attempt.deaths,
                json.dumps(episode.attempt.skills_created),
                episode.attempt.failure,
                episode.started_at,
                episode.finished_at,
            ),
        )

    def close(self) -> None:
        self.database.close()

    def __enter__(self) -> "TrainingLab":
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()
