from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Callable, Mapping, Sequence

from .models import EpisodeResult, Scenario


@dataclass(frozen=True, slots=True)
class CapabilityEstimate:
    capability: str
    successes: int
    failures: int
    difficulty: float
    last_practiced_at: float | None = None

    @property
    def mastery(self) -> float:
        return (self.successes + 1) / (self.successes + self.failures + 2)

    @property
    def uncertainty(self) -> float:
        total = self.successes + self.failures + 2
        return math.sqrt(self.mastery * (1 - self.mastery) / (total + 1))


@dataclass(frozen=True, slots=True)
class PracticeCandidate:
    objective: str
    capability_tags: tuple[str, ...]
    base_difficulty: float
    world_options: Mapping[str, object]
    success_contract: Mapping[str, object]


CandidateGenerator = Callable[[Sequence[CapabilityEstimate]], Sequence[PracticeCandidate]]
Adversary = Callable[[PracticeCandidate, Sequence[CapabilityEstimate]], tuple[str, ...]]


class CurriculumManager:
    """Selects practice from measured weakness/uncertainty, not a fixed walkthrough."""

    def __init__(
        self,
        candidate_generator: CandidateGenerator,
        *,
        mastery_threshold: float = 0.8,
        regression_interval: int = 10,
        seed: int = 0,
        adversary: Adversary | None = None,
    ) -> None:
        self.candidate_generator = candidate_generator
        self.mastery_threshold = mastery_threshold
        self.regression_interval = regression_interval
        self._random = random.Random(seed)
        self.adversary = adversary
        self._estimates: dict[str, CapabilityEstimate] = {}
        self.episodes = 0

    def estimates(self) -> tuple[CapabilityEstimate, ...]:
        return tuple(sorted(self._estimates.values(), key=lambda item: item.capability))

    def propose(self) -> Scenario:
        estimates = self.estimates()
        candidates = list(self.candidate_generator(estimates))
        if not candidates:
            raise RuntimeError("curriculum generator returned no valid practice objectives")
        regression_due = self.episodes > 0 and self.episodes % self.regression_interval == 0
        scored: list[tuple[float, PracticeCandidate]] = []
        for candidate in candidates:
            relevant = [self._estimate(tag) for tag in candidate.capability_tags]
            weakest = min((item.mastery for item in relevant), default=0.5)
            uncertainty = max((item.uncertainty for item in relevant), default=0.25)
            difficulty_gap = abs(candidate.base_difficulty - weakest)
            frontier_score = 0.55 * (1.0 - difficulty_gap) + 0.35 * uncertainty
            if regression_due and all(item.mastery >= self.mastery_threshold for item in relevant):
                frontier_score += 0.5
            scored.append((frontier_score, candidate))
        best_score = max(score for score, _ in scored)
        near_best = [candidate for score, candidate in scored if score >= best_score - 0.02]
        choice = self._random.choice(near_best)
        difficulty = min(1.0, max(0.0, choice.base_difficulty))
        adversarial = ()
        if all(self._estimate(tag).mastery >= self.mastery_threshold for tag in choice.capability_tags):
            difficulty = min(1.0, difficulty + 0.1)
            adversarial = ("vary_starting_conditions",)
        if self.adversary:
            adversarial = tuple(dict.fromkeys((*adversarial, *self.adversary(choice, estimates))))
        return Scenario(
            objective=choice.objective,
            seed=self._random.randrange(-(2**63), 2**63),
            difficulty=difficulty,
            capability_tags=choice.capability_tags,
            world_options=choice.world_options,
            success_contract=choice.success_contract,
            adversarial_modifiers=adversarial,
        )

    def record(self, episode: EpisodeResult) -> None:
        self.episodes += 1
        for capability in episode.scenario.capability_tags:
            current = self._estimate(capability)
            success = episode.verified_success and not episode.budget_exhausted
            failures = current.failures + int(not success)
            successes = current.successes + int(success)
            mastery = (successes + 1) / (successes + failures + 2)
            difficulty = current.difficulty
            if mastery >= self.mastery_threshold and success:
                difficulty = min(1.0, max(difficulty, episode.scenario.difficulty) + 0.05)
            elif not success:
                difficulty = max(0.0, min(difficulty, episode.scenario.difficulty) - 0.03)
            self._estimates[capability] = CapabilityEstimate(
                capability, successes, failures, difficulty, episode.finished_at
            )

    def _estimate(self, capability: str) -> CapabilityEstimate:
        return self._estimates.get(capability, CapabilityEstimate(capability, 0, 0, 0.2))
