from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class ResourceBudget:
    wall_seconds: float = 600.0
    max_actions: int = 10_000
    max_model_calls: int = 1_000
    max_tokens: int = 500_000
    max_deaths: int = 5


@dataclass(frozen=True, slots=True)
class Scenario:
    objective: str
    seed: int
    difficulty: float
    capability_tags: tuple[str, ...]
    world_options: Mapping[str, Any] = field(default_factory=dict)
    success_contract: Mapping[str, Any] = field(default_factory=dict)
    adversarial_modifiers: tuple[str, ...] = ()
    scenario_id: str = field(default_factory=lambda: str(uuid.uuid4()))


@dataclass(frozen=True, slots=True)
class WorldHandle:
    world_id: str
    endpoint: str
    process_id: int | None = None
    client_attached: bool = False
    client_process_id: int | None = None


@dataclass(frozen=True, slots=True)
class AttemptResult:
    success_claimed: bool
    final_observation: Mapping[str, Any]
    verification_evidence: tuple[Mapping[str, Any], ...]
    actions: int
    model_calls: int
    tokens: int
    deaths: int
    reward: float
    skills_created: tuple[str, ...] = ()
    failure: str | None = None


@dataclass(frozen=True, slots=True)
class EpisodeResult:
    scenario: Scenario
    attempt: AttemptResult
    verified_success: bool
    budget_exhausted: bool
    started_at: float
    finished_at: float = field(default_factory=time.time)

    @property
    def elapsed_seconds(self) -> float:
        return self.finished_at - self.started_at
