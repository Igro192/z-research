"""Cancellable HTTP/1.1 JSON transport for local inference servers.

Closing the socket on cancellation lets a model server stop generation. A
blocking urlopen in a worker thread continued using RAM/CPU after Stop.
"""
from __future__ import annotations

import asyncio
import json
import ssl
from typing import Any, Mapping
from urllib.parse import urlsplit


class AsyncJsonTransport:
    max_response_bytes = 8 * 1024 * 1024

    async def request(self, method: str, url: str, headers: Mapping[str, str],
                      body: Mapping[str, Any] | None, timeout: float) -> tuple[int, Mapping[str, Any]]:
        from .router import RouterError

        target = urlsplit(url)
        if target.scheme not in {"http", "https"} or not target.hostname or target.username:
            raise RouterError("model endpoint must be an HTTP(S) URL without embedded credentials")
        writer: asyncio.StreamWriter | None = None
        try:
            async with asyncio.timeout(timeout):
                port = target.port or (443 if target.scheme == "https" else 80)
                reader, writer = await asyncio.open_connection(
                    target.hostname, port,
                    ssl=ssl.create_default_context() if target.scheme == "https" else None,
                    limit=64 * 1024,
                )
                data = json.dumps(body).encode("utf-8") if body is not None else b""
                path = (target.path or "/") + ("?" + target.query if target.query else "")
                request_headers = {str(key).lower(): str(value) for key, value in headers.items()}
                request_headers.update({
                    "host": target.netloc, "connection": "close",
                    "content-length": str(len(data)), "accept-encoding": "identity",
                })
                if body is not None:
                    request_headers.setdefault("content-type", "application/json")
                if any("\r" in value or "\n" in value for value in [method, path, *request_headers, *request_headers.values()]):
                    raise RouterError("invalid newline in HTTP request")
                head = f"{method} {path} HTTP/1.1\r\n" + "".join(f"{key}: {value}\r\n" for key, value in request_headers.items())
                writer.write(head.encode("latin-1") + b"\r\n" + data)
                await writer.drain()
                response = await reader.readuntil(b"\r\n\r\n")
                lines = response.decode("latin-1").split("\r\n")
                code = int(lines[0].split(" ", 2)[1])
                response_headers = dict(line.split(":", 1) for line in lines[1:] if ":" in line)
                response_headers = {key.lower(): value.strip() for key, value in response_headers.items()}
                chunks: list[bytes] = []
                size = 0
                if response_headers.get("transfer-encoding", "").lower() == "chunked":
                    while True:
                        length = int((await reader.readline()).split(b";", 1)[0].strip(), 16)
                        if length == 0:
                            break
                        size += length
                        if length < 0 or size > self.max_response_bytes:
                            raise RouterError("model response exceeded size limit")
                        chunks.append(await reader.readexactly(length))
                        if await reader.readexactly(2) != b"\r\n":
                            raise RouterError("malformed HTTP chunk")
                elif "content-length" in response_headers:
                    length = int(response_headers["content-length"])
                    if length < 0 or length > self.max_response_bytes:
                        raise RouterError("model response exceeded size limit")
                    chunks.append(await reader.readexactly(length))
                else:
                    while chunk := await reader.read(64 * 1024):
                        size += len(chunk)
                        if size > self.max_response_bytes:
                            raise RouterError("model response exceeded size limit")
                        chunks.append(chunk)
                payload = b"".join(chunks)
                if not 200 <= code < 300:
                    raise RouterError(f"model endpoint returned HTTP {code}: {payload[:1024].decode('utf-8', errors='replace')}")
                decoded = json.loads(payload.decode("utf-8"))
                if not isinstance(decoded, dict):
                    raise RouterError("model endpoint did not return a JSON object")
                return code, decoded
        except (OSError, TimeoutError, ValueError, asyncio.IncompleteReadError, asyncio.LimitOverrunError) as error:
            raise RouterError(f"model request failed: {type(error).__name__}: {error}") from error
        finally:
            if writer is not None:
                writer.close()

