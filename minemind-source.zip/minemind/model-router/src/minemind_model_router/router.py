from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
import json
import os
import platform
import subprocess
import time
from typing import Any, Awaitable, Callable, Mapping, Protocol, Sequence
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from .http_transport import AsyncJsonTransport


class RouterError(RuntimeError):
    pass


class Transport(Protocol):
    async def request(self, method: str, url: str, headers: Mapping[str, str], body: Mapping[str, Any] | None, timeout: float) -> tuple[int, Mapping[str, Any]]: ...


class UrllibTransport(AsyncJsonTransport):
    """Compatibility name; requests now close their sockets on cancellation."""


@dataclass(slots=True, frozen=True)
class Endpoint:
    id: str
    kind: str
    base_url: str
    priority: int = 100
    api_key: str | None = None
    max_concurrency: int = 1
    timeout_seconds: float = 90.0


@dataclass(slots=True, frozen=True)
class ModelInfo:
    endpoint_id: str
    id: str
    capabilities: frozenset[str]
    context_length: int | None = None
    parameter_count: int | None = None
    quantization: str | None = None


@dataclass(slots=True, frozen=True)
class CompletionRequest:
    role: str
    messages: tuple[Mapping[str, Any], ...]
    required_capabilities: frozenset[str] = frozenset({"chat"})
    model: str | None = None
    temperature: float = 0.2
    max_tokens: int = 1024
    json_schema: Mapping[str, Any] | None = None
    tools: tuple[Mapping[str, Any], ...] = ()


@dataclass(slots=True, frozen=True)
class CompletionResult:
    endpoint_id: str
    model: str
    content: str
    tool_calls: tuple[Mapping[str, Any], ...]
    latency_ms: float
    input_tokens: int | None
    output_tokens: int | None
    raw_finish_reason: str | None

    def json(self) -> Mapping[str, Any]:
        content = self.content.strip()
        if content.startswith("```"):
            lines = content.splitlines()
            if lines and lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            content = "\n".join(lines).strip()
        try:
            value = json.loads(content)
        except json.JSONDecodeError as exc:
            # Some otherwise compatible local endpoints append a short stop
            # marker after a complete object.  Accept exactly the first complete
            # object, but never invent missing braces for truncated output.
            start = content.find("{")
            try:
                value, _ = json.JSONDecoder().raw_decode(content[start:]) if start >= 0 else (None, 0)
            except json.JSONDecodeError:
                raise RouterError(f"model {self.model} did not return complete JSON") from exc
        if not isinstance(value, dict):
            raise RouterError("structured model response must be an object")
        return value


@dataclass(slots=True)
class _Health:
    failures: int = 0
    circuit_open_until: float = 0.0
    latency_ema_ms: float = 0.0
    last_error: str | None = None
    completed_calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    calls_without_token_usage: int = 0


@dataclass(slots=True, frozen=True)
class HardwareProfile:
    ram_gb: float
    vram_gb: float
    cpu_count: int
    accelerator: str


def detect_hardware() -> HardwareProfile:
    pages = int(os.sysconf("SC_PHYS_PAGES")) if hasattr(os, "sysconf") else 0
    page_size = int(os.sysconf("SC_PAGE_SIZE")) if hasattr(os, "sysconf") else 0
    ram = pages * page_size / (1024 ** 3) if pages and page_size else 0.0
    vram = 0.0
    accelerator = "cpu"
    try:
        output = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=2, check=False,
        ).stdout
        values = [float(line.strip()) for line in output.splitlines() if line.strip().replace(".", "", 1).isdigit()]
        if values:
            vram, accelerator = max(values) / 1024, "cuda"
    except (OSError, subprocess.TimeoutExpired):
        if platform.system() == "Darwin" and platform.machine() == "arm64":
            vram, accelerator = ram, "metal-unified"
    return HardwareProfile(ram_gb=round(ram, 1), vram_gb=round(vram, 1), cpu_count=os.cpu_count() or 1, accelerator=accelerator)


def recommend_preset(profile: HardwareProfile) -> dict[str, Any]:
    capacity = max(profile.ram_gb, profile.vram_gb)
    if capacity < 12:
        return {"name": "minimal", "simultaneous_models": 1, "model_size_b": "1-4", "quantization": "Q4", "vision": False}
    if capacity < 32:
        return {"name": "balanced", "simultaneous_models": 2, "model_size_b": "7-14", "quantization": "Q4/Q5", "vision": True}
    return {"name": "maximum", "simultaneous_models": 4, "model_size_b": "14-70", "quantization": "hardware-dependent", "vision": True}


class ModelRouter:
    def __init__(self, endpoints: Sequence[Endpoint], *, transport: Transport | None = None, max_concurrent: int = 4) -> None:
        if not endpoints:
            raise ValueError("at least one model endpoint is required")
        self.endpoints = {endpoint.id: endpoint for endpoint in endpoints}
        self.transport = transport or UrllibTransport()
        self.models: dict[str, list[ModelInfo]] = {endpoint.id: [] for endpoint in endpoints}
        self.health = {endpoint.id: _Health() for endpoint in endpoints}
        self._global = asyncio.Semaphore(max_concurrent)
        self._endpoint_limits = {endpoint.id: asyncio.Semaphore(endpoint.max_concurrency) for endpoint in endpoints}
        self.role_preferences: dict[str, tuple[str, ...]] = {}

    def set_role_preference(self, role: str, model_ids: Sequence[str]) -> None:
        self.role_preferences[role] = tuple(model_ids)

    @staticmethod
    def _infer_capabilities(model: Mapping[str, Any]) -> frozenset[str]:
        name = str(model.get("id") or model.get("name") or "").lower()
        caps = {"chat"}
        if any(token in name for token in ("embed", "bge", "e5-", "nomic")):
            caps = {"embedding"}
        if any(token in name for token in ("vision", "vl", "llava", "pixtral", "gemma-3")):
            caps.add("vision")
        if any(token in name for token in ("code", "coder", "codestral")):
            caps.add("code")
        if any(token in name for token in ("reason", "qwq", "r1", "gpt-oss")):
            caps.add("reasoning")
        # Tool/JSON use is probed at call time; compatible servers all accept the fields.
        caps.update({"json", "tools"})
        return frozenset(caps)

    async def discover(self) -> list[ModelInfo]:
        discovered: list[ModelInfo] = []
        for endpoint in sorted(self.endpoints.values(), key=lambda item: item.priority):
            try:
                _, payload = await self.transport.request("GET", endpoint.base_url.rstrip("/") + "/models", self._headers(endpoint), None, min(5.0, endpoint.timeout_seconds))
                raw_models = payload.get("data", [])
                infos = []
                for model in raw_models:
                    model_id = str(model.get("id") or model.get("name") or "")
                    if model_id:
                        meta = model.get("meta") or {}
                        infos.append(ModelInfo(endpoint.id, model_id, self._infer_capabilities(model), meta.get("n_ctx_train"), meta.get("n_params"), meta.get("quantization")))
                self.models[endpoint.id] = infos
                discovered.extend(infos)
                self._mark_success(endpoint.id, 0)
            except RouterError as exc:
                self._mark_failure(endpoint.id, str(exc))
        return discovered

    def _headers(self, endpoint: Endpoint) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if endpoint.api_key:
            headers["Authorization"] = f"Bearer {endpoint.api_key}"
        return headers

    def _candidates(self, request: CompletionRequest) -> list[tuple[Endpoint, ModelInfo]]:
        now = time.monotonic()
        preferred = self.role_preferences.get(request.role, ())
        result: list[tuple[Endpoint, ModelInfo]] = []
        for endpoint in self.endpoints.values():
            if self.health[endpoint.id].circuit_open_until > now:
                continue
            for model in self.models.get(endpoint.id, []):
                if request.model and model.id != request.model:
                    continue
                if not request.required_capabilities.issubset(model.capabilities):
                    continue
                result.append((endpoint, model))
        def score(candidate: tuple[Endpoint, ModelInfo]) -> tuple[int, int, float]:
            endpoint, model = candidate
            pref = preferred.index(model.id) if model.id in preferred else len(preferred) + 1
            return pref, endpoint.priority, self.health[endpoint.id].latency_ema_ms
        return sorted(result, key=score)

    async def complete(self, request: CompletionRequest) -> CompletionResult:
        if not any(self.models.values()):
            await self.discover()
        candidates = self._candidates(request)
        if not candidates:
            failures = {key: value.last_error for key, value in self.health.items()}
            raise RouterError(f"no healthy model satisfies {sorted(request.required_capabilities)}; {failures}")
        errors: list[str] = []
        for endpoint, model in candidates:
            try:
                return await self._complete_one(endpoint, model, request)
            except RouterError as exc:
                errors.append(f"{endpoint.id}/{model.id}: {exc}")
                self._mark_failure(endpoint.id, str(exc))
        raise RouterError("all eligible model calls failed: " + "; ".join(errors))

    async def _complete_one(self, endpoint: Endpoint, model: ModelInfo, request: CompletionRequest) -> CompletionResult:
        body: dict[str, Any] = {
            "model": model.id, "messages": list(request.messages), "temperature": request.temperature,
            "max_tokens": request.max_tokens, "stream": False,
        }
        if request.tools:
            body["tools"] = list(request.tools)
        if request.json_schema:
            body["response_format"] = {"type": "json_schema", "json_schema": {"name": "minemind_response", "strict": True, "schema": request.json_schema}}
        started = time.monotonic()
        async with self._global, self._endpoint_limits[endpoint.id]:
            status, payload = await self.transport.request("POST", endpoint.base_url.rstrip("/") + "/chat/completions", self._headers(endpoint), body, endpoint.timeout_seconds)
        latency = (time.monotonic() - started) * 1000
        if status < 200 or status >= 300:
            raise RouterError(f"completion status {status}")
        try:
            choice = payload["choices"][0]
            message = choice["message"]
        except (KeyError, IndexError, TypeError) as exc:
            raise RouterError("malformed completion response") from exc
        usage = payload.get("usage", {})
        input_tokens = usage.get("prompt_tokens")
        output_tokens = usage.get("completion_tokens")
        self._mark_success(endpoint.id, latency)
        health = self.health[endpoint.id]
        health.completed_calls += 1
        if isinstance(input_tokens, int) and input_tokens >= 0 and isinstance(output_tokens, int) and output_tokens >= 0:
            health.input_tokens += input_tokens
            health.output_tokens += output_tokens
        else:
            health.calls_without_token_usage += 1
        return CompletionResult(
            endpoint.id, model.id, str(message.get("content") or ""), tuple(message.get("tool_calls") or ()),
            latency, input_tokens, output_tokens, choice.get("finish_reason"),
        )

    def _mark_success(self, endpoint_id: str, latency_ms: float) -> None:
        health = self.health[endpoint_id]
        health.failures = 0
        health.circuit_open_until = 0
        health.last_error = None
        if latency_ms:
            health.latency_ema_ms = latency_ms if not health.latency_ema_ms else 0.2 * latency_ms + 0.8 * health.latency_ema_ms

    def _mark_failure(self, endpoint_id: str, error: str) -> None:
        health = self.health[endpoint_id]
        health.failures += 1
        health.last_error = error
        if health.failures >= 3:
            health.circuit_open_until = time.monotonic() + min(60, 2 ** health.failures)

    def status(self) -> dict[str, Any]:
        now = time.monotonic()
        return {endpoint_id: {"models": [model.id for model in self.models[endpoint_id]], "failures": health.failures,
            "circuit_open": health.circuit_open_until > now, "latency_ema_ms": round(health.latency_ema_ms, 1),
            "last_error": health.last_error, "completed_calls": health.completed_calls,
            "input_tokens": health.input_tokens, "output_tokens": health.output_tokens,
            "calls_without_token_usage": health.calls_without_token_usage}
            for endpoint_id, health in self.health.items()}
