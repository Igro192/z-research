import unittest

from minemind_model_router import CompletionRequest, Endpoint, HardwareProfile, ModelRouter, recommend_preset


class FakeTransport:
    def __init__(self):
        self.calls = []

    async def request(self, method, url, headers, body, timeout):
        self.calls.append((method, url, body))
        if url.endswith("/models"):
            return 200, {"data": [{"id": "local-reasoner"}]}
        return 200, {"choices": [{"message": {"content": '{"proposal":"look"}'}, "finish_reason": "stop"}], "usage": {"prompt_tokens": 5, "completion_tokens": 3}}


class RouterTests(unittest.IsolatedAsyncioTestCase):
    async def test_discovers_and_completes(self):
        transport = FakeTransport()
        router = ModelRouter([Endpoint("local", "openai_compatible", "http://localhost/v1")], transport=transport)
        models = await router.discover()
        self.assertEqual(models[0].id, "local-reasoner")
        result = await router.complete(CompletionRequest("critic", ({"role": "user", "content": "inspect"},)))
        self.assertEqual(result.json()["proposal"], "look")
        status = router.status()["local"]
        self.assertEqual(status["completed_calls"], 1)
        self.assertEqual(status["input_tokens"], 5)
        self.assertEqual(status["output_tokens"], 3)
        self.assertEqual(status["calls_without_token_usage"], 0)

    def test_presets_degrade(self):
        self.assertEqual(recommend_preset(HardwareProfile(8, 0, 4, "cpu"))["name"], "minimal")
        self.assertEqual(recommend_preset(HardwareProfile(64, 24, 16, "cuda"))["name"], "maximum")


if __name__ == "__main__":
    unittest.main()
