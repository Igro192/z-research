import asyncio
import unittest

from minemind_model_router import UrllibTransport, RouterError


class TransportTests(unittest.IsolatedAsyncioTestCase):
    async def test_cancel_closes_model_connection_promptly(self):
        received, closed = asyncio.Event(), asyncio.Event()

        async def model(reader, writer):
            await reader.readuntil(b"\r\n\r\n")
            received.set()
            await reader.read()
            closed.set()
            writer.close()

        server = await asyncio.start_server(model, "127.0.0.1", 0)
        async with server:
            url = f"http://127.0.0.1:{server.sockets[0].getsockname()[1]}/model"
            request = asyncio.create_task(UrllibTransport().request("GET", url, {}, None, 45))
            await asyncio.wait_for(received.wait(), 1)
            request.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await request
            await asyncio.wait_for(closed.wait(), 1)

    async def test_reads_chunked_json(self):
        async def model(reader, writer):
            await reader.readuntil(b"\r\n\r\n")
            writer.write(b'HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n6\r\n{"ok":\r\n5\r\ntrue}\r\n0\r\n\r\n')
            await writer.drain()
            writer.close()

        server = await asyncio.start_server(model, "127.0.0.1", 0)
        async with server:
            url = f"http://127.0.0.1:{server.sockets[0].getsockname()[1]}/model"
            status, payload = await UrllibTransport().request("GET", url, {}, None, 1)
            self.assertEqual((status, payload), (200, {"ok": True}))
