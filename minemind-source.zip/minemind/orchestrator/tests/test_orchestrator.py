import unittest

from minemind_orchestrator import CognitiveOrchestrator, Role


async def invoker(role, context):
    if role == Role.CRITIC:
        return {"summary": "safe enough", "choice": {"verdict": "accept"}, "confidence": .8, "risk": .1, "evidence": []}
    return {"summary": f"proposal from {role}", "choice": {"action": "query"}, "confidence": .8, "risk": .1,
            "evidence": [{"id": 1}, {"id": 2}], "assumptions": [], "estimated_cost": 1}


class OrchestratorTests(unittest.IsolatedAsyncioTestCase):
    async def test_high_impact_includes_critic(self):
        orchestrator = CognitiveOrchestrator(invoker)
        decision = await orchestrator.decide(Role.TACTICAL_PLANNER, {}, uncertainty=.6, impact=.9)
        self.assertIsNotNone(decision.selected)
        self.assertIn(Role.CRITIC, {proposal.role for proposal in decision.proposals})

    async def test_economy_mode_uses_one_role_for_ordinary_low_impact_step(self):
        invoked = []

        async def economical(role, context):
            invoked.append(role)
            return {
                "summary": "bounded action",
                "choice": {"action": {"kind": "query", "parameters": {"selector": "local_state"}}},
                "evidence": [], "assumptions": [], "confidence": .8,
                "risk": 0, "estimated_cost": .1,
            }

        decision = await CognitiveOrchestrator(
            economical, max_concurrent=1, economy_mode=True
        ).decide(Role.TACTICAL_PLANNER, {}, uncertainty=.5, impact=.7)
        self.assertIsNotNone(decision.selected)
        self.assertEqual(invoked, [Role.TACTICAL_PLANNER])

    async def test_tactical_prompt_uses_compact_required_output(self):
        supplied = []

        async def inspect(role, context):
            supplied.append(context["required_output"])
            return {
                "choice": {"action": {"kind": "query", "parameters": {"selector": "local_state"}}},
                "confidence": .8, "risk": 0,
            }

        await CognitiveOrchestrator(inspect, max_concurrent=1, economy_mode=True).decide(
            Role.TACTICAL_PLANNER, {}, uncertainty=.2, impact=.2
        )
        self.assertEqual(
            supplied,
            [{"choice": {"action": {"kind": "atomic action", "parameters": {}}},
              "confidence": "0..1", "risk": "0..1"}],
        )

    async def test_economy_mode_does_not_expand_low_impact_uncertain_step(self):
        invoked = []

        async def uncertain(role, context):
            invoked.append(role)
            return {
                "choice": {"action": {"kind": "query", "parameters": {"selector": "local_state"}}},
                "confidence": .3, "risk": .1,
            }

        await CognitiveOrchestrator(uncertain, max_concurrent=1, economy_mode=True).decide(
            Role.TACTICAL_PLANNER, {}, uncertainty=.99, impact=.7
        )
        self.assertEqual(invoked, [Role.TACTICAL_PLANNER])

    def test_reactive_interrupts_and_resumes(self):
        decision = CognitiveOrchestrator.reactive({"player": {"air": 10}}, "plan:v2:m1")
        self.assertEqual(decision.emergency, "drowning")
        self.assertEqual(decision.resume_token, "plan:v2:m1")

    def test_lava_escape_prefers_observed_safe_surface(self):
        decision = CognitiveOrchestrator.reactive({
            "player": {"in_lava": True, "position": {"x": 0.5, "y": 63, "z": 0.5}},
            "nearby_blocks": [
                {"id": "minecraft:lava", "x": 0, "y": 63, "z": 0},
                {"id": "minecraft:stone", "x": 2, "y": 62, "z": 0},
            ],
        }, "plan:v3:escape")
        self.assertEqual(decision.emergency, "lava_escape")
        self.assertEqual(decision.action.kind.value, "navigate")
        self.assertEqual(decision.action.parameters["target"], {"x": 2.5, "y": 63.0, "z": 0.5})

    def test_fire_escape_targets_visible_water(self):
        decision = CognitiveOrchestrator.reactive({
            "player": {"on_fire": True, "position": {"x": 1, "y": 64, "z": 1}},
            "nearby_blocks": [{"id": "minecraft:water", "x": 3, "y": 64, "z": 1}],
        }, "resume")
        self.assertEqual(decision.emergency, "fire_escape")
        self.assertEqual(decision.action.kind.value, "navigate")

    def test_critical_health_does_not_loop_on_empty_inventory(self):
        decision = CognitiveOrchestrator.reactive({
            "player": {"health": 6, "hunger": 15},
            "inventory": [],
        }, "resume")
        self.assertIsNone(decision)

    def test_critical_health_eats_only_when_safe_food_is_observed(self):
        decision = CognitiveOrchestrator.reactive({
            "player": {"health": 6, "hunger": 15},
            "inventory": [{"id": "minecraft:bread", "count": 1}],
        }, "resume")
        self.assertEqual(decision.emergency, "critical_health")
        self.assertEqual(decision.action.kind.value, "use")


if __name__ == "__main__":
    unittest.main()
