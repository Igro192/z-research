from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from enum import StrEnum
import math
from typing import Any, Awaitable, Callable, Mapping, Sequence
from uuid import uuid4

from minemind_protocol import ActionCommand, ActionKind


class Role(StrEnum):
    EXECUTIVE = "executive"
    WORLD_MODEL = "world_model"
    STRATEGIC_PLANNER = "strategic_planner"
    TACTICAL_PLANNER = "tactical_planner"
    EXPLORER = "explorer"
    SKILL_INVENTOR = "skill_inventor"
    CRITIC = "critic"
    VERIFIER = "verifier"
    MEMORY_LIBRARIAN = "memory_librarian"
    LEARNING = "learning"
    REACTIVE_CONTROLLER = "reactive_controller"


@dataclass(slots=True, frozen=True)
class RoleSpec:
    role: Role
    model_selector: str
    max_tokens: int = 1024
    temperature: float = 0.2
    timeout_seconds: float = 90.0


@dataclass(slots=True, frozen=True)
class AgentProposal:
    proposal_id: str
    role: Role
    summary: str
    choice: Mapping[str, Any]
    evidence: tuple[Mapping[str, Any], ...]
    assumptions: tuple[Mapping[str, Any], ...]
    confidence: float
    risk: float
    estimated_cost: float


@dataclass(slots=True, frozen=True)
class Arbitration:
    selected: AgentProposal | None
    proposals: tuple[AgentProposal, ...]
    rejected: tuple[Mapping[str, Any], ...]
    decision_summary: str
    needs_clarification: bool = False


@dataclass(slots=True, frozen=True)
class ReactiveDecision:
    emergency: str
    action: ActionCommand
    resume_token: str


RoleInvoker = Callable[[Role, Mapping[str, Any]], Awaitable[Mapping[str, Any]]]


class CognitiveOrchestrator:
    _SAFE_FOOD_IDS = frozenset({
        "apple", "baked_potato", "beetroot", "beetroot_soup", "bread", "carrot",
        "chorus_fruit", "cooked_beef", "cooked_chicken", "cooked_cod", "cooked_mutton",
        "cooked_porkchop", "cooked_rabbit", "cooked_salmon", "cookie", "dried_kelp",
        "golden_apple", "golden_carrot", "honey_bottle", "melon_slice", "mushroom_stew",
        "potato", "pumpkin_pie", "rabbit_stew", "rotten_flesh", "spider_eye",
        "sweet_berries", "glow_berries", "tropical_fish",
    })

    def __init__(self, invoker: RoleInvoker, role_specs: Sequence[RoleSpec] | None = None,
                 max_concurrent: int = 4, economy_mode: bool = False) -> None:
        self.invoker = invoker
        self.roles = {spec.role: spec for spec in (role_specs or self.default_roles())}
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self.economy_mode = economy_mode

    @staticmethod
    def default_roles() -> tuple[RoleSpec, ...]:
        fast = {Role.WORLD_MODEL, Role.TACTICAL_PLANNER, Role.MEMORY_LIBRARIAN, Role.LEARNING}
        return tuple(RoleSpec(role, "builtin:reactive" if role == Role.REACTIVE_CONTROLLER else ("auto:fast" if role in fast else "auto:reasoning"),
            max_tokens=512 if role in fast else 1536, temperature=0.1 if role in {Role.CRITIC, Role.VERIFIER} else 0.25)
            for role in Role)

    @staticmethod
    def reactive(observation: Mapping[str, Any], resume_token: str) -> ReactiveDecision | None:
        """Non-model emergency policy. It uses only general survival invariants."""
        player = observation.get("player", {})
        events = observation.get("events", [])
        health = float(player.get("health", 20))
        air = int(player.get("air", 300))
        hunger = int(player.get("hunger", 20))
        burning = bool(player.get("on_fire", False))
        in_lava = bool(player.get("in_lava", False))
        imminent_fall = any(event.get("type") == "fall_risk" and float(event.get("severity", 0)) > 0.7 for event in events)
        if in_lava:
            safe_target = CognitiveOrchestrator._nearest_safe_surface(observation)
            if safe_target is not None:
                return ReactiveDecision(
                    "lava_escape",
                    ActionCommand.create(ActionKind.NAVIGATE, {"target": safe_target, "tolerance": 0.8, "maxTicks": 80}, risk=0.1),
                    resume_token,
                )
            return ReactiveDecision("lava_surface", ActionCommand.create(ActionKind.SWIM, {"direction": "up"}, risk=0.15), resume_token)
        if burning:
            water_target = CognitiveOrchestrator._nearest_observed_water(observation)
            if water_target is not None:
                return ReactiveDecision(
                    "fire_escape",
                    ActionCommand.create(ActionKind.NAVIGATE, {"target": water_target, "tolerance": 0.8, "maxTicks": 80}, risk=0.1),
                    resume_token,
                )
        if air < 45:
            return ReactiveDecision("drowning", ActionCommand.create(ActionKind.SWIM, {"direction": "up"}), resume_token)
        if imminent_fall:
            return ReactiveDecision("fall", ActionCommand.create(ActionKind.SNEAK, {"enabled": True}), resume_token)
        # Never preempt useful work with an action whose precondition is known
        # to be false.  The old policy repeatedly issued USE with an empty
        # inventory, starving the objective loop forever after a failed eat.
        if health <= 8 and hunger < 20 and CognitiveOrchestrator._safe_food_available(observation):
            return ReactiveDecision("critical_health", ActionCommand.create(ActionKind.USE, {"selector": "best_safe_food"}), resume_token)
        return None

    @staticmethod
    def _safe_food_available(observation: Mapping[str, Any]) -> bool:
        inventory = observation.get("inventory", ())
        if not isinstance(inventory, Sequence) or isinstance(inventory, (str, bytes)):
            player = observation.get("player", {})
            inventory = player.get("inventory", ()) if isinstance(player, Mapping) else ()
        for stack in inventory:
            if not isinstance(stack, Mapping) or int(stack.get("count", 0)) <= 0:
                continue
            item_id = str(stack.get("id", stack.get("item", ""))).lower().removeprefix("minecraft:")
            if item_id in CognitiveOrchestrator._SAFE_FOOD_IDS:
                return True
        return False

    @staticmethod
    def _nearest_observed_water(observation: Mapping[str, Any]) -> Mapping[str, float] | None:
        return CognitiveOrchestrator._nearest_block_target(
            observation,
            lambda block_id: block_id in {"minecraft:water", "minecraft:bubble_column"},
            stand_above=False,
        )

    @staticmethod
    def _nearest_safe_surface(observation: Mapping[str, Any]) -> Mapping[str, float] | None:
        dangerous = {
            "minecraft:lava", "minecraft:fire", "minecraft:soul_fire", "minecraft:magma_block",
            "minecraft:cactus", "minecraft:sweet_berry_bush", "minecraft:powder_snow",
        }
        blocks = tuple(item for item in observation.get("nearby_blocks", observation.get("nearbyBlocks", ())) if isinstance(item, Mapping))
        occupied = {(int(item.get("x", 0)), int(item.get("y", 0)), int(item.get("z", 0))): str(item.get("id", "")) for item in blocks}
        player = observation.get("player", {})
        position = player.get("position", {}) if isinstance(player, Mapping) else {}
        px, py, pz = (float(position.get(axis, 0.0)) for axis in ("x", "y", "z")) if isinstance(position, Mapping) else (0.0, 0.0, 0.0)
        candidates: list[tuple[float, Mapping[str, float]]] = []
        for (x, y, z), block_id in occupied.items():
            if not block_id or block_id in dangerous or block_id in {"minecraft:water", "minecraft:bubble_column"}:
                continue
            if (x, y + 1, z) in occupied or (x, y + 2, z) in occupied:
                continue
            distance = (x + 0.5 - px) ** 2 + (y + 1.0 - py) ** 2 + (z + 0.5 - pz) ** 2
            if distance < 0.5:
                continue
            candidates.append((distance, {"x": x + 0.5, "y": y + 1.0, "z": z + 0.5}))
        return min(candidates, key=lambda item: item[0])[1] if candidates else None

    @staticmethod
    def _nearest_block_target(observation: Mapping[str, Any], predicate: Callable[[str], bool], *, stand_above: bool) -> Mapping[str, float] | None:
        blocks = tuple(item for item in observation.get("nearby_blocks", observation.get("nearbyBlocks", ())) if isinstance(item, Mapping))
        player = observation.get("player", {})
        position = player.get("position", {}) if isinstance(player, Mapping) else {}
        px, py, pz = (float(position.get(axis, 0.0)) for axis in ("x", "y", "z")) if isinstance(position, Mapping) else (0.0, 0.0, 0.0)
        candidates: list[tuple[float, Mapping[str, float]]] = []
        for item in blocks:
            if not predicate(str(item.get("id", ""))):
                continue
            x, y, z = float(item.get("x", 0)), float(item.get("y", 0)), float(item.get("z", 0))
            target = {"x": x + 0.5, "y": y + (1.0 if stand_above else 0.2), "z": z + 0.5}
            candidates.append(((target["x"] - px) ** 2 + (target["y"] - py) ** 2 + (target["z"] - pz) ** 2, target))
        return min(candidates, key=lambda item: item[0])[1] if candidates else None

    async def _invoke(self, role: Role, context: Mapping[str, Any]) -> AgentProposal:
        if role == Role.TACTICAL_PLANNER:
            # Small local models are materially faster and more reliable when
            # the prompt mirrors the compact schema instead of asking them to
            # narrate a second, unused copy of the decision contract.
            required_output = {
                "choice": {"action": {"kind": "atomic action", "parameters": {}}},
                "confidence": "0..1", "risk": "0..1",
            }
        else:
            required_output = {
                "proposal_id": "optional stable id",
                "summary": "concise decision summary without chain-of-thought",
                "choice": ({"verdict": "accept|reject|unsafe|unsupported", "target_proposal_id": "optional"}
                           if role == Role.CRITIC else
                           ({"verified": "boolean"} if role == Role.VERIFIER else
                            {"action": {"kind": "one listed atomic action", "parameters": {}},
                             "predicted_effects": [{"path": "observable path", "value": "expected value"}],
                             "alternatives": []})),
                "evidence": [{"source_id": "supplied evidence identifier", "claim": "supported claim"}],
                "assumptions": [{"claim": "unverified assumption", "confidence": "0..1"}],
                "confidence": "0..1", "risk": "0..1", "estimated_cost": "nonnegative",
            }
        async with self._semaphore:
            raw = await self.invoker(role, {**dict(context), "required_output": required_output})
        confidence = max(0.0, min(1.0, float(raw.get("confidence", 0))))
        risk = max(0.0, min(1.0, float(raw.get("risk", 0))))
        return AgentProposal(
            str(raw.get("proposal_id") or uuid4()), role, str(raw.get("summary", "")),
            dict(raw.get("choice", {})), tuple(raw.get("evidence", ())), tuple(raw.get("assumptions", ())),
            confidence, risk, max(0.0, float(raw.get("estimated_cost", 1))),
        )

    async def solicit(self, primary_role: Role, context: Mapping[str, Any], *, uncertainty: float, impact: float) -> tuple[AgentProposal, ...]:
        roles = [primary_role]
        # On a memory-constrained machine, role diversity is scheduled only
        # when uncertainty or impact justifies the extra inference.  All roles
        # remain available; ordinary low-impact steps no longer queue three
        # copies of the same local model before the first action can run.
        explorer_threshold = 0.8 if self.economy_mode else 0.35
        alternate_threshold = 0.95 if self.economy_mode else 0.65
        critic_uncertainty = 0.85 if self.economy_mode else 0.5
        critic_impact = 0.8 if self.economy_mode else 0.5
        if self.economy_mode:
            # On a one-model machine, high uncertainty must not turn every
            # ordinary movement/mining decision into four serial generations.
            # High-impact actions still receive independent criticism; the
            # safety gate and trusted post-action verifier remain mandatory.
            if impact >= critic_impact:
                roles.append(Role.CRITIC)
        else:
            if uncertainty >= explorer_threshold:
                roles.append(Role.EXPLORER)
            if uncertainty >= alternate_threshold:
                roles.append(Role.STRATEGIC_PLANNER if primary_role != Role.STRATEGIC_PLANNER else Role.TACTICAL_PLANNER)
            if impact >= critic_impact or uncertainty >= critic_uncertainty:
                roles.append(Role.CRITIC)
        # Keep role order stable for deterministic tests while executing concurrently.
        roles = list(dict.fromkeys(roles))
        results = await asyncio.gather(*(self._invoke(role, context) for role in roles), return_exceptions=True)
        proposals = tuple(result for result in results if isinstance(result, AgentProposal))
        if not proposals:
            errors = [str(result) for result in results if isinstance(result, Exception)]
            raise RuntimeError("all cognitive roles failed: " + "; ".join(errors))
        return proposals

    @staticmethod
    def _fingerprint(choice: Mapping[str, Any]) -> str:
        import json
        return json.dumps(choice, sort_keys=True, separators=(",", ":"))

    async def arbitrate(self, proposals: Sequence[AgentProposal], context: Mapping[str, Any], *, impact: float) -> Arbitration:
        candidates = [proposal for proposal in proposals if proposal.role != Role.CRITIC]
        critics = [proposal for proposal in proposals if proposal.role == Role.CRITIC]
        if not candidates:
            return Arbitration(None, tuple(proposals), (), "No executable proposal survived role execution.", True)
        rejection: list[Mapping[str, Any]] = []
        scored: list[tuple[float, AgentProposal]] = []
        for proposal in candidates:
            evidence_quality = min(1.0, len(proposal.evidence) / 3)
            assumption_penalty = min(0.4, len(proposal.assumptions) * 0.08)
            score = 0.55 * proposal.confidence + 0.25 * evidence_quality - 0.45 * proposal.risk - assumption_penalty - 0.02 * math.log1p(proposal.estimated_cost)
            objections = [critic for critic in critics if critic.choice.get("target_proposal_id") in (None, proposal.proposal_id)
                          and critic.choice.get("verdict") in {"reject", "unsafe", "unsupported"}]
            score -= sum(0.2 + 0.3 * critic.confidence for critic in objections)
            if objections:
                rejection.append({"proposal_id": proposal.proposal_id, "objections": [critic.summary for critic in objections]})
            scored.append((score, proposal))
        scored.sort(key=lambda item: (-item[0], item[1].proposal_id))
        best_score, best = scored[0]
        unique_choices = {self._fingerprint(proposal.choice) for proposal in candidates}
        needs_clarification = best_score < 0 or (impact >= 0.8 and not critics)
        summary = f"Selected {best.role.value} proposal from {len(candidates)} candidates using confidence, evidence, risk, assumptions, cost, and critic objections."
        if len(unique_choices) > 1:
            summary += " Materially different alternatives were considered."
        if needs_clarification:
            summary = "No proposal cleared the evidence/risk threshold; clarification or safer evidence gathering is required."
        return Arbitration(None if needs_clarification else best, tuple(proposals), tuple(rejection), summary, needs_clarification)

    async def decide(self, primary_role: Role, context: Mapping[str, Any], *, uncertainty: float, impact: float) -> Arbitration:
        proposals = await self.solicit(primary_role, context, uncertainty=uncertainty, impact=impact)
        return await self.arbitrate(proposals, context, impact=impact)

    async def verify(self, claim: Mapping[str, Any], evidence: Sequence[Mapping[str, Any]]) -> AgentProposal:
        return await self._invoke(Role.VERIFIER, {
            "instruction": "Independently evaluate only the supplied observable evidence. Never infer success from plan completion or model assertions.",
            "claim": dict(claim), "evidence": list(evidence),
        })
