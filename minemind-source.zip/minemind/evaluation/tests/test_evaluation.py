import tempfile
import unittest
import json
from dataclasses import replace
from contextlib import redirect_stderr, redirect_stdout
from io import StringIO
from pathlib import Path

from minemind_evaluation import (
    AttemptTelemetry,
    BeatMinecraftVerifier,
    EvaluationEvent,
    EvaluationRunner,
    beat_minecraft_suite,
)
from minemind_evaluation.cli import main
from minemind_evaluation.fabric import _decode_journal, _journal_provenance, _trusted_deaths, _trusted_nonnegative_number


def telemetry(trusted=True, claimed=True):
    fight = "fight-1"
    player = "agent-player"
    events = (
        EvaluationEvent(BeatMinecraftVerifier.DRAGON, 100, {"fight_id": fight}, trusted, "dragon"),
        EvaluationEvent(BeatMinecraftVerifier.PORTAL, 101, {"fight_id": fight}, trusted, "portal"),
        EvaluationEvent(BeatMinecraftVerifier.COMPLETION, 120, {"fight_id": fight, "player_id": player}, trusted, "complete"),
    )
    return AttemptTelemetry(
        claimed,
        {"dragon_fight": {"previously_killed": True, "exit_portal_active": True}, "evaluated_player_id": player},
        events,
        1000,
        0,
        False,
        20,
        2000,
        0,
        3,
        ("learned.skill",),
        ("old.skill",),
        100,
    )


class Agent:
    async def attempt(self, instruction, seed, budget):
        self.last_instruction = instruction
        return telemetry()


class BrokenAgent:
    async def attempt(self, instruction, seed, budget):
        raise RuntimeError("server failed to start")


class EvaluationTest(unittest.TestCase):
    def test_beat_verifier_requires_trusted_correlated_events(self):
        verifier = BeatMinecraftVerifier()
        self.assertTrue(verifier.verify(telemetry()).success)
        self.assertFalse(verifier.verify(telemetry(trusted=False)).success)

    def test_agent_receives_only_open_ended_instruction(self):
        import asyncio

        with tempfile.TemporaryDirectory() as directory:
            agent = Agent()
            runner = EvaluationRunner(agent, Path(directory) / "eval.sqlite3")
            suite = beat_minecraft_suite()
            self.assertEqual(suite.tasks[0].budget.wall_seconds, 7_200)
            one_seed_task = suite.tasks[0]
            one_seed_suite = type(suite)(suite.suite_id, suite.protocol_version, (type(one_seed_task)(
                one_seed_task.task_id,
                one_seed_task.instruction,
                (one_seed_task.seeds[0],),
                one_seed_task.budget,
                one_seed_task.verifier,
                one_seed_task.success_contract,
                one_seed_task.tags,
            ),), True, False)
            results = asyncio.run(runner.run(one_seed_suite))
            self.assertEqual(agent.last_instruction, "Beat Minecraft.")
            self.assertTrue(results[0].verified_success)
            report = runner.summarize(suite.suite_id, results)
            self.assertEqual(report.completion_rate, 1.0)
            runner.close()

    def test_zero_attempts_are_not_measured(self):
        with tempfile.TemporaryDirectory() as directory:
            runner = EvaluationRunner(Agent(), Path(directory) / "eval.sqlite3")
            report = runner.summarize("empty", ())
            self.assertEqual(report.measurement_status, "not_measured")
            self.assertIsNone(report.completion_rate)
            self.assertIsNone(report.replans)
            runner.close()

    def test_infrastructure_failure_is_not_a_measured_game_attempt(self):
        import asyncio
        from minemind_evaluation import diagnostic_suite

        with tempfile.TemporaryDirectory() as directory:
            runner = EvaluationRunner(BrokenAgent(), Path(directory) / "eval.sqlite3")
            suite = diagnostic_suite()
            one = replace(suite, tasks=(replace(suite.tasks[0], seeds=(1,)),))
            results = asyncio.run(runner.run(one))
            report = runner.summarize(suite.suite_id, results)
            self.assertEqual(report.measurement_status, "not_measured")
            self.assertEqual(report.attempts, 0)
            self.assertEqual(report.infrastructure_failures, 1)
            runner.close()

    def test_smoke_cli_is_labelled_simulated_and_resumes(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "metrics"
            arguments = ["smoke", "--output-dir", str(output), "--seed", "42", "--resume"]
            with redirect_stdout(StringIO()):
                self.assertEqual(main(arguments), 0)
                self.assertEqual(main(arguments), 0)
            summary = json.loads((output / "summary.json").read_text())
            self.assertTrue(summary["metadata"]["simulated"])
            self.assertFalse(summary["metadata"]["real_minecraft_measured"])
            self.assertEqual(summary["metadata"]["newly_executed_attempts"], 0)
            self.assertEqual(summary["metrics"]["attempts"], 4)
            connection = __import__("sqlite3").connect(output / "results.sqlite3")
            try:
                provenance = connection.execute(
                    "SELECT DISTINCT run_mode,simulated,real_minecraft_measured FROM evaluation_results"
                ).fetchall()
            finally:
                connection.close()
            self.assertEqual(provenance, [("deterministic_smoke", 1, 0)])

    def test_smoke_refuses_beat_minecraft(self):
        with tempfile.TemporaryDirectory() as directory, redirect_stderr(StringIO()):
            result = main(["smoke", "--suite", "beat-minecraft", "--output-dir", directory])
            self.assertEqual(result, 2)
            self.assertFalse((Path(directory) / "summary.json").exists())

    def test_only_server_journal_entries_are_trusted(self):
        raw = (
            {"protocol_version": "1.0.0", "source": "model", "event_type": "minecraft:end_dragon_defeated", "game_tick": 1, "event_id": "bad", "payload": {}},
            {"protocol_version": "1.0.0", "source": "fabric_server", "event_type": "minemind:authoritative_snapshot", "game_tick": 2, "event_id": "state", "payload": {"state": {"player": {"alive": True}}}},
        )
        events, state = _decode_journal(raw)
        self.assertFalse(events[0].trusted_server_event)
        self.assertTrue(events[1].trusted_server_event)
        self.assertTrue(state["player"]["alive"])

    def test_deaths_and_resource_waste_come_from_trusted_snapshot(self):
        raw = ({
            "protocol_version": "1.0.0",
            "source": "fabric_server",
            "event_type": "minemind:authoritative_snapshot",
            "game_tick": 2,
            "event_id": "state",
            "payload": {"state": {"evaluated_player_id": "agent", "evaluation_metrics": {"deaths": 2, "resources_wasted": 3.5}}},
        },)
        events, state = _decode_journal(raw)
        self.assertEqual(_trusted_deaths(events, state), 2)
        self.assertEqual(_trusted_nonnegative_number(state, "resources_wasted"), 3.5)

    def test_real_journal_requires_expected_world_session_and_separate_bot_actor(self):
        raw = ({
            "protocol_version": "1.0.0", "source": "fabric_server",
            "event_type": "minemind:authoritative_snapshot", "game_tick": 2,
            "event_id": "state", "payload": {
                "world_id": "world-1", "world_session_id": "session-1",
                "state": {
                    "evaluated_player_id": "bot-1", "bot_uuid": "bot-1",
                    "evaluated_player_role": "minemind_ai",
                    "embodiment_mode": "SEPARATE_LOCAL_PLAYER",
                },
            },
        },)
        events, state = _decode_journal(raw, expected_world_id="world-1")
        provenance = _journal_provenance(events, state, "world-1")
        self.assertTrue(events[0].trusted_server_event)
        self.assertTrue(provenance["verified"])
        wrong_events, _ = _decode_journal(raw, expected_world_id="another-world")
        self.assertFalse(wrong_events[0].trusted_server_event)

    def test_fabric_run_without_actor_provenance_is_not_measured(self):
        import asyncio
        from minemind_evaluation import diagnostic_suite

        with tempfile.TemporaryDirectory() as directory:
            runner = EvaluationRunner(Agent(), Path(directory) / "eval.sqlite3", run_mode="fabric")
            suite = diagnostic_suite()
            one = replace(suite, tasks=(replace(suite.tasks[0], seeds=(1,)),))
            results = asyncio.run(runner.run(one))
            self.assertFalse(results[0].verified_success)
            self.assertFalse(results[0].real_minecraft_measured)
            report = runner.summarize(one.suite_id, results)
            self.assertEqual(report.measurement_status, "not_measured")
            self.assertEqual(report.attempts, 0)
            runner.close()

    def test_legacy_real_rows_are_preserved_but_demoted_without_actor_provenance(self):
        import sqlite3

        with tempfile.TemporaryDirectory() as directory:
            database_path = Path(directory) / "legacy.sqlite3"
            database = sqlite3.connect(database_path)
            with database:
                database.execute("""CREATE TABLE evaluation_results(
                    suite_id TEXT NOT NULL,task_id TEXT NOT NULL,seed INTEGER NOT NULL,
                    attempt_index INTEGER NOT NULL,verified_success INTEGER NOT NULL,
                    false_success INTEGER NOT NULL,budget_exhausted INTEGER NOT NULL,
                    telemetry_json TEXT NOT NULL,verification_reason TEXT NOT NULL,
                    evidence_json TEXT NOT NULL,recorded_at REAL NOT NULL,
                    definition_hash TEXT NOT NULL DEFAULT '',run_mode TEXT NOT NULL DEFAULT 'fabric',
                    simulated INTEGER NOT NULL DEFAULT 0,real_minecraft_measured INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY(suite_id,task_id,seed,attempt_index))""")
                database.execute(
                    "INSERT INTO evaluation_results VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    ("s", "t", 1, 0, 1, 0, 0, "{}", "legacy", "[]", 1.0, "h", "fabric", 0, 1),
                )
            database.close()
            runner = EvaluationRunner(Agent(), database_path, run_mode="fabric")
            row = runner.database.execute(
                "SELECT real_minecraft_measured,evidence_provenance_json FROM evaluation_results"
            ).fetchone()
            self.assertEqual(tuple(row), (0, "{}"))
            runner.close()

    def test_resume_rejects_changed_budget_definition(self):
        import asyncio
        from minemind_evaluation import diagnostic_suite

        with tempfile.TemporaryDirectory() as directory:
            runner = EvaluationRunner(Agent(), Path(directory) / "eval.sqlite3")
            suite = diagnostic_suite()
            task = replace(suite.tasks[0], seeds=(1,))
            one = replace(suite, tasks=(task,))
            asyncio.run(runner.run(one, resume=True))
            changed = replace(one, tasks=(replace(task, budget=replace(task.budget, max_actions=9)),))
            with self.assertRaises(ValueError):
                asyncio.run(runner.run(changed, resume=True))
            runner.close()

    def test_init_fabric_config_is_explicit_about_eula(self):
        with tempfile.TemporaryDirectory() as directory, redirect_stdout(StringIO()), redirect_stderr(StringIO()):
            config = Path(directory) / "fabric.json"
            self.assertEqual(main(["init-fabric-config", "--output", str(config)]), 0)
            payload = json.loads(config.read_text())
            self.assertFalse(payload["server"]["eula_accepted"])
            self.assertEqual(payload["agent_runtime"]["base_url"], "http://127.0.0.1:8080")
            self.assertEqual(main(["init-fabric-config", "--output", str(config)]), 2)

    def test_fabric_without_client_driver_writes_not_measured_artifact(self):
        with tempfile.TemporaryDirectory() as directory, redirect_stdout(StringIO()):
            root = Path(directory)
            config = root / "fabric.json"
            self.assertEqual(main(["init-fabric-config", "--output", str(config)]), 0)
            output = root / "metrics"
            self.assertEqual(main([
                "run-fabric", "--config", str(config), "--suite", "beat-minecraft",
                "--seed", "42", "--output-dir", str(output),
            ]), 2)
            summary = json.loads((output / "summary.json").read_text(encoding="utf-8"))
            self.assertEqual(summary["metadata"]["measurement_status"], "not_measured")
            self.assertFalse(summary["metadata"]["real_minecraft_measured"])
            self.assertFalse(summary["metadata"]["simulated"])
            self.assertEqual(summary["metrics"]["attempts"], 0)
            self.assertIsNone(summary["metrics"]["completion_rate"])
            self.assertIn("client driver", summary["metadata"]["not_measured_reason"])
            self.assertEqual((output / "attempts.jsonl").read_text(encoding="utf-8"), "")


if __name__ == "__main__":
    unittest.main()
