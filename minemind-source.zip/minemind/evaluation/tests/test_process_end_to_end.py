import asyncio
import json
import sys
import tempfile
import threading
import unittest
from dataclasses import replace
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from minemind_evaluation import EvaluationRunner, beat_minecraft_suite
from minemind_evaluation.artifacts import write_metrics
from minemind_evaluation.fabric import FabricEvaluationAgent
from minemind_training_lab import (
    JavaServerBackend,
    JavaServerConfig,
    RuntimeBridgeClient,
    WorldProvisioner,
)


class _RuntimeHandler(BaseHTTPRequestHandler):
    requests = []

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        payload = json.loads(self.rfile.read(length))
        type(self).requests.append(payload)
        response = json.dumps({
            "claimed_success": False,
            "elapsed_seconds": 0.1,
            "deaths": None,
            "unrecoverable_failure": False,
            "model_calls": 1,
            "tokens": None,
            "resources_wasted": None,
            "replans": None,
            "new_skills": [],
            "transferred_skills_used": [],
            "actions": 0,
            "failure": "offline fixture deliberately does not solve the objective",
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)

    def log_message(self, format, *args):
        return


class ProcessEndToEndTest(unittest.TestCase):
    def test_server_client_runtime_journal_resume_and_cleanup(self):
        fixture = (
            Path(__file__).parents[2]
            / "training-lab"
            / "tests"
            / "fixtures"
            / "deterministic_process.py"
        ).resolve()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            template = root / "server-template"
            template.mkdir()
            (template / "template-marker.txt").write_text("not world state", encoding="utf-8")
            worlds = root / "worlds"
            runtime_server = ThreadingHTTPServer(("127.0.0.1", 0), _RuntimeHandler)
            _RuntimeHandler.requests = []
            thread = threading.Thread(target=runtime_server.serve_forever, daemon=True)
            thread.start()
            try:
                backend = JavaServerBackend(
                    WorldProvisioner(worlds, template),
                    JavaServerConfig(
                        command=(sys.executable, str(fixture), "server"),
                        endpoint="127.0.0.1:25575",
                        ready_text="Done (offline fixture)",
                        startup_timeout_seconds=5,
                        stop_timeout_seconds=5,
                        eula_accepted=True,
                        client_command=(
                            sys.executable,
                            str(fixture),
                            "client",
                            "{server_endpoint}",
                            "{world_id}",
                        ),
                        client_stop_command="quit",
                        require_client=True,
                    ),
                )
                bridge = RuntimeBridgeClient(
                    f"http://127.0.0.1:{runtime_server.server_port}", timeout_seconds=2
                )
                agent = FabricEvaluationAgent(backend, bridge)
                database = root / "results.sqlite3"
                suite = beat_minecraft_suite()
                task = replace(suite.tasks[0], seeds=(8675309,))
                suite = replace(suite, tasks=(task,))
                with EvaluationRunner(
                    agent, database, run_mode="offline_process_fixture"
                ) as runner:
                    first = asyncio.run(runner.run(suite, resume=True))
                    second = asyncio.run(runner.run(suite, resume=True))
                    persisted = runner.load_results(suite.suite_id)
                    report = runner.summarize(suite.suite_id, persisted)
                self.assertEqual(len(first), 1)
                self.assertEqual(second, ())
                self.assertFalse(first[0].verified_success)
                self.assertTrue(first[0].telemetry.trusted_journal_observed)
                self.assertFalse(first[0].real_minecraft_measured)
                self.assertTrue(first[0].simulated)
                self.assertEqual(_RuntimeHandler.requests[0]["objective"], "Beat Minecraft.")
                self.assertNotIn("seed", _RuntimeHandler.requests[0])
                self.assertNotIn("success_contract", _RuntimeHandler.requests[0])
                self.assertEqual(list(worlds.iterdir()), [])
                paths = write_metrics(
                    root / "metrics",
                    suite,
                    persisted,
                    report,
                    run_mode="offline_process_fixture",
                    newly_executed=1,
                )
                summary = json.loads(paths["summary"].read_text(encoding="utf-8"))
                self.assertFalse(summary["metadata"]["real_minecraft_measured"])
            finally:
                runtime_server.shutdown()
                runtime_server.server_close()
                thread.join(timeout=2)

    def test_world_bearing_template_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            template = root / "template" / "world"
            template.mkdir(parents=True)
            (template / "level.dat").write_bytes(b"forbidden")
            with self.assertRaises(ValueError):
                WorldProvisioner(root / "training", template.parent)


if __name__ == "__main__":
    unittest.main()
