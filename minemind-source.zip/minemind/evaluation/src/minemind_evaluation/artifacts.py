from __future__ import annotations

import json
import os
import tempfile
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Mapping, Sequence

from .models import EvaluationResult, EvaluationSuite
from .runner import SuiteReport


def write_metrics(
    output_directory: str | Path,
    suite: EvaluationSuite,
    results: Sequence[EvaluationResult],
    report: SuiteReport,
    *,
    run_mode: str,
    newly_executed: int,
    not_measured_reason: str | None = None,
) -> Mapping[str, Path]:
    destination = Path(output_directory)
    destination.mkdir(parents=True, exist_ok=True)
    is_real = any(result.real_minecraft_measured for result in results)
    metadata = {
        "schema_version": "1.0.0",
        "suite_id": suite.suite_id,
        "suite_protocol_version": suite.protocol_version,
        "run_mode": run_mode,
        "simulated": run_mode in {"deterministic_smoke", "offline_process_fixture"},
        "real_minecraft_measured": is_real,
        "measurement_status": report.measurement_status,
        "persisted_records": len(results),
        "persisted_attempts": report.attempts,
        "newly_executed_attempts": newly_executed,
        "generated_at": time.time(),
        "agent_received_success_contract": suite.agent_receives_contract,
        "not_measured_reason": not_measured_reason,
    }
    summary_path = destination / "summary.json"
    jsonl_path = destination / "attempts.jsonl"
    _atomic_json(summary_path, {"metadata": metadata, "metrics": asdict(report)})
    _atomic_jsonl(
        jsonl_path,
        ({"metadata": metadata, "result": asdict(result)} for result in results),
    )
    return {"summary": summary_path, "attempts": jsonl_path}


def _atomic_json(destination: Path, value: Any) -> None:
    descriptor, temporary = tempfile.mkstemp(prefix=f".{destination.name}.", dir=destination.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, sort_keys=True, indent=2, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, destination)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def _atomic_jsonl(destination: Path, values: Sequence[Any] | Any) -> None:
    descriptor, temporary = tempfile.mkstemp(prefix=f".{destination.name}.", dir=destination.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            for value in values:
                handle.write(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False))
                handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, destination)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise
