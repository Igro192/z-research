from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class TaskBudget:
    wall_seconds: float
    max_actions: int
    max_model_calls: int
    max_tokens: int
    max_deaths: int

    def __post_init__(self) -> None:
        if self.wall_seconds <= 0:
            raise ValueError("wall_seconds must be positive")
        if min(self.max_actions, self.max_model_calls, self.max_tokens, self.max_deaths) < 0:
            raise ValueError("budget counters cannot be negative")


@dataclass(frozen=True, slots=True)
class EvaluationEvent:
    event_type: str
    game_tick: int
    payload: Mapping[str, Any]
    trusted_server_event: bool
    event_id: str
    world_id: str | None = None
    world_session_id: str | None = None
    actor_id: str | None = None


@dataclass(frozen=True, slots=True)
class BenchmarkTask:
    task_id: str
    instruction: str
    seeds: tuple[int, ...]
    budget: TaskBudget
    verifier: str
    success_contract: Mapping[str, Any] = field(default_factory=dict)
    tags: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class EvaluationSuite:
    suite_id: str
    protocol_version: str
    tasks: tuple[BenchmarkTask, ...]
    clean_world_per_attempt: bool = True
    agent_receives_contract: bool = False


@dataclass(frozen=True, slots=True)
class AttemptTelemetry:
    claimed_success: bool
    final_state: Mapping[str, Any]
    events: tuple[EvaluationEvent, ...]
    elapsed_seconds: float
    deaths: int | None
    unrecoverable_failure: bool
    model_calls: int
    tokens: int | None
    resources_wasted: float | None
    replans: int | None
    new_skills: tuple[str, ...]
    transferred_skills_used: tuple[str, ...]
    actions: int
    environment_started: bool = True
    trusted_journal_observed: bool = False
    attempt_index: int = 0
    failure: str | None = None
    trusted_provenance_verified: bool = False
    evidence_provenance: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class EvaluationResult:
    suite_id: str
    task_id: str
    seed: int
    telemetry: AttemptTelemetry
    verified_success: bool
    verification_reason: str
    evidence_event_ids: tuple[str, ...]
    false_success_claim: bool
    budget_exhausted: bool
    run_mode: str = "unspecified"
    simulated: bool = False
    real_minecraft_measured: bool = False
    evidence_provenance: Mapping[str, Any] = field(default_factory=dict)
    recorded_at: float = field(default_factory=time.time)
