from __future__ import annotations

import asyncio
import hashlib
import json
import sqlite3
import statistics
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Iterable, Protocol

from .models import AttemptTelemetry, BenchmarkTask, EvaluationEvent, EvaluationResult, EvaluationSuite
from .verifiers import BeatMinecraftVerifier, ContractVerifier


class EvaluationAgent(Protocol):
    async def attempt(self, instruction: str, seed: int, budget: object) -> AttemptTelemetry: ...


@dataclass(frozen=True, slots=True)
class SuiteReport:
    suite_id: str
    measurement_status: str
    attempts: int
    completion_rate: float | None
    median_completion_seconds: float | None
    deaths: int | None
    unrecoverable_failures: int
    model_calls: int
    tokens: int | None
    resources_wasted: float | None
    replans: int | None
    new_skills_created: int
    transferred_skills_used: int
    false_success_claims: int
    budget_exhaustions: int
    infrastructure_failures: int
    improvement_by_attempt: tuple[float, ...]
    mastered_task_regressions: int


class EvaluationRunner:
    def __init__(
        self,
        agent: EvaluationAgent,
        database: str | Path,
        *,
        run_mode: str = "unspecified",
    ) -> None:
        if run_mode not in {
            "unspecified", "deterministic_smoke", "offline_process_fixture", "fabric"
        }:
            raise ValueError(f"unsupported evaluation run mode {run_mode!r}")
        self.agent = agent
        self.run_mode = run_mode
        self.database = sqlite3.connect(database, isolation_level=None)
        self.database.row_factory = sqlite3.Row
        self.database.execute("PRAGMA journal_mode=WAL")
        self.database.execute(
            """CREATE TABLE IF NOT EXISTS evaluation_results(
                suite_id TEXT NOT NULL, task_id TEXT NOT NULL, seed INTEGER NOT NULL,
                attempt_index INTEGER NOT NULL, verified_success INTEGER NOT NULL,
                false_success INTEGER NOT NULL, budget_exhausted INTEGER NOT NULL,
                telemetry_json TEXT NOT NULL, verification_reason TEXT NOT NULL,
                evidence_json TEXT NOT NULL, recorded_at REAL NOT NULL,
                definition_hash TEXT NOT NULL DEFAULT '',
                run_mode TEXT NOT NULL DEFAULT 'legacy_unspecified',
                simulated INTEGER NOT NULL DEFAULT 0,
                real_minecraft_measured INTEGER NOT NULL DEFAULT 0,
                evidence_provenance_json TEXT NOT NULL DEFAULT '{}',
                evaluated_actor_id TEXT,
                world_id TEXT,
                world_session_id TEXT,
                PRIMARY KEY(suite_id,task_id,seed,attempt_index)
            )"""
        )
        columns = {
            str(row[1]) for row in self.database.execute("PRAGMA table_info(evaluation_results)").fetchall()
        }
        legacy_without_actor_provenance = "evidence_provenance_json" not in columns
        if "definition_hash" not in columns:
            self.database.execute(
                "ALTER TABLE evaluation_results ADD COLUMN definition_hash TEXT NOT NULL DEFAULT ''"
            )
        for name, declaration in (
            ("run_mode", "TEXT NOT NULL DEFAULT 'legacy_unspecified'"),
            ("simulated", "INTEGER NOT NULL DEFAULT 0"),
            ("real_minecraft_measured", "INTEGER NOT NULL DEFAULT 0"),
            ("evidence_provenance_json", "TEXT NOT NULL DEFAULT '{}'"),
            ("evaluated_actor_id", "TEXT"),
            ("world_id", "TEXT"),
            ("world_session_id", "TEXT"),
        ):
            if name not in columns:
                self.database.execute(
                    f"ALTER TABLE evaluation_results ADD COLUMN {name} {declaration}"
                )
        self.database.execute(
            "CREATE TABLE IF NOT EXISTS evaluation_schema_migrations(version INTEGER PRIMARY KEY, applied_at REAL NOT NULL)"
        )
        self.database.execute(
            "INSERT OR IGNORE INTO evaluation_schema_migrations(version,applied_at) VALUES(2,?)",
            (time.time(),),
        )
        if legacy_without_actor_provenance:
            # Preserve legacy telemetry, but do not let rows created before actor
            # provenance existed continue to claim real-Minecraft measurement.
            self.database.execute(
                "UPDATE evaluation_results SET real_minecraft_measured=0 WHERE evidence_provenance_json='{}'"
            )
        self.contract_verifier = ContractVerifier()
        self.beat_verifier = BeatMinecraftVerifier()

    async def run(
        self,
        suite: EvaluationSuite,
        *,
        resume: bool = False,
        attempt_index: int = 0,
    ) -> tuple[EvaluationResult, ...]:
        results: list[EvaluationResult] = []
        for task in suite.tasks:
            for seed in task.seeds:
                definition_hash = self._definition_hash(suite, task)
                if resume and self._exists(
                    suite.suite_id, task.task_id, seed, attempt_index, definition_hash
                ):
                    continue
                started = time.monotonic()
                try:
                    telemetry = await asyncio.wait_for(
                        self.agent.attempt(task.instruction, seed, task.budget),
                        timeout=task.budget.wall_seconds + 30,
                    )
                except asyncio.TimeoutError:
                    telemetry = AttemptTelemetry(
                        False, {}, (), time.monotonic() - started, None, True, task.budget.max_model_calls,
                        None, None, None, (), (), task.budget.max_actions,
                        failure="evaluation wall-clock timeout",
                    )
                except Exception as error:
                    telemetry = AttemptTelemetry(
                        claimed_success=False,
                        final_state={},
                        events=(),
                        elapsed_seconds=time.monotonic() - started,
                        deaths=None,
                        unrecoverable_failure=True,
                        model_calls=0,
                        tokens=None,
                        resources_wasted=None,
                        replans=None,
                        new_skills=(),
                        transferred_skills_used=(),
                        actions=0,
                        environment_started=False,
                        failure=f"evaluation infrastructure failed: {type(error).__name__}: {error}",
                    )
                telemetry = replace(telemetry, attempt_index=attempt_index)
                result = self._verify(suite, task, seed, telemetry)
                self._record(result, definition_hash)
                results.append(result)
        return tuple(results)

    def _verify(self, suite: EvaluationSuite, task: BenchmarkTask, seed: int, telemetry: AttemptTelemetry) -> EvaluationResult:
        budget_exhausted = (
            telemetry.elapsed_seconds > task.budget.wall_seconds
            or telemetry.actions > task.budget.max_actions
            or telemetry.model_calls > task.budget.max_model_calls
            or (telemetry.tokens is not None and telemetry.tokens > task.budget.max_tokens)
            or (telemetry.deaths is not None and telemetry.deaths > task.budget.max_deaths)
        )
        if task.verifier == "beat_minecraft":
            verification = self.beat_verifier.verify(telemetry)
        elif task.verifier == "contract":
            verification = self.contract_verifier.verify(telemetry, task.success_contract)
        else:
            raise ValueError(f"unknown verifier {task.verifier}")
        if self.run_mode == "fabric" and not telemetry.trusted_provenance_verified:
            verification = type(verification)(
                False,
                "trusted journal does not prove the expected world/session and separate MineMind actor",
                (),
            )
        verified = verification.success and not budget_exhausted
        real_minecraft = (
            self.run_mode == "fabric"
            and telemetry.environment_started
            and telemetry.trusted_journal_observed
            and telemetry.trusted_provenance_verified
        )
        return EvaluationResult(
            suite.suite_id,
            task.task_id,
            seed,
            telemetry,
            verified,
            "budget exhausted" if budget_exhausted else verification.reason,
            verification.evidence_event_ids,
            telemetry.claimed_success and not verified,
            budget_exhausted,
            self.run_mode,
            self.run_mode in {"deterministic_smoke", "offline_process_fixture"},
            real_minecraft,
            dict(telemetry.evidence_provenance),
        )

    def summarize(self, suite_id: str, results: tuple[EvaluationResult, ...]) -> SuiteReport:
        measured = tuple(
            item for item in results
            if item.telemetry.environment_started
            and (item.run_mode != "fabric" or item.real_minecraft_measured)
        )
        infrastructure_failures = len(results) - len(measured)
        if not measured:
            return SuiteReport(
                suite_id=suite_id,
                measurement_status="not_measured",
                attempts=0,
                completion_rate=None,
                median_completion_seconds=None,
                deaths=None,
                unrecoverable_failures=infrastructure_failures,
                model_calls=0,
                tokens=None,
                resources_wasted=None,
                replans=None,
                new_skills_created=0,
                transferred_skills_used=0,
                false_success_claims=0,
                budget_exhaustions=0,
                infrastructure_failures=infrastructure_failures,
                improvement_by_attempt=(),
                mastered_task_regressions=0,
            )
        successes = [item for item in measured if item.verified_success]
        by_attempt: dict[int, list[bool]] = {}
        for item in measured:
            by_attempt.setdefault(item.telemetry.attempt_index, []).append(item.verified_success)
        rates = [sum(values) / len(values) for _, values in sorted(by_attempt.items())]
        improvements = tuple(rates[index] - rates[index - 1] for index in range(1, len(rates)))
        regressions = 0
        histories: dict[tuple[str, int], list[EvaluationResult]] = {}
        for item in measured:
            histories.setdefault((item.task_id, item.seed), []).append(item)
        for history in histories.values():
            ordered = sorted(history, key=lambda item: item.telemetry.attempt_index)
            previously_mastered = False
            for item in ordered:
                if previously_mastered and not item.verified_success:
                    regressions += 1
                previously_mastered = previously_mastered or item.verified_success
        return SuiteReport(
            suite_id,
            "measured",
            len(measured),
            len(successes) / len(measured),
            statistics.median(item.telemetry.elapsed_seconds for item in successes) if successes else None,
            _sum_optional(item.telemetry.deaths for item in measured),
            sum(item.telemetry.unrecoverable_failure for item in measured) + infrastructure_failures,
            sum(item.telemetry.model_calls for item in measured),
            _sum_optional(item.telemetry.tokens for item in measured),
            _sum_optional(item.telemetry.resources_wasted for item in measured),
            _sum_optional(item.telemetry.replans for item in measured),
            sum(len(item.telemetry.new_skills) for item in measured),
            sum(len(item.telemetry.transferred_skills_used) for item in measured),
            sum(item.false_success_claim for item in measured),
            sum(item.budget_exhausted for item in measured),
            infrastructure_failures,
            improvements,
            regressions,
        )

    def load_results(self, suite_id: str) -> tuple[EvaluationResult, ...]:
        rows = self.database.execute(
            """SELECT * FROM evaluation_results WHERE suite_id=?
               ORDER BY task_id,seed,attempt_index""",
            (suite_id,),
        ).fetchall()
        results: list[EvaluationResult] = []
        for row in rows:
            telemetry_raw = json.loads(row["telemetry_json"])
            telemetry_raw["events"] = tuple(
                EvaluationEvent(**event)
                for event in telemetry_raw.get("events", [])
            )
            for field in ("new_skills", "transferred_skills_used"):
                telemetry_raw[field] = tuple(telemetry_raw.get(field, ()))
            telemetry = AttemptTelemetry(**telemetry_raw)
            results.append(
                EvaluationResult(
                    suite_id=str(row["suite_id"]),
                    task_id=str(row["task_id"]),
                    seed=int(row["seed"]),
                    telemetry=telemetry,
                    verified_success=bool(row["verified_success"]),
                    verification_reason=str(row["verification_reason"]),
                    evidence_event_ids=tuple(json.loads(row["evidence_json"])),
                    false_success_claim=bool(row["false_success"]),
                    budget_exhausted=bool(row["budget_exhausted"]),
                    run_mode=str(row["run_mode"]),
                    simulated=bool(row["simulated"]),
                    real_minecraft_measured=bool(row["real_minecraft_measured"]),
                    evidence_provenance=(
                        json.loads(str(row["evidence_provenance_json"]))
                        if "evidence_provenance_json" in row.keys() else {}
                    ),
                    recorded_at=float(row["recorded_at"]),
                )
            )
        return tuple(results)

    def _exists(
        self,
        suite_id: str,
        task_id: str,
        seed: int,
        attempt_index: int,
        definition_hash: str,
    ) -> bool:
        row = self.database.execute(
            """SELECT 1 FROM evaluation_results
               WHERE suite_id=? AND task_id=? AND seed=? AND attempt_index=?""",
            (suite_id, task_id, seed, attempt_index),
        ).fetchone()
        if row is None:
            return False
        stored = self.database.execute(
            """SELECT definition_hash FROM evaluation_results
               WHERE suite_id=? AND task_id=? AND seed=? AND attempt_index=?""",
            (suite_id, task_id, seed, attempt_index),
        ).fetchone()[0]
        if stored != definition_hash:
            raise ValueError(
                "resume definition mismatch; use a new attempt-index or database for changed budgets/protocols"
            )
        return True

    def _definition_hash(self, suite: EvaluationSuite, task: BenchmarkTask) -> str:
        definition = {
            "suite_id": suite.suite_id,
            "protocol_version": suite.protocol_version,
            "clean_world_per_attempt": suite.clean_world_per_attempt,
            "agent_receives_contract": suite.agent_receives_contract,
            "task_id": task.task_id,
            "instruction": task.instruction,
            "budget": asdict(task.budget),
            "verifier": task.verifier,
            "success_contract": task.success_contract,
            "tags": task.tags,
            "run_mode": self.run_mode,
        }
        encoded = json.dumps(definition, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()

    def _record(self, result: EvaluationResult, definition_hash: str) -> None:
        telemetry = asdict(result.telemetry)
        telemetry["events"] = [asdict(event) for event in result.telemetry.events]
        self.database.execute(
            """INSERT OR REPLACE INTO evaluation_results(
                 suite_id,task_id,seed,attempt_index,verified_success,false_success,
                 budget_exhausted,telemetry_json,verification_reason,evidence_json,recorded_at,
                 definition_hash
                 ,run_mode,simulated,real_minecraft_measured,evidence_provenance_json,
                 evaluated_actor_id,world_id,world_session_id
               ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                result.suite_id, result.task_id, result.seed, result.telemetry.attempt_index,
                int(result.verified_success), int(result.false_success_claim), int(result.budget_exhausted),
                json.dumps(telemetry, sort_keys=True), result.verification_reason,
                json.dumps(result.evidence_event_ids), result.recorded_at, definition_hash,
                result.run_mode, int(result.simulated), int(result.real_minecraft_measured),
                json.dumps(result.evidence_provenance, sort_keys=True),
                result.evidence_provenance.get("evaluated_actor_id"),
                result.evidence_provenance.get("expected_world_id"),
                (result.evidence_provenance.get("world_session_ids") or [None])[0],
            ),
        )

    def close(self) -> None:
        self.database.close()

    def __enter__(self) -> "EvaluationRunner":
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()


def _sum_optional(values: Iterable[int | float | None]) -> int | float | None:
    materialized = tuple(values)
    if any(value is None for value in materialized):
        return None
    return sum(value for value in materialized if value is not None)
