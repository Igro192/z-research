from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from .models import AttemptTelemetry, EvaluationEvent


@dataclass(frozen=True, slots=True)
class Verification:
    success: bool
    reason: str
    evidence_event_ids: tuple[str, ...] = ()


def _path(document: Mapping[str, Any], dotted: str) -> Any:
    value: Any = document
    for part in dotted.split("."):
        if not isinstance(value, Mapping) or part not in value:
            raise KeyError(dotted)
        value = value[part]
    return value


class ContractVerifier:
    """Checks result-state contracts without exposing them to the evaluated agent."""

    def verify(self, telemetry: AttemptTelemetry, contract: Mapping[str, Any]) -> Verification:
        failures: list[str] = []
        for condition in contract.get("all_of", []):
            try:
                actual = _path(telemetry.final_state, str(condition["path"]))
            except KeyError:
                failures.append(f"missing state path {condition['path']}")
                continue
            operator = condition.get("operator", "eq")
            expected = condition.get("value")
            passed = {
                "eq": actual == expected,
                "gte": isinstance(actual, (int, float)) and actual >= expected,
                "lte": isinstance(actual, (int, float)) and actual <= expected,
                "contains": expected in actual if isinstance(actual, (str, list, tuple, set, dict)) else False,
            }.get(operator)
            if passed is None:
                raise ValueError(f"unsupported contract operator {operator}")
            if not passed:
                failures.append(f"{condition['path']} did not satisfy {operator}")
        required_events = set(contract.get("required_trusted_events", []))
        trusted_types = {event.event_type for event in telemetry.events if event.trusted_server_event}
        missing = required_events - trusted_types
        if missing:
            failures.append(f"missing trusted events: {sorted(missing)}")
        evidence = tuple(
            event.event_id
            for event in telemetry.events
            if event.trusted_server_event and event.event_type in required_events
        )
        return Verification(not failures, "; ".join(failures) if failures else "state contract satisfied", evidence)


class BeatMinecraftVerifier:
    """Independent outcome verifier; contains no action sequence or walkthrough.

    It requires correlated, trusted server evidence for the dragon-fight state,
    activated exit portal, and the evaluated player taking the completion
    transition. Chat, model claims, signs, books, and client-only state never count.
    """

    DRAGON = "minecraft:end_dragon_defeated"
    PORTAL = "minecraft:end_exit_portal_activated"
    COMPLETION = "minecraft:player_completion_transition"

    def verify(self, telemetry: AttemptTelemetry, contract: Mapping[str, Any] | None = None) -> Verification:
        trusted = [event for event in telemetry.events if event.trusted_server_event]
        by_type: dict[str, list[EvaluationEvent]] = {}
        for event in trusted:
            by_type.setdefault(event.event_type, []).append(event)
        missing = [kind for kind in (self.DRAGON, self.PORTAL, self.COMPLETION) if kind not in by_type]
        if missing:
            return Verification(False, f"missing trusted completion evidence: {missing}")
        final_fight = telemetry.final_state.get("dragon_fight", {})
        if not isinstance(final_fight, Mapping) or final_fight.get("previously_killed") is not True:
            return Verification(False, "authoritative final state does not mark the dragon defeated")
        if final_fight.get("exit_portal_active") is not True:
            return Verification(False, "authoritative final state does not mark the exit portal active")
        player_id = telemetry.final_state.get("evaluated_player_id")
        completions = [event for event in by_type[self.COMPLETION] if event.payload.get("player_id") == player_id]
        if not player_id or not completions:
            return Verification(False, "completion transition is not tied to the evaluated player")
        dragon_fights = {
            value for event in by_type[self.DRAGON]
            if isinstance((value := event.payload.get("fight_id")), str) and value
        }
        portal_fights = {
            value for event in by_type[self.PORTAL]
            if isinstance((value := event.payload.get("fight_id")), str) and value
        }
        completion_fights = {
            value for event in completions
            if isinstance((value := event.payload.get("fight_id")), str) and value
        }
        common = dragon_fights & portal_fights & completion_fights
        if not common:
            return Verification(False, "completion evidence does not refer to one dragon fight")
        for chosen in sorted(common):
            dragons = sorted(
                (event for event in by_type[self.DRAGON] if event.payload.get("fight_id") == chosen),
                key=lambda event: event.game_tick,
            )
            portals = sorted(
                (event for event in by_type[self.PORTAL] if event.payload.get("fight_id") == chosen),
                key=lambda event: event.game_tick,
            )
            transitions = sorted(
                (event for event in completions if event.payload.get("fight_id") == chosen),
                key=lambda event: event.game_tick,
            )
            for dragon in dragons:
                for portal in portals:
                    for completion in transitions:
                        if dragon.game_tick <= portal.game_tick <= completion.game_tick:
                            return Verification(
                                True,
                                "dragon defeat and player completion transition independently verified",
                                (dragon.event_id, portal.event_id, completion.event_id),
                            )
        return Verification(False, "completion evidence has an invalid causal order")
