from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from minemind_training_lab import (
    JavaServerBackend,
    ResourceBudget,
    RuntimeAttempt,
    RuntimeBridgeClient,
    Scenario,
)

from .models import AttemptTelemetry, EvaluationEvent, TaskBudget


@dataclass(slots=True)
class FabricEvaluationAgent:
    backend: JavaServerBackend
    runtime: RuntimeBridgeClient
    journal_path: str = "minemind/evaluation-events.jsonl"

    async def attempt(self, instruction: str, seed: int, budget: TaskBudget) -> AttemptTelemetry:
        """Run one clean server and trust only its private Fabric event journal."""
        scenario = Scenario(
            objective=instruction,
            seed=seed,
            difficulty=1.0,
            capability_tags=("evaluation",),
            world_options={"evaluation": True, "clean_seed": True},
            success_contract={},
        )
        resource_budget = ResourceBudget(
            wall_seconds=budget.wall_seconds,
            max_actions=budget.max_actions,
            max_model_calls=budget.max_model_calls,
            max_tokens=budget.max_tokens,
            max_deaths=budget.max_deaths,
        )
        handle = await self.backend.start(scenario)
        failure: str | None = None
        try:
            try:
                attempt = await self.runtime.attempt(instruction, handle, resource_budget)
            except Exception as error:
                failure = f"agent runtime failed: {type(error).__name__}: {error}"
                attempt = RuntimeAttempt(
                    claimed_success=False,
                    elapsed_seconds=0.0,
                    deaths=None,
                    unrecoverable_failure=True,
                    model_calls=0,
                    tokens=None,
                    resources_wasted=None,
                    replans=None,
                    new_skills=(),
                    transferred_skills_used=(),
                    actions=0,
                    failure=failure,
                )
            journal = self.backend.read_trusted_journal(handle, relative_path=self.journal_path)
            events, final_state = _decode_journal(journal, expected_world_id=handle.world_id)
            provenance = _journal_provenance(events, final_state, handle.world_id)
            deaths = _trusted_deaths(events, final_state)
            resources_wasted = _trusted_nonnegative_number(
                final_state, "resources_wasted"
            )
            return AttemptTelemetry(
                claimed_success=attempt.claimed_success,
                final_state=final_state,
                events=events,
                elapsed_seconds=attempt.elapsed_seconds,
                deaths=deaths,
                unrecoverable_failure=attempt.unrecoverable_failure,
                model_calls=attempt.model_calls,
                tokens=attempt.tokens,
                resources_wasted=resources_wasted,
                replans=attempt.replans,
                new_skills=attempt.new_skills,
                transferred_skills_used=attempt.transferred_skills_used,
                actions=attempt.actions,
                trusted_journal_observed=any(event.trusted_server_event for event in events),
                failure=attempt.failure or failure,
                trusted_provenance_verified=bool(provenance["verified"]),
                evidence_provenance=provenance,
            )
        finally:
            await self.backend.stop(handle)


def _decode_journal(
    journal: tuple[Mapping[str, object], ...],
    *,
    expected_world_id: str | None = None,
) -> tuple[tuple[EvaluationEvent, ...], Mapping[str, Any]]:
    events: list[EvaluationEvent] = []
    final_state: Mapping[str, Any] = {}
    seen_event_ids: set[str] = set()
    for index, raw in enumerate(journal):
        event_type = str(raw.get("event_type", ""))
        source = raw.get("source")
        protocol = raw.get("protocol_version")
        trusted = source == "fabric_server" and protocol == "1.0.0"
        payload = raw.get("payload", {})
        if not isinstance(payload, dict):
            payload = {"invalid_payload": True}
            trusted = False
        world_id = str(payload.get("world_id")) if payload.get("world_id") not in (None, "") else None
        world_session_id = str(payload.get("world_session_id")) if payload.get("world_session_id") not in (None, "") else None
        actor_id = str(payload.get("player_id")) if payload.get("player_id") not in (None, "") else None
        if expected_world_id is not None and (
            world_id != expected_world_id or world_session_id is None
        ):
            trusted = False
        try:
            game_tick = int(raw.get("game_tick", -1))
        except (TypeError, ValueError):
            game_tick = -1
            trusted = False
        event_id = str(raw.get("event_id", f"journal-{index}"))
        if game_tick < 0 or not event_type or not event_id or event_id in seen_event_ids:
            trusted = False
        seen_event_ids.add(event_id)
        event = EvaluationEvent(
            event_type, game_tick, payload, trusted, event_id,
            world_id, world_session_id, actor_id,
        )
        events.append(event)
        if trusted and event_type == "minemind:authoritative_snapshot":
            state = payload.get("state")
            if isinstance(state, dict):
                final_state = state
    return tuple(events), final_state


def _journal_provenance(
    events: tuple[EvaluationEvent, ...],
    final_state: Mapping[str, Any],
    expected_world_id: str,
) -> dict[str, Any]:
    trusted = tuple(event for event in events if event.trusted_server_event)
    worlds = sorted({event.world_id for event in trusted if event.world_id})
    sessions = sorted({event.world_session_id for event in trusted if event.world_session_id})
    actor_id = final_state.get("evaluated_player_id")
    role = str(final_state.get("evaluated_player_role", ""))
    mode = str(final_state.get("embodiment_mode", ""))
    bot_uuid = str(final_state.get("bot_uuid") or actor_id or "")
    verified = bool(
        trusted
        and worlds == [expected_world_id]
        and len(sessions) == 1
        and isinstance(actor_id, str)
        and actor_id
        and actor_id == bot_uuid
        and role == "minemind_ai"
        and mode == "SEPARATE_LOCAL_PLAYER"
    )
    return {
        "verified": verified,
        "expected_world_id": expected_world_id,
        "journal_world_ids": worlds,
        "world_session_ids": sessions,
        "evaluated_actor_id": actor_id,
        "evaluated_actor_role": role or None,
        "embodiment_mode": mode or None,
        "bot_uuid": bot_uuid or None,
        "reason": "separate MineMind player provenance verified" if verified else "journal does not prove one expected world/session and separate MineMind actor",
    }


def _trusted_deaths(
    events: tuple[EvaluationEvent, ...], final_state: Mapping[str, Any]
) -> int | None:
    snapshot_value = _trusted_nonnegative_number(final_state, "deaths")
    if snapshot_value is not None:
        if snapshot_value.is_integer():
            return int(snapshot_value)
        return None
    player_id = final_state.get("evaluated_player_id")
    if not isinstance(player_id, str) or not player_id:
        return None
    death_events = [
        event
        for event in events
        if event.trusted_server_event
        and event.event_type == "minecraft:player_death"
        and event.payload.get("player_id") == player_id
    ]
    return len(death_events)


def _trusted_nonnegative_number(
    final_state: Mapping[str, Any], name: str
) -> float | None:
    metrics = final_state.get("evaluation_metrics")
    if not isinstance(metrics, Mapping):
        return None
    value = metrics.get(name)
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return None
    converted = float(value)
    if converted < 0 or converted == float("inf") or converted == float("-inf") or converted != converted:
        return None
    return converted
