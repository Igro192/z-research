from __future__ import annotations

import argparse
import asyncio
import json
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any, Mapping, Sequence

from minemind_training_lab import JavaServerBackend, JavaServerConfig, RuntimeBridgeClient, WorldProvisioner

from .artifacts import write_metrics
from .fabric import FabricEvaluationAgent
from .runner import EvaluationRunner
from .runner import SuiteReport
from .smoke import DeterministicSmokeAgent
from .suites import available_suites, override_budgets, select_seeds, suite_by_name


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="minemind-eval",
        description="Reproducible MineMind evaluation and Fabric training-world harness",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    listing = commands.add_parser("list-suites", help="List built-in seeded evaluation suites")
    listing.add_argument("--json", action="store_true", help="Emit machine-readable JSON")

    smoke = commands.add_parser(
        "smoke",
        help="Run a deterministic synthetic diagnostics check (never a real-game result)",
    )
    _common_run_arguments(smoke, default_suite="diagnostics")

    initialize = commands.add_parser(
        "init-fabric-config", help="Write a validated Fabric evaluation configuration template"
    )
    initialize.add_argument("--output", type=Path, required=True)
    initialize.add_argument("--force", action="store_true")

    fabric = commands.add_parser(
        "run-fabric", help="Run seeded tasks in disposable Fabric server worlds"
    )
    fabric.add_argument("--config", type=Path, required=True)
    _common_run_arguments(fabric, default_suite="diagnostics")
    return parser


def _common_run_arguments(parser: argparse.ArgumentParser, *, default_suite: str) -> None:
    parser.add_argument("--suite", choices=sorted(available_suites()), default=default_suite)
    parser.add_argument("--seed", type=int, action="append", default=[])
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--database", type=Path)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--attempt-index", type=int, default=0)
    parser.add_argument("--wall-seconds", type=float)
    parser.add_argument("--max-actions", type=int)
    parser.add_argument("--max-model-calls", type=int)
    parser.add_argument("--max-tokens", type=int)
    parser.add_argument("--max-deaths", type=int)


def main(argv: Sequence[str] | None = None) -> int:
    arguments = _parser().parse_args(argv)
    try:
        if arguments.command == "list-suites":
            return _list_suites(arguments.json)
        if arguments.command == "init-fabric-config":
            return _init_config(arguments.output, arguments.force)
        if arguments.command == "smoke":
            if arguments.suite != "diagnostics":
                raise ValueError(
                    "smoke mode supports diagnostics only and will not manufacture Beat Minecraft results"
                )
            return asyncio.run(_run(arguments, DeterministicSmokeAgent(), "deterministic_smoke"))
        if arguments.command == "run-fabric":
            config = _load_config(arguments.config)
            server_config = config.get("server", {})
            if isinstance(server_config, Mapping) and server_config.get("client_command") == []:
                return _fabric_not_measured(
                    arguments,
                    config,
                    "no client driver is configured; a dedicated server alone has no embodied player",
                )
            agent = _fabric_agent(config)
            return asyncio.run(_run(arguments, agent, "fabric", config=config))
    except (KeyError, OSError, RuntimeError, TypeError, ValueError, PermissionError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    return 2


def _list_suites(as_json: bool) -> int:
    suites = available_suites()
    payload = {
        name: {
            "suite_id": suite.suite_id,
            "protocol_version": suite.protocol_version,
            "clean_world_per_attempt": suite.clean_world_per_attempt,
            "agent_receives_contract": suite.agent_receives_contract,
            "tasks": [
                {
                    "task_id": task.task_id,
                    "instruction": task.instruction,
                    "seeds": list(task.seeds),
                    "budget": asdict(task.budget),
                    "verifier": task.verifier,
                }
                for task in suite.tasks
            ],
        }
        for name, suite in suites.items()
    }
    if as_json:
        print(json.dumps(payload, sort_keys=True, indent=2))
    else:
        for name, suite in suites.items():
            print(f"{name}: {suite.suite_id} ({len(suite.tasks)} tasks)")
            for task in suite.tasks:
                print(f"  {task.task_id}: {task.instruction} [{len(task.seeds)} seeds]")
    return 0


def _fabric_not_measured(
    arguments: argparse.Namespace,
    config: Mapping[str, Any],
    reason: str,
) -> int:
    """Write an explicit zero-attempt result and make automation observe failure."""

    if arguments.attempt_index < 0:
        raise ValueError("attempt-index cannot be negative")
    suite = select_seeds(suite_by_name(arguments.suite), arguments.seed)
    configured_budget = dict(config.get("budget_overrides", {}))
    configured_budget.update(_budget_arguments(arguments))
    suite = override_budgets(suite, configured_budget)
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    report = SuiteReport(
        suite_id=suite.suite_id,
        measurement_status="not_measured",
        attempts=0,
        completion_rate=None,
        median_completion_seconds=None,
        deaths=None,
        unrecoverable_failures=0,
        model_calls=0,
        tokens=None,
        resources_wasted=None,
        replans=None,
        new_skills_created=0,
        transferred_skills_used=0,
        false_success_claims=0,
        budget_exhaustions=0,
        infrastructure_failures=1,
        improvement_by_attempt=(),
        mastered_task_regressions=0,
    )
    paths = write_metrics(
        arguments.output_dir,
        suite,
        (),
        report,
        run_mode="fabric",
        newly_executed=0,
        not_measured_reason=reason,
    )
    print(json.dumps({
        "measurement_status": "not_measured",
        "attempts": 0,
        "completion_rate": None,
        "newly_executed": 0,
        "run_mode": "fabric",
        "reason": reason,
        "summary": str(paths["summary"]),
        "attempts_jsonl": str(paths["attempts"]),
    }, sort_keys=True))
    return 2


async def _run(
    arguments: argparse.Namespace,
    agent: object,
    run_mode: str,
    *,
    config: Mapping[str, Any] | None = None,
) -> int:
    if arguments.attempt_index < 0:
        raise ValueError("attempt-index cannot be negative")
    suite = suite_by_name(arguments.suite)
    suite = select_seeds(suite, arguments.seed)
    configured_budget = dict((config or {}).get("budget_overrides", {}))
    configured_budget.update(_budget_arguments(arguments))
    suite = override_budgets(suite, configured_budget)
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    database = arguments.database or arguments.output_dir / "results.sqlite3"
    with EvaluationRunner(agent, database, run_mode=run_mode) as runner:  # type: ignore[arg-type]
        newly_executed = await runner.run(
            suite, resume=arguments.resume, attempt_index=arguments.attempt_index
        )
        selected_attempts = {
            (task.task_id, seed) for task in suite.tasks for seed in task.seeds
        }
        persisted = tuple(
            result
            for result in runner.load_results(suite.suite_id)
            if (result.task_id, result.seed) in selected_attempts
        )
        report = runner.summarize(suite.suite_id, persisted)
    paths = write_metrics(
        arguments.output_dir,
        suite,
        persisted,
        report,
        run_mode=run_mode,
        newly_executed=len(newly_executed),
    )
    print(json.dumps({
        "measurement_status": report.measurement_status,
        "attempts": report.attempts,
        "completion_rate": report.completion_rate,
        "newly_executed": len(newly_executed),
        "run_mode": run_mode,
        "summary": str(paths["summary"]),
        "attempts_jsonl": str(paths["attempts"]),
    }, sort_keys=True))
    return 0


def _budget_arguments(arguments: argparse.Namespace) -> dict[str, int | float]:
    values = {
        "wall_seconds": arguments.wall_seconds,
        "max_actions": arguments.max_actions,
        "max_model_calls": arguments.max_model_calls,
        "max_tokens": arguments.max_tokens,
        "max_deaths": arguments.max_deaths,
    }
    return {key: value for key, value in values.items() if value is not None}


def _init_config(destination: Path, force: bool) -> int:
    if destination.exists() and not force:
        raise FileExistsError(f"{destination} already exists; use --force to replace it")
    destination.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": "1.0.0",
        "server": {
            "training_root": "./work/training-worlds",
            "template_world": "./fabric-server-template",
            "command": ["java", "-Xms2G", "-Xmx4G", "-jar", "fabric-server-launch.jar", "nogui"],
            "endpoint": "127.0.0.1:25565",
            "ready_text": "Done (",
            "startup_timeout_seconds": 120,
            "stop_timeout_seconds": 30,
            "eula_accepted": False,
            "environment": {},
            "journal_path": "minemind/evaluation-events.jsonl",
            "required_artifacts": [
                "fabric-server-launch.jar",
                "mods/minemind-minecraft-mod-*.jar",
                "mods/fabric-api-*.jar"
            ],
            "client_command": [],
            "client_ready_text": "MINEMIND_CLIENT_READY",
            "client_stop_command": None,
        },
        "agent_runtime": {"base_url": "http://127.0.0.1:8080", "timeout_seconds": 30},
        "budget_overrides": {},
    }
    destination.write_text(json.dumps(payload, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(str(destination))
    return 0


def _load_config(path: Path) -> Mapping[str, Any]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or raw.get("schema_version") != "1.0.0":
        raise ValueError("Fabric config must be an object with schema_version 1.0.0")
    if not isinstance(raw.get("server"), dict) or not isinstance(raw.get("agent_runtime"), dict):
        raise ValueError("Fabric config requires server and agent_runtime objects")
    server = dict(raw["server"])
    for key in ("training_root", "template_world"):
        value = server.get(key)
        if value is not None:
            candidate = Path(str(value))
            if not candidate.is_absolute():
                server[key] = str((path.parent / candidate).resolve())
    raw["server"] = server
    return raw


def _fabric_agent(config: Mapping[str, Any]) -> FabricEvaluationAgent:
    server = config["server"]
    runtime = config["agent_runtime"]
    if not isinstance(server, Mapping) or not isinstance(runtime, Mapping):
        raise ValueError("invalid Fabric configuration")
    template = server.get("template_world")
    provisioner = WorldProvisioner(
        str(server["training_root"]), str(template) if template is not None else None
    )
    command = server.get("command")
    if not isinstance(command, list) or not all(isinstance(item, str) for item in command):
        raise ValueError("server.command must be an array of strings")
    client_command = server.get("client_command", [])
    if not isinstance(client_command, list) or not all(
        isinstance(item, str) for item in client_command
    ):
        raise ValueError("server.client_command must be an array of strings")
    required_artifacts = server.get("required_artifacts", [])
    if not isinstance(required_artifacts, list) or not all(
        isinstance(item, str) for item in required_artifacts
    ):
        raise ValueError("server.required_artifacts must be an array of strings")
    environment = server.get("environment", {})
    if not isinstance(environment, dict) or not all(
        isinstance(key, str) and isinstance(value, str) for key, value in environment.items()
    ):
        raise ValueError("server.environment must contain string keys and values")
    backend = JavaServerBackend(
        provisioner,
        JavaServerConfig(
            command=tuple(command),
            endpoint=str(server["endpoint"]),
            ready_text=str(server.get("ready_text", "Done (")),
            startup_timeout_seconds=float(server.get("startup_timeout_seconds", 120)),
            stop_timeout_seconds=float(server.get("stop_timeout_seconds", 30)),
            eula_accepted=bool(server.get("eula_accepted", False)),
            environment=environment,
            required_artifacts=tuple(required_artifacts),
            client_command=tuple(client_command),
            client_ready_text=str(server.get("client_ready_text", "MINEMIND_CLIENT_READY")),
            client_stop_command=(
                str(server["client_stop_command"])
                if server.get("client_stop_command") is not None else None
            ),
            require_client=True,
        ),
    )
    bridge = RuntimeBridgeClient(
        str(runtime["base_url"]), timeout_seconds=float(runtime.get("timeout_seconds", 30))
    )
    return FabricEvaluationAgent(
        backend, bridge, journal_path=str(server.get("journal_path", "minemind/evaluation-events.jsonl"))
    )


if __name__ == "__main__":
    raise SystemExit(main())
