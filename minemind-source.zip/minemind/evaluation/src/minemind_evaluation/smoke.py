from __future__ import annotations

from .models import AttemptTelemetry, EvaluationEvent, TaskBudget


class DeterministicSmokeAgent:
    """Synthetic protocol check. Its outputs are never labelled real-game results."""

    async def attempt(self, instruction: str, seed: int, budget: TaskBudget) -> AttemptTelemetry:
        final_state: dict[str, object]
        events: tuple[EvaluationEvent, ...] = ()
        if instruction == "Stay alive for five in-game minutes.":
            final_state = {"survival": {"elapsed_ticks": 6000}, "player": {"alive": True}}
        elif instruction == "Obtain any log item.":
            final_state = {"inventory": {"tags": ["minecraft:logs"]}}
        elif instruction == "Obtain a stone pickaxe.":
            final_state = {"inventory": {"items": ["minecraft:stone_pickaxe"]}}
        elif instruction == "Reach the Nether.":
            final_state = {"player": {"dimension": "minecraft:the_nether"}}
            events = (
                EvaluationEvent(
                    "minecraft:changed_dimension",
                    80,
                    {"player_id": "smoke-agent", "to": "minecraft:the_nether"},
                    True,
                    f"smoke-dimension-{seed}",
                ),
            )
        else:
            raise ValueError(
                "deterministic smoke supports diagnostics only; it never simulates Beat Minecraft"
            )
        elapsed = 1.0 + abs(seed % 100) / 100.0
        return AttemptTelemetry(
            claimed_success=True,
            final_state=final_state,
            events=events,
            elapsed_seconds=elapsed,
            deaths=0,
            unrecoverable_failure=False,
            model_calls=1,
            tokens=32,
            resources_wasted=0.0,
            replans=0,
            new_skills=(),
            transferred_skills_used=(),
            actions=4,
        )

