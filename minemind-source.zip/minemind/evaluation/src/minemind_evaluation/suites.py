from __future__ import annotations

from dataclasses import replace
from typing import Mapping, Sequence

from .models import BenchmarkTask, EvaluationSuite, TaskBudget


_DIAGNOSTIC_SEEDS = (104729, 130363, 155921, 196613, 216091)
_BEAT_SEEDS = (32416190071, 32416187567, 32416189381, 32416189733, 32416189909)


def diagnostic_suite() -> EvaluationSuite:
    short = TaskBudget(600, 8_000, 600, 250_000, 3)
    return EvaluationSuite(
        suite_id="minemind.diagnostics.v1",
        protocol_version="1.0.0",
        tasks=(
            BenchmarkTask(
                "survival.no_death",
                "Stay alive for five in-game minutes.",
                _DIAGNOSTIC_SEEDS,
                short,
                "contract",
                {"all_of": [{"path": "survival.elapsed_ticks", "operator": "gte", "value": 6000}, {"path": "player.alive", "operator": "eq", "value": True}]},
                ("survival", "reactive"),
            ),
            BenchmarkTask(
                "inventory.obtain_log",
                "Obtain any log item.",
                _DIAGNOSTIC_SEEDS,
                short,
                "contract",
                {"all_of": [{"path": "inventory.tags", "operator": "contains", "value": "minecraft:logs"}]},
                ("perception", "movement", "interaction"),
            ),
            BenchmarkTask(
                "crafting.obtain_stone_pickaxe",
                "Obtain a stone pickaxe.",
                _DIAGNOSTIC_SEEDS,
                short,
                "contract",
                {"all_of": [{"path": "inventory.items", "operator": "contains", "value": "minecraft:stone_pickaxe"}]},
                ("resource", "crafting"),
            ),
            BenchmarkTask(
                "exploration.enter_nether",
                "Reach the Nether.",
                _DIAGNOSTIC_SEEDS,
                TaskBudget(1800, 30_000, 1500, 750_000, 5),
                "contract",
                {
                    "all_of": [{"path": "player.dimension", "operator": "eq", "value": "minecraft:the_nether"}],
                    "required_trusted_events": ["minecraft:changed_dimension"],
                },
                ("long_horizon", "dimension_travel"),
            ),
        ),
        agent_receives_contract=False,
    )


def beat_minecraft_suite() -> EvaluationSuite:
    return EvaluationSuite(
        suite_id="minemind.beat_minecraft.clean_seed.v1",
        protocol_version="1.0.0",
        tasks=(
            BenchmarkTask(
                task_id="beat_minecraft",
                instruction="Beat Minecraft.",
                seeds=_BEAT_SEEDS,
                # The acceptance target is a genuine completion inside two
                # hours. A timeout is a measured failure, never a reason to
                # fabricate or infer success.
                budget=TaskBudget(7_200, 500_000, 20_000, 10_000_000, 20),
                verifier="beat_minecraft",
                success_contract={},
                tags=("open_ended", "long_horizon", "clean_seed"),
            ),
        ),
        clean_world_per_attempt=True,
        agent_receives_contract=False,
    )


def available_suites() -> Mapping[str, EvaluationSuite]:
    return {
        "diagnostics": diagnostic_suite(),
        "beat-minecraft": beat_minecraft_suite(),
    }


def suite_by_name(name: str) -> EvaluationSuite:
    try:
        return available_suites()[name]
    except KeyError as error:
        raise KeyError(f"unknown suite {name!r}; choose from {sorted(available_suites())}") from error


def select_seeds(suite: EvaluationSuite, seeds: Sequence[int]) -> EvaluationSuite:
    if not seeds:
        return suite
    selected = tuple(dict.fromkeys(int(seed) for seed in seeds))
    if any(seed < -(2**63) or seed >= 2**63 for seed in selected):
        raise ValueError("Minecraft evaluation seeds must fit a signed 64-bit integer")
    return replace(
        suite,
        tasks=tuple(
            replace(task, seeds=selected)
            for task in suite.tasks
        ),
    )


def override_budgets(suite: EvaluationSuite, values: Mapping[str, int | float | None]) -> EvaluationSuite:
    tasks: list[BenchmarkTask] = []
    for task in suite.tasks:
        raw = {
            "wall_seconds": task.budget.wall_seconds,
            "max_actions": task.budget.max_actions,
            "max_model_calls": task.budget.max_model_calls,
            "max_tokens": task.budget.max_tokens,
            "max_deaths": task.budget.max_deaths,
        }
        raw.update({key: value for key, value in values.items() if value is not None})
        tasks.append(replace(task, budget=TaskBudget(**raw)))
    return replace(suite, tasks=tuple(tasks))
