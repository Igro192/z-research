from pathlib import Path
import os,subprocess,sys
r=Path(__file__).resolve().parent
e=os.environ.copy();e['PYTHONDONTWRITEBYTECODE']='1';e['PYTHONPATH']=os.pathsep.join(str(p) for p in r.glob('*/src'))
raise SystemExit(subprocess.call([sys.executable,'-m','pytest','-q','--import-mode=importlib','-p','no:cacheprovider',*[str(p) for p in r.glob('*/tests')]],cwd=r,env=e))
