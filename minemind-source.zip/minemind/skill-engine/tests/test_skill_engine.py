import asyncio
import tempfile
import unittest
from pathlib import Path

from minemind_skill_engine import (
    ActionResult,
    BehaviorNode,
    BytecodeInstruction,
    BytecodeOp,
    BytecodeProgram,
    EvaluationEvidence,
    IsolatedEvaluationAuthority,
    NodeKind,
    ParameterSpec,
    SafeExpression,
    SandboxViolation,
    SkillLifecycle,
    SkillEvaluationQueue,
    SkillManifest,
    SkillRegistry,
    SkillRuntime,
    SkillStore,
    SkillTest,
)


class CounterExecutor:
    def __init__(self, test):
        self.value = int(test.initial_state.get("count", 0))

    async def execute(self, capability, arguments):
        if capability != "increment":
            return ActionResult(False, error="unsupported")
        self.value += int(arguments["amount"])
        return ActionResult(True, {"count": self.value}, cost=1.0)


def manifest(version="1.0.0", amount=1):
    return SkillManifest(
        skill_id="learned.increment",
        version=version,
        purpose="Increment a simulated state counter",
        applicability="state['safe'] == True",
        parameters={"amount": ParameterSpec("integer", default=amount)},
        required_resources=(),
        expected_effects=("counter increased",),
        root=BehaviorNode(
            NodeKind.REPEAT,
            "repeat",
            {"count": 2},
            (BehaviorNode(NodeKind.ACTION, "act", {"capability": "increment", "arguments": {"amount": "=params['amount']"}}),),
        ),
        safety_constraints=("state['safe'] == True",),
        tests=(SkillTest("twice", {"amount": amount}, {"count": 0, "safe": True}, f"state['count'] == {2 * amount}"),),
        confidence=0.5,
    )


TRUSTED_FIXTURE = EvaluationEvidence("test:disposable-world", isolated=True, trusted=True)


def approve_candidate(_manifest, _report):
    return True, None


class SkillEngineTest(unittest.TestCase):
    def test_sandbox_rejects_import_and_attributes(self):
        with self.assertRaises(SandboxViolation):
            SafeExpression("__import__('os').system('id')")

    def test_executes_bounded_graph(self):
        item = manifest()
        result = asyncio.run(SkillRuntime({"increment"}).run(item, CounterExecutor(item.tests[0]), {"amount": 2}, {"count": 0, "safe": True}))
        self.assertEqual(result.status.value, "succeeded")
        self.assertEqual(result.final_state["count"], 4)
        self.assertEqual(result.actions, 2)

    def test_promotes_hot_loads_and_rolls_back(self):
        with tempfile.TemporaryDirectory() as directory:
            store = SkillStore(Path(directory) / "skills.sqlite3")
            self.addCleanup(store.close)
            lifecycle = SkillLifecycle(store, SkillRuntime({"increment"}))
            first = manifest("1.0.0", 1)
            lifecycle.submit(first)
            report = asyncio.run(lifecycle.evaluate(
                first, CounterExecutor, critic=approve_candidate, evidence=TRUSTED_FIXTURE
            ))
            self.assertTrue(report.promoted)
            registry = SkillRegistry(store)
            self.assertEqual(registry.resolve(first.skill_id).version, "1.0.0")
            second = manifest("1.1.0", 2)
            lifecycle.submit(second)
            asyncio.run(lifecycle.evaluate(
                second, CounterExecutor, critic=approve_candidate, evidence=TRUSTED_FIXTURE
            ))
            self.assertEqual(registry.resolve(first.skill_id).version, "1.1.0")
            lifecycle.rollback(first.skill_id)
            self.assertEqual(registry.resolve(first.skill_id).version, "1.0.0")
            with self.assertRaises(ValueError):
                store.put(manifest("1.0.0", 9))

    def test_composes_a_versioned_dependency(self):
        child = manifest("1.0.0", 1)
        parent = SkillManifest(
            skill_id="learned.composed",
            version="1.0.0",
            purpose="Compose another reusable skill",
            applicability="state['safe'] == True",
            parameters={"amount": ParameterSpec("integer", default=3)},
            required_resources=(),
            expected_effects=("counter increased",),
            root=BehaviorNode(NodeKind.SKILL, "child", {"skill_id": child.skill_id, "arguments": {"amount": "=params['amount']"}}),
            safety_constraints=("state['safe'] == True",),
            dependencies={child.skill_id: child.version},
        )
        runtime = SkillRuntime({"increment"}, skill_resolver=lambda skill_id: child)
        result = asyncio.run(runtime.run(parent, CounterExecutor(child.tests[0]), {"amount": 3}, {"count": 0, "safe": True}))
        self.assertEqual(result.final_state["count"], 6)
        self.assertEqual(result.status.value, "succeeded")

    def test_live_regression_rolls_back(self):
        with tempfile.TemporaryDirectory() as directory:
            store = SkillStore(Path(directory) / "skills.sqlite3")
            self.addCleanup(store.close)
            lifecycle = SkillLifecycle(store, SkillRuntime({"increment"}))
            first = manifest("1.0.0", 1)
            second = manifest("1.1.0", 2)
            for item in (first, second):
                lifecycle.submit(item)
                asyncio.run(lifecycle.evaluate(
                    item, CounterExecutor, critic=approve_candidate, evidence=TRUSTED_FIXTURE
                ))
            self.assertIsNone(lifecycle.record_live_outcome(first.skill_id, success=False, safe=True, actions=2, cost=2, minimum_attempts=2))
            rolled_back = lifecycle.record_live_outcome(first.skill_id, success=False, safe=True, actions=2, cost=2, minimum_attempts=2)
            self.assertEqual(rolled_back.version, "1.0.0")

    def test_generated_finite_bytecode_is_sandboxed_and_bounded(self):
        program = BytecodeProgram((
            BytecodeInstruction(BytecodeOp.ACTION, capability="increment", arguments={"amount": 1}, on_success=1, on_failure=2),
            BytecodeInstruction(BytecodeOp.BRANCH, expression="state['count'] < 2", if_true=0, if_false=2),
            BytecodeInstruction(BytecodeOp.RETURN, success=True),
        ), max_steps=8)
        item = SkillManifest(
            skill_id="learned.bytecode",
            version="1.0.0",
            purpose="Run generated finite policy code",
            applicability="state['safe'] == True",
            parameters={},
            required_resources=(),
            expected_effects=("counter reaches two",),
            root=BehaviorNode(NodeKind.PROGRAM, "program", program.to_config()),
            safety_constraints=("state['safe'] == True",),
        )
        result = asyncio.run(SkillRuntime({"increment"}).run(item, CounterExecutor(manifest().tests[0]), {}, {"count": 0, "safe": True}))
        self.assertEqual(result.status.value, "succeeded")
        self.assertEqual(result.final_state["count"], 2)

    def test_promotion_requires_critic_and_trusted_isolated_evidence(self):
        with tempfile.TemporaryDirectory() as directory:
            store = SkillStore(Path(directory) / "skills.sqlite3")
            self.addCleanup(store.close)
            lifecycle = SkillLifecycle(store, SkillRuntime({"increment"}))
            item = manifest()
            lifecycle.submit(item)
            report = asyncio.run(lifecycle.evaluate(item, CounterExecutor))
            self.assertFalse(report.promoted)
            self.assertFalse(report.trusted_isolated_evidence)
            with self.assertRaises(KeyError):
                store.active(item.skill_id)

    def test_durable_queue_waits_for_authority_then_promotes(self):
        with tempfile.TemporaryDirectory() as directory:
            store = SkillStore(Path(directory) / "skills.sqlite3")
            self.addCleanup(store.close)
            lifecycle = SkillLifecycle(store, SkillRuntime({"increment"}))
            item = manifest()
            lifecycle.submit(item)
            unconfigured = SkillEvaluationQueue(store, lifecycle)
            job_id = unconfigured.enqueue(item.skill_id, item.version)
            self.assertIsNone(asyncio.run(unconfigured.run_once()))
            self.assertEqual(store.evaluation_job(job_id)["status"], "queued")

            authority = IsolatedEvaluationAuthority(
                "test:disposable-world",
                executor_factory=CounterExecutor,
                critic=approve_candidate,
            )
            completed = asyncio.run(
                SkillEvaluationQueue(store, lifecycle, authority).run_once()
            )
            self.assertEqual(completed["status"], "promoted")
            self.assertTrue(completed["trusted_isolated"])
            self.assertEqual(store.active(item.skill_id).version, item.version)

    def test_queue_rejects_untrusted_authority(self):
        with self.assertRaises(ValueError):
            IsolatedEvaluationAuthority(
                "test:not-isolated",
                executor_factory=CounterExecutor,
                critic=approve_candidate,
                isolated=False,
            )


if __name__ == "__main__":
    unittest.main()
