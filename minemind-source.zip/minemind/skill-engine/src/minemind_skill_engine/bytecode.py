from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping

from .dsl import JsonValue
from .sandbox import SafeExpression


class BytecodeOp(str, Enum):
    ACTION = "action"
    BRANCH = "branch"
    GOTO = "goto"
    RETURN = "return"


@dataclass(frozen=True, slots=True)
class BytecodeInstruction:
    op: BytecodeOp
    capability: str | None = None
    arguments: Mapping[str, JsonValue] = field(default_factory=dict)
    expression: str | None = None
    on_success: int | None = None
    on_failure: int | None = None
    if_true: int | None = None
    if_false: int | None = None
    target: int | None = None
    success: bool | None = None

    def to_dict(self) -> dict[str, JsonValue]:
        return {
            "op": self.op.value,
            "capability": self.capability,
            "arguments": dict(self.arguments),
            "expression": self.expression,
            "on_success": self.on_success,
            "on_failure": self.on_failure,
            "if_true": self.if_true,
            "if_false": self.if_false,
            "target": self.target,
            "success": self.success,
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "BytecodeInstruction":
        return cls(
            op=BytecodeOp(str(raw["op"])),
            capability=raw.get("capability"),
            arguments=dict(raw.get("arguments", {})),
            expression=raw.get("expression"),
            on_success=raw.get("on_success"),
            on_failure=raw.get("on_failure"),
            if_true=raw.get("if_true"),
            if_false=raw.get("if_false"),
            target=raw.get("target"),
            success=raw.get("success"),
        )


@dataclass(frozen=True, slots=True)
class BytecodeProgram:
    """Finite generated policy code; it can only branch and invoke allowed actions."""

    instructions: tuple[BytecodeInstruction, ...]
    entry: int = 0
    max_steps: int = 128

    def to_config(self) -> dict[str, JsonValue]:
        return {
            "instructions": [instruction.to_dict() for instruction in self.instructions],
            "entry": self.entry,
            "max_steps": self.max_steps,
        }

    @classmethod
    def from_config(cls, raw: Mapping[str, Any]) -> "BytecodeProgram":
        return cls(
            tuple(BytecodeInstruction.from_dict(item) for item in raw.get("instructions", [])),
            int(raw.get("entry", 0)),
            int(raw.get("max_steps", 128)),
        )

    def validate(self, allowed_capabilities: set[str]) -> None:
        if not self.instructions or len(self.instructions) > 256:
            raise ValueError("bytecode must contain between 1 and 256 instructions")
        if not 1 <= self.max_steps <= 4096:
            raise ValueError("bytecode step budget is outside the bounded range")
        self._target(self.entry)
        for instruction in self.instructions:
            if instruction.op is BytecodeOp.ACTION:
                if instruction.capability not in allowed_capabilities:
                    raise ValueError(f"bytecode uses unavailable capability {instruction.capability}")
                self._target(instruction.on_success)
                self._target(instruction.on_failure)
            elif instruction.op is BytecodeOp.BRANCH:
                if instruction.expression is None:
                    raise ValueError("branch expression is required")
                SafeExpression(instruction.expression)
                self._target(instruction.if_true)
                self._target(instruction.if_false)
            elif instruction.op is BytecodeOp.GOTO:
                self._target(instruction.target)
            elif instruction.op is BytecodeOp.RETURN:
                if instruction.success is None:
                    raise ValueError("return success value is required")

    def _target(self, value: int | None) -> None:
        if not isinstance(value, int) or isinstance(value, bool) or not 0 <= value < len(self.instructions):
            raise ValueError(f"invalid bytecode target {value}")

