from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from pathlib import Path

from .dsl import SkillManifest


class SkillStore:
    """Transactional source of truth for candidates, active versions, and evidence."""

    def __init__(self, database: str | Path) -> None:
        self.database = str(database)
        self._local = threading.local()
        self._migrate()

    def _connection(self) -> sqlite3.Connection:
        connection = getattr(self._local, "connection", None)
        if connection is None:
            connection = sqlite3.connect(self.database, timeout=10, isolation_level=None)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute("PRAGMA foreign_keys=ON")
            self._local.connection = connection
        return connection

    def _migrate(self) -> None:
        connection = self._connection()
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS skill_schema_version(version INTEGER PRIMARY KEY);
            INSERT OR IGNORE INTO skill_schema_version(version) VALUES (1);
            CREATE TABLE IF NOT EXISTS skills(
                skill_id TEXT NOT NULL,
                version TEXT NOT NULL,
                stage TEXT NOT NULL,
                manifest_json TEXT NOT NULL,
                active INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                PRIMARY KEY(skill_id, version)
            );
            CREATE UNIQUE INDEX IF NOT EXISTS one_active_skill
                ON skills(skill_id) WHERE active = 1;
            CREATE TABLE IF NOT EXISTS skill_evaluations(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                skill_id TEXT NOT NULL,
                version TEXT NOT NULL,
                success_rate REAL NOT NULL,
                safety_rate REAL NOT NULL,
                mean_actions REAL NOT NULL,
                mean_cost REAL NOT NULL,
                report_json TEXT NOT NULL,
                created_at REAL NOT NULL,
                FOREIGN KEY(skill_id, version) REFERENCES skills(skill_id, version)
            );
            CREATE TABLE IF NOT EXISTS live_executions(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                skill_id TEXT NOT NULL,
                version TEXT NOT NULL,
                success INTEGER NOT NULL,
                safe INTEGER NOT NULL,
                actions INTEGER NOT NULL,
                cost REAL NOT NULL,
                context_json TEXT NOT NULL,
                created_at REAL NOT NULL,
                FOREIGN KEY(skill_id, version) REFERENCES skills(skill_id, version)
            );
            CREATE INDEX IF NOT EXISTS live_execution_lookup
              ON live_executions(skill_id,version,created_at DESC);
            CREATE TABLE IF NOT EXISTS registry_generation(
                singleton INTEGER PRIMARY KEY CHECK(singleton = 1),
                generation INTEGER NOT NULL
            );
            INSERT OR IGNORE INTO registry_generation(singleton, generation) VALUES (1, 0);
            CREATE TABLE IF NOT EXISTS skill_evaluation_jobs(
                job_id TEXT PRIMARY KEY,
                skill_id TEXT NOT NULL,
                version TEXT NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('queued','running','promoted','rejected','failed')),
                evidence_source TEXT,
                trusted_isolated INTEGER NOT NULL DEFAULT 0,
                report_json TEXT,
                error TEXT,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                started_at REAL,
                completed_at REAL,
                FOREIGN KEY(skill_id, version) REFERENCES skills(skill_id, version)
            );
            CREATE UNIQUE INDEX IF NOT EXISTS one_open_skill_evaluation_job
              ON skill_evaluation_jobs(skill_id,version)
              WHERE status IN ('queued','running');
            CREATE INDEX IF NOT EXISTS skill_evaluation_job_queue
              ON skill_evaluation_jobs(status,created_at);
            """
        )
        self._migrate_legacy_evaluations(connection)

    @staticmethod
    def _migrate_legacy_evaluations(connection: sqlite3.Connection) -> None:
        columns = {
            str(row[1]) for row in connection.execute("PRAGMA table_info(evaluations)").fetchall()
        }
        expected = {
            "skill_id", "version", "success_rate", "safety_rate", "mean_actions",
            "mean_cost", "report_json", "created_at",
        }
        if expected.issubset(columns):
            connection.execute(
                """INSERT OR IGNORE INTO skill_evaluations(
                     id,skill_id,version,success_rate,safety_rate,mean_actions,mean_cost,report_json,created_at
                   ) SELECT id,skill_id,version,success_rate,safety_rate,mean_actions,mean_cost,report_json,created_at
                     FROM evaluations"""
            )

    def put(self, manifest: SkillManifest, stage: str = "candidate") -> None:
        now = time.time()
        payload = json.dumps(manifest.to_dict(), sort_keys=True, separators=(",", ":"))
        connection = self._connection()
        connection.execute("BEGIN IMMEDIATE")
        try:
            existing = connection.execute(
                "SELECT manifest_json FROM skills WHERE skill_id=? AND version=?",
                (manifest.skill_id, manifest.version),
            ).fetchone()
            if existing:
                if str(existing["manifest_json"]) != payload:
                    raise ValueError(
                        f"skill versions are immutable: {manifest.skill_id}@{manifest.version} already exists"
                    )
                connection.execute("COMMIT")
                return
            connection.execute(
                """INSERT INTO skills(skill_id, version, stage, manifest_json, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (manifest.skill_id, manifest.version, stage, payload, now, now),
            )
            self._bump(connection)
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise

    def get(self, skill_id: str, version: str) -> SkillManifest:
        row = self._connection().execute(
            "SELECT manifest_json FROM skills WHERE skill_id=? AND version=?", (skill_id, version)
        ).fetchone()
        if not row:
            raise KeyError(f"unknown skill {skill_id}@{version}")
        return SkillManifest.from_dict(json.loads(row["manifest_json"]))

    def active(self, skill_id: str) -> SkillManifest:
        row = self._connection().execute(
            "SELECT manifest_json FROM skills WHERE skill_id=? AND active=1", (skill_id,)
        ).fetchone()
        if not row:
            raise KeyError(f"no promoted version for {skill_id}")
        return SkillManifest.from_dict(json.loads(row["manifest_json"]))

    def list_active(self) -> tuple[SkillManifest, ...]:
        rows = self._connection().execute(
            "SELECT manifest_json FROM skills WHERE active=1 ORDER BY skill_id"
        ).fetchall()
        return tuple(SkillManifest.from_dict(json.loads(row["manifest_json"])) for row in rows)

    def set_stage(self, skill_id: str, version: str, stage: str) -> None:
        connection = self._connection()
        cursor = connection.execute(
            "UPDATE skills SET stage=?, updated_at=? WHERE skill_id=? AND version=?",
            (stage, time.time(), skill_id, version),
        )
        if cursor.rowcount != 1:
            raise KeyError(f"unknown skill {skill_id}@{version}")

    def promote(self, skill_id: str, version: str) -> None:
        connection = self._connection()
        connection.execute("BEGIN IMMEDIATE")
        try:
            exists = connection.execute(
                "SELECT 1 FROM skills WHERE skill_id=? AND version=?", (skill_id, version)
            ).fetchone()
            if not exists:
                raise KeyError(f"unknown skill {skill_id}@{version}")
            connection.execute("UPDATE skills SET active=0 WHERE skill_id=?", (skill_id,))
            connection.execute(
                "UPDATE skills SET active=1, stage='promoted', updated_at=? WHERE skill_id=? AND version=?",
                (time.time(), skill_id, version),
            )
            self._bump(connection)
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise

    def deprecate(self, skill_id: str, version: str) -> None:
        connection = self._connection()
        connection.execute("BEGIN IMMEDIATE")
        try:
            cursor = connection.execute(
                """UPDATE skills SET active=0,stage='deprecated',updated_at=?
                   WHERE skill_id=? AND version=?""",
                (time.time(), skill_id, version),
            )
            if cursor.rowcount != 1:
                raise KeyError(f"unknown skill {skill_id}@{version}")
            self._bump(connection)
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise

    def rollback(self, skill_id: str) -> SkillManifest:
        rows = self._connection().execute(
            "SELECT version FROM skills WHERE skill_id=? AND stage='promoted' ORDER BY updated_at DESC",
            (skill_id,),
        ).fetchall()
        active = self.active(skill_id)
        target = next((row["version"] for row in rows if row["version"] != active.version), None)
        if target is None:
            raise LookupError(f"no previous promoted version for {skill_id}")
        self.promote(skill_id, target)
        return self.active(skill_id)

    def record_evaluation(self, skill_id: str, version: str, report: dict[str, object]) -> None:
        self._connection().execute(
            """INSERT INTO skill_evaluations(
                 skill_id,version,success_rate,safety_rate,mean_actions,mean_cost,report_json,created_at
               ) VALUES(?,?,?,?,?,?,?,?)""",
            (
                skill_id,
                version,
                report["success_rate"],
                report["safety_rate"],
                report["mean_actions"],
                report["mean_cost"],
                json.dumps(report, sort_keys=True),
                time.time(),
            ),
        )

    def record_live_execution(
        self,
        skill_id: str,
        version: str,
        *,
        success: bool,
        safe: bool,
        actions: int,
        cost: float,
        context: dict[str, object] | None = None,
    ) -> None:
        self.get(skill_id, version)
        self._connection().execute(
            """INSERT INTO live_executions(
                 skill_id,version,success,safe,actions,cost,context_json,created_at
               ) VALUES(?,?,?,?,?,?,?,?)""",
            (
                skill_id, version, int(success), int(safe), actions, cost,
                json.dumps(context or {}, sort_keys=True), time.time(),
            ),
        )

    def recent_performance(self, skill_id: str, version: str, limit: int = 50) -> dict[str, float]:
        rows = self._connection().execute(
            """SELECT success,safe,actions,cost FROM live_executions
               WHERE skill_id=? AND version=? ORDER BY created_at DESC LIMIT ?""",
            (skill_id, version, limit),
        ).fetchall()
        if not rows:
            return {"attempts": 0.0, "success_rate": 0.0, "safety_rate": 0.0, "mean_actions": 0.0, "mean_cost": 0.0}
        count = len(rows)
        return {
            "attempts": float(count),
            "success_rate": sum(int(row["success"]) for row in rows) / count,
            "safety_rate": sum(int(row["safe"]) for row in rows) / count,
            "mean_actions": sum(int(row["actions"]) for row in rows) / count,
            "mean_cost": sum(float(row["cost"]) for row in rows) / count,
        }

    def enqueue_evaluation(self, skill_id: str, version: str) -> str:
        """Persist a candidate evaluation request, deduplicating open requests."""

        self.get(skill_id, version)
        connection = self._connection()
        connection.execute("BEGIN IMMEDIATE")
        try:
            existing = connection.execute(
                """SELECT job_id FROM skill_evaluation_jobs
                   WHERE skill_id=? AND version=? AND status IN ('queued','running')""",
                (skill_id, version),
            ).fetchone()
            if existing:
                connection.execute("COMMIT")
                return str(existing["job_id"])
            job_id = str(uuid.uuid4())
            now = time.time()
            connection.execute(
                """INSERT INTO skill_evaluation_jobs(
                     job_id,skill_id,version,status,created_at,updated_at
                   ) VALUES(?,?,?,'queued',?,?)""",
                (job_id, skill_id, version, now, now),
            )
            connection.execute("COMMIT")
            return job_id
        except Exception:
            connection.execute("ROLLBACK")
            raise

    def claim_evaluation(self, evidence_source: str) -> dict[str, object] | None:
        """Atomically claim the oldest queued job for a configured worker."""

        connection = self._connection()
        connection.execute("BEGIN IMMEDIATE")
        try:
            row = connection.execute(
                """SELECT * FROM skill_evaluation_jobs
                   WHERE status='queued' ORDER BY created_at,job_id LIMIT 1"""
            ).fetchone()
            if row is None:
                connection.execute("COMMIT")
                return None
            now = time.time()
            connection.execute(
                """UPDATE skill_evaluation_jobs
                   SET status='running',evidence_source=?,trusted_isolated=1,
                       started_at=?,updated_at=? WHERE job_id=? AND status='queued'""",
                (evidence_source, now, now, row["job_id"]),
            )
            connection.execute("COMMIT")
            return self.evaluation_job(str(row["job_id"]))
        except Exception:
            connection.execute("ROLLBACK")
            raise

    def finish_evaluation(
        self,
        job_id: str,
        status: str,
        *,
        report: dict[str, object] | None = None,
        error: str | None = None,
    ) -> None:
        if status not in {"promoted", "rejected", "failed"}:
            raise ValueError("evaluation job terminal status is invalid")
        now = time.time()
        cursor = self._connection().execute(
            """UPDATE skill_evaluation_jobs
               SET status=?,report_json=?,error=?,completed_at=?,updated_at=?
               WHERE job_id=? AND status='running'""",
            (
                status,
                json.dumps(report, sort_keys=True) if report is not None else None,
                error,
                now,
                now,
                job_id,
            ),
        )
        if cursor.rowcount != 1:
            raise RuntimeError(f"evaluation job {job_id} is not running")

    def evaluation_job(self, job_id: str) -> dict[str, object]:
        row = self._connection().execute(
            "SELECT * FROM skill_evaluation_jobs WHERE job_id=?", (job_id,)
        ).fetchone()
        if row is None:
            raise KeyError(f"unknown skill evaluation job {job_id}")
        value = dict(row)
        value["trusted_isolated"] = bool(value["trusted_isolated"])
        raw_report = value.pop("report_json")
        value["report"] = json.loads(str(raw_report)) if raw_report else None
        return value

    def list_evaluation_jobs(self, status: str | None = None) -> tuple[dict[str, object], ...]:
        if status is None:
            rows = self._connection().execute(
                "SELECT job_id FROM skill_evaluation_jobs ORDER BY created_at,job_id"
            ).fetchall()
        else:
            rows = self._connection().execute(
                "SELECT job_id FROM skill_evaluation_jobs WHERE status=? ORDER BY created_at,job_id",
                (status,),
            ).fetchall()
        return tuple(self.evaluation_job(str(row["job_id"])) for row in rows)

    @property
    def generation(self) -> int:
        return int(self._connection().execute(
            "SELECT generation FROM registry_generation WHERE singleton=1"
        ).fetchone()[0])

    @staticmethod
    def _bump(connection: sqlite3.Connection) -> None:
        connection.execute("UPDATE registry_generation SET generation=generation+1 WHERE singleton=1")

    def close(self) -> None:
        connection = getattr(self._local, "connection", None)
        if connection is not None:
            connection.close()
            self._local.connection = None

    def __enter__(self) -> "SkillStore":
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()


class SkillRegistry:
    """Hot-reloaded immutable view of the active skill set."""

    def __init__(self, store: SkillStore) -> None:
        self.store = store
        self._generation = -1
        self._active: dict[str, SkillManifest] = {}
        self.reload()

    def reload(self) -> bool:
        generation = self.store.generation
        if generation == self._generation:
            return False
        self._active = {skill.skill_id: skill for skill in self.store.list_active()}
        self._generation = generation
        return True

    def resolve(self, skill_id: str) -> SkillManifest:
        self.reload()
        try:
            return self._active[skill_id]
        except KeyError as error:
            raise KeyError(f"no hot-loaded skill named {skill_id}") from error

    def snapshot(self) -> tuple[SkillManifest, ...]:
        self.reload()
        return tuple(self._active[key] for key in sorted(self._active))
