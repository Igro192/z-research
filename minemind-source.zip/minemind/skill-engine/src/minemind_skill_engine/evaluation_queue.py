from __future__ import annotations

import asyncio
from dataclasses import dataclass

from .lifecycle import Critic, EvaluationEvidence, ExecutorFactory, SkillLifecycle, Thresholds
from .registry import SkillStore


@dataclass(frozen=True, slots=True)
class IsolatedEvaluationAuthority:
    """Explicit authority for a real isolated evaluator; there is no default simulator."""

    source: str
    executor_factory: ExecutorFactory
    critic: Critic
    trusted: bool = True
    isolated: bool = True

    def __post_init__(self) -> None:
        if not self.source.strip():
            raise ValueError("evaluation evidence source is required")
        if not self.trusted or not self.isolated:
            raise ValueError("skill promotion workers require trusted isolated evaluation")


class SkillEvaluationQueue:
    """Durable candidate queue whose worker can only promote from trusted evidence."""

    def __init__(
        self,
        store: SkillStore,
        lifecycle: SkillLifecycle,
        authority: IsolatedEvaluationAuthority | None = None,
        *,
        thresholds: Thresholds = Thresholds(),
    ) -> None:
        self.store = store
        self.lifecycle = lifecycle
        self.authority = authority
        self.thresholds = thresholds

    def enqueue(self, skill_id: str, version: str) -> str:
        return self.store.enqueue_evaluation(skill_id, version)

    async def run_once(self) -> dict[str, object] | None:
        # Unconfigured runtimes leave work durably queued. They never substitute a
        # self-fulfilling in-process simulator for isolated game evidence.
        if self.authority is None:
            return None
        job = self.store.claim_evaluation(self.authority.source)
        if job is None:
            return None
        job_id = str(job["job_id"])
        try:
            manifest = self.store.get(str(job["skill_id"]), str(job["version"]))
            report = await self.lifecycle.evaluate(
                manifest,
                self.authority.executor_factory,
                thresholds=self.thresholds,
                critic=self.authority.critic,
                evidence=EvaluationEvidence(
                    source=self.authority.source,
                    isolated=self.authority.isolated,
                    trusted=self.authority.trusted,
                ),
            )
            self.store.finish_evaluation(
                job_id,
                "promoted" if report.promoted else "rejected",
                report=report.to_dict(),
            )
        except Exception as error:
            self.store.finish_evaluation(job_id, "failed", error=f"{type(error).__name__}: {error}")
        return self.store.evaluation_job(job_id)

    async def run_until_empty(self) -> tuple[dict[str, object], ...]:
        completed: list[dict[str, object]] = []
        while True:
            job = await self.run_once()
            if job is None:
                return tuple(completed)
            completed.append(job)

    async def run_forever(self, stop: asyncio.Event, poll_seconds: float = 0.5) -> None:
        if self.authority is None:
            raise RuntimeError("no trusted isolated skill evaluator is configured")
        while not stop.is_set():
            if await self.run_once() is None:
                try:
                    await asyncio.wait_for(stop.wait(), timeout=poll_seconds)
                except TimeoutError:
                    pass
