from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Mapping


JsonValue = None | bool | int | float | str | list["JsonValue"] | dict[str, "JsonValue"]


class NodeKind(str, Enum):
    SEQUENCE = "sequence"
    SELECTOR = "selector"
    ACTION = "action"
    CONDITION = "condition"
    REPEAT = "repeat"
    SKILL = "skill"
    PROGRAM = "program"
    SUCCEED = "succeed"
    FAIL = "fail"


@dataclass(frozen=True, slots=True)
class ParameterSpec:
    type: str
    required: bool = True
    default: JsonValue = None
    minimum: float | None = None
    maximum: float | None = None
    enum: tuple[JsonValue, ...] = ()


@dataclass(frozen=True, slots=True)
class BehaviorNode:
    kind: NodeKind
    node_id: str
    config: Mapping[str, JsonValue] = field(default_factory=dict)
    children: tuple["BehaviorNode", ...] = ()

    def to_dict(self) -> dict[str, JsonValue]:
        return {
            "kind": self.kind.value,
            "node_id": self.node_id,
            "config": dict(self.config),
            "children": [child.to_dict() for child in self.children],
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "BehaviorNode":
        return cls(
            kind=NodeKind(str(raw["kind"])),
            node_id=str(raw["node_id"]),
            config=dict(raw.get("config", {})),
            children=tuple(cls.from_dict(item) for item in raw.get("children", [])),
        )


@dataclass(frozen=True, slots=True)
class SkillTest:
    name: str
    parameters: Mapping[str, JsonValue]
    initial_state: Mapping[str, JsonValue]
    expected: str
    max_actions: int = 64


@dataclass(frozen=True, slots=True)
class SkillManifest:
    skill_id: str
    version: str
    purpose: str
    applicability: str
    parameters: Mapping[str, ParameterSpec]
    required_resources: tuple[str, ...]
    expected_effects: tuple[str, ...]
    root: BehaviorNode
    safety_constraints: tuple[str, ...]
    recovery: BehaviorNode | None = None
    tests: tuple[SkillTest, ...] = ()
    dependencies: Mapping[str, str] = field(default_factory=dict)
    provenance: Mapping[str, JsonValue] = field(default_factory=dict)
    performance_statistics: Mapping[str, float] = field(default_factory=dict)
    confidence: float = 0.0
    known_failures: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, JsonValue]:
        return {
            "skill_id": self.skill_id,
            "version": self.version,
            "purpose": self.purpose,
            "applicability": self.applicability,
            "parameters": {key: asdict(value) for key, value in self.parameters.items()},
            "required_resources": list(self.required_resources),
            "expected_effects": list(self.expected_effects),
            "root": self.root.to_dict(),
            "safety_constraints": list(self.safety_constraints),
            "recovery": self.recovery.to_dict() if self.recovery else None,
            "tests": [asdict(test) for test in self.tests],
            "dependencies": dict(self.dependencies),
            "provenance": dict(self.provenance),
            "performance_statistics": dict(self.performance_statistics),
            "confidence": self.confidence,
            "known_failures": list(self.known_failures),
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "SkillManifest":
        return cls(
            skill_id=str(raw["skill_id"]),
            version=str(raw["version"]),
            purpose=str(raw["purpose"]),
            applicability=str(raw.get("applicability", "True")),
            parameters={key: ParameterSpec(**value) for key, value in raw.get("parameters", {}).items()},
            required_resources=tuple(raw.get("required_resources", [])),
            expected_effects=tuple(raw.get("expected_effects", [])),
            root=BehaviorNode.from_dict(raw["root"]),
            safety_constraints=tuple(raw.get("safety_constraints", [])),
            recovery=BehaviorNode.from_dict(raw["recovery"]) if raw.get("recovery") else None,
            tests=tuple(SkillTest(**item) for item in raw.get("tests", [])),
            dependencies=dict(raw.get("dependencies", {})),
            provenance=dict(raw.get("provenance", {})),
            performance_statistics={
                key: float(value) for key, value in raw.get("performance_statistics", {}).items()
            },
            confidence=float(raw.get("confidence", 0.0)),
            known_failures=tuple(raw.get("known_failures", [])),
        )


@dataclass(frozen=True, slots=True)
class ActionResult:
    success: bool
    observation: Mapping[str, JsonValue] = field(default_factory=dict)
    error: str | None = None
    cost: float = 0.0
