from __future__ import annotations

import ast
import math
from dataclasses import dataclass, field
from types import CodeType
from typing import Any, Mapping


class SandboxViolation(ValueError):
    """Raised when generated skill content exceeds the pure expression sandbox."""


_PURE_FUNCTIONS = {
    "abs": abs,
    "all": all,
    "any": any,
    "bool": bool,
    "float": float,
    "int": int,
    "len": len,
    "max": max,
    "min": min,
    "round": round,
    "str": str,
    "sum": sum,
    "sqrt": math.sqrt,
}

_ALLOWED_NODES = (
    ast.Expression,
    ast.Constant,
    ast.Name,
    ast.Load,
    ast.BoolOp,
    ast.And,
    ast.Or,
    ast.UnaryOp,
    ast.Not,
    ast.USub,
    ast.UAdd,
    ast.BinOp,
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Div,
    ast.FloorDiv,
    ast.Mod,
    ast.Compare,
    ast.Eq,
    ast.NotEq,
    ast.Lt,
    ast.LtE,
    ast.Gt,
    ast.GtE,
    ast.In,
    ast.NotIn,
    ast.Is,
    ast.IsNot,
    ast.IfExp,
    ast.List,
    ast.Tuple,
    ast.Dict,
    ast.Set,
    ast.Subscript,
    ast.Slice,
    ast.Call,
)


@dataclass(frozen=True, slots=True)
class SafeExpression:
    """A pure, bounded expression used for generated guards and calculations.

    Attribute access, imports, comprehensions, lambdas, assignment, reflection, and
    arbitrary calls are rejected before compilation. Evaluation receives no Python
    builtins and cannot access the OS, filesystem, or network.
    """

    source: str
    _code: CodeType = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        tree = ast.parse(self.source, mode="eval")
        nodes = list(ast.walk(tree))
        if len(nodes) > 128:
            raise SandboxViolation("expression is too complex")
        for node in nodes:
            if not isinstance(node, _ALLOWED_NODES):
                raise SandboxViolation(f"forbidden syntax: {type(node).__name__}")
            if isinstance(node, ast.Call):
                if not isinstance(node.func, ast.Name) or node.func.id not in _PURE_FUNCTIONS:
                    raise SandboxViolation("only approved pure functions may be called")
                if node.keywords:
                    raise SandboxViolation("keyword arguments are not permitted")
            if isinstance(node, ast.Name) and node.id.startswith("__"):
                raise SandboxViolation("private names are forbidden")
        object.__setattr__(self, "_code", compile(tree, "<skill-expression>", "eval"))

    def evaluate(self, variables: Mapping[str, Any]) -> Any:
        if any(key.startswith("__") for key in variables):
            raise SandboxViolation("private variables are forbidden")
        scope = dict(_PURE_FUNCTIONS)
        scope.update(variables)
        return eval(self._code, {"__builtins__": {}}, scope)  # noqa: S307 - validated AST
