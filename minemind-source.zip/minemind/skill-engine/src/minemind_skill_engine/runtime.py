from __future__ import annotations

import asyncio
import math
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Mapping, Protocol

from .dsl import ActionResult, BehaviorNode, JsonValue, NodeKind, SkillManifest
from .bytecode import BytecodeOp, BytecodeProgram
from .sandbox import SafeExpression
from .validation import validate_manifest


class AtomicExecutor(Protocol):
    async def execute(self, capability: str, arguments: Mapping[str, JsonValue]) -> ActionResult: ...


class ExecutionStatus(str, Enum):
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"
    SAFETY_STOP = "safety_stop"
    BUDGET_EXHAUSTED = "budget_exhausted"


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    status: ExecutionStatus
    actions: int
    elapsed_seconds: float
    final_state: Mapping[str, JsonValue]
    error: str | None = None
    trace: tuple[Mapping[str, JsonValue], ...] = ()


@dataclass(slots=True)
class _Context:
    parameters: dict[str, JsonValue]
    state: dict[str, JsonValue]
    actions: int = 0
    trace: list[Mapping[str, JsonValue]] = field(default_factory=list)
    failure: str | None = None
    skill_stack: list[str] = field(default_factory=list)


EmergencyCheck = Callable[[], bool]
SkillResolver = Callable[[str], SkillManifest]


class SkillRuntime:
    """Executes a validated graph; generated content only selects host capabilities."""

    def __init__(
        self,
        allowed_capabilities: set[str],
        *,
        max_actions: int = 256,
        timeout_seconds: float = 30.0,
        skill_resolver: SkillResolver | None = None,
        max_composition_depth: int = 12,
    ) -> None:
        self.allowed_capabilities = set(allowed_capabilities)
        self.max_actions = max_actions
        self.timeout_seconds = timeout_seconds
        self.skill_resolver = skill_resolver
        self.max_composition_depth = max_composition_depth

    async def run(
        self,
        manifest: SkillManifest,
        executor: AtomicExecutor,
        parameters: Mapping[str, JsonValue],
        state: Mapping[str, JsonValue],
        *,
        cancelled: asyncio.Event | None = None,
        emergency_stop: EmergencyCheck | None = None,
    ) -> ExecutionResult:
        validate_manifest(manifest, self.allowed_capabilities)
        _validate_json_value(dict(state), "state")
        _validate_json_value(dict(parameters), "parameters")
        bound = self._bind_parameters(manifest, parameters)
        context = _Context(bound, dict(state), skill_stack=[manifest.skill_id])
        started = time.monotonic()
        terminal = ExecutionStatus.FAILED
        try:
            if not bool(SafeExpression(manifest.applicability).evaluate(self._variables(context))):
                context.failure = "applicability condition is false"
            elif not self._safety_ok(manifest, context):
                terminal = ExecutionStatus.SAFETY_STOP
                context.failure = "a safety constraint is false"
            else:
                ok = await asyncio.wait_for(
                    self._node(manifest.root, executor, context, manifest, cancelled, emergency_stop),
                    timeout=self.timeout_seconds,
                )
                terminal = ExecutionStatus.SUCCEEDED if ok else ExecutionStatus.FAILED
                if not ok and manifest.recovery and terminal is ExecutionStatus.FAILED:
                    await self._node(manifest.recovery, executor, context, manifest, cancelled, emergency_stop)
        except asyncio.TimeoutError:
            terminal = ExecutionStatus.BUDGET_EXHAUSTED
            context.failure = "skill timeout exhausted"
        except _Cancelled:
            terminal = ExecutionStatus.CANCELLED
            context.failure = "execution cancelled"
        except _SafetyStop:
            terminal = ExecutionStatus.SAFETY_STOP
            context.failure = "emergency or safety constraint stopped execution"
        except _BudgetExhausted:
            terminal = ExecutionStatus.BUDGET_EXHAUSTED
            context.failure = "action budget exhausted"
        return ExecutionResult(
            status=terminal,
            actions=context.actions,
            elapsed_seconds=time.monotonic() - started,
            final_state=context.state,
            error=context.failure,
            trace=tuple(context.trace),
        )

    async def _node(
        self,
        node: BehaviorNode,
        executor: AtomicExecutor,
        context: _Context,
        manifest: SkillManifest,
        cancelled: asyncio.Event | None,
        emergency_stop: EmergencyCheck | None,
    ) -> bool:
        self._gate(context, manifest, cancelled, emergency_stop)
        if node.kind is NodeKind.SUCCEED:
            return True
        if node.kind is NodeKind.FAIL:
            context.failure = str(node.config.get("reason", "explicit failure"))
            return False
        if node.kind is NodeKind.CONDITION:
            return bool(SafeExpression(str(node.config["expression"])).evaluate(self._variables(context)))
        if node.kind is NodeKind.SEQUENCE:
            for child in node.children:
                if not await self._node(child, executor, context, manifest, cancelled, emergency_stop):
                    return False
            return True
        if node.kind is NodeKind.SELECTOR:
            for child in node.children:
                if await self._node(child, executor, context, manifest, cancelled, emergency_stop):
                    return True
            return False
        if node.kind is NodeKind.REPEAT:
            for _ in range(int(node.config["count"])):
                if not await self._node(node.children[0], executor, context, manifest, cancelled, emergency_stop):
                    return False
            return True
        if node.kind is NodeKind.SKILL:
            if self.skill_resolver is None:
                context.failure = "skill composition resolver is not configured"
                return False
            skill_id = str(node.config["skill_id"])
            if skill_id in context.skill_stack:
                context.failure = f"recursive skill composition detected: {skill_id}"
                return False
            if len(context.skill_stack) >= self.max_composition_depth:
                context.failure = "skill composition depth exhausted"
                return False
            child = self.skill_resolver(skill_id)
            expected_version = manifest.dependencies.get(skill_id)
            if expected_version and child.version != expected_version:
                context.failure = (
                    f"dependency mismatch for {skill_id}: expected {expected_version}, got {child.version}"
                )
                return False
            validate_manifest(child, self.allowed_capabilities)
            arguments = self._resolve(node.config.get("arguments", {}), context)
            if not isinstance(arguments, dict):
                raise ValueError("composed skill arguments must be an object")
            _validate_json_value(arguments, "composed skill arguments")
            child_parameters = self._bind_parameters(child, arguments)
            previous_parameters = context.parameters
            context.parameters = child_parameters
            context.skill_stack.append(skill_id)
            try:
                if not bool(SafeExpression(child.applicability).evaluate(self._variables(context))):
                    context.failure = f"composed skill {skill_id} is not applicable"
                    return False
                if not self._safety_ok(child, context):
                    raise _SafetyStop
                succeeded = await self._node(
                    child.root, executor, context, child, cancelled, emergency_stop
                )
                if not succeeded and child.recovery:
                    await self._node(
                        child.recovery, executor, context, child, cancelled, emergency_stop
                    )
                return succeeded
            finally:
                context.skill_stack.pop()
                context.parameters = previous_parameters
        if node.kind is NodeKind.PROGRAM:
            return await self._program(
                node, executor, context, manifest, cancelled, emergency_stop
            )
        if node.kind is NodeKind.ACTION:
            if context.actions >= self.max_actions:
                raise _BudgetExhausted
            capability = str(node.config["capability"])
            arguments = self._resolve(node.config.get("arguments", {}), context)
            if not isinstance(arguments, dict):
                raise ValueError("resolved action arguments must be an object")
            _validate_json_value(arguments, "action arguments")
            result = await executor.execute(capability, arguments)
            _validate_json_value(dict(result.observation), "action observation")
            context.actions += 1
            context.state.update(result.observation)
            context.trace.append(
                {
                    "node_id": node.node_id,
                    "capability": capability,
                    "arguments": arguments,
                    "success": result.success,
                    "error": result.error,
                    "cost": result.cost,
                }
            )
            if not result.success:
                context.failure = result.error or f"{capability} failed"
            return result.success
        raise AssertionError(f"unhandled node kind: {node.kind}")

    async def _program(
        self,
        node: BehaviorNode,
        executor: AtomicExecutor,
        context: _Context,
        manifest: SkillManifest,
        cancelled: asyncio.Event | None,
        emergency_stop: EmergencyCheck | None,
    ) -> bool:
        program = BytecodeProgram.from_config(node.config)
        program.validate(self.allowed_capabilities)
        counter = 0
        pc = program.entry
        while counter < program.max_steps:
            self._gate(context, manifest, cancelled, emergency_stop)
            instruction = program.instructions[pc]
            counter += 1
            if instruction.op is BytecodeOp.RETURN:
                return bool(instruction.success)
            if instruction.op is BytecodeOp.GOTO:
                pc = int(instruction.target)
                continue
            if instruction.op is BytecodeOp.BRANCH:
                outcome = bool(
                    SafeExpression(str(instruction.expression)).evaluate(self._variables(context))
                )
                pc = int(instruction.if_true if outcome else instruction.if_false)
                continue
            if instruction.op is BytecodeOp.ACTION:
                if context.actions >= self.max_actions:
                    raise _BudgetExhausted
                arguments = self._resolve(dict(instruction.arguments), context)
                if not isinstance(arguments, dict):
                    raise ValueError("bytecode action arguments must be an object")
                _validate_json_value(arguments, "bytecode action arguments")
                result = await executor.execute(str(instruction.capability), arguments)
                _validate_json_value(dict(result.observation), "bytecode action observation")
                context.actions += 1
                context.state.update(result.observation)
                context.trace.append(
                    {
                        "node_id": f"{node.node_id}:{pc}",
                        "capability": str(instruction.capability),
                        "arguments": arguments,
                        "success": result.success,
                        "error": result.error,
                        "cost": result.cost,
                        "sandbox": "finite_bytecode",
                    }
                )
                if not result.success:
                    context.failure = result.error or f"{instruction.capability} failed"
                pc = int(instruction.on_success if result.success else instruction.on_failure)
                continue
        context.failure = "sandbox bytecode step budget exhausted"
        return False

    def _gate(
        self,
        context: _Context,
        manifest: SkillManifest,
        cancelled: asyncio.Event | None,
        emergency_stop: EmergencyCheck | None,
    ) -> None:
        if cancelled and cancelled.is_set():
            raise _Cancelled
        if emergency_stop and emergency_stop():
            raise _SafetyStop
        if not self._safety_ok(manifest, context):
            raise _SafetyStop

    @staticmethod
    def _variables(context: _Context) -> dict[str, Any]:
        return {"params": context.parameters, "state": context.state}

    def _safety_ok(self, manifest: SkillManifest, context: _Context) -> bool:
        variables = self._variables(context)
        return all(bool(SafeExpression(item).evaluate(variables)) for item in manifest.safety_constraints)

    def _resolve(self, value: JsonValue, context: _Context) -> JsonValue:
        if isinstance(value, str) and value.startswith("="):
            return SafeExpression(value[1:]).evaluate(self._variables(context))
        if isinstance(value, list):
            return [self._resolve(item, context) for item in value]
        if isinstance(value, dict):
            return {key: self._resolve(item, context) for key, item in value.items()}
        return value

    @staticmethod
    def _bind_parameters(manifest: SkillManifest, supplied: Mapping[str, JsonValue]) -> dict[str, JsonValue]:
        unknown = set(supplied) - set(manifest.parameters)
        if unknown:
            raise ValueError(f"unknown skill parameters: {sorted(unknown)}")
        bound: dict[str, JsonValue] = {}
        for name, spec in manifest.parameters.items():
            if name in supplied:
                value = supplied[name]
            elif spec.required and spec.default is None:
                raise ValueError(f"missing parameter: {name}")
            else:
                value = spec.default
            if spec.enum and value not in spec.enum:
                raise ValueError(f"parameter {name} is outside its enum")
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                if spec.minimum is not None and value < spec.minimum:
                    raise ValueError(f"parameter {name} is below minimum")
                if spec.maximum is not None and value > spec.maximum:
                    raise ValueError(f"parameter {name} is above maximum")
            bound[name] = value
        return bound


class _Cancelled(Exception):
    pass


class _SafetyStop(Exception):
    pass


class _BudgetExhausted(Exception):
    pass


def _validate_json_value(value: Any, location: str) -> None:
    if value is None or isinstance(value, (bool, int, str)):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise TypeError(f"{location} contains a non-finite number")
        return
    if isinstance(value, list):
        for item in value:
            _validate_json_value(item, location)
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError(f"{location} contains a non-string object key")
            _validate_json_value(item, location)
        return
    raise TypeError(f"{location} contains forbidden runtime object {type(value).__name__}")
