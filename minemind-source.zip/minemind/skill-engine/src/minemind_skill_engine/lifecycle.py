from __future__ import annotations

import statistics
from dataclasses import dataclass
from enum import Enum
from typing import Callable, Mapping

from .dsl import JsonValue, SkillManifest, SkillTest
from .registry import SkillStore
from .runtime import AtomicExecutor, ExecutionStatus, SkillRuntime
from .sandbox import SafeExpression
from .validation import validate_manifest


class SkillStage(str, Enum):
    CANDIDATE = "candidate"
    TESTED = "tested"
    PROMOTED = "promoted"
    REJECTED = "rejected"
    DEPRECATED = "deprecated"


@dataclass(frozen=True, slots=True)
class Thresholds:
    minimum_success_rate: float = 0.8
    minimum_safety_rate: float = 1.0
    maximum_mean_actions: float = 128.0
    maximum_mean_cost: float = float("inf")


@dataclass(frozen=True, slots=True)
class CandidateReport:
    skill_id: str
    version: str
    success_rate: float
    safety_rate: float
    mean_actions: float
    mean_cost: float
    critic_approved: bool
    failures: tuple[str, ...]
    evidence_source: str | None = None
    trusted_isolated_evidence: bool = False
    promoted: bool = False

    def to_dict(self) -> dict[str, object]:
        return {
            "skill_id": self.skill_id,
            "version": self.version,
            "success_rate": self.success_rate,
            "safety_rate": self.safety_rate,
            "mean_actions": self.mean_actions,
            "mean_cost": self.mean_cost,
            "critic_approved": self.critic_approved,
            "failures": list(self.failures),
            "evidence_source": self.evidence_source,
            "trusted_isolated_evidence": self.trusted_isolated_evidence,
            "promoted": self.promoted,
        }


@dataclass(frozen=True, slots=True)
class EvaluationEvidence:
    source: str
    isolated: bool
    trusted: bool


ExecutorFactory = Callable[[SkillTest], AtomicExecutor]
Critic = Callable[[SkillManifest, CandidateReport], tuple[bool, str | None]]


class SkillLifecycle:
    def __init__(self, store: SkillStore, runtime: SkillRuntime) -> None:
        self.store = store
        self.runtime = runtime

    def submit(self, manifest: SkillManifest) -> None:
        validate_manifest(manifest, self.runtime.allowed_capabilities)
        self.store.put(manifest, SkillStage.CANDIDATE.value)

    async def evaluate(
        self,
        manifest: SkillManifest,
        executor_factory: ExecutorFactory,
        *,
        thresholds: Thresholds = Thresholds(),
        critic: Critic | None = None,
        evidence: EvaluationEvidence | None = None,
    ) -> CandidateReport:
        if not manifest.tests:
            raise ValueError("candidate promotion requires at least one isolated test")
        outcomes: list[bool] = []
        safety: list[bool] = []
        actions: list[int] = []
        costs: list[float] = []
        failures: list[str] = []
        for scenario in manifest.tests:
            limited_runtime = SkillRuntime(
                self.runtime.allowed_capabilities,
                max_actions=min(scenario.max_actions, self.runtime.max_actions),
                timeout_seconds=self.runtime.timeout_seconds,
                skill_resolver=self.runtime.skill_resolver,
                max_composition_depth=self.runtime.max_composition_depth,
            )
            result = await limited_runtime.run(
                manifest,
                executor_factory(scenario),
                scenario.parameters,
                scenario.initial_state,
            )
            expected = False
            if result.status is ExecutionStatus.SUCCEEDED:
                expected = bool(SafeExpression(scenario.expected).evaluate({"state": result.final_state}))
            outcomes.append(expected)
            safety.append(result.status is not ExecutionStatus.SAFETY_STOP)
            actions.append(result.actions)
            costs.append(sum(float(item.get("cost", 0.0)) for item in result.trace))
            if not expected:
                failures.append(f"{scenario.name}: {result.error or result.status.value}")
        trusted_isolated = bool(
            evidence is not None and evidence.trusted and evidence.isolated and evidence.source.strip()
        )
        if critic is None:
            failures.append("critic: independent critic approval is required")
        if not trusted_isolated:
            failures.append("evidence: trusted isolated evaluation is required")
        preliminary = CandidateReport(
            manifest.skill_id,
            manifest.version,
            statistics.fmean(outcomes),
            statistics.fmean(safety),
            statistics.fmean(actions),
            statistics.fmean(costs),
            critic_approved=False,
            failures=tuple(failures),
            evidence_source=evidence.source if evidence else None,
            trusted_isolated_evidence=trusted_isolated,
        )
        critic_approved = False
        if critic:
            critic_approved, criticism = critic(manifest, preliminary)
            if criticism:
                failures.append(f"critic: {criticism}")
        passes = (
            preliminary.success_rate >= thresholds.minimum_success_rate
            and preliminary.safety_rate >= thresholds.minimum_safety_rate
            and preliminary.mean_actions <= thresholds.maximum_mean_actions
            and preliminary.mean_cost <= thresholds.maximum_mean_cost
            and critic_approved
            and trusted_isolated
        )
        report = CandidateReport(
            preliminary.skill_id,
            preliminary.version,
            preliminary.success_rate,
            preliminary.safety_rate,
            preliminary.mean_actions,
            preliminary.mean_cost,
            critic_approved,
            tuple(failures),
            evidence_source=evidence.source if evidence else None,
            trusted_isolated_evidence=trusted_isolated,
            promoted=passes,
        )
        self.store.record_evaluation(manifest.skill_id, manifest.version, report.to_dict())
        if passes:
            self.store.set_stage(manifest.skill_id, manifest.version, SkillStage.TESTED.value)
            self.store.promote(manifest.skill_id, manifest.version)
        else:
            self.store.set_stage(manifest.skill_id, manifest.version, SkillStage.REJECTED.value)
        return report

    def rollback(self, skill_id: str) -> SkillManifest:
        return self.store.rollback(skill_id)

    def record_live_outcome(
        self,
        skill_id: str,
        *,
        success: bool,
        safe: bool,
        actions: int,
        cost: float,
        context: dict[str, object] | None = None,
        rollback_threshold: float = 0.6,
        minimum_attempts: int = 10,
    ) -> SkillManifest | None:
        active = self.store.active(skill_id)
        self.store.record_live_execution(
            skill_id,
            active.version,
            success=success,
            safe=safe,
            actions=actions,
            cost=cost,
            context=context,
        )
        performance = self.store.recent_performance(skill_id, active.version)
        regressed = (
            performance["attempts"] >= minimum_attempts
            and (performance["success_rate"] < rollback_threshold or performance["safety_rate"] < 1.0)
        )
        if regressed:
            try:
                return self.store.rollback(skill_id)
            except LookupError:
                self.store.deprecate(skill_id, active.version)
        return None
