from __future__ import annotations

import re
from typing import Iterable

from .dsl import BehaviorNode, NodeKind, ParameterSpec, SkillManifest
from .bytecode import BytecodeProgram
from .sandbox import SafeExpression


class InvalidSkill(ValueError):
    pass


_IDENTIFIER = re.compile(r"^[a-z][a-z0-9_.-]{2,127}$")
_VERS = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$")
_PARAM_TYPES = {"boolean", "integer", "number", "string", "object", "array"}


def _walk(node: BehaviorNode, depth: int = 1) -> Iterable[tuple[BehaviorNode, int]]:
    yield node, depth
    for child in node.children:
        yield from _walk(child, depth + 1)


def validate_manifest(
    manifest: SkillManifest,
    allowed_capabilities: set[str],
    *,
    max_nodes: int = 256,
    max_depth: int = 24,
    max_repeat: int = 64,
) -> None:
    if not _IDENTIFIER.match(manifest.skill_id):
        raise InvalidSkill("skill_id must be a namespaced lowercase identifier")
    if not _VERS.match(manifest.version):
        raise InvalidSkill("version must use semantic major.minor.patch form")
    if not 0 <= manifest.confidence <= 1:
        raise InvalidSkill("confidence must be between zero and one")
    SafeExpression(manifest.applicability)
    for constraint in manifest.safety_constraints:
        SafeExpression(constraint)
    for test in manifest.tests:
        SafeExpression(test.expected)
        if not 1 <= test.max_actions <= 10_000:
            raise InvalidSkill("test action budget is invalid")
    for name, spec in manifest.parameters.items():
        _validate_parameter(name, spec)
    visited: set[str] = set()
    count = 0
    for node, depth in _walk(manifest.root):
        count += 1
        if count > max_nodes:
            raise InvalidSkill("behavior graph exceeds node limit")
        if depth > max_depth:
            raise InvalidSkill("behavior graph exceeds depth limit")
        if node.node_id in visited:
            raise InvalidSkill(f"duplicate node id: {node.node_id}")
        visited.add(node.node_id)
        _validate_node(node, allowed_capabilities, max_repeat)
    if manifest.recovery:
        for node, depth in _walk(manifest.recovery):
            count += 1
            if count > max_nodes or depth > max_depth:
                raise InvalidSkill("recovery graph exceeds limits")
            if node.node_id in visited:
                raise InvalidSkill(f"duplicate node id: {node.node_id}")
            visited.add(node.node_id)
            _validate_node(node, allowed_capabilities, max_repeat)


def _validate_parameter(name: str, spec: ParameterSpec) -> None:
    if not _IDENTIFIER.match(name):
        raise InvalidSkill(f"invalid parameter name: {name}")
    if spec.type not in _PARAM_TYPES:
        raise InvalidSkill(f"unsupported parameter type: {spec.type}")
    if spec.minimum is not None and spec.maximum is not None and spec.minimum > spec.maximum:
        raise InvalidSkill(f"invalid bounds for parameter {name}")


def _validate_node(node: BehaviorNode, allowed: set[str], max_repeat: int) -> None:
    if node.kind in {NodeKind.SEQUENCE, NodeKind.SELECTOR} and not node.children:
        raise InvalidSkill(f"{node.kind.value} must have children")
    if node.kind is NodeKind.ACTION:
        capability = str(node.config.get("capability", ""))
        if capability not in allowed:
            raise InvalidSkill(f"unavailable atomic capability: {capability}")
        if node.children:
            raise InvalidSkill("action nodes cannot have children")
    elif node.kind is NodeKind.SKILL:
        skill_id = str(node.config.get("skill_id", ""))
        if not _IDENTIFIER.match(skill_id):
            raise InvalidSkill("composed skill node requires a valid skill_id")
        if node.children:
            raise InvalidSkill("composed skill nodes cannot have children")
    elif node.kind is NodeKind.PROGRAM:
        if node.children:
            raise InvalidSkill("bytecode program nodes cannot have children")
        try:
            BytecodeProgram.from_config(node.config).validate(allowed)
        except (KeyError, TypeError, ValueError) as error:
            raise InvalidSkill(f"invalid sandbox bytecode: {error}") from error
    elif node.kind is NodeKind.CONDITION:
        SafeExpression(str(node.config.get("expression", "False")))
        if node.children:
            raise InvalidSkill("condition nodes cannot have children")
    elif node.kind is NodeKind.REPEAT:
        count = node.config.get("count")
        if not isinstance(count, int) or isinstance(count, bool) or not 1 <= count <= max_repeat:
            raise InvalidSkill("repeat count is missing or outside the bounded range")
        if len(node.children) != 1:
            raise InvalidSkill("repeat requires exactly one child")
    elif node.kind in {NodeKind.SUCCEED, NodeKind.FAIL} and node.children:
        raise InvalidSkill(f"{node.kind.value} nodes cannot have children")
