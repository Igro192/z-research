from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from enum import StrEnum
import json
import math
from pathlib import Path
import sqlite3
from threading import RLock
from typing import Any, Iterable, Mapping


class BeliefKind(StrEnum):
    OBSERVED = "observed"
    REMEMBERED = "remembered"
    INFERRED = "inferred"
    PREDICTED = "predicted"
    UNKNOWN = "unknown"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


@dataclass(slots=True, frozen=True)
class Belief:
    key: str
    value: Any
    kind: BeliefKind
    confidence: float
    uncertainty: float
    observed_at: str
    evidence_ids: tuple[str, ...]
    world_id: str
    expires_tick: int | None = None


@dataclass(slots=True, frozen=True)
class PredictionComparison:
    prediction_id: str
    matched: int
    contradicted: int
    unknown: int
    error: float
    surprises: tuple[str, ...]


class WorldModel:
    """Thread-safe persistent belief state with explicit epistemic classes."""

    def __init__(self, database: str | Path = ":memory:") -> None:
        self._lock = RLock()
        self._db = sqlite3.connect(str(database), check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._migrate()

    def _migrate(self) -> None:
        with self._db:
            self._db.executescript(
                """
                PRAGMA journal_mode=WAL;
                PRAGMA foreign_keys=ON;
                CREATE TABLE IF NOT EXISTS world_model_schema_version(version INTEGER PRIMARY KEY);
                INSERT OR IGNORE INTO world_model_schema_version(version) VALUES (1);
                CREATE TABLE IF NOT EXISTS beliefs(
                    world_id TEXT NOT NULL, key TEXT NOT NULL, value_json TEXT NOT NULL,
                    kind TEXT NOT NULL, confidence REAL NOT NULL, uncertainty REAL NOT NULL,
                    observed_at TEXT NOT NULL, evidence_json TEXT NOT NULL,
                    expires_tick INTEGER, updated_tick INTEGER NOT NULL,
                    PRIMARY KEY(world_id, key)
                );
                CREATE TABLE IF NOT EXISTS entities(
                    world_id TEXT NOT NULL, entity_id TEXT NOT NULL, type TEXT NOT NULL,
                    x REAL NOT NULL, y REAL NOT NULL, z REAL NOT NULL,
                    vx REAL NOT NULL, vy REAL NOT NULL, vz REAL NOT NULL,
                    last_tick INTEGER NOT NULL, confidence REAL NOT NULL,
                    data_json TEXT NOT NULL, PRIMARY KEY(world_id, entity_id)
                );
                CREATE TABLE IF NOT EXISTS spatial_cells(
                    world_id TEXT NOT NULL, dimension TEXT NOT NULL,
                    x INTEGER NOT NULL, y INTEGER NOT NULL, z INTEGER NOT NULL,
                    block_id TEXT NOT NULL, properties_json TEXT NOT NULL,
                    last_tick INTEGER NOT NULL, confidence REAL NOT NULL,
                    PRIMARY KEY(world_id, dimension, x, y, z)
                );
                CREATE TABLE IF NOT EXISTS causal_edges(
                    cause TEXT NOT NULL, effect TEXT NOT NULL, successes REAL NOT NULL DEFAULT 1,
                    failures REAL NOT NULL DEFAULT 1, updated_at TEXT NOT NULL,
                    PRIMARY KEY(cause, effect)
                );
                """
            )

    def close(self) -> None:
        self._db.close()

    def upsert_belief(self, belief: Belief, tick: int) -> None:
        if not 0 <= belief.confidence <= 1 or not 0 <= belief.uncertainty <= 1:
            raise ValueError("confidence and uncertainty must be probabilities")
        with self._lock, self._db:
            existing = self._db.execute(
                "SELECT kind, confidence FROM beliefs WHERE world_id=? AND key=?",
                (belief.world_id, belief.key),
            ).fetchone()
            # Direct observations supersede inference. Weaker inference cannot erase
            # a more confident direct observation.
            if existing and existing["kind"] == BeliefKind.OBSERVED.value and belief.kind != BeliefKind.OBSERVED:
                if float(existing["confidence"]) >= belief.confidence:
                    return
            self._db.execute(
                """INSERT INTO beliefs VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(world_id,key) DO UPDATE SET
                value_json=excluded.value_json, kind=excluded.kind,
                confidence=excluded.confidence, uncertainty=excluded.uncertainty,
                observed_at=excluded.observed_at, evidence_json=excluded.evidence_json,
                expires_tick=excluded.expires_tick, updated_tick=excluded.updated_tick""",
                (
                    belief.world_id, belief.key, json.dumps(belief.value, sort_keys=True), belief.kind.value,
                    belief.confidence, belief.uncertainty, belief.observed_at,
                    json.dumps(belief.evidence_ids), belief.expires_tick, tick,
                ),
            )

    def ingest_observation(self, world_id: str, observation: Mapping[str, Any], evidence_id: str) -> list[Belief]:
        tick = int(observation.get("tick", 0))
        env = observation.get("environment", {})
        player = observation.get("player", {})
        dimension = str(env.get("dimension", "unknown"))
        emitted: list[Belief] = []
        for key, value in (
            ("player", player),
            ("controlled_actor", observation.get("controlled_actor", {})),
            ("human_players", observation.get("human_players", [])),
            ("embodiment", observation.get("embodiment", {})),
            ("environment", env),
            ("inventory", observation.get("inventory", [])),
        ):
            belief = Belief(
                key=key, value=value, kind=BeliefKind.OBSERVED, confidence=1.0,
                uncertainty=0.0, observed_at=_now(), evidence_ids=(evidence_id,), world_id=world_id,
                expires_tick=tick + (2 if key in {"player", "controlled_actor", "human_players", "embodiment"} else 20),
            )
            self.upsert_belief(belief, tick)
            emitted.append(belief)

        with self._lock, self._db:
            for block in observation.get("nearby_blocks", []):
                position = block.get("position", block)
                try:
                    coords = tuple(int(position[k]) for k in ("x", "y", "z"))
                    block_id = str(block["id"])
                except (KeyError, TypeError, ValueError):
                    continue
                self._db.execute(
                    """INSERT INTO spatial_cells VALUES(?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(world_id,dimension,x,y,z) DO UPDATE SET
                    block_id=excluded.block_id, properties_json=excluded.properties_json,
                    last_tick=excluded.last_tick, confidence=excluded.confidence""",
                    (world_id, dimension, *coords, block_id, json.dumps(block.get("properties", {})), tick, 1.0),
                )
            for entity in observation.get("nearby_entities", []):
                self._track_entity(world_id, entity, tick)
        return emitted

    def _track_entity(self, world_id: str, entity: Mapping[str, Any], tick: int) -> None:
        entity_id = str(entity.get("uuid") or entity.get("id") or "")
        pos = entity.get("position", {})
        if not entity_id or not all(axis in pos for axis in ("x", "y", "z")):
            return
        x, y, z = (float(pos[axis]) for axis in ("x", "y", "z"))
        old = self._db.execute(
            "SELECT x,y,z,last_tick,vx,vy,vz FROM entities WHERE world_id=? AND entity_id=?",
            (world_id, entity_id),
        ).fetchone()
        vx = vy = vz = 0.0
        if old and tick > old["last_tick"]:
            dt = tick - old["last_tick"]
            # Exponential smoothing avoids treating network jitter as intent.
            vx = 0.6 * ((x - old["x"]) / dt) + 0.4 * old["vx"]
            vy = 0.6 * ((y - old["y"]) / dt) + 0.4 * old["vy"]
            vz = 0.6 * ((z - old["z"]) / dt) + 0.4 * old["vz"]
        self._db.execute(
            """INSERT INTO entities VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(world_id,entity_id) DO UPDATE SET
            type=excluded.type,x=excluded.x,y=excluded.y,z=excluded.z,
            vx=excluded.vx,vy=excluded.vy,vz=excluded.vz,last_tick=excluded.last_tick,
            confidence=excluded.confidence,data_json=excluded.data_json""",
            (world_id, entity_id, str(entity.get("type", "unknown")), x, y, z, vx, vy, vz, tick, 1.0, json.dumps(entity)),
        )

    def get_belief(self, world_id: str, key: str, current_tick: int | None = None) -> Belief | None:
        row = self._db.execute("SELECT * FROM beliefs WHERE world_id=? AND key=?", (world_id, key)).fetchone()
        if not row:
            return None
        confidence = float(row["confidence"])
        uncertainty = float(row["uncertainty"])
        if current_tick is not None and row["expires_tick"] is not None and current_tick > row["expires_tick"]:
            age = current_tick - row["expires_tick"]
            confidence *= math.exp(-age / 200.0)
            uncertainty = max(uncertainty, 1 - confidence)
        return Belief(
            key=row["key"], value=json.loads(row["value_json"]), kind=BeliefKind(row["kind"]),
            confidence=confidence, uncertainty=uncertainty, observed_at=row["observed_at"],
            evidence_ids=tuple(json.loads(row["evidence_json"])), world_id=row["world_id"],
            expires_tick=row["expires_tick"],
        )

    def query_spatial(self, world_id: str, dimension: str, center: tuple[int, int, int], radius: int, limit: int = 512) -> list[dict[str, Any]]:
        if not 0 <= radius <= 128:
            raise ValueError("radius must be between 0 and 128")
        x, y, z = center
        rows = self._db.execute(
            """SELECT * FROM spatial_cells WHERE world_id=? AND dimension=?
            AND x BETWEEN ? AND ? AND y BETWEEN ? AND ? AND z BETWEEN ? AND ?
            ORDER BY (x-?)*(x-?)+(y-?)*(y-?)+(z-?)*(z-?) LIMIT ?""",
            (world_id, dimension, x-radius, x+radius, y-radius, y+radius, z-radius, z+radius,
             x, x, y, y, z, z, min(limit, 2048)),
        ).fetchall()
        return [{"position": {"x": r["x"], "y": r["y"], "z": r["z"]}, "id": r["block_id"],
                 "properties": json.loads(r["properties_json"]), "confidence": r["confidence"]} for r in rows]

    def predict_entities(self, world_id: str, current_tick: int, horizon_ticks: int = 5) -> list[dict[str, Any]]:
        rows = self._db.execute("SELECT * FROM entities WHERE world_id=?", (world_id,)).fetchall()
        predictions = []
        for row in rows:
            age = max(0, current_tick - row["last_tick"])
            confidence = float(row["confidence"]) * math.exp(-age / 40.0) * math.exp(-horizon_ticks / 100.0)
            dt = age + horizon_ticks
            predictions.append({
                "entity_id": row["entity_id"], "type": row["type"],
                "position": {"x": row["x"] + row["vx"] * dt, "y": row["y"] + row["vy"] * dt,
                             "z": row["z"] + row["vz"] * dt},
                "confidence": confidence, "kind": BeliefKind.PREDICTED.value,
            })
        return predictions

    def compare_prediction(self, prediction_id: str, expected: Iterable[Mapping[str, Any]], actual: Iterable[Mapping[str, Any]]) -> PredictionComparison:
        actual_by_path = {str(effect.get("path")): effect.get("value") for effect in actual if "path" in effect}
        matched = contradicted = unknown = 0
        surprises: list[str] = []
        for effect in expected:
            path = str(effect.get("path", ""))
            if path not in actual_by_path:
                unknown += 1
            elif actual_by_path[path] == effect.get("value"):
                matched += 1
            else:
                contradicted += 1
                surprises.append(path)
        total = max(1, matched + contradicted + unknown)
        return PredictionComparison(prediction_id, matched, contradicted, unknown, (contradicted + 0.5 * unknown) / total, tuple(surprises))

    def update_causality(self, cause: str, effects: Iterable[str], succeeded: bool) -> None:
        with self._lock, self._db:
            for effect in effects:
                self._db.execute(
                    """INSERT INTO causal_edges(cause,effect,successes,failures,updated_at) VALUES(?,?,?,?,?)
                    ON CONFLICT(cause,effect) DO UPDATE SET
                    successes=successes+excluded.successes-1,
                    failures=failures+excluded.failures-1, updated_at=excluded.updated_at""",
                    (cause, effect, 2 if succeeded else 1, 1 if succeeded else 2, _now()),
                )

    def causal_probability(self, cause: str, effect: str) -> float:
        row = self._db.execute("SELECT successes,failures FROM causal_edges WHERE cause=? AND effect=?", (cause, effect)).fetchone()
        return 0.5 if not row else row["successes"] / (row["successes"] + row["failures"])

    def compact_summary(self, world_id: str, current_tick: int, max_entities: int = 16) -> dict[str, Any]:
        beliefs = {}
        for key in ("player", "controlled_actor", "human_players", "embodiment", "environment", "inventory"):
            belief = self.get_belief(world_id, key, current_tick)
            beliefs[key] = asdict(belief) if belief else {"kind": BeliefKind.UNKNOWN.value, "confidence": 0.0}
        entities = self.predict_entities(world_id, current_tick)[:max_entities]
        return {"world_id": world_id, "tick": current_tick, "beliefs": beliefs, "nearby_entity_predictions": entities}
