import tempfile
import unittest

from minemind_world_model import WorldModel


class WorldModelTests(unittest.TestCase):
    def test_ingests_and_tracks_epistemic_state(self):
        model = WorldModel(":memory:")
        model.ingest_observation("w", {"tick": 10, "player": {"health": 20}, "environment": {"dimension": "overworld"},
            "inventory": [], "nearby_blocks": [{"id": "minecraft:stone", "position": {"x": 1, "y": 2, "z": 3}}]}, "e1")
        self.assertEqual(model.get_belief("w", "player").value["health"], 20)
        self.assertEqual(model.query_spatial("w", "overworld", (0, 2, 0), 4)[0]["id"], "minecraft:stone")

    def test_prediction_comparison_reports_surprise(self):
        model = WorldModel()
        result = model.compare_prediction("p", [{"path": "inventory.log", "value": 1}], [{"path": "inventory.log", "value": 0}])
        self.assertEqual(result.contradicted, 1)
        self.assertGreater(result.error, 0)

    def test_causal_belief_learns(self):
        model = WorldModel()
        before = model.causal_probability("mine", "block_removed")
        model.update_causality("mine", ["block_removed"], True)
        self.assertGreater(model.causal_probability("mine", "block_removed"), before)


if __name__ == "__main__":
    unittest.main()
