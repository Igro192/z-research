from __future__ import annotations

import base64
import hashlib
import json
import math
import re
import sqlite3
import threading
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Sequence

from .models import (
    EpistemicStatus,
    MemoryInput,
    MemoryKind,
    MemoryRecord,
    Provenance,
    RetrievedMemory,
)


_TOKEN = re.compile(r"[a-z0-9_:-]+")
_UNTRUSTED_SOURCE_TYPES = {
    "chat",
    "player_chat",
    "server_message",
    "sign",
    "book",
    "item_name",
}


@dataclass(frozen=True, slots=True)
class DeletionScope:
    memory_ids: tuple[str, ...] = ()
    kinds: tuple[MemoryKind, ...] = ()
    world_id: str | None = None
    objective_id: str | None = None
    before: float | None = None
    include_all: bool = False


class MemoryStore:
    """SQLite memory with provenance, epistemic state, correction, and deletion.

    Content originating in chat, signs, books, item names, or server messages is
    permanently marked ``data_only``. Consumers can use it as evidence but must
    never promote it to system-policy authority.
    """

    def __init__(self, database: str | Path) -> None:
        self.database = str(database)
        self._local = threading.local()
        self._migrate()

    def _connection(self) -> sqlite3.Connection:
        connection = getattr(self._local, "connection", None)
        if connection is None:
            connection = sqlite3.connect(self.database, timeout=10, isolation_level=None)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys=ON")
            connection.execute("PRAGMA journal_mode=WAL")
            self._local.connection = connection
        return connection

    def _migrate(self) -> None:
        self._connection().executescript(
            """
            CREATE TABLE IF NOT EXISTS memory_schema_version(version INTEGER PRIMARY KEY);
            INSERT OR IGNORE INTO memory_schema_version(version) VALUES (1);
            CREATE TABLE IF NOT EXISTS memories(
                memory_id TEXT PRIMARY KEY,
                kind TEXT NOT NULL,
                text_content TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                media BLOB,
                mime_type TEXT,
                source_type TEXT NOT NULL,
                source_id TEXT NOT NULL,
                source_actor TEXT NOT NULL,
                source_observed_at REAL NOT NULL,
                source_trust REAL NOT NULL CHECK(source_trust BETWEEN 0 AND 1),
                external_untrusted INTEGER NOT NULL,
                instruction_authority TEXT NOT NULL,
                epistemic_status TEXT NOT NULL,
                confidence REAL NOT NULL CHECK(confidence BETWEEN 0 AND 1),
                uncertainty REAL NOT NULL CHECK(uncertainty BETWEEN 0 AND 1),
                salience REAL NOT NULL CHECK(salience BETWEEN 0 AND 1),
                world_id TEXT,
                objective_id TEXT,
                x REAL, y REAL, z REAL,
                tags_json TEXT NOT NULL,
                content_hash TEXT NOT NULL,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                last_accessed_at REAL NOT NULL,
                expires_at REAL,
                duplicate_count INTEGER NOT NULL DEFAULT 1,
                archived INTEGER NOT NULL DEFAULT 0,
                superseded_by TEXT,
                FOREIGN KEY(superseded_by) REFERENCES memories(memory_id)
            );
            CREATE INDEX IF NOT EXISTS memory_lookup
              ON memories(kind, world_id, archived, updated_at);
            CREATE INDEX IF NOT EXISTS memory_hash
              ON memories(kind, world_id, content_hash);
            CREATE TABLE IF NOT EXISTS evidence_links(
                memory_id TEXT NOT NULL,
                evidence_memory_id TEXT NOT NULL,
                relation TEXT NOT NULL,
                created_at REAL NOT NULL,
                PRIMARY KEY(memory_id, evidence_memory_id, relation),
                FOREIGN KEY(memory_id) REFERENCES memories(memory_id) ON DELETE CASCADE,
                FOREIGN KEY(evidence_memory_id) REFERENCES memories(memory_id) ON DELETE CASCADE
            );
            """
        )

    def remember(self, item: MemoryInput) -> MemoryRecord:
        self._validate(item)
        now = time.time()
        digest = self._digest(item)
        world_key = item.world_id or ""
        connection = self._connection()
        connection.execute("BEGIN IMMEDIATE")
        try:
            existing = connection.execute(
                """SELECT memory_id,confidence,uncertainty,duplicate_count FROM memories
                   WHERE kind=? AND COALESCE(world_id,'')=? AND content_hash=?
                     AND archived=0 AND superseded_by IS NULL""",
                (item.kind.value, world_key, digest),
            ).fetchone()
            if existing:
                duplicate_count = int(existing["duplicate_count"]) + 1
                combined_confidence = 1.0 - (1.0 - float(existing["confidence"])) * (1.0 - item.confidence)
                combined_uncertainty = min(float(existing["uncertainty"]), item.uncertainty)
                connection.execute(
                    """UPDATE memories SET confidence=?, uncertainty=?, salience=MAX(salience,?),
                       duplicate_count=?, updated_at=?, last_accessed_at=? WHERE memory_id=?""",
                    (combined_confidence, combined_uncertainty, item.salience, duplicate_count, now, now, existing["memory_id"]),
                )
                memory_id = str(existing["memory_id"])
            else:
                memory_id = str(uuid.uuid4())
                coords = item.coordinates or (None, None, None)
                external_untrusted = (
                    item.provenance.external_untrusted
                    or item.provenance.source_type.casefold() in _UNTRUSTED_SOURCE_TYPES
                )
                authority = "data_only" if external_untrusted else "evidence"
                connection.execute(
                    """INSERT INTO memories(
                      memory_id,kind,text_content,payload_json,media,mime_type,source_type,source_id,
                      source_actor,source_observed_at,source_trust,external_untrusted,instruction_authority,
                      epistemic_status,confidence,uncertainty,salience,world_id,objective_id,x,y,z,tags_json,
                      content_hash,created_at,updated_at,last_accessed_at,expires_at
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        memory_id,
                        item.kind.value,
                        item.text,
                        json.dumps(item.payload, sort_keys=True, separators=(",", ":")),
                        item.media,
                        item.mime_type,
                        item.provenance.source_type,
                        item.provenance.source_id,
                        item.provenance.actor,
                        item.provenance.observed_at,
                        item.provenance.trust,
                        int(external_untrusted),
                        authority,
                        item.status.value,
                        item.confidence,
                        item.uncertainty,
                        item.salience,
                        item.world_id,
                        item.objective_id,
                        coords[0], coords[1], coords[2],
                        json.dumps(sorted(set(item.tags))),
                        digest,
                        now, now, now, item.expires_at,
                    ),
                )
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise
        return self.get(memory_id)

    def get(self, memory_id: str, *, touch: bool = True) -> MemoryRecord:
        connection = self._connection()
        row = connection.execute("SELECT * FROM memories WHERE memory_id=?", (memory_id,)).fetchone()
        if not row:
            raise KeyError(f"unknown memory {memory_id}")
        if touch:
            connection.execute("UPDATE memories SET last_accessed_at=? WHERE memory_id=?", (time.time(), memory_id))
        return self._decode(row)

    def retrieve(
        self,
        query: str,
        *,
        kinds: Sequence[MemoryKind] = (),
        world_id: str | None = None,
        objective_id: str | None = None,
        near_coordinates: tuple[float, float, float] | None = None,
        radius: float | None = None,
        limit: int = 12,
        include_archived: bool = False,
        now: float | None = None,
    ) -> tuple[RetrievedMemory, ...]:
        if limit < 1:
            return ()
        instant = now or time.time()
        clauses = ["superseded_by IS NULL", "(expires_at IS NULL OR expires_at>?)"]
        arguments: list[object] = [instant]
        if not include_archived:
            clauses.append("archived=0")
        if kinds:
            clauses.append(f"kind IN ({','.join('?' for _ in kinds)})")
            arguments.extend(kind.value for kind in kinds)
        if world_id is not None:
            clauses.append("(world_id=? OR world_id IS NULL)")
            arguments.append(world_id)
        if objective_id is not None:
            clauses.append("(objective_id=? OR objective_id IS NULL)")
            arguments.append(objective_id)
        rows = self._connection().execute(
            f"SELECT * FROM memories WHERE {' AND '.join(clauses)} ORDER BY updated_at DESC LIMIT 2000",
            arguments,
        ).fetchall()
        query_tokens = self._tokens(query)
        ranked: list[RetrievedMemory] = []
        for row in rows:
            record = self._decode(row)
            spatial_weight = 0.0
            if near_coordinates is not None and record.item.coordinates is not None:
                distance = math.dist(near_coordinates, record.item.coordinates)
                if radius is not None and distance > radius:
                    continue
                spatial_weight = 1.0 / (1.0 + distance / 32.0)
            content_tokens = self._tokens(record.item.text + " " + " ".join(record.item.tags))
            if query_tokens:
                intersection = len(query_tokens & content_tokens)
                relevance = intersection / math.sqrt(max(1, len(query_tokens) * len(content_tokens)))
            else:
                relevance = 0.5
            confidence = record.item.confidence * (1.0 - record.item.uncertainty) * record.item.provenance.trust
            age_days = max(0.0, instant - record.updated_at) / 86_400
            recency = math.exp(-age_days / 30.0)
            status_factor = {
                EpistemicStatus.OBSERVED: 1.0,
                EpistemicStatus.REMEMBERED: 0.9,
                EpistemicStatus.INFERRED: 0.75,
                EpistemicStatus.PREDICTED: 0.6,
                EpistemicStatus.UNKNOWN: 0.2,
                EpistemicStatus.CONTRADICTED: 0.05,
            }[record.item.status]
            score = status_factor * (
                0.45 * relevance
                + 0.25 * confidence
                + 0.12 * recency
                + 0.10 * record.item.salience
                + 0.08 * spatial_weight
            )
            ranked.append(RetrievedMemory(record, score, relevance, confidence, recency))
        ranked.sort(key=lambda item: (-item.score, item.record.memory_id))
        result = tuple(ranked[:limit])
        if result:
            ids = [item.record.memory_id for item in result]
            placeholders = ",".join("?" for _ in ids)
            self._connection().execute(
                f"UPDATE memories SET last_accessed_at=? WHERE memory_id IN ({placeholders})", [instant, *ids]
            )
        return result

    def correct(self, old_memory_id: str, replacement: MemoryInput, reason: str) -> MemoryRecord:
        old = self.get(old_memory_id, touch=False)
        if (
            old.item.kind == replacement.kind
            and old.item.text == replacement.text
            and old.item.payload == replacement.payload
            and old.item.media == replacement.media
            and old.item.world_id == replacement.world_id
        ):
            raise ValueError("a correction must provide contradictory replacement evidence")
        new = self.remember(replacement)
        connection = self._connection()
        connection.execute("BEGIN IMMEDIATE")
        try:
            connection.execute(
                "UPDATE memories SET epistemic_status=?, superseded_by=?, updated_at=? WHERE memory_id=?",
                (EpistemicStatus.CONTRADICTED.value, new.memory_id, time.time(), old.memory_id),
            )
            connection.execute(
                "INSERT OR IGNORE INTO evidence_links(memory_id,evidence_memory_id,relation,created_at) VALUES(?,?,?,?)",
                (new.memory_id, old.memory_id, f"corrects:{reason[:240]}", time.time()),
            )
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise
        return new

    def consolidate(
        self,
        source_ids: Sequence[str],
        summary: MemoryInput,
    ) -> MemoryRecord:
        if not source_ids:
            raise ValueError("consolidation requires source memories")
        for source_id in source_ids:
            self.get(source_id, touch=False)
        consolidated = self.remember(summary)
        connection = self._connection()
        connection.execute("BEGIN IMMEDIATE")
        try:
            for source_id in source_ids:
                if source_id == consolidated.memory_id:
                    continue
                connection.execute(
                    "INSERT OR IGNORE INTO evidence_links(memory_id,evidence_memory_id,relation,created_at) VALUES(?,?,?,?)",
                    (consolidated.memory_id, source_id, "consolidates", time.time()),
                )
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise
        return consolidated

    def apply_forgetting(
        self,
        *,
        now: float | None = None,
        minimum_age_days: float = 30.0,
        retention_threshold: float = 0.18,
        protected_kinds: Sequence[MemoryKind] = (MemoryKind.USER_PREFERENCE, MemoryKind.PROCEDURAL),
    ) -> int:
        instant = now or time.time()
        cutoff = instant - minimum_age_days * 86_400
        protected = {item.value for item in protected_kinds}
        rows = self._connection().execute(
            "SELECT memory_id,kind,confidence,uncertainty,salience,last_accessed_at FROM memories WHERE archived=0 AND updated_at<?",
            (cutoff,),
        ).fetchall()
        archive: list[str] = []
        for row in rows:
            if row["kind"] in protected:
                continue
            age_days = max(0.0, instant - float(row["last_accessed_at"])) / 86_400
            access_recency = math.exp(-age_days / 30.0)
            retention = (
                0.35 * float(row["confidence"]) * (1.0 - float(row["uncertainty"]))
                + 0.4 * float(row["salience"])
                + 0.25 * access_recency
            )
            if retention < retention_threshold:
                archive.append(str(row["memory_id"]))
        if archive:
            placeholders = ",".join("?" for _ in archive)
            self._connection().execute(
                f"UPDATE memories SET archived=1,updated_at=? WHERE memory_id IN ({placeholders})",
                [instant, *archive],
            )
        return len(archive)

    def export_jsonl(self, destination: str | Path, scope: DeletionScope = DeletionScope(include_all=True)) -> int:
        rows = self._select_scope(scope)
        with Path(destination).open("w", encoding="utf-8") as handle:
            for row in rows:
                record = self._decode(row)
                item = asdict(record.item)
                item["kind"] = record.item.kind.value
                item["status"] = record.item.status.value
                if record.item.media is not None:
                    item["media"] = base64.b64encode(record.item.media).decode("ascii")
                payload = asdict(record)
                payload["item"] = item
                handle.write(json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n")
        return len(rows)

    def delete(self, scope: DeletionScope) -> int:
        if not any((scope.memory_ids, scope.kinds, scope.world_id, scope.objective_id, scope.before, scope.include_all)):
            raise ValueError("refusing unscoped deletion; set include_all explicitly")
        rows = self._select_scope(scope)
        ids = [str(row["memory_id"]) for row in rows]
        if not ids:
            return 0
        connection = self._connection()
        placeholders = ",".join("?" for _ in ids)
        connection.execute("BEGIN IMMEDIATE")
        try:
            connection.execute(
                f"DELETE FROM evidence_links WHERE memory_id IN ({placeholders}) OR evidence_memory_id IN ({placeholders})",
                [*ids, *ids],
            )
            connection.execute(f"UPDATE memories SET superseded_by=NULL WHERE superseded_by IN ({placeholders})", ids)
            connection.execute(f"DELETE FROM memories WHERE memory_id IN ({placeholders})", ids)
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise
        return len(ids)

    def _select_scope(self, scope: DeletionScope) -> list[sqlite3.Row]:
        clauses: list[str] = []
        arguments: list[object] = []
        if scope.memory_ids:
            clauses.append(f"memory_id IN ({','.join('?' for _ in scope.memory_ids)})")
            arguments.extend(scope.memory_ids)
        if scope.kinds:
            clauses.append(f"kind IN ({','.join('?' for _ in scope.kinds)})")
            arguments.extend(kind.value for kind in scope.kinds)
        if scope.world_id is not None:
            clauses.append("world_id=?")
            arguments.append(scope.world_id)
        if scope.objective_id is not None:
            clauses.append("objective_id=?")
            arguments.append(scope.objective_id)
        if scope.before is not None:
            clauses.append("created_at<?")
            arguments.append(scope.before)
        if not clauses and not scope.include_all:
            raise ValueError("scope does not select any memories")
        where = " AND ".join(clauses) if clauses else "1=1"
        return self._connection().execute(f"SELECT * FROM memories WHERE {where}", arguments).fetchall()

    def close(self) -> None:
        connection = getattr(self._local, "connection", None)
        if connection is not None:
            connection.close()
            self._local.connection = None

    def __enter__(self) -> "MemoryStore":
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()

    @staticmethod
    def _validate(item: MemoryInput) -> None:
        for name, value in (("confidence", item.confidence), ("uncertainty", item.uncertainty), ("salience", item.salience), ("trust", item.provenance.trust)):
            if not 0 <= value <= 1:
                raise ValueError(f"{name} must be between zero and one")
        if item.media is not None and not item.mime_type:
            raise ValueError("multimodal memory requires a MIME type")
        if item.mime_type and item.media is None:
            raise ValueError("MIME type requires media bytes")
        json.dumps(item.payload)

    @classmethod
    def _digest(cls, item: MemoryInput) -> str:
        normalized = " ".join(sorted(cls._tokens(item.text)))
        payload = json.dumps(item.payload, sort_keys=True, separators=(",", ":"))
        hasher = hashlib.sha256()
        hasher.update(normalized.encode())
        hasher.update(b"\0")
        hasher.update(payload.encode())
        hasher.update(b"\0")
        hasher.update(item.media or b"")
        return hasher.hexdigest()

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return set(_TOKEN.findall(text.casefold()))

    @staticmethod
    def _decode(row: sqlite3.Row) -> MemoryRecord:
        coords = None if row["x"] is None else (float(row["x"]), float(row["y"]), float(row["z"]))
        provenance = Provenance(
            source_type=str(row["source_type"]),
            source_id=str(row["source_id"]),
            observed_at=float(row["source_observed_at"]),
            actor=str(row["source_actor"]),
            trust=float(row["source_trust"]),
            external_untrusted=bool(row["external_untrusted"]),
        )
        item = MemoryInput(
            kind=MemoryKind(row["kind"]),
            text=str(row["text_content"]),
            payload=json.loads(row["payload_json"]),
            media=row["media"],
            mime_type=row["mime_type"],
            provenance=provenance,
            status=EpistemicStatus(row["epistemic_status"]),
            confidence=float(row["confidence"]),
            uncertainty=float(row["uncertainty"]),
            salience=float(row["salience"]),
            world_id=row["world_id"],
            objective_id=row["objective_id"],
            coordinates=coords,
            expires_at=row["expires_at"],
            tags=tuple(json.loads(row["tags_json"])),
        )
        return MemoryRecord(
            memory_id=str(row["memory_id"]),
            item=item,
            created_at=float(row["created_at"]),
            updated_at=float(row["updated_at"]),
            last_accessed_at=float(row["last_accessed_at"]),
            duplicate_count=int(row["duplicate_count"]),
            archived=bool(row["archived"]),
            superseded_by=row["superseded_by"],
            instruction_authority=str(row["instruction_authority"]),
        )
