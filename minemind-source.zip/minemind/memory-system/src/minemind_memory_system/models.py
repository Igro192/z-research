from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping


class MemoryKind(str, Enum):
    WORKING = "working"
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    SPATIAL = "spatial"
    CAUSAL = "causal"
    PROCEDURAL = "procedural"
    AUTOBIOGRAPHICAL = "autobiographical"
    USER_PREFERENCE = "user_preference"
    SELF_MODEL = "self_model"


class EpistemicStatus(str, Enum):
    OBSERVED = "observed"
    REMEMBERED = "remembered"
    INFERRED = "inferred"
    PREDICTED = "predicted"
    UNKNOWN = "unknown"
    CONTRADICTED = "contradicted"


@dataclass(frozen=True, slots=True)
class Provenance:
    source_type: str
    source_id: str
    observed_at: float
    actor: str = "system"
    trust: float = 1.0
    external_untrusted: bool = False


@dataclass(frozen=True, slots=True)
class MemoryInput:
    kind: MemoryKind
    text: str = ""
    payload: Mapping[str, Any] = field(default_factory=dict)
    media: bytes | None = None
    mime_type: str | None = None
    provenance: Provenance = field(default_factory=lambda: Provenance("system", "unknown", 0.0))
    status: EpistemicStatus = EpistemicStatus.OBSERVED
    confidence: float = 1.0
    uncertainty: float = 0.0
    salience: float = 0.5
    world_id: str | None = None
    objective_id: str | None = None
    coordinates: tuple[float, float, float] | None = None
    expires_at: float | None = None
    tags: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class MemoryRecord:
    memory_id: str
    item: MemoryInput
    created_at: float
    updated_at: float
    last_accessed_at: float
    duplicate_count: int
    archived: bool
    superseded_by: str | None
    instruction_authority: str


@dataclass(frozen=True, slots=True)
class RetrievedMemory:
    record: MemoryRecord
    score: float
    relevance: float
    confidence_weight: float
    recency_weight: float

