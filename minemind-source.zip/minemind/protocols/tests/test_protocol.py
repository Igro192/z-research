import json
import unittest

from minemind_protocol import ActionCommand, ActionKind, Envelope, EventKind, Objective, Observation, ProtocolError, new_envelope


class ProtocolTests(unittest.TestCase):
    def test_round_trip_preserves_envelope(self):
        objective = Objective.create("discover something new", "player-1")
        event = new_envelope(EventKind.OBJECTIVE, objective, source="fabric", session_id="s1")
        self.assertEqual(Envelope.from_json(event.to_json()), event)

    def test_action_requires_atomic_parameters(self):
        with self.assertRaises(ProtocolError):
            ActionCommand.create(ActionKind.NAVIGATE)
        with self.assertRaises(ProtocolError):
            ActionCommand.create(ActionKind.SNEAK)
        with self.assertRaises(ProtocolError):
            ActionCommand.create(ActionKind.INVENTORY)
        action = ActionCommand.create(ActionKind.NAVIGATE, {"target": {"x": 1, "y": 64, "z": 2}})
        self.assertEqual(action.kind, ActionKind.NAVIGATE)

    def test_rejects_incompatible_major(self):
        event = new_envelope(EventKind.HEARTBEAT, {}, source="test", session_id="s")
        value = event.to_dict()
        value["version"] = "2.0"
        with self.assertRaises(ProtocolError):
            Envelope.from_dict(value)

    def test_serializes_enum_values(self):
        action = ActionCommand.create(ActionKind.JUMP)
        encoded = json.dumps(action.to_dict())
        self.assertIn('"jump"', encoded)

    def test_travel_requires_target_dimension(self):
        with self.assertRaises(ProtocolError):
            ActionCommand.create(ActionKind.TRAVEL)
        action = ActionCommand.create(ActionKind.TRAVEL, {"dimension": "the_nether"})
        self.assertEqual(action.kind, ActionKind.TRAVEL)

    def test_separate_player_action_fields_round_trip(self):
        action = ActionCommand.create(
            ActionKind.COLLECT,
            {"selector": "#minecraft:logs", "count": 1},
            objective_id="objective-1",
            actor_id="minemind_player",
            before_state_revision=8,
            expected_postconditions=({"path": "inventory.count", "op": "delta_gte", "value": 1},),
        )
        decoded = ActionCommand.from_dict(action.to_dict())
        self.assertEqual(decoded, action)
        self.assertEqual(decoded.actor_id, "minemind_player")

    def test_protocol_accepts_actuator_progress_and_capability_reports(self):
        progress = new_envelope(EventKind.ACTUATOR_PROGRESS, {"action_id": "a", "phase": "moving"}, source="bot", session_id="s")
        capability = new_envelope(EventKind.CAPABILITY_REPORT, {"implemented": ["navigate"]}, source="bot", session_id="s")
        self.assertEqual(Envelope.from_json(progress.to_json()).kind, EventKind.ACTUATOR_PROGRESS)
        self.assertEqual(Envelope.from_json(capability.to_json()).kind, EventKind.CAPABILITY_REPORT)

    def test_observation_rejects_human_controlled_actor_alias(self):
        with self.assertRaises(ProtocolError):
            Observation(
                1, 1, {"uuid": "bot"}, {},
                controlled_actor={"uuid": "bot", "role": "minemind_ai"},
                human_players=({"uuid": "bot", "name": "owner"},),
            )


if __name__ == "__main__":
    unittest.main()
