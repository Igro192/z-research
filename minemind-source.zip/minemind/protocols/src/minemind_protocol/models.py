from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import StrEnum
import json
from typing import Any, Mapping
from uuid import uuid4

PROTOCOL_VERSION = "1.1"


class ProtocolError(ValueError):
    pass


class EventKind(StrEnum):
    HELLO = "hello"
    HEARTBEAT = "heartbeat"
    OBSERVATION = "observation"
    OBJECTIVE = "objective"
    ACTION = "action"
    ACTION_RESULT = "action_result"
    QUERY = "query"
    CONTROL = "control"
    STATUS = "status"
    LEARNING_RECORD = "learning_record"
    AUDIT = "audit"
    OBSERVATION_DELTA = "observation.delta"
    ACTUATOR_EXECUTE = "actuator.execute"
    ACTUATOR_PROGRESS = "actuator.progress"
    ACTUATOR_RESULT = "actuator.result"
    CAPABILITY_REPORT = "capability.report"
    CONTROL_CANCEL = "control.cancel"


class TrustClass(StrEnum):
    SYSTEM = "system"
    AUTHORIZED_USER = "authorized_user"
    GAME_OBSERVATION = "game_observation"
    EXTERNAL_UNTRUSTED = "external_untrusted"
    GENERATED_SKILL = "generated_skill"


class ActionKind(StrEnum):
    MOVE = "move"
    LOOK = "look"
    JUMP = "jump"
    SWIM = "swim"
    SNEAK = "sneak"
    NAVIGATE = "navigate"
    INTERACT = "interact"
    USE = "use"
    PLACE = "place"
    BREAK = "break"
    MINE = "mine"
    ATTACK = "attack"
    DEFEND = "defend"
    INVENTORY = "inventory"
    EQUIP = "equip"
    CRAFT = "craft"
    SMELT = "smelt"
    TRADE = "trade"
    ENCHANT = "enchant"
    BREW = "brew"
    CONTAINER = "container"
    COMMUNICATE = "communicate"
    QUERY = "query"
    CANCEL = "cancel"
    COLLECT = "collect"
    ACQUIRE = "acquire"
    FOLLOW = "follow"
    RESPAWN = "respawn"
    TRAVEL = "travel"
    BUILD_PORTAL = "build_portal"
    MOUNT = "mount"


_REQUIRED_ACTION_PARAMETERS: dict[ActionKind, frozenset[str]] = {
    ActionKind.MOVE: frozenset({"direction"}),
    ActionKind.LOOK: frozenset({"yaw", "pitch"}),
    ActionKind.NAVIGATE: frozenset({"target"}),
    ActionKind.INTERACT: frozenset({"target"}),
    ActionKind.PLACE: frozenset({"item", "target"}),
    ActionKind.BREAK: frozenset({"target"}),
    ActionKind.MINE: frozenset({"target"}),
    ActionKind.ATTACK: frozenset({"target"}),
    ActionKind.SNEAK: frozenset({"enabled"}),
    ActionKind.INVENTORY: frozenset({"operation"}),
    ActionKind.EQUIP: frozenset({"item"}),
    ActionKind.CRAFT: frozenset({"recipe", "count"}),
    ActionKind.SMELT: frozenset({"input", "fuel"}),
    ActionKind.TRADE: frozenset({"offer"}),
    ActionKind.ENCHANT: frozenset({"item"}),
    ActionKind.BREW: frozenset({"recipe"}),
    ActionKind.CONTAINER: frozenset({"operation"}),
    ActionKind.COMMUNICATE: frozenset({"message"}),
    ActionKind.QUERY: frozenset({"selector"}),
    ActionKind.COLLECT: frozenset({"selector", "count"}),
    ActionKind.ACQUIRE: frozenset({"selector", "count"}),
    ActionKind.FOLLOW: frozenset({"target"}),
    # Dimension travel is an atomic portal interaction.  Portal construction
    # and resource acquisition remain separate capabilities, so a planner can
    # report a precise gap instead of pretending a missing portal exists.
    ActionKind.TRAVEL: frozenset({"dimension"}),
    ActionKind.BUILD_PORTAL: frozenset({"dimension"}),
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def _plain(value: Any) -> Any:
    if isinstance(value, StrEnum):
        return value.value
    if hasattr(value, "to_dict"):
        return value.to_dict()
    if isinstance(value, Mapping):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_plain(v) for v in value]
    return value


@dataclass(slots=True, frozen=True)
class ActionCommand:
    action_id: str
    kind: ActionKind
    parameters: Mapping[str, Any] = field(default_factory=dict)
    deadline_ms: int = 10_000
    predicted_effects: tuple[Mapping[str, Any], ...] = ()
    risk: float = 0.0
    requires_confirmation: bool = False
    plan_step_id: str | None = None
    objective_id: str | None = None
    actor_id: str = "minemind_player"
    before_state_revision: int | None = None
    expected_postconditions: tuple[Mapping[str, Any], ...] = ()

    def __post_init__(self) -> None:
        if not self.action_id:
            raise ProtocolError("action_id is required")
        if not 1 <= self.deadline_ms <= 1_200_000:
            raise ProtocolError("deadline_ms must be between 1 and 1200000")
        if not 0.0 <= self.risk <= 1.0:
            raise ProtocolError("risk must be between 0 and 1")
        missing = _REQUIRED_ACTION_PARAMETERS.get(self.kind, frozenset()) - self.parameters.keys()
        if missing:
            raise ProtocolError(f"{self.kind.value} missing parameters: {sorted(missing)}")

    @classmethod
    def create(cls, kind: ActionKind | str, parameters: Mapping[str, Any] | None = None, **kwargs: Any) -> "ActionCommand":
        return cls(str(uuid4()), ActionKind(kind), parameters or {}, **kwargs)

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ActionCommand":
        return cls(
            action_id=str(value["action_id"]),
            kind=ActionKind(value["kind"]),
            parameters=dict(value.get("parameters", {})),
            deadline_ms=int(value.get("deadline_ms", 10_000)),
            predicted_effects=tuple(value.get("predicted_effects", ())),
            risk=float(value.get("risk", 0.0)),
            requires_confirmation=bool(value.get("requires_confirmation", False)),
            plan_step_id=value.get("plan_step_id"),
            objective_id=value.get("objective_id"),
            actor_id=str(value.get("actor_id", "minemind_player")),
            before_state_revision=int(value["before_state_revision"]) if value.get("before_state_revision") is not None else None,
            expected_postconditions=tuple(value.get("expected_postconditions", ())),
        )

    def to_dict(self) -> dict[str, Any]:
        return _plain(asdict(self))


@dataclass(slots=True, frozen=True)
class ActionResult:
    action_id: str
    status: str
    started_at: str
    finished_at: str
    actual_effects: tuple[Mapping[str, Any], ...] = ()
    error: Mapping[str, Any] | None = None
    resource_cost: Mapping[str, float] = field(default_factory=dict)
    interrupted_by: str | None = None

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ActionResult":
        return cls(
            action_id=str(value["action_id"]), status=str(value["status"]),
            started_at=str(value["started_at"]), finished_at=str(value["finished_at"]),
            actual_effects=tuple(value.get("actual_effects", ())), error=value.get("error"),
            resource_cost=dict(value.get("resource_cost", {})), interrupted_by=value.get("interrupted_by"),
        )

    def to_dict(self) -> dict[str, Any]:
        return _plain(asdict(self))


@dataclass(slots=True, frozen=True)
class Observation:
    tick: int
    sequence: int
    player: Mapping[str, Any]
    environment: Mapping[str, Any]
    inventory: tuple[Mapping[str, Any], ...] = ()
    nearby_blocks: tuple[Mapping[str, Any], ...] = ()
    nearby_entities: tuple[Mapping[str, Any], ...] = ()
    events: tuple[Mapping[str, Any], ...] = ()
    interfaces: tuple[Mapping[str, Any], ...] = ()
    visual_frame: Mapping[str, Any] | None = None
    full: bool = False
    # ``player`` is always the entity controlled by cognition.  In the live
    # separate-player embodiment it is MineMind, never the human owner.
    # These additive fields make that binding explicit while keeping v1.0
    # recordings readable.
    controlled_actor: Mapping[str, Any] = field(default_factory=dict)
    human_players: tuple[Mapping[str, Any], ...] = ()
    embodiment: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        player_id = str(self.player.get("uuid") or self.player.get("id") or "")
        actor_id = str(self.controlled_actor.get("uuid") or self.controlled_actor.get("id") or "")
        if player_id and actor_id and player_id != actor_id:
            raise ProtocolError("observation player does not match controlled_actor")
        human_ids = {
            str(item.get("uuid") or item.get("id") or "")
            for item in self.human_players
            if isinstance(item, Mapping)
        }
        if actor_id and actor_id in human_ids:
            raise ProtocolError("controlled_actor cannot also be a human player")

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "Observation":
        return cls(
            tick=int(value["tick"]), sequence=int(value["sequence"]),
            player=dict(value.get("player", {})), environment=dict(value.get("environment", {})),
            inventory=tuple(value.get("inventory", ())), nearby_blocks=tuple(value.get("nearby_blocks", ())),
            nearby_entities=tuple(value.get("nearby_entities", ())), events=tuple(value.get("events", ())),
            interfaces=tuple(value.get("interfaces", ())), visual_frame=value.get("visual_frame"),
            full=bool(value.get("full", False)),
            controlled_actor=dict(value.get("controlled_actor", {})),
            human_players=tuple(value.get("human_players", ())),
            embodiment=dict(value.get("embodiment", {})),
        )

    def to_dict(self) -> dict[str, Any]:
        return _plain(asdict(self))


@dataclass(slots=True, frozen=True)
class Objective:
    objective_id: str
    text: str
    requested_by: str
    created_at: str = field(default_factory=_utc_now)
    constraints: Mapping[str, Any] = field(default_factory=dict)
    success_criteria: tuple[Mapping[str, Any], ...] = ()

    @classmethod
    def create(cls, text: str, requested_by: str, **kwargs: Any) -> "Objective":
        normalized = text.strip()
        if not normalized:
            raise ProtocolError("objective text cannot be empty")
        return cls(str(uuid4()), normalized, requested_by, **kwargs)

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "Objective":
        return cls(
            objective_id=str(value["objective_id"]), text=str(value["text"]),
            requested_by=str(value["requested_by"]), created_at=str(value.get("created_at", _utc_now())),
            constraints=dict(value.get("constraints", {})),
            success_criteria=tuple(value.get("success_criteria", ())),
        )

    def to_dict(self) -> dict[str, Any]:
        return _plain(asdict(self))


@dataclass(slots=True, frozen=True)
class Envelope:
    id: str
    version: str
    kind: EventKind
    timestamp: str
    source: str
    session_id: str
    world_id: str | None
    correlation_id: str | None
    trust: TrustClass
    payload: Mapping[str, Any]

    def __post_init__(self) -> None:
        try:
            major = int(self.version.split(".", 1)[0])
        except (ValueError, IndexError) as exc:
            raise ProtocolError(f"invalid protocol version {self.version!r}") from exc
        if major != int(PROTOCOL_VERSION.split(".")[0]):
            raise ProtocolError(f"unsupported protocol major version {self.version}")
        for name in ("id", "source", "session_id"):
            if not getattr(self, name):
                raise ProtocolError(f"{name} is required")

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "Envelope":
        required = {"id", "version", "kind", "timestamp", "source", "session_id", "trust", "payload"}
        missing = required - value.keys()
        if missing:
            raise ProtocolError(f"envelope missing fields: {sorted(missing)}")
        return cls(
            id=str(value["id"]), version=str(value["version"]), kind=EventKind(value["kind"]),
            timestamp=str(value["timestamp"]), source=str(value["source"]),
            session_id=str(value["session_id"]), world_id=value.get("world_id"),
            correlation_id=value.get("correlation_id"), trust=TrustClass(value["trust"]),
            payload=dict(value["payload"]),
        )

    @classmethod
    def from_json(cls, value: str | bytes) -> "Envelope":
        try:
            decoded = json.loads(value)
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ProtocolError("invalid JSON envelope") from exc
        if not isinstance(decoded, dict):
            raise ProtocolError("envelope must be a JSON object")
        return cls.from_dict(decoded)

    def to_dict(self) -> dict[str, Any]:
        return _plain(asdict(self))

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), separators=(",", ":"), sort_keys=True)


def new_envelope(
    kind: EventKind | str,
    payload: Mapping[str, Any] | ActionCommand | ActionResult | Observation | Objective,
    *,
    source: str,
    session_id: str,
    world_id: str | None = None,
    correlation_id: str | None = None,
    trust: TrustClass = TrustClass.SYSTEM,
) -> Envelope:
    body = payload.to_dict() if hasattr(payload, "to_dict") else dict(payload)
    return Envelope(
        id=str(uuid4()), version=PROTOCOL_VERSION, kind=EventKind(kind), timestamp=_utc_now(),
        source=source, session_id=session_id, world_id=world_id,
        correlation_id=correlation_id, trust=trust, payload=body,
    )
