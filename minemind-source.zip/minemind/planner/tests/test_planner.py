import unittest

from minemind_planner import HierarchicalPlanner, MilestoneStatus, PlanStore
from minemind_protocol import Objective


async def proposer(role, context):
    if role == "strategic_planner":
        return {"assumptions": [{"claim": "unknown", "confidence": 0.2}], "milestones": [
            {"id": "observe", "description": "resolve relevant unknown state", "completion_evidence": [{"path": "observation.sequence", "op": ">", "value": 0}]},
            {"id": "attempt", "description": "attempt objective using learned competence", "completion_evidence": [{"path": "verifier.objective", "op": "==", "value": True}], "dependencies": ["observe"]},
        ]}
    return {"rationale": "gather missing evidence", "action": {"kind": "query", "parameters": {"selector": "local_state"}}, "predicted_effects": [{"path": "observation.sequence", "value": 1}], "confidence": 0.8}


class PlannerTests(unittest.IsolatedAsyncioTestCase):
    async def test_builds_dag_and_atomic_proposal(self):
        planner = HierarchicalPlanner(proposer, PlanStore())
        plan = await planner.create_plan(Objective.create("novel task", "p"), {}, [], [])
        self.assertEqual(plan.ready()[0].id, "observe")
        proposal = await planner.propose_action(plan.ready()[0], {}, [])
        self.assertEqual(proposal.action.kind.value, "query")

    async def test_repairs_model_cycle_without_inventing_milestones(self):
        async def cyclic(role, context):
            return {"milestones": [
                {"id": "a", "description": "a", "completion_evidence": [{}], "dependencies": ["b"]},
                {"id": "b", "description": "b", "completion_evidence": [{}], "dependencies": ["a"]},
            ]}
        plan = await HierarchicalPlanner(cyclic).create_plan(Objective.create("x", "p"), {}, [], [])
        self.assertEqual([node.id for node in plan.milestones], ["a", "b"])
        self.assertTrue(all(node.dependencies == () for node in plan.milestones))

    async def test_repairs_duplicate_local_model_ids(self):
        async def duplicate(role, context):
            evidence = [{"path": "environment.objective_verified", "op": "==", "value": True}]
            return {"milestones": [
                {"id": "default", "description": "first", "completion_evidence": evidence},
                {"id": "default", "description": "second", "completion_evidence": evidence},
            ]}
        plan = await HierarchicalPlanner(duplicate).create_plan(Objective.create("x", "p"), {}, [], [])
        self.assertEqual([node.id for node in plan.milestones], ["default", "default-2"])

    async def test_repairs_omitted_local_model_milestone_fields_without_claiming_success(self):
        async def omitted(role, context):
            return {"assumptions": [], "milestones": [{"id": "m1"}]}
        plan = await HierarchicalPlanner(omitted).create_plan(
            Objective.create("a novel objective", "p"), {"tick": 42}, [], []
        )
        self.assertIn("a novel objective", plan.milestones[0].description)
        self.assertEqual(
            plan.milestones[0].completion_evidence,
            ({"path": "environment.objective_verified", "op": "==", "value": True},),
        )

    async def test_rejects_trivial_root_existence_as_completion_evidence(self):
        async def trivial(role, context):
            return {"milestones": [{
                "id": "fake",
                "description": "claim progress because the embodiment object exists",
                "completion_evidence": [{"path": "embodiment", "op": "exists", "value": True}],
            }]}

        plan = await HierarchicalPlanner(trivial).create_plan(Objective.create("x", "p"), {}, [], [])
        self.assertEqual(
            plan.milestones[0].completion_evidence,
            ({"path": "environment.objective_verified", "op": "==", "value": True},),
        )

    async def test_model_cannot_mark_milestone_achieved_without_game_evidence(self):
        async def false_claim(role, context):
            return {"milestones": [{
                "id": "fake",
                "description": "unsupported completion claim",
                "completion_evidence": [{"path": "player.health", "op": ">", "value": 0}],
                "status": "achieved",
            }]}

        plan = await HierarchicalPlanner(false_claim).create_plan(Objective.create("x", "p"), {}, [], [])
        self.assertEqual(plan.milestones[0].status, MilestoneStatus.PENDING)

    async def test_repairs_compact_inventory_category_without_inventing_variant(self):
        async def category(role, context):
            return {"milestones": [{
                "id": "logs",
                "description": "obtain a log",
                "completion_evidence": [{
                    "path": "inventory", "op": "contains", "value": {"item_type": "logs"},
                }],
            }]}

        plan = await HierarchicalPlanner(category).create_plan(Objective.create("obtain a log", "p"), {}, [], [])
        self.assertEqual(plan.milestones[0].completion_evidence, ({
            "path": "inventory", "op": "any", "where": {"id_contains": "log"}, "count_gte": 1,
        },))

    async def test_parses_compact_dimension_predicate_from_small_model(self):
        async def compact(role, context):
            return {"milestones": [{
                "id": "nether",
                "description": "enter the Nether",
                "completion_evidence": "player.dimension == 'minecraft:the_nether'",
            }]}

        plan = await HierarchicalPlanner(compact).create_plan(Objective.create("go to the nether", "p"), {}, [], [])
        self.assertEqual(plan.milestones[0].completion_evidence, ({
            "path": "player.dimension", "op": "==", "value": "minecraft:the_nether",
        },))

    async def test_parses_compact_block_contains_predicate(self):
        async def compact(role, context):
            return {"milestones": [{
                "id": "portal",
                "description": "find an active portal",
                "completion_evidence": ["nearby_blocks.contains(nether_portal)"],
            }]}

        plan = await HierarchicalPlanner(compact).create_plan(Objective.create("find a portal", "p"), {}, [], [])
        self.assertEqual(plan.milestones[0].completion_evidence, ({
            "path": "nearby_blocks", "op": "any", "where": {"id_contains": "nether_portal"}, "count_gte": 1,
        },))


if __name__ == "__main__":
    unittest.main()
