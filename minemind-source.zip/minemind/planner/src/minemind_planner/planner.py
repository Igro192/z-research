from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import StrEnum
import json
from pathlib import Path
import sqlite3
from typing import Any, Awaitable, Callable, Mapping, Sequence
from uuid import uuid4

from minemind_protocol import ActionCommand, ActionKind, Objective


class PlanningError(ValueError):
    pass


class MilestoneStatus(StrEnum):
    PENDING = "pending"
    READY = "ready"
    ACTIVE = "active"
    BLOCKED = "blocked"
    ACHIEVED = "achieved"
    INVALIDATED = "invalidated"


@dataclass(slots=True, frozen=True)
class Milestone:
    id: str
    description: str
    completion_evidence: tuple[Mapping[str, Any], ...]
    dependencies: tuple[str, ...] = ()
    status: MilestoneStatus = MilestoneStatus.PENDING
    priority: int = 0
    uncertainty: float = 0.5
    attempts: int = 0


@dataclass(slots=True, frozen=True)
class Plan:
    plan_id: str
    objective_id: str
    version: int
    created_at: str
    reason: str
    assumptions: tuple[Mapping[str, Any], ...]
    milestones: tuple[Milestone, ...]
    parent_version: int | None = None

    def ready(self) -> tuple[Milestone, ...]:
        achieved = {node.id for node in self.milestones if node.status == MilestoneStatus.ACHIEVED}
        return tuple(node for node in self.milestones if node.status in {MilestoneStatus.PENDING, MilestoneStatus.READY, MilestoneStatus.ACTIVE}
                     and all(dep in achieved for dep in node.dependencies))


@dataclass(slots=True, frozen=True)
class TacticalProposal:
    rationale: str
    action: ActionCommand
    predicted_effects: tuple[Mapping[str, Any], ...]
    confidence: float
    alternatives: tuple[Mapping[str, Any], ...] = ()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


class PlanStore:
    def __init__(self, database: str | Path = ":memory:") -> None:
        self.db = sqlite3.connect(str(database), check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        with self.db:
            self.db.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS plans(
                    objective_id TEXT NOT NULL, version INTEGER NOT NULL,
                    plan_id TEXT NOT NULL, created_at TEXT NOT NULL, reason TEXT NOT NULL,
                    parent_version INTEGER, plan_json TEXT NOT NULL,
                    PRIMARY KEY(objective_id, version)
                );
                CREATE TABLE IF NOT EXISTS active_plans(
                    objective_id TEXT PRIMARY KEY, version INTEGER NOT NULL
                );
                """
            )

    @staticmethod
    def _encode(plan: Plan) -> str:
        value = asdict(plan)
        for item in value["milestones"]:
            item["status"] = item["status"].value if isinstance(item["status"], StrEnum) else item["status"]
        return json.dumps(value, sort_keys=True)

    @staticmethod
    def _decode(value: str) -> Plan:
        raw = json.loads(value)
        return Plan(
            plan_id=raw["plan_id"], objective_id=raw["objective_id"], version=raw["version"],
            created_at=raw["created_at"], reason=raw["reason"], assumptions=tuple(raw["assumptions"]),
            milestones=tuple(Milestone(**{**node, "completion_evidence": tuple(node["completion_evidence"]),
                                          "dependencies": tuple(node.get("dependencies", ())),
                                          "status": MilestoneStatus(node["status"])}) for node in raw["milestones"]),
            parent_version=raw.get("parent_version"),
        )

    def save(self, plan: Plan, activate: bool = True) -> None:
        with self.db:
            self.db.execute("INSERT INTO plans VALUES(?,?,?,?,?,?,?)", (plan.objective_id, plan.version, plan.plan_id, plan.created_at, plan.reason, plan.parent_version, self._encode(plan)))
            if activate:
                self.db.execute("INSERT INTO active_plans VALUES(?,?) ON CONFLICT(objective_id) DO UPDATE SET version=excluded.version", (plan.objective_id, plan.version))

    def active(self, objective_id: str) -> Plan | None:
        row = self.db.execute("SELECT p.plan_json FROM plans p JOIN active_plans a USING(objective_id,version) WHERE p.objective_id=?", (objective_id,)).fetchone()
        return self._decode(row[0]) if row else None

    def revisions(self, objective_id: str) -> list[Plan]:
        return [self._decode(row[0]) for row in self.db.execute("SELECT plan_json FROM plans WHERE objective_id=? ORDER BY version", (objective_id,))]

    def close(self) -> None:
        self.db.close()


ProposalFunction = Callable[[str, Mapping[str, Any]], Awaitable[Mapping[str, Any]]]


class HierarchicalPlanner:
    def __init__(self, proposer: ProposalFunction, store: PlanStore | None = None) -> None:
        self.proposer = proposer
        self.store = store or PlanStore()

    async def create_plan(self, objective: Objective, belief: Mapping[str, Any], memories: Sequence[Mapping[str, Any]], skills: Sequence[Mapping[str, Any]]) -> Plan:
        raw = await self.proposer("strategic_planner", {
            "instruction": (
                "Create a milestone DAG, not an action walkthrough. Use only evidence available. Mark unknown prerequisites as investigations. "
                "For an immediate objective with one observable success condition return exactly one milestone; otherwise return at most three. "
                "Use at most two short assumptions and keep descriptions under 80 characters. "
                "Every completion_evidence item must use the observable predicate DSL: path is a key in the supplied observation "
                "(for example tick, inventory, player.health, environment.success_signals.enteredEnd); op is ==, !=, >, >=, <, <=, "
                "contains, exists, or any. For an inventory condition use op any with where fields and count_gte, for example "
                "{\"path\":\"inventory\",\"op\":\"any\",\"where\":{\"id\":\"minecraft:oak_log\"},\"count_gte\":1}."
            ),
            "objective": objective.to_dict(), "belief": belief, "relevant_memories": list(memories),
            "available_skills": list(skills), "required_output": {"assumptions": [], "milestones": []},
        })
        plan = self._parse_plan(objective, raw, reason="initial plan", version=1, parent=None,
                                fallback_tick=int(belief.get("tick", 0)))
        self.store.save(plan)
        return plan

    async def replan(self, objective: Objective, belief: Mapping[str, Any], reason: str,
                     surprises: Sequence[Mapping[str, Any]], memories: Sequence[Mapping[str, Any]],
                     skills: Sequence[Mapping[str, Any]]) -> Plan:
        previous = self.store.active(objective.objective_id)
        if not previous:
            return await self.create_plan(objective, belief, memories, skills)
        raw = await self.proposer("strategic_planner", {
            "instruction": (
                "Revise the milestone DAG from contradictory evidence. Preserve achieved nodes only when their evidence remains valid. "
                "Use only observable path/op/value predicates; list membership uses op any with where fields and count_gte."
            ),
            "objective": objective.to_dict(), "belief": belief, "previous_plan": json.loads(PlanStore._encode(previous)),
            "replan_reason": reason, "surprises": list(surprises), "relevant_memories": list(memories),
            "available_skills": list(skills), "required_output": {"assumptions": [], "milestones": []},
        })
        plan = self._parse_plan(objective, raw, reason=reason, version=previous.version + 1, parent=previous.version,
                                fallback_tick=int(belief.get("tick", 0)))
        self.store.save(plan)
        return plan

    def _parse_plan(self, objective: Objective, raw: Mapping[str, Any], *, reason: str, version: int,
                    parent: int | None, fallback_tick: int = 0) -> Plan:
        nodes_raw = raw.get("milestones")
        if not isinstance(nodes_raw, list) or not nodes_raw:
            raise PlanningError("strategic proposal must contain non-empty milestones")
        nodes: list[Milestone] = []
        seen: set[str] = set()
        for index, item in enumerate(nodes_raw):
            if not isinstance(item, Mapping):
                raise PlanningError("milestone must be an object")
            node_id = str(item.get("id") or f"m{index + 1}")
            if node_id in seen:
                node_id = f"{node_id}-{index + 1}"
            seen.add(node_id)
            description = str(item.get("description", "")).strip()
            evidence = self._normalize_evidence(item.get("completion_evidence", []))
            # Small quantized local models occasionally omit a field even when
            # constrained to JSON. Repair only the structure with a conservative
            # trusted-game predicate; never turn elapsed time into task success.
            if not description:
                description = f"Advance objective through milestone {node_id}: {objective.text[:160]}"
            if not self._valid_evidence(evidence):
                evidence = [{"path": "environment.objective_verified", "op": "==", "value": True}]
            # Model claims are proposals, never trusted completion signals.
            # The runtime promotes a node only after matching its predicates
            # against a fresh trusted game observation.
            status = MilestoneStatus.PENDING
            uncertainty = max(0.0, min(1.0, float(item.get("uncertainty", 0.5))))
            nodes.append(Milestone(node_id, description, tuple(evidence), tuple(map(str, item.get("dependencies", ()))),
                status, int(item.get("priority", 0)), uncertainty, max(0, int(item.get("attempts", 0)))))
        known_ids = {node.id for node in nodes}
        nodes = [Milestone(
            node.id, node.description, node.completion_evidence,
            tuple(dependency for dependency in node.dependencies if dependency in known_ids and dependency != node.id),
            node.status, node.priority, node.uncertainty, node.attempts,
        ) for node in nodes]
        try:
            self._validate_dag(nodes)
        except PlanningError as error:
            if "cycle" not in str(error):
                raise
            # A cyclic model graph has no executable ordering. Preserve the
            # model's milestones/evidence but remove only the malformed edges;
            # later evidence and replanning still decide what is achieved.
            nodes = [Milestone(
                node.id, node.description, node.completion_evidence, (), node.status,
                node.priority, node.uncertainty, node.attempts,
            ) for node in nodes]
            self._validate_dag(nodes)
        return Plan(str(uuid4()), objective.objective_id, version, _now(), reason, tuple(raw.get("assumptions", ())), tuple(nodes), parent)

    @staticmethod
    def _normalize_evidence(value: Any) -> Any:
        """Repair common compact-model list membership into the typed DSL.

        This preserves the model's proposed resource category; it never adds a
        Minecraft-specific goal or claims completion.  Exact evidence is left
        unchanged.
        """
        # Quantized local models occasionally ignore the JSON-schema array and
        # emit compact predicates such as ``player.dimension ==
        # 'minecraft:the_nether'`` or ``nearby_blocks.contains(nether_portal)``.
        # Parse only this conservative predicate grammar; never turn prose or
        # a model's success claim into evidence.
        if isinstance(value, str):
            parsed: list[Mapping[str, Any]] = []
            for fragment in value.split("&&"):
                criterion = HierarchicalPlanner._parse_evidence_fragment(fragment.strip())
                if criterion is None:
                    return value
                parsed.append(criterion)
            return parsed or value
        if not isinstance(value, list):
            return value
        normalized: list[Any] = []
        for raw in value:
            if isinstance(raw, str):
                criterion = HierarchicalPlanner._parse_evidence_fragment(raw.strip())
                normalized.append(criterion if criterion is not None else raw)
                continue
            if not isinstance(raw, Mapping):
                normalized.append(raw)
                continue
            criterion = dict(raw)
            if criterion.get("path") == "inventory" and criterion.get("op") == "contains":
                expected = criterion.get("value")
                where: dict[str, Any] | None = None
                if isinstance(expected, Mapping):
                    item_id = expected.get("id") or expected.get("item")
                    item_type = expected.get("item_type") or expected.get("type")
                    if isinstance(item_id, str) and item_id:
                        where = {"id": item_id} if ":" in item_id else {"id_contains": item_id}
                    elif isinstance(item_type, str) and item_type:
                        where = {"id_contains": item_type.rstrip("s")}
                elif isinstance(expected, str) and expected:
                    where = {"id": expected} if ":" in expected else {"id_contains": expected.rstrip("s")}
                if where:
                    criterion = {"path": "inventory", "op": "any", "where": where,
                                 "count_gte": max(1, int(criterion.get("count_gte", 1)))}
            normalized.append(criterion)
        return normalized

    @staticmethod
    def _parse_evidence_fragment(fragment: str) -> Mapping[str, Any] | None:
        import re
        contains = re.fullmatch(r"([A-Za-z_][A-Za-z0-9_.]*)\.contains\(([^)]+)\)", fragment)
        if contains:
            path, raw_value = contains.groups()
            root = path.split(".", 1)[0]
            if root not in {"inventory", "nearby_blocks", "nearby_entities", "interfaces"}:
                return None
            value = raw_value.strip().strip("'\"")
            if not value:
                return None
            key = "id_contains" if root in {"inventory", "nearby_blocks"} else "name_contains"
            return {"path": root, "op": "any", "where": {key: value}, "count_gte": 1}
        comparison = re.fullmatch(r"([A-Za-z_][A-Za-z0-9_.]*)\s*(==|!=|>=|<=|>|<)\s*(.+)", fragment)
        if not comparison:
            return None
        path, op, raw_value = comparison.groups()
        root = path.split(".", 1)[0]
        if root not in {
            "tick", "sequence", "player", "environment", "inventory", "nearby_blocks",
            "nearby_entities", "interfaces", "controlled_actor", "human_players", "embodiment",
        }:
            return None
        token = raw_value.strip()
        if len(token) >= 2 and token[0] == token[-1] and token[0] in "'\"":
            value: Any = token[1:-1]
        elif token.lower() in {"true", "false"}:
            value = token.lower() == "true"
        else:
            try:
                value = float(token) if "." in token else int(token)
            except ValueError:
                return None
        return {"path": path, "op": op, "value": value}

    @staticmethod
    def _valid_evidence(value: Any) -> bool:
        allowed_roots = {
            "tick", "sequence", "player", "environment", "inventory", "nearby_blocks",
            "nearby_entities", "interfaces", "controlled_actor", "human_players", "embodiment",
        }
        allowed_ops = {"==", "!=", ">", ">=", "<", "<=", "contains", "exists", "any", "count_eq"}
        if not isinstance(value, list) or not value:
            return False
        for criterion in value:
            if not isinstance(criterion, Mapping):
                return False
            path = str(criterion.get("path", ""))
            op = str(criterion.get("op", "=="))
            if not path or path.startswith("/") or path.split(".", 1)[0] not in allowed_roots or op not in allowed_ops:
                return False
            # Root existence is always true in a valid observation and thus
            # cannot demonstrate progress (for example `embodiment exists`).
            if op == "exists" and "." not in path:
                return False
            if op == "any" and (not isinstance(criterion.get("where"), Mapping) or not criterion.get("where")):
                return False
        return True

    @staticmethod
    def _validate_dag(nodes: Sequence[Milestone]) -> None:
        by_id = {node.id: node for node in nodes}
        for node in nodes:
            missing = set(node.dependencies) - by_id.keys()
            if missing:
                raise PlanningError(f"milestone {node.id} has missing dependencies {sorted(missing)}")
        visiting: set[str] = set()
        visited: set[str] = set()
        def visit(node_id: str) -> None:
            if node_id in visiting:
                raise PlanningError("milestone graph contains a cycle")
            if node_id in visited:
                return
            visiting.add(node_id)
            for dependency in by_id[node_id].dependencies:
                visit(dependency)
            visiting.remove(node_id)
            visited.add(node_id)
        for node in nodes:
            visit(node.id)

    async def propose_action(self, milestone: Milestone, belief: Mapping[str, Any], skills: Sequence[Mapping[str, Any]]) -> TacticalProposal:
        raw = await self.proposer("tactical_planner", {
            "instruction": "Propose exactly one bounded atomic action or one promoted skill invocation. Do not assume effects; include a falsifiable prediction.",
            "milestone": asdict(milestone), "belief": belief, "available_skills": list(skills),
            "atomic_actions": [kind.value for kind in ActionKind],
        })
        try:
            kind = ActionKind(raw["action"]["kind"])
            params = raw["action"].get("parameters", {})
            confidence = float(raw.get("confidence", 0.0))
            risk = float(raw.get("risk", 0.0))
            predicted = tuple(raw.get("predicted_effects", ()))
            command = ActionCommand.create(kind, params, predicted_effects=predicted, risk=risk, plan_step_id=milestone.id)
        except (KeyError, TypeError, ValueError) as exc:
            raise PlanningError(f"invalid tactical proposal: {exc}") from exc
        if not 0 <= confidence <= 1:
            raise PlanningError("proposal confidence must be a probability")
        return TacticalProposal(str(raw.get("rationale", "")), command, predicted, confidence, tuple(raw.get("alternatives", ())))

    def update_milestone(self, plan: Plan, milestone_id: str, status: MilestoneStatus) -> Plan:
        if milestone_id not in {node.id for node in plan.milestones}:
            raise PlanningError(f"unknown milestone {milestone_id}")
        nodes = tuple(Milestone(**{**asdict(node), "status": status if node.id == milestone_id else node.status}) for node in plan.milestones)
        revised = Plan(str(uuid4()), plan.objective_id, plan.version + 1, _now(), f"milestone {milestone_id} -> {status.value}", plan.assumptions, nodes, plan.version)
        self.store.save(revised)
        return revised
