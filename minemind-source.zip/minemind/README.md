# MineMind — original research components

Local-first Minecraft agent infrastructure. This release contains original Python protocol, model-routing, world-model, planner, orchestrator, runtime, skill, memory, learning, curriculum and evaluation components with their existing tests. Apache-2.0 applies; see LICENSE.

Game binaries, accounts, server worlds, launcher integrations, model weights, Node modules and private data are excluded. No unseen-seed Minecraft completion rate has been demonstrated. Runtime/interface tests and deterministic fixtures must not be described as real gameplay success.

For source tests, add each component's src directory to PYTHONPATH. Requires Python 3.11+, pytest and pytest-asyncio; some components use websockets. See requirements.txt and test_components.py.
