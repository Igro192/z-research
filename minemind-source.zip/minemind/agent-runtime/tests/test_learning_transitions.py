import asyncio
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest

from minemind_protocol import ActionCommand, ActionKind, ActionResult, Objective, Observation
from minemind_runtime.integrations import LearningService
from minemind_runtime.loop import AgentLoop, RuntimeServices
from minemind_runtime.store import RuntimeStore
from minemind_world_model import WorldModel


@dataclass
class _Comparison:
    error: float
    surprises: tuple[str, ...] = ()


class _WorldModel(WorldModel):
    def compare_prediction(self, prediction_id, expected, actual):
        return _Comparison(0.2, ("player.health",))


class _Bridge:
    def __init__(self, result, observation):
        self.result = result
        self.observation = observation

    async def execute(self, command, timeout):
        return self.result

    async def wait_observation(self, sequence, timeout):
        return self.observation

    def status(self):
        return SimpleNamespace(world_id="world-1", session_id="session-1")

    def action_provenance(self):
        return {
            "world_id": "world-1", "session_id": "session-1",
            "controlled_actor_id": "bot-1", "controlled_actor_name": "MineMind",
            "embodiment_mode": "SEPARATE_LOCAL_PLAYER", "observation_sequence": 1,
            "human_control_possible": False,
        }


class RuntimeLearningTransitionTest(unittest.TestCase):
    def test_action_and_verified_task_flow_into_prioritized_replay(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runtime_store = RuntimeStore(root / "runtime.sqlite3")
            learning = LearningService(str(root / "learning.sqlite3"))
            world_model = _WorldModel(root / "world.sqlite3")
            self.addCleanup(runtime_store.close)
            self.addCleanup(learning.close)
            self.addCleanup(world_model.close)

            objective = Objective.create("novel objective", "tester")
            runtime_store.create_objective(objective)
            observation = Observation(
                tick=2,
                sequence=2,
                player={"health": 18, "hunger": 20, "air": 300},
                environment={"dimension": "overworld"},
            )
            action = ActionCommand.create(ActionKind.QUERY, {"selector": "local_state"})
            result = ActionResult(
                action_id=action.action_id,
                status="safety_stop",
                started_at="start",
                finished_at="finish",
                actual_effects=(
                    {"type": "damage", "amount": 2, "path": "player.health", "value": 18},
                ),
                error={"code": "unsafe"},
                resource_cost={"iron": 2.0, "time_seconds": 1.5},
            )
            bridge = _Bridge(result, observation)
            config = SimpleNamespace(
                tick_timeout_seconds=1.0,
                budgets=SimpleNamespace(confirmation_risk_threshold=0.8),
                safety=SimpleNamespace(protected_entities=(), protected_blocks=()),
            )
            loop = AgentLoop(
                config,
                runtime_store,
                bridge,
                world_model,
                planner=None,
                orchestrator=None,
                cognition=None,
                services=RuntimeServices(learning=learning),
            )
            signature = f"{action.kind.value}:{action.parameters}"
            loop._recent_actions.append(signature)
            runtime_store.set_state(
                f"prediction_error:{objective.objective_id}:{action.kind.value}", 0.8
            )
            before = {
                "world_id": "world-1",
                "tick": 1,
                "beliefs": {
                    "player": {"value": {"health": 20}, "uncertainty": 0.5},
                    "environment": {"value": {}, "uncertainty": 0.5},
                },
            }
            asyncio.run(loop.handle_control({"operation": "feedback", "value": -0.5}))
            _, after, _, reward = asyncio.run(loop._execute_action(
                objective,
                None,
                None,
                Observation(1, 1, {"health": 20}, {}),
                before,
                action,
                ({"path": "player.health", "value": 18},),
                (),
                retrieved_memories=({"memory_id": "memory-7"},),
            ))
            self.assertLess(reward["resource_penalty"], 0)
            self.assertLess(reward["repetition_penalty"], 0)
            self.assertLess(reward["unsafe_penalty"], 0)
            self.assertLess(reward["user_preference"], 0)
            self.assertGreater(reward["information_gain"], 0)
            self.assertGreater(reward["prediction_error_reduction"], 0)

            asyncio.run(loop._record_outcome_transition(
                objective,
                after,
                outcome="succeeded",
                terminal=True,
                verified=True,
                achieved_goals=(objective.text,),
                retrieved_memories=({"memory_id": "memory-7"},),
            ))
            transitions = [sample.transition for sample in learning.replay.sample(10, beta=0)]
            self.assertEqual(len(transitions), 2)
            action_transition = next(item for item in transitions if item.action.get("kind") == "query")
            terminal_transition = next(
                item for item in transitions if item.action.get("kind") == "task_outcome"
            )
            self.assertEqual(action_transition.retrieved_memory_ids, ("memory-7",))
            self.assertFalse(action_transition.terminal)
            self.assertEqual(action_transition.resource_cost, 2.0)
            self.assertEqual(action_transition.time_cost_seconds, 1.5)
            self.assertEqual(action_transition.provenance["controlled_actor_id"], "bot-1")
            self.assertFalse(action_transition.provenance["human_control_targeted"])
            self.assertEqual(action_transition.reward_schema_version, "1.0.0")
            self.assertTrue(terminal_transition.terminal)
            self.assertTrue(terminal_transition.verification_result)
            self.assertGreater(terminal_transition.reward_components["extrinsic"], 20)

    def test_false_success_verification_is_penalized(self):
        with tempfile.TemporaryDirectory() as directory:
            runtime_store = RuntimeStore(Path(directory) / "runtime.sqlite3")
            learning = LearningService(str(Path(directory) / "learning.sqlite3"))
            world_model = _WorldModel(Path(directory) / "world.sqlite3")
            self.addCleanup(runtime_store.close)
            self.addCleanup(learning.close)
            self.addCleanup(world_model.close)
            config = SimpleNamespace(
                tick_timeout_seconds=1.0,
                budgets=SimpleNamespace(confirmation_risk_threshold=0.8),
                safety=SimpleNamespace(protected_entities=(), protected_blocks=()),
            )
            loop = AgentLoop(
                config, runtime_store, SimpleNamespace(), world_model, None, None, None,
                RuntimeServices(learning=learning),
            )
            objective = Objective.create("objective", "tester")
            asyncio.run(loop._record_outcome_transition(
                objective,
                {},
                outcome="verification_rejected",
                terminal=False,
                verified=False,
                false_success_claim=True,
            ))
            transition = learning.replay.sample(1, beta=0)[0].transition
            self.assertFalse(transition.terminal)
            self.assertFalse(transition.verification_result)
            self.assertLess(transition.reward_components["false_success_penalty"], 0)


if __name__ == "__main__":
    unittest.main()
