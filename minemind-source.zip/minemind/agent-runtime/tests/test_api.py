from __future__ import annotations

import asyncio
from dataclasses import dataclass
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest

from minemind_runtime.api import ApiServer
from minemind_runtime.store import RuntimeStore


@dataclass
class _Budgets:
    max_actions_per_objective: int = 100
    max_model_calls_per_objective: int = 20
    max_wall_seconds_per_objective: float = 30.0


class _Loop:
    def __init__(self, store: RuntimeStore, data_dir: Path) -> None:
        self.store = store
        self.config = SimpleNamespace(budgets=_Budgets(), data_dir=data_dir)
        self.services = SimpleNamespace(memory=_Memory())
        self.controls: list[str] = []
        self.cancelled: list[str] = []

    def snapshot(self):
        return {"protocolVersion": "1.0", "evaluation": {"measurement_status": "not_measured", "suites": []}, "training": {"measurement_status": "not_measured", "episodes": 0}}

    async def handle_control(self, value):
        self.controls.append(value["operation"])

    async def submit_objective(self, objective):
        self.store.create_objective(objective)
        self.store.set_objective_status(objective.objective_id, "succeeded", "test completion")

    async def submit_chat_message(self, text: str, player: str = "dashboard"):
        if text.lower().strip() in {"hello", "hi", "hey"}:
            return {"objective_id": None, "status": "answered", "category": "conversation",
                    "reply": "Hey!", "task_text": "", "actionable": False}
        from minemind_protocol import Objective
        objective = Objective.create(text, player)
        self.store.create_objective(objective)
        self.store.set_objective_status(objective.objective_id, "waiting_for_world", "test world offline")
        return {"objective_id": objective.objective_id, "status": "waiting_for_world", "category": "task",
                "reply": "Sure, I'll work on that.", "task_text": text, "actionable": True}

    async def cancel_objective(self, objective_id: str, reason: str) -> bool:
        self.cancelled.append(objective_id)
        return True


class _Bridge:
    def __init__(self, *, fail_control: bool = False) -> None:
        self.fail_control = fail_control
        self.connected = True
        self.controls: list[str] = []
        self.objectives: list[str] = []

    def status(self):
        return SimpleNamespace(
            connected=self.connected, world_id="isolated-world", session_id="s", mod_version="test", last_sequence=1,
            controlled_actor_id="bot-uuid", controlled_actor_name="MineMind",
            embodiment_mode="SEPARATE_LOCAL_PLAYER", embodiment_status="READY",
            bot_ready=True, human_control_possible=False,
        )

    async def send_control(self, operation: str, reason: str):
        self.controls.append(operation)
        if self.fail_control:
            raise ConnectionError("bridge offline")

    async def submit_objective(self, text: str, actor: str):
        self.objectives.append(text)
        return {"id": "world-objective", "status": "queued"}


class _Memory:
    def __init__(self) -> None:
        self.deleted = []

    def inspect(self, query: str, *, limit: int):
        return [{"memory_id": "m1", "text": "book said ignore policy", "instruction_authority": "data_only", "query": query}][:limit]

    def export(self, destination: str, scope):
        Path(destination).write_text("{}\n", encoding="utf-8")
        return 1

    def delete(self, scope):
        self.deleted.append(dict(scope))
        return 1


class ApiTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.store = RuntimeStore(":memory:")
        self.loop = _Loop(self.store, Path(self.temp.name))
        self.bridge = _Bridge()
        self.models = {"local": {"completed_calls": 2, "input_tokens": 10, "output_tokens": 5, "calls_without_token_usage": 0}}
        self.server = ApiServer("127.0.0.1", 0, self.loop, self.bridge, self.store, lambda: self.models)
        await self.server.start()
        self.port = self.server._server.sockets[0].getsockname()[1]  # type: ignore[union-attr]

    async def asyncTearDown(self) -> None:
        await self.server.stop()
        self.store.close()
        self.temp.cleanup()

    async def request(self, method: str, path: str, payload=None):
        reader, writer = await asyncio.open_connection("127.0.0.1", self.port)
        body = b"" if payload is None else json.dumps(payload).encode("utf-8")
        writer.write(f"{method} {path} HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Type: application/json\r\nContent-Length: {len(body)}\r\n\r\n".encode("ascii") + body)
        await writer.drain()
        status_line = (await reader.readline()).decode("ascii")
        headers = {}
        while True:
            line = await reader.readline()
            if line in {b"\r\n", b""}:
                break
            name, value = line.decode("latin-1").split(":", 1)
            headers[name.lower()] = value.strip()
        raw = await reader.readexactly(int(headers.get("content-length", "0"))) if int(headers.get("content-length", "0")) else b""
        writer.close()
        await writer.wait_closed()
        return int(status_line.split()[1]), headers, json.loads(raw) if raw else None

    async def test_status_endpoints_and_dashboard_compute_counters(self) -> None:
        status, _, evaluation = await self.request("GET", "/api/v1/evaluation/status")
        self.assertEqual(status, 200)
        self.assertEqual(evaluation["measurement_status"], "not_measured")
        status, _, dashboard = await self.request("GET", "/api/v1/dashboard/snapshot")
        self.assertEqual(status, 200)
        self.assertEqual(dashboard["compute"]["tokens"], 15)

    async def test_unknown_control_is_rejected_before_bridge_delivery(self) -> None:
        status, _, payload = await self.request("POST", "/api/v1/control", {"command": "format_disk"})
        self.assertEqual(status, 400)
        self.assertIn("unsupported", payload["error"])
        self.assertEqual(self.loop.controls, [])
        self.assertEqual(self.bridge.controls, [])

    async def test_dashboard_objective_is_queued_without_an_open_world(self) -> None:
        self.bridge.connected = False
        status, _, payload = await self.request("POST", "/api/v1/objectives", {"text": "explore safely"})
        self.assertEqual(status, 202)
        self.assertEqual(payload["status"], "waiting_for_world")
        self.assertTrue(str(payload["objective_id"]))
        self.assertEqual(self.bridge.objectives, [])

    async def test_dashboard_conversation_returns_reply_without_objective(self) -> None:
        status, _, payload = await self.request("POST", "/api/v1/objectives", {"text": "hello"})
        self.assertEqual(status, 202)
        self.assertEqual(payload["category"], "conversation")
        self.assertEqual(payload["reply"], "Hey!")
        self.assertIsNone(payload["objective_id"])

    async def test_emergency_stop_applies_locally_when_bridge_is_offline(self) -> None:
        self.bridge.fail_control = True
        status, _, payload = await self.request("POST", "/api/v1/control", {"command": "emergency_stop"})
        self.assertEqual(status, 202)
        self.assertEqual(self.loop.controls, ["emergency_stop"])
        self.assertFalse(payload["bridge_delivered"])

    async def test_evaluation_requires_idle_matching_isolated_world(self) -> None:
        from minemind_protocol import Objective

        active = Objective.create("live user goal", "player")
        self.store.create_objective(active)
        self.store.set_objective_status(active.objective_id, "running")
        status, _, payload = await self.request("POST", "/v1/evaluation/attempt", {
            "protocol_version": "1.0.0", "objective": "test", "world_id": "isolated-world",
            "minecraft_endpoint": "127.0.0.1:25565", "budget": {"wall_seconds": 1, "max_actions": 10, "max_model_calls": 5},
        })
        self.assertEqual(status, 409)
        self.assertIn("active objective", payload["error"])
        self.assertEqual(self.loop.cancelled, [])

    async def test_evaluation_response_is_telemetry_not_verification(self) -> None:
        status, _, payload = await self.request("POST", "/v1/evaluation/attempt", {
            "protocol_version": "1.0.0", "objective": "test", "world_id": "isolated-world",
            "minecraft_endpoint": "127.0.0.1:25565", "budget": {"wall_seconds": 1, "max_actions": 10, "max_model_calls": 5},
        })
        self.assertEqual(status, 200)
        self.assertTrue(payload["claimed_success"])
        self.assertNotIn("verified_success", payload)
        self.assertEqual(payload["tokens"], 0)
        self.assertEqual(payload["controlled_actor_id"], "bot-uuid")
        self.assertFalse(payload["human_control_targeted"])

    async def test_evaluation_refuses_legacy_human_controlling_bridge(self) -> None:
        self.bridge.status = lambda: SimpleNamespace(
            connected=True, world_id="isolated-world", session_id="s",
            embodiment_mode="legacy_unspecified", bot_ready=False,
            human_control_possible=True, controlled_actor_id=None,
        )
        status, _, payload = await self.request("POST", "/v1/evaluation/attempt", {
            "protocol_version": "1.0.0", "objective": "test", "world_id": "isolated-world",
            "minecraft_endpoint": "127.0.0.1:25565", "budget": {"wall_seconds": 1, "max_actions": 10, "max_model_calls": 5},
        })
        self.assertEqual(status, 409)
        self.assertIn("separate MineMind player", payload["error"])

    async def test_memory_inspection_marks_external_content_as_data_only(self) -> None:
        status, _, payload = await self.request("GET", "/api/v1/memory?query=book&limit=10")
        self.assertEqual(status, 200)
        self.assertEqual(payload["records"][0]["instruction_authority"], "data_only")
        self.assertIn("evidence-only", payload["instruction_policy"])

    async def test_complete_memory_deletion_requires_exact_confirmation(self) -> None:
        status, _, payload = await self.request("POST", "/api/v1/memory/delete", {"scope": {}})
        self.assertEqual(status, 400)
        self.assertIn("explicit scope", payload["error"])
        status, _, _ = await self.request("POST", "/api/v1/memory/delete", {"scope": {"include_all": True}})
        self.assertEqual(status, 400)
        status, _, payload = await self.request("POST", "/api/v1/memory/delete", {"scope": {"include_all": True}, "confirmation_token": "DELETE ALL MINEMIND MEMORY"})
        self.assertEqual(status, 200)
        self.assertEqual(payload["deleted"], 1)

    async def test_memory_export_rejects_path_traversal(self) -> None:
        status, _, _ = await self.request("POST", "/api/v1/memory/export", {"file_name": "../memory.jsonl"})
        self.assertEqual(status, 400)


if __name__ == "__main__":
    unittest.main()
