from minemind_protocol import Observation
from minemind_runtime.fast_path import compile_direct_skill, direct_postcondition_met


def observation() -> Observation:
    return Observation(1, 7, {"id": "bot"}, {}, controlled_actor={"id": "bot"})


def test_collect_compiles_to_generic_skill_without_model() -> None:
    compiled = compile_direct_skill("@mind get wood", "objective-1", observation())
    assert compiled is not None
    assert compiled.skill_id == "builtin.generic.collect"
    assert compiled.command.kind.value == "collect"
    assert compiled.command.parameters["selector"] == "wood"
    assert compiled.command.objective_id == "objective-1"
    assert compiled.command.before_state_revision == 7


def test_complex_objective_is_not_scripted() -> None:
    assert compile_direct_skill("beat Minecraft", "objective-1", observation()) is None
    assert compile_direct_skill("get wood and build a house", "objective-1", observation()) is None


def test_collect_requires_inventory_evidence() -> None:
    compiled = compile_direct_skill("collect 2 logs", "objective-1", observation())
    assert compiled is not None
    assert not direct_postcondition_met(compiled, {"status": "succeeded", "actual_effects": []})
    assert direct_postcondition_met(compiled, {"status": "succeeded", "actual_effects": [{"path": "inventory.count", "delta": 2}]})
