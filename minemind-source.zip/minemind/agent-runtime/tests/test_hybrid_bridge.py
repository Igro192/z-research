import asyncio
from dataclasses import replace
from datetime import datetime, timezone
import unittest
from types import SimpleNamespace

from minemind_protocol import ActionCommand, ActionKind, ActionResult, Observation
from minemind_runtime.bridge import BridgeStatus
from minemind_runtime.hybrid_bridge import HybridBridge


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _observation(sequence: int, logs: int) -> Observation:
    actor = {"uuid": "bot-uuid", "name": "MineMind_AI", "role": "minemind_ai"}
    return Observation(
        tick=sequence * 20,
        sequence=sequence,
        player={"uuid": "bot-uuid", "position": {"x": sequence, "y": 64, "z": 0}},
        environment={},
        inventory=({"id": "minecraft:oak_log", "count": logs},),
        controlled_actor=actor,
        human_players=({"uuid": "human-uuid", "name": "Owner"},),
        embodiment={"mode": "MINEFLAYER_NETWORK_CLIENT", "status": "READY", "connected": True,
                    "humanControlPossible": False, "botUuid": "bot-uuid"},
    )


class _Store:
    def audit(self, *args, **kwargs):
        pass


class _Actuator:
    def __init__(self) -> None:
        self.objectives = asyncio.Queue()
        self.controls = asyncio.Queue()
        self.connected = asyncio.Event()
        self.store = _Store()
        self.commands = []
        self.control_commands = []

    async def start(self):
        self.connected.set()

    async def stop(self):
        self.connected.clear()

    def status(self):
        return BridgeStatus(True, "session", "world", "bot", 2, "bot-uuid", "MineMind_AI",
                            "MINEFLAYER_NETWORK_CLIENT", "READY", True, False)

    async def execute(self, command, timeout):
        self.commands.append(command)
        return ActionResult(command.action_id, "succeeded", _now(), _now(),
                            ({"path": "inventory.count", "value": 999, "delta": 999},))

    async def send_control(self, operation, reason):
        self.control_commands.append(operation)
        return {"status": "queued"}

    def capability_gaps(self):
        return ()


class _Verifier:
    def __init__(self) -> None:
        self.objectives = asyncio.Queue()
        self.controls = asyncio.Queue()
        self.connected = asyncio.Event()
        self.latest_observation = _observation(1, 0)

    async def start(self):
        self.connected.set()

    async def stop(self):
        self.connected.clear()

    def status(self):
        return BridgeStatus(True, "verified", "world", "fabric", self.latest_observation.sequence,
                            "bot-uuid", "MineMind_AI", "MINEFLAYER_NETWORK_CLIENT", "READY", True, False)

    async def wait_observation(self, after_sequence, timeout):
        self.latest_observation = _observation(after_sequence + 1, 1)
        return self.latest_observation

    async def submit_objective(self, text, actor):
        return {"id": "objective-1", "status": "QUEUED"}

    async def send_control(self, operation, reason):
        return {"status": "queued"}


class HybridBridgeTests(unittest.IsolatedAsyncioTestCase):
    async def test_place_waits_past_a_stale_server_snapshot(self):
        actuator, verifier = _Actuator(), _Verifier()
        async def place(command, timeout):
            return ActionResult(command.action_id, "succeeded", _now(), _now(), ({
                "path": "world.block", "value": {"id": "minecraft:crafting_table", "position": {"x": 4, "y": 64, "z": 5}},
            },))
        async def observe(sequence, timeout):
            snapshot = _observation(sequence + 1, 0)
            if sequence >= 2:
                snapshot = replace(snapshot, nearby_blocks=({"id": "minecraft:crafting_table", "x": 4, "y": 64, "z": 5},))
            verifier.latest_observation = snapshot
            return snapshot
        actuator.execute, verifier.wait_observation = place, observe
        result = await HybridBridge(actuator, verifier).execute(
            ActionCommand.create(ActionKind.PLACE, {"item": "minecraft:crafting_table", "target": {"semantic": "safe_nearby"}}), 1,
        )
        self.assertEqual(result.status, "succeeded")
        self.assertEqual(verifier.latest_observation.sequence, 3)
        block = next(effect for effect in result.actual_effects if effect["path"] == "world.block")
        self.assertEqual(block["source"], "server_verifier")

    async def test_chat_stop_reaches_network_actuator_and_runtime(self):
        actuator, verifier = _Actuator(), _Verifier()
        bridge = HybridBridge(actuator, verifier)
        await bridge.start()
        try:
            event = SimpleNamespace(payload={"operation": "emergency_stop"})
            await verifier.controls.put(event)
            self.assertIs(await asyncio.wait_for(bridge.controls.get(), 1), event)
            await asyncio.sleep(0)
            self.assertEqual(actuator.control_commands, ["emergency_stop"])
        finally:
            await bridge.stop()

    async def test_requires_matching_bot_and_server_identity(self):
        bridge = HybridBridge(_Actuator(), _Verifier())
        await bridge.start()
        try:
            await asyncio.wait_for(bridge.connected.wait(), 1)
            self.assertTrue(bridge.status().bot_ready)
            self.assertFalse(bridge.status().human_control_possible)
            self.assertEqual(bridge.status().controlled_actor_id, "bot-uuid")
        finally:
            await bridge.stop()

    async def test_collect_result_uses_server_inventory_evidence(self):
        bridge = HybridBridge(_Actuator(), _Verifier())
        await bridge.start()
        try:
            await asyncio.wait_for(bridge.connected.wait(), 1)
            command = ActionCommand.create(ActionKind.COLLECT, {"selector": "log", "count": 1})
            result = await bridge.execute(command, 1)
            inventory = next(effect for effect in result.actual_effects if effect["path"] == "inventory.count")
            self.assertEqual(inventory["delta"], 1)
            self.assertEqual(inventory["source"], "server_verifier")
            self.assertNotEqual(inventory["value"], 999)
        finally:
            await bridge.stop()


if __name__ == "__main__":
    unittest.main()
