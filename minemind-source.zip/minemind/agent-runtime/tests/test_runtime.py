import asyncio
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from minemind_model_router import Endpoint
from minemind_planner import MilestoneStatus
from minemind_protocol import ActionCommand, ActionKind, ActionResult, EventKind, Objective, Observation, TrustClass, new_envelope
from minemind_runtime.app import RuntimeApplication
from minemind_runtime.config import Address, BridgeConfig, Budgets, RuntimeConfig, SafetyConfig
from minemind_runtime.loop import AgentLoop, EvidenceEvaluator, RuntimeServices, SafetyGate
from minemind_runtime.http_bridge import HttpBridgeClient
from minemind_runtime.store import RuntimeStore


class RuntimeTests(unittest.TestCase):
    def test_chat_reply_removes_model_channel_suffix(self):
        self.assertEqual(
            AgentLoop._clean_chat_reply("Hello! How can I help? 🌆minecraft:"),
            "Hello! How can I help?",
        )

    def test_planner_receives_inventory_and_position_from_world_model_beliefs(self):
        belief = {"world_id": "test", "tick": 12, "beliefs": {
            "inventory": {"value": [{"id": "minecraft:birch_log", "count": 3, "slot": 0}], "confidence": 1},
            "player": {"value": {"position": {"x": 4, "y": 64, "z": 4}, "health": 20}, "confidence": 1},
        }}
        compact = AgentLoop._prompt_belief(belief)
        self.assertEqual(compact["facts"]["inventory"]["value"], [{"id": "minecraft:birch_log", "count": 3}])
        self.assertEqual(compact["facts"]["player"]["value"]["position"]["x"], 4)

    def test_bounded_compiler_rejects_invented_steps_for_open_ended_goal(self):
        self.assertEqual(AgentLoop._requested_verbs("beat Minecraft"), [])
        self.assertFalse(AgentLoop._explicitly_requests("beat Minecraft", ("craft", "craft", "craft")))
        self.assertTrue(AgentLoop._explicitly_requests("craft a table and place it down", ("craft", "place")))
        self.assertEqual(
            AgentLoop._requested_verbs("please craft a table, then place it down"),
            ["craft", "place"],
        )

    def test_command_like_chat_cannot_be_downgraded_to_conversation(self):
        self.assertTrue(AgentLoop._contains_action_language("get wood and craft it into sticks"))
        self.assertFalse(AgentLoop._contains_action_language("hello, how are you?"))
        self.assertFalse(AgentLoop._contains_action_language("what are you doing?"))
        self.assertFalse(AgentLoop._contains_action_language("how do I get wood?"))
        self.assertTrue(AgentLoop._contains_action_language("can you get wood and craft sticks?"))

    def test_local_model_cannot_misroute_greetings_controls_or_commands(self):
        self.assertEqual(
            AgentLoop._enforce_chat_intent("hello", "status", "Hey!", "ignored"),
            ("conversation", "Hey!", ""),
        )
        self.assertEqual(
            AgentLoop._enforce_chat_intent("stop", "conversation", "Okay.", ""),
            ("cancel", "Okay.", ""),
        )
        self.assertEqual(
            AgentLoop._enforce_chat_intent(
                "get wood and craft it into sticks", "conversation", "On it!", ""
            ),
            ("task", "On it!", "get wood and craft it into sticks"),
        )

    def test_compound_craft_target_is_recovered_from_into_phrase(self):
        self.assertEqual(
            AgentLoop._explicit_target("get wood and craft it into sticks right now", "craft"),
            "sticks",
        )

    def test_generic_imperative_fallback_preserves_compound_actions(self):
        self.assertEqual(
            [step["verb"] for step in AgentLoop._fallback_bounded_steps("get wood and craft it into sticks")],
            ["acquire", "craft"],
        )
        self.assertEqual(
            [step["target"] for step in AgentLoop._fallback_bounded_steps("craft a crafting table and place it down")],
            ["crafting table", "crafting table"],
        )
        self.assertEqual(
            AgentLoop._fallback_bounded_steps("how do I get wood?"),
            None,
        )

    def test_semantic_inventory_predicates_use_real_vanilla_ids(self):
        self.assertEqual(AgentLoop._namespaced("sticks"), "minecraft:stick")
        self.assertEqual(AgentLoop._namespaced("two furnaces".removeprefix("two ")), "minecraft:furnace")
        self.assertEqual(AgentLoop._namespaced("stone pickaxes"), "minecraft:stone_pickaxe")
        self.assertEqual(AgentLoop._inventory_selector("wood"), "log")
        self.assertEqual(AgentLoop._inventory_selector("minecraft:oak_log"), "log")
        self.assertEqual(AgentLoop._inventory_selector("minecraft:birch_planks"), "plank")

    def test_item_families_expand_to_real_vanilla_outputs(self):
        self.assertEqual(
            AgentLoop._expand_item_group("stone tools"),
            ("stone_pickaxe", "stone_axe", "stone_shovel", "stone_sword", "stone_hoe"),
        )
        self.assertEqual(
            AgentLoop._expand_item_group("full iron armor"),
            ("iron_helmet", "iron_chestplate", "iron_leggings", "iron_boots"),
        )
        self.assertEqual(AgentLoop._expand_item_group("crafting table"), ("crafting table",))

    def test_replayed_objective_is_idempotent(self):
        store = RuntimeStore(":memory:")
        objective = Objective.create("collect one log", "tester")
        self.assertTrue(store.create_objective(objective))
        self.assertFalse(store.create_objective(objective))
        status = store.objective_status(objective.objective_id)
        self.assertEqual(status["text"], "collect one log")
        self.assertEqual(status["status"], "queued")
        store.close()

    def test_fabric_event_cursor_survives_runtime_restart(self):
        store = RuntimeStore(":memory:")
        first = HttpBridgeClient("127.0.0.1", 8767, store, token="test")
        first._select_server_session({"worldSessionId": "server-session-1"})
        first._event_cursor = 418
        store.set_state(first._cursor_key("server-session-1"), {"cursor": 418})

        restarted = HttpBridgeClient("127.0.0.1", 8767, store, token="test")
        restarted._select_server_session({"worldSessionId": "server-session-1"})
        self.assertEqual(restarted._event_cursor, 418)
        restarted._select_server_session({"worldSessionId": "server-session-2"})
        self.assertEqual(restarted._event_cursor, 0)
        store.close()

    def test_objective_recovers_after_restart(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "runtime.db"
            objective = Objective.create("open-ended task", "tester")
            store = RuntimeStore(path)
            store.create_objective(objective)
            store.set_objective_status(objective.objective_id, "running")
            recovered = RuntimeStore(path).active_objective()
            self.assertEqual(recovered.objective_id, objective.objective_id)

    def test_evidence_is_observation_based(self):
        evidence = [{"path": "environment.dimension", "op": "==", "value": "the_end"}]
        self.assertTrue(EvidenceEvaluator.matches(evidence, {"environment": {"dimension": "the_end"}}))
        self.assertFalse(EvidenceEvaluator.matches(evidence, {"model_claim": "the_end"}))

    def test_inventory_category_evidence_matches_only_trusted_observed_items(self):
        evidence = [{"path": "inventory", "op": "any", "where": {"id_contains": "log"}, "count_gte": 2}]
        self.assertTrue(EvidenceEvaluator.matches(evidence, {
            "inventory": [{"id": "minecraft:spruce_log", "count": 2}],
        }))
        self.assertFalse(EvidenceEvaluator.matches(evidence, {
            "inventory": [{"id": "minecraft:oak_planks", "count": 64}],
            "model_claim": "has logs",
        }))

    def test_action_transaction_is_atomic(self):
        store = RuntimeStore(":memory:")
        objective = Objective.create("x", "p")
        store.create_objective(objective)
        action = ActionCommand.create(ActionKind.QUERY, {"selector": "local_state"})
        store.begin_action(action.action_id, objective.objective_id, 1, "m1", {}, [], [], action.to_dict(), {
            "controlled_actor_id": "bot-1", "controlled_actor_name": "MineMind",
            "embodiment_mode": "SEPARATE_LOCAL_PLAYER", "observation_sequence": 7,
            "world_id": "world-1", "session_id": "session-1", "human_control_targeted": False,
        })
        store.finish_action(action.action_id, {"status": "success"}, {"tick": 2}, {"total": 1})
        self.assertEqual(store.dashboard_counts()["completed_actions"], 1)
        transaction = store.action_transaction(action.action_id)
        self.assertEqual(transaction["actor_id"], "bot-1")
        self.assertEqual(transaction["embodiment_mode"], "SEPARATE_LOCAL_PLAYER")
        self.assertFalse(transaction["provenance"]["human_control_targeted"])
        self.assertEqual(transaction["reward_schema_version"], "1.0.0")

    def test_observation_journal_compacts_high_cardinality_terrain(self):
        """A live observation must not turn the durable journal into a map dump."""
        store = RuntimeStore(":memory:")
        observation = Observation(
            tick=1, sequence=1, player={"uuid": "bot"}, environment={},
            inventory=({"id": "minecraft:birch_log", "count": 1},),
            nearby_blocks=tuple({"x": index, "id": "minecraft:stone"} for index in range(500)),
            controlled_actor={"uuid": "bot", "name": "MineMind_AI"},
        )
        store.append_event(new_envelope(
            EventKind.OBSERVATION, observation, source="test", session_id="session",
            trust=TrustClass.GAME_OBSERVATION,
        ))
        encoded = str(store._db.execute("SELECT event_json FROM events").fetchone()[0])
        self.assertLess(len(encoded), 2_000)
        self.assertNotIn("nearby_blocks", encoded)
        self.assertIn("minecraft:birch_log", encoded)
        store.close()

    def test_legacy_database_migrates_replan_counter(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "legacy.db"
            database = sqlite3.connect(path)
            with database:
                database.executescript(
                    """
                    CREATE TABLE schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);
                    INSERT INTO schema_migrations VALUES(1, 'legacy');
                    CREATE TABLE objectives(
                        objective_id TEXT PRIMARY KEY, text TEXT NOT NULL, requested_by TEXT NOT NULL,
                        created_at TEXT NOT NULL, status TEXT NOT NULL, reason TEXT,
                        action_count INTEGER NOT NULL DEFAULT 0, model_call_count INTEGER NOT NULL DEFAULT 0,
                        started_at TEXT, finished_at TEXT, objective_json TEXT NOT NULL
                    );
                    """
                )
            database.close()

            store = RuntimeStore(path)
            objective = Objective.create("recover from an action failure", "tester")
            store.create_objective(objective)
            self.assertEqual(store.increment(objective.objective_id, "replan_count"), 1)
            self.assertEqual(store.objective_status(objective.objective_id)["replan_count"], 1)
            columns = {row[1] for row in store._db.execute("PRAGMA table_info(action_transactions)")}
            self.assertIn("actor_id", columns)
            self.assertIn("reward_schema_version", columns)
            store.close()


class RuntimeAsyncTests(unittest.IsolatedAsyncioTestCase):
    async def test_stone_tools_expand_into_five_real_autoclef_acquisition_goals(self) -> None:
        class _Cognition:
            async def call(self, role, context, schema=None):
                return {
                    "scope": "bounded",
                    "summary": "Obtain the requested stone tool set",
                    "steps": [{
                        "id": "tools", "verb": "acquire", "target": "stone tools",
                        "count": 1, "parameters": {},
                    }],
                }

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = RuntimeConfig(
                root=root, data_dir=root / "data", log_level="INFO", deterministic=True,
                tick_timeout_seconds=1.0, max_concurrent_model_calls=1,
                bridge=BridgeConfig("127.0.0.1", 0, "websocket"), api=Address("127.0.0.1", 0),
                bridge_token="test", budgets=Budgets(),
                endpoints=(Endpoint("local", "openai_compatible", "http://127.0.0.1:1/v1"),),
                role_selectors={}, safety=SafetyConfig(),
            )
            application = RuntimeApplication(config, RuntimeServices())
            application.loop.cognition = _Cognition()
            objective = Objective.create("get stone tools", "Owner")
            application.store.create_objective(objective)
            observation = Observation(
                tick=1, sequence=4,
                player={"uuid": "bot", "name": "MineMind_AI", "position": {"x": 0, "y": 64, "z": 0}},
                environment={"dimension": "overworld"}, inventory=(),
                controlled_actor={"uuid": "bot", "name": "MineMind_AI", "role": "minemind_ai"},
                embodiment={"mode": "DEDICATED_FABRIC_CLIENT", "status": "READY", "humanControlPossible": False},
            )
            plan, actions = await application.loop._compile_bounded_objective(objective, observation)
            self.assertEqual(
                [command.parameters["selector"] for command in actions.values()],
                ["stone_pickaxe", "stone_axe", "stone_shovel", "stone_sword", "stone_hoe"],
            )
            self.assertEqual([command.kind for command in actions.values()], [ActionKind.ACQUIRE] * 5)
            self.assertEqual(len(plan.milestones), 5)
            await application.stop()

    async def test_cancel_interrupts_model_and_pause_echo_cannot_revive_goal(self):
        store = RuntimeStore(":memory:")
        objective = Objective.create("a complex task", "Owner")
        store.create_objective(objective)
        store.set_objective_status(objective.objective_id, "planning")
        loop = AgentLoop.__new__(AgentLoop)
        loop.store = store
        loop._active_objective = objective
        loop.cancelled, loop.paused = asyncio.Event(), asyncio.Event()
        loop._objective_task = asyncio.create_task(asyncio.sleep(45))
        await loop.handle_control({"operation": "cancel"})
        await loop.handle_control({"operation": "pause"})
        await asyncio.gather(loop._objective_task, return_exceptions=True)
        self.assertTrue(loop._objective_task.cancelled())
        self.assertEqual(store.objective_status(objective.objective_id)["status"], "cancelled")
        self.assertIsNone(store.active_objective())
        store.close()

    async def test_new_chat_goal_preempts_stalled_model_without_losing_goal(self):
        store = RuntimeStore(":memory:")
        stalled = Objective.create("a complex task", "Owner")
        store.create_objective(stalled)
        store.set_objective_status(stalled.objective_id, "waiting_for_model")
        loop = AgentLoop.__new__(AgentLoop)
        loop.store, loop._active_objective = store, stalled
        loop.cancelled = asyncio.Event()
        loop._objective_task = asyncio.create_task(asyncio.sleep(45))
        interrupted_task = loop._objective_task
        command = Objective.create("collect 1 log", "Owner")
        await loop.submit_objective(command)
        await asyncio.gather(interrupted_task, return_exceptions=True)
        self.assertTrue(interrupted_task.cancelled())
        # The lightweight fixture does not own a bridge; stop the newly
        # launched command task before the loop callback can execute it.
        loop.stopping = asyncio.Event()
        loop.stopping.set()
        loop._objective_task.cancel()
        await asyncio.gather(loop._objective_task, return_exceptions=True)
        self.assertEqual(store.objective_status(stalled.objective_id)["status"], "paused")
        self.assertEqual(store.active_objective().objective_id, command.objective_id)
        store.set_objective_status(command.objective_id, "succeeded")
        self.assertIsNone(store.active_objective())
        self.assertEqual(store.active_objective(include_paused=True).objective_id, stalled.objective_id)
        store.close()

    async def test_bounded_compiler_repairs_only_verbs_explicitly_requested(self) -> None:
        class _Cognition:
            async def call(self, role, context, schema=None):
                self.context = context
                return {
                    "scope": "bounded",
                    "summary": "Craft then place the requested workstation",
                    "steps": [
                        {"id": "craft", "verb": "craft", "target": "crafting_table", "count": 1, "parameters": {}},
                        # Regression: qwen2.5:1.5b sometimes substituted equip
                        # for the user's literal second verb, place.
                        {"id": "place", "verb": "equip", "target": "crafting_table", "count": 1, "parameters": {}},
                    ],
                    "_model": {"model": "qwen2.5:1.5b", "latency_ms": 250.0},
                }

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = RuntimeConfig(
                root=root, data_dir=root / "data", log_level="INFO", deterministic=True,
                tick_timeout_seconds=1.0, max_concurrent_model_calls=1,
                bridge=BridgeConfig("127.0.0.1", 0, "websocket"), api=Address("127.0.0.1", 0),
                bridge_token="test", budgets=Budgets(),
                endpoints=(Endpoint("local", "openai_compatible", "http://127.0.0.1:1/v1"),),
                role_selectors={}, safety=SafetyConfig(),
            )
            application = RuntimeApplication(config, RuntimeServices())
            cognition = _Cognition()
            application.loop.cognition = cognition
            objective = Objective.create("craft a crafting table and place it down", "Owner")
            application.store.create_objective(objective)
            observation = Observation(
                tick=1, sequence=4,
                player={"uuid": "bot", "name": "MineMind_AI", "position": {"x": 0, "y": 64, "z": 0}},
                environment={"dimension": "overworld"}, inventory=(),
                controlled_actor={"uuid": "bot", "name": "MineMind_AI", "role": "minemind_ai"},
                embodiment={"mode": "MINEFLAYER_NETWORK_CLIENT", "status": "READY", "humanControlPossible": False},
            )

            plan, actions = await application.loop._compile_bounded_objective(objective, observation)
            self.assertEqual(cognition.context["required_step_verbs"], ["craft", "place"])
            self.assertEqual([action.kind for action in actions.values()], [ActionKind.CRAFT, ActionKind.PLACE])
            self.assertEqual(plan.milestones[1].description, "place crafting_table")
            audit = application.store._db.execute(
                "SELECT summary FROM audit_log WHERE category='executive' ORDER BY sequence DESC LIMIT 1"
            ).fetchone()
            self.assertEqual(audit[0], "Reconciled compiler verbs to explicit user effects")
            await application.stop()

    async def test_model_compiles_generic_craft_and_place_graph(self) -> None:
        class _Cognition:
            async def call(self, role, context, schema=None):
                self.role, self.context, self.schema = role, context, schema
                return {
                    "scope": "bounded",
                    "summary": "Craft then place the requested workstation",
                    "steps": [
                        {"id": "craft", "verb": "craft", "target": "crafting_table", "count": 1, "parameters": {}},
                        {"id": "place", "verb": "place", "target": "crafting_table", "count": 1, "parameters": {}},
                    ],
                    "_model": {"model": "qwen2.5:1.5b", "latency_ms": 250.0},
                }

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = RuntimeConfig(
                root=root, data_dir=root / "data", log_level="INFO", deterministic=True,
                tick_timeout_seconds=1.0, max_concurrent_model_calls=1,
                bridge=BridgeConfig("127.0.0.1", 0, "websocket"), api=Address("127.0.0.1", 0),
                bridge_token="test", budgets=Budgets(),
                endpoints=(Endpoint("local", "openai_compatible", "http://127.0.0.1:1/v1"),),
                role_selectors={}, safety=SafetyConfig(),
            )
            application = RuntimeApplication(config, RuntimeServices())
            cognition = _Cognition()
            application.loop.cognition = cognition
            objective = Objective.create("craft a crafting table and place it down", "Owner")
            application.store.create_objective(objective)
            observation = Observation(
                tick=1, sequence=4,
                player={"uuid": "bot", "name": "MineMind_AI", "position": {"x": 0, "y": 64, "z": 0}},
                environment={"dimension": "overworld"},
                inventory=({"id": "minecraft:birch_log", "count": 2},),
                controlled_actor={"uuid": "bot", "name": "MineMind_AI", "role": "minemind_ai"},
                embodiment={"mode": "MINEFLAYER_NETWORK_CLIENT", "status": "READY", "humanControlPossible": False},
            )

            plan, actions = await application.loop._compile_bounded_objective(objective, observation)
            self.assertEqual([action.kind for action in actions.values()], [ActionKind.CRAFT, ActionKind.PLACE])
            self.assertEqual(actions["craft"].parameters["recipe"], "minecraft:crafting_table")
            self.assertEqual(actions["place"].parameters["target"], {"semantic": "safe_nearby"})
            self.assertEqual(plan.milestones[1].dependencies, ("craft",))
            self.assertEqual(application.store.objective_status(objective.objective_id)["model_call_count"], 1)
            self.assertEqual(application.loop.snapshot()["agents"][0]["currentTask"], "Craft then place the requested workstation")
            # Both effects were independently seen, but placement consumes the
            # table. A redundant verifier inventory predicate cannot undo that.
            for node in plan.milestones:
                plan = application.planner.update_milestone(plan, node.id, MilestoneStatus.ACHIEVED)
            placed = Observation(tick=5, sequence=8, player=observation.player,
                environment=observation.environment, inventory=(),
                nearby_blocks=({"id": "minecraft:crafting_table", "x": 1, "y": 64, "z": 0},))
            async def verify(_claim, _evidence):
                return SimpleNamespace(choice={"verified": True}, confidence=0.95,
                    summary="The requested table was crafted and placed", evidence=({
                        "path": "inventory", "op": "any", "where": {"id": "minecraft:crafting_table"},
                    },))
            application.orchestrator.verify = verify
            self.assertTrue(await application.loop._verify_completion(objective, plan, placed))
            await application.stop()

    async def test_replayed_event_does_not_relaunch_or_break_next_objective(self) -> None:
        store = RuntimeStore(":memory:")
        launched = []
        loop = AgentLoop.__new__(AgentLoop)
        loop.store = store
        loop._objective_task = None
        loop._launch_objective = launched.append
        first = Objective.create("collect one log", "tester")
        second = Objective.create("collect another log", "tester")

        await loop.submit_objective(first)
        await loop.submit_objective(first)
        await loop.submit_objective(second)

        self.assertEqual([item.objective_id for item in launched], [first.objective_id, second.objective_id])
        self.assertIsNotNone(store.objective_status(second.objective_id))
        store.close()

    async def test_interactive_runtime_does_not_start_training_when_disabled(self) -> None:
        class _Learning:
            def __init__(self) -> None:
                self.calls = 0

            async def train_if_ready(self):
                self.calls += 1

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            learning = _Learning()
            config = RuntimeConfig(
                root=root,
                data_dir=root / "data",
                log_level="INFO",
                deterministic=True,
                tick_timeout_seconds=1.0,
                max_concurrent_model_calls=1,
                bridge=BridgeConfig("127.0.0.1", 0, "websocket"),
                api=Address("127.0.0.1", 0),
                bridge_token="test-bridge-token",
                budgets=Budgets(),
                endpoints=(Endpoint("local", "openai_compatible", "http://127.0.0.1:1/v1"),),
                role_selectors={},
                safety=SafetyConfig(),
                training={"enabled": False},
            )
            application = RuntimeApplication(config, RuntimeServices(learning=learning))
            await application.start()
            try:
                await asyncio.sleep(0)
                self.assertIsNone(application._training_task)
                self.assertEqual(learning.calls, 0)
            finally:
                await application.stop()

    async def test_websocket_bot_executes_wood_fast_path_without_model_call(self) -> None:
        from websockets.asyncio.client import connect

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = RuntimeConfig(
                root=root,
                data_dir=root / "data",
                log_level="INFO",
                deterministic=True,
                tick_timeout_seconds=1.0,
                max_concurrent_model_calls=1,
                bridge=BridgeConfig("127.0.0.1", 0, "websocket"),
                api=Address("127.0.0.1", 0),
                bridge_token="test-bridge-token",
                budgets=Budgets(max_wall_seconds_per_objective=10),
                endpoints=(Endpoint("local", "openai_compatible", "http://127.0.0.1:1/v1"),),
                role_selectors={},
                safety=SafetyConfig(),
            )
            application = RuntimeApplication(config, RuntimeServices())
            await application.start()
            try:
                port = application.bridge._server.sockets[0].getsockname()[1]
                async with connect(f"ws://127.0.0.1:{port}/bridge") as socket:
                    hello = new_envelope(
                        EventKind.HELLO,
                        {
                            "token": "test-bridge-token",
                            "mod_version": "bot-client-test",
                            "embodiment": {
                                "mode": "MINEFLAYER_NETWORK_CLIENT",
                                "status": "READY",
                                "botName": "MineMind_AI",
                                "botUuid": "bot-uuid",
                                "connected": True,
                                "humanControlPossible": False,
                            },
                        },
                        source="bot-client",
                        session_id="session-1",
                        world_id="world-1",
                    )
                    await socket.send(hello.to_json())
                    observation = Observation(
                        tick=1,
                        sequence=1,
                        player={"uuid": "bot-uuid", "name": "MineMind_AI", "position": {"x": 0, "y": 64, "z": 0}},
                        environment={"dimension": "overworld"},
                        inventory=(),
                        controlled_actor={"uuid": "bot-uuid", "name": "MineMind_AI", "role": "minemind_ai"},
                        human_players=({"uuid": "human-uuid", "name": "Owner", "role": "human_player"},),
                        embodiment={
                            "mode": "MINEFLAYER_NETWORK_CLIENT", "status": "READY",
                            "connected": True, "humanControlPossible": False,
                        },
                        full=True,
                    )
                    await socket.send(new_envelope(
                        EventKind.OBSERVATION, observation, source="bot-client", session_id="session-1",
                        world_id="world-1", trust=TrustClass.GAME_OBSERVATION,
                    ).to_json())

                    objective = Objective.create("get wood", "dashboard")
                    await application.loop.submit_objective(objective)
                    command_event = json.loads(await asyncio.wait_for(socket.recv(), 2.0))
                    self.assertEqual(command_event["kind"], "actuator.execute")
                    self.assertEqual(command_event["payload"]["kind"], "collect")
                    self.assertEqual(command_event["payload"]["actor_id"], "minemind_player")

                    result = ActionResult(
                        action_id=command_event["payload"]["action_id"], status="succeeded",
                        started_at="2026-01-01T00:00:00Z", finished_at="2026-01-01T00:00:01Z",
                        actual_effects=({"path": "inventory.count", "value": 1, "delta": 1},),
                    )
                    await socket.send(new_envelope(
                        EventKind.ACTUATOR_RESULT, result, source="bot-client", session_id="session-1",
                        world_id="world-1", correlation_id=command_event["id"], trust=TrustClass.GAME_OBSERVATION,
                    ).to_json())
                    after = Observation(
                        tick=2, sequence=2,
                        player=observation.player, environment=observation.environment,
                        inventory=({"id": "minecraft:oak_log", "count": 1, "slot": 36},),
                        controlled_actor=observation.controlled_actor,
                        human_players=observation.human_players,
                        embodiment=observation.embodiment,
                    )
                    await socket.send(new_envelope(
                        EventKind.OBSERVATION, after, source="bot-client", session_id="session-1",
                        world_id="world-1", trust=TrustClass.GAME_OBSERVATION,
                    ).to_json())

                    for _ in range(100):
                        status = application.store.objective_status(objective.objective_id) or {}
                        if status.get("status") == "succeeded":
                            break
                        await asyncio.sleep(0.01)
                    self.assertEqual(status.get("status"), "succeeded")
                    self.assertEqual(status.get("model_call_count"), 0)
                    self.assertEqual(status.get("action_count"), 1)
                    snapshot = application.loop.snapshot()
                    self.assertEqual(snapshot["actors"]["controlled"]["state"]["uuid"], "bot-uuid")
                    self.assertEqual(snapshot["actors"]["humans"][0]["uuid"], "human-uuid")
                    await asyncio.wait_for(application.loop._objective_task, 2)
                    self.assertIsNone(application.loop._active_objective)
                    finished = application.loop.snapshot()["objective"]
                    self.assertEqual(finished["objective_id"], objective.objective_id)
                    self.assertEqual(finished["status"], "succeeded")
                    self.assertEqual(finished["action_count"], 1)
            finally:
                await application.stop()

    async def test_offline_objective_is_immediately_visible_as_waiting_for_world(self) -> None:
        class _Bridge:
            connected = __import__("asyncio").Event()

            @staticmethod
            def status():
                return SimpleNamespace(connected=False, world_id=None)

            async def wait_observation(self, *_args, **_kwargs):
                raise __import__("asyncio").TimeoutError

        store = RuntimeStore(":memory:")
        objective = Objective.create("wait for a world", "dashboard")
        store.create_objective(objective)
        loop = AgentLoop.__new__(AgentLoop)
        loop.bridge = _Bridge()
        loop.store = store
        loop.cancelled = __import__("asyncio").Event()
        loop.paused = __import__("asyncio").Event()
        loop.paused.set()
        loop.config = SimpleNamespace(budgets=SimpleNamespace(
            max_wall_seconds_per_objective=60,
            max_actions_per_objective=10,
        ), tick_timeout_seconds=0.01)
        loop.planner = SimpleNamespace(store=SimpleNamespace(active=lambda _objective_id: None))
        loop._active_objective = None
        loop._active_plan = None
        loop._recent_actions = []
        loop._last_decision = None
        loop._background = set()
        loop.services = SimpleNamespace()
        loop.stopping = __import__("asyncio").Event()
        task = __import__("asyncio").create_task(loop._run_objective(objective))
        await __import__("asyncio").sleep(0)
        self.assertEqual(store.objective_status(objective.objective_id)["status"], "waiting_for_world")
        task.cancel()
        await __import__("asyncio").gather(task, return_exceptions=True)
        store.close()

    async def test_action_failure_replan_is_persisted(self) -> None:
        class _Planner:
            async def replan(self, *_args, **_kwargs):
                return SimpleNamespace(version=2)

        store = RuntimeStore(":memory:")
        objective = Objective.create("novel task", "tester")
        store.create_objective(objective)
        loop = AgentLoop.__new__(AgentLoop)
        loop.store = store
        loop.config = SimpleNamespace(budgets=SimpleNamespace(max_model_calls_per_objective=10))
        loop.planner = _Planner()
        loop._active_plan = None

        plan = await loop._replan(
            objective,
            {"world_id": "w"},
            "action failed",
            ({"type": "action failed"},),
            (),
            (),
        )

        status = store.objective_status(objective.objective_id)
        self.assertEqual(plan.version, 2)
        self.assertEqual(status["model_call_count"], 1)
        self.assertEqual(status["replan_count"], 1)
        store.close()

    async def test_application_stop_closes_all_owned_resources_idempotently(self) -> None:
        class _Closable:
            def __init__(self) -> None:
                self.calls = 0

            def close(self) -> None:
                self.calls += 1

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            resources = [_Closable() for _ in range(5)]
            services = RuntimeServices(*resources)
            config = RuntimeConfig(
                root=root,
                data_dir=root / "data",
                log_level="INFO",
                deterministic=True,
                tick_timeout_seconds=1.0,
                max_concurrent_model_calls=1,
                bridge=BridgeConfig("127.0.0.1", 8765),
                api=Address("127.0.0.1", 8080),
                bridge_token=None,
                budgets=Budgets(),
                endpoints=(Endpoint("local", "openai_compatible", "http://127.0.0.1:11434/v1"),),
                role_selectors={},
                safety=SafetyConfig(),
            )
            application = RuntimeApplication(config, services)
            await application.stop()
            await application.stop()

            self.assertEqual([resource.calls for resource in resources], [1, 1, 1, 1, 1])
            with self.assertRaises(sqlite3.ProgrammingError):
                application.store.dashboard_counts()


if __name__ == "__main__":
    unittest.main()
