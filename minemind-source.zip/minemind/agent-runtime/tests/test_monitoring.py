from __future__ import annotations

from dataclasses import replace
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

from minemind_runtime.config import load_config
from minemind_runtime.monitoring import capability_gaps, evaluation_status, training_status
from minemind_runtime.store import RuntimeStore


ROOT = Path(__file__).resolve().parents[2]


class _Bridge:
    def capability_gaps(self):
        return ({"capability": "navigate", "evidence": "CAPABILITY_GAP", "occurrences": 2},)


class _Skills:
    def status(self):
        return {"last_gap": {"capability": "safe retreat", "reason": "three failed recoveries", "failures": [{}, {}, {}]}}


class MonitoringTests(unittest.TestCase):
    def _config(self, root: Path):
        base = load_config(ROOT / "config" / "minemind.toml")
        return replace(
            base,
            root=root,
            data_dir=root / "data",
            evaluation={"results_database": "data/evaluation.db"},
            training={"enabled": True, "results_database": "data/training.db"},
        )

    def test_real_evaluation_is_separated_from_simulated_and_legacy_rows(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = self._config(root)
            config.data_dir.mkdir()
            database = sqlite3.connect(config.data_dir / "evaluation.db")
            database.execute("""CREATE TABLE evaluation_results(
                suite_id TEXT, task_id TEXT, seed INTEGER, attempt_index INTEGER,
                verified_success INTEGER, false_success INTEGER, budget_exhausted INTEGER,
                telemetry_json TEXT, verification_reason TEXT, evidence_json TEXT,
                recorded_at REAL, run_mode TEXT, simulated INTEGER, real_minecraft_measured INTEGER)""")
            values = (
                ("minemind.diagnostics.v1", "real", 1, 0, 1, 0, 0, json.dumps({"elapsed_seconds": 10, "deaths": 0}), "trusted", "[]", 2.0, "fabric", 0, 1),
                ("minemind.diagnostics.v1", "smoke", 2, 0, 1, 0, 0, json.dumps({"elapsed_seconds": 1}), "synthetic", "[]", 1.0, "deterministic_smoke", 1, 0),
            )
            database.executemany("INSERT INTO evaluation_results VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", values)
            database.commit()
            database.close()
            store = RuntimeStore(root / "runtime.db")
            status = evaluation_status(config, store)
            store.close()
        diagnostics = next(item for item in status["suites"] if item["suite_id"] == "minemind.diagnostics.v1")
        self.assertEqual(diagnostics["attempts"], 1)
        self.assertEqual(diagnostics["completion_rate"], 1.0)
        self.assertEqual(diagnostics["simulated_attempts"], 1)
        self.assertEqual(status["simulated_attempts"], 1)
        self.assertEqual({item["evidence_scope"] for item in status["recent_runs"]}, {"real_minecraft", "simulated"})

    def test_missing_evaluation_database_is_not_measured(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = self._config(root)
            store = RuntimeStore(root / "runtime.db")
            status = evaluation_status(config, store)
            store.close()
        self.assertEqual(status["measurement_status"], "not_measured")
        self.assertTrue(all(item["completion_rate"] is None for item in status["suites"]))

    def test_training_status_builds_capability_matrix(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = self._config(root)
            config.data_dir.mkdir()
            database = sqlite3.connect(config.data_dir / "training.db")
            database.execute("""CREATE TABLE training_episodes(
              scenario_id TEXT, objective TEXT, seed INTEGER, difficulty REAL,
              capability_tags_json TEXT, success INTEGER, budget_exhausted INTEGER,
              reward REAL, actions INTEGER, model_calls INTEGER, tokens INTEGER,
              deaths INTEGER, skills_created_json TEXT, failure TEXT,
              started_at REAL, finished_at REAL)""")
            database.execute("INSERT INTO training_episodes VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                "s1", "practice", 4, 0.2, '["navigation"]', 1, 0, 1.0, 2, 1, 3, 0, "[]", None, 1.0, 2.0,
            ))
            database.commit()
            database.close()
            store = RuntimeStore(root / "runtime.db")
            status = training_status(config, store)
            store.close()
        self.assertEqual(status["measurement_status"], "measured")
        self.assertEqual(status["episodes"], 1)
        self.assertEqual(status["capability_matrix"][0]["capability"], "navigation")

    def test_capability_gap_projection_has_stable_internal_sources(self) -> None:
        services = type("Services", (), {"skills": _Skills()})()
        gaps = capability_gaps(_Bridge(), services)
        self.assertEqual({item["source"] for item in gaps}, {"runtime", "skill_engine"})
        self.assertTrue(all(len(item["gap_id"]) == 16 for item in gaps))


if __name__ == "__main__":
    unittest.main()
