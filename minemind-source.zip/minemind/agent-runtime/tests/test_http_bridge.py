import asyncio
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import tempfile
import threading
import unittest

from minemind_protocol import ActionCommand, ActionKind
from minemind_runtime.http_bridge import HttpBridgeClient
from minemind_runtime.store import RuntimeStore


class _State:
    events = []
    last_action = None


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def _json(self, status, value):
        encoded = json.dumps(value).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def do_GET(self):
        if self.path == "/v1/health":
            self._json(200, {"status": "ok", "protocolVersion": "1.0", "observationSequence": 1,
                "botReady": True, "embodiment": {"mode": "SEPARATE_LOCAL_PLAYER", "status": "READY",
                    "botName": "MineMind", "botUuid": "bot-uuid", "connected": True,
                    "humanControlPossible": False}})
        elif self.path == "/v1/capabilities":
            self._json(200, {"protocolVersion": "1.0", "humanControlPossible": False,
                "embodiment": {"mode": "SEPARATE_LOCAL_PLAYER", "status": "READY",
                    "botName": "MineMind", "botUuid": "bot-uuid", "connected": True},
                "atomicActions": {"QUERY": "IMPLEMENTED", "NAVIGATE": "CAPABILITY_GAP"}})
        elif self.path.startswith("/v1/events"):
            after = int(self.path.split("after=", 1)[1].split("&", 1)[0])
            events = [item for item in _State.events if item["sequence"] > after]
            self._json(200, {"latestSequence": len(_State.events), "events": events})
        elif self.path == "/v1/observation":
            self._json(200, {"protocolVersion": "1.0", "sequence": 1, "serverTick": 20,
                "worldSessionId": "test-world", "player": {"uuid": "bot-uuid", "name": "MineMind", "health": 20, "food": 18, "air": 300,
                    "onFire": True, "fallDistance": 2.5, "remainingFireTicks": 30},
                "aiPlayer": {"uuid": "bot-uuid", "name": "MineMind", "health": 20, "food": 18, "air": 300,
                    "onFire": True, "fallDistance": 2.5, "remainingFireTicks": 30},
                "humanPlayers": [{"uuid": "human-uuid", "name": "Owner", "authorized": True,
                    "position": {"x": 1, "y": 64, "z": 2}}],
                "embodiment": {"mode": "SEPARATE_LOCAL_PLAYER", "status": "READY", "botName": "MineMind",
                    "botUuid": "bot-uuid", "connected": True, "humanControlPossible": False},
                "environment": {"dimension": "minecraft:overworld"}, "nearbyBlocks": [], "nearbyEntities": [],
                "inventory": [], "container": {"open": False}, "successSignals": {}, "untrustedWorldText": [],
                "recentSounds": [{"sound": "minecraft:block.bell.use", "gameTick": 19}],
                "recentDamage": [{"amount": 2.0, "damageType": "minecraft:in_fire", "gameTick": 18}]})
        else:
            self._json(404, {})

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        body = json.loads(self.rfile.read(length) or b"{}")
        if self.path == "/v1/actions":
            _State.last_action = body
            sequence = len(_State.events) + 1
            _State.events.append({"sequence": sequence, "type": "action.completed", "emittedAt": "now", "payload": {
                "id": body["id"], "status": "SUCCEEDED", "code": "query_completed", "message": "ok",
                "evidence": {"observation": {"sequence": 1}}, "completedAt": "2026-01-01T00:00:00Z"}})
            self._json(202, {"id": body["id"], "status": "QUEUED", "code": "queued", "message": "queued", "evidence": {}, "completedAt": "now"})
        else:
            self._json(202, {"id": "objective-1", "status": "QUEUED"})


class HttpBridgeTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        _State.events = []
        _State.last_action = None
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.temp = tempfile.TemporaryDirectory()
        token_file = Path(self.temp.name) / "minemind.json"
        token_file.write_text(json.dumps({"authenticationToken": "x" * 40}))
        self.store = RuntimeStore(":memory:")
        self.bridge = HttpBridgeClient("127.0.0.1", self.server.server_port, self.store, token_file=token_file, poll_interval=0.01)
        await self.bridge.start()
        await asyncio.wait_for(self.bridge.connected.wait(), 2)

    async def asyncTearDown(self):
        await self.bridge.stop()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=1)
        self.store.close()
        self.temp.cleanup()

    async def test_normalizes_observation_and_completes_action(self):
        observation = await self.bridge.wait_observation(-1, 1)
        self.assertEqual(observation.player["hunger"], 18)
        self.assertTrue(observation.player["on_fire"])
        self.assertEqual(observation.player["fall_distance"], 2.5)
        self.assertEqual([event["type"] for event in observation.events], ["sound", "damage"])
        self.assertTrue(all(event["instruction_eligible"] is False for event in observation.events))
        self.assertEqual(self.bridge.status().world_id, "test-world")
        self.assertEqual(observation.controlled_actor["uuid"], "bot-uuid")
        self.assertEqual(observation.human_players[0]["uuid"], "human-uuid")
        self.assertFalse(observation.embodiment["humanControlPossible"])
        command = ActionCommand.create(ActionKind.QUERY, {"selector": "local_state"})
        result = await self.bridge.execute(command, 2)
        self.assertEqual(result.status, "succeeded")
        self.assertTrue(any(effect["path"] == "observation" for effect in result.actual_effects))
        self.assertEqual(_State.last_action["actor"], "bot-uuid")
        self.assertNotEqual(_State.last_action["actor"], "human-uuid")

    async def test_capability_gap_fails_honestly_without_post(self):
        command = ActionCommand.create(ActionKind.NAVIGATE, {"target": {"x": 0, "y": 64, "z": 0}})
        result = await self.bridge.execute(command, 1)
        self.assertEqual(result.status, "capability_gap")

    async def test_action_fails_closed_if_separate_bot_identity_is_not_ready(self):
        self.bridge._bot_ready = False
        command = ActionCommand.create(ActionKind.QUERY, {"selector": "local_state"})
        result = await self.bridge.execute(command, 1)
        self.assertEqual(result.status, "safety_stop")
        self.assertEqual(result.error["code"], "separate_player_not_ready")
        self.assertIsNone(_State.last_action)

    def test_legacy_human_observation_is_rejected(self):
        with self.assertRaises(ConnectionError):
            HttpBridgeClient._normalize_observation({
                "sequence": 1, "serverTick": 1,
                "player": {"uuid": "human"},
                "environment": {},
            })

    def test_identity_aliasing_between_human_and_bot_is_rejected(self):
        with self.assertRaises(ConnectionError):
            HttpBridgeClient._normalize_observation({
                "sequence": 1, "serverTick": 1,
                "player": {"uuid": "same"}, "aiPlayer": {"uuid": "same"},
                "humanPlayers": [{"uuid": "same"}],
                "embodiment": {"mode": "SEPARATE_LOCAL_PLAYER", "status": "READY",
                    "botUuid": "same", "connected": True, "humanControlPossible": False},
                "environment": {},
            }, human_control_possible=False)

    def test_real_network_client_modes_are_normalized_for_server_verification(self):
        for mode in ("MINEFLAYER_NETWORK_CLIENT", "DEDICATED_FABRIC_CLIENT"):
            observation = HttpBridgeClient._normalize_observation({
                "sequence": 2, "serverTick": 40,
                "player": {"uuid": "bot", "name": "MineMind_AI"},
                "aiPlayer": {"uuid": "bot", "name": "MineMind_AI", "food": 20},
                "humanPlayers": [{"uuid": "human", "name": "Owner"}],
                "embodiment": {"mode": mode, "status": "READY",
                    "botUuid": "bot", "botName": "MineMind_AI", "connected": True,
                    "humanControlPossible": False},
                "environment": {}, "inventory": [], "nearbyBlocks": [], "nearbyEntities": [],
            }, human_control_possible=False)
            self.assertEqual(observation.embodiment["mode"], mode)
            self.assertEqual(observation.controlled_actor["uuid"], "bot")
            self.assertEqual(observation.human_players[0]["uuid"], "human")


if __name__ == "__main__":
    unittest.main()
