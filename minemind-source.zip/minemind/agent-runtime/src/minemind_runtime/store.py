from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
from threading import RLock
from typing import Any, Mapping

from minemind_protocol import Envelope, EventKind, Objective


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


class RuntimeStore:
    """Durable event journal and recovery state. Writes are transactionally ordered."""

    # Observations are already available as the live world-model snapshot and
    # as before/after state on action transactions.  Persisting every nearby
    # block list verbatim made a few minutes of play consume nearly a gigabyte
    # on the 8-GB development Mac.  Keep the identity/state needed for replay
    # and audit, while deliberately omitting the high-cardinality local map.
    _COMPACT_OBSERVATION_FIELDS = (
        "tick", "sequence", "player", "environment", "inventory",
        "controlled_actor", "human_players", "embodiment", "full",
    )

    def __init__(self, database: str | Path) -> None:
        path = Path(database)
        if str(database) != ":memory:":
            path.parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(str(database), check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._lock = RLock()
        self._migrate()

    def _migrate(self) -> None:
        migrations = [
            """
            CREATE TABLE IF NOT EXISTS events(
                sequence INTEGER PRIMARY KEY AUTOINCREMENT, event_id TEXT UNIQUE NOT NULL,
                kind TEXT NOT NULL, timestamp TEXT NOT NULL, session_id TEXT NOT NULL,
                world_id TEXT, event_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS objectives(
                objective_id TEXT PRIMARY KEY, text TEXT NOT NULL, requested_by TEXT NOT NULL,
                created_at TEXT NOT NULL, status TEXT NOT NULL, reason TEXT,
                action_count INTEGER NOT NULL DEFAULT 0, model_call_count INTEGER NOT NULL DEFAULT 0,
                started_at TEXT, finished_at TEXT, objective_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS runtime_state(
                key TEXT PRIMARY KEY, value_json TEXT NOT NULL, updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS action_transactions(
                action_id TEXT PRIMARY KEY, objective_id TEXT NOT NULL, plan_version INTEGER,
                milestone_id TEXT, before_json TEXT NOT NULL, alternatives_json TEXT NOT NULL,
                prediction_json TEXT NOT NULL, command_json TEXT NOT NULL, result_json TEXT,
                after_json TEXT, reward_json TEXT, created_at TEXT NOT NULL, completed_at TEXT
            );
            CREATE TABLE IF NOT EXISTS audit_log(
                sequence INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT NOT NULL,
                category TEXT NOT NULL, severity TEXT NOT NULL, summary TEXT NOT NULL,
                detail_json TEXT NOT NULL
            );
            """,
            """
            ALTER TABLE objectives ADD COLUMN replan_count INTEGER NOT NULL DEFAULT 0;
            """,
        ]
        with self._db:
            self._db.execute("CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)")
            for version, script in enumerate(migrations, 1):
                if not self._db.execute("SELECT 1 FROM schema_migrations WHERE version=?", (version,)).fetchone():
                    self._db.executescript(script)
                    self._db.execute("INSERT INTO schema_migrations VALUES(?,?)", (version, utc_now()))
            self._migrate_action_provenance()

    def _migrate_action_provenance(self) -> None:
        """Add actor/reward provenance without discarding 0.1.0 journals."""
        self._db.execute(
            """CREATE TABLE IF NOT EXISTS action_transactions(
                action_id TEXT PRIMARY KEY, objective_id TEXT NOT NULL, plan_version INTEGER,
                milestone_id TEXT, before_json TEXT NOT NULL, alternatives_json TEXT NOT NULL,
                prediction_json TEXT NOT NULL, command_json TEXT NOT NULL, result_json TEXT,
                after_json TEXT, reward_json TEXT, created_at TEXT NOT NULL, completed_at TEXT
            )"""
        )
        columns = {
            str(row[1]) for row in self._db.execute("PRAGMA table_info(action_transactions)").fetchall()
        }
        additions = (
            ("actor_id", "TEXT"),
            ("actor_name", "TEXT"),
            ("embodiment_mode", "TEXT NOT NULL DEFAULT 'legacy_unspecified'"),
            ("observation_sequence", "INTEGER"),
            ("session_id", "TEXT"),
            ("world_id", "TEXT"),
            ("provenance_json", "TEXT NOT NULL DEFAULT '{}'"),
            ("reward_schema_version", "TEXT NOT NULL DEFAULT '1.0.0'"),
        )
        for name, declaration in additions:
            if name not in columns:
                self._db.execute(f"ALTER TABLE action_transactions ADD COLUMN {name} {declaration}")
        self._db.execute(
            "INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(3,?)",
            (utc_now(),),
        )

    def append_event(self, event: Envelope) -> int:
        with self._lock, self._db:
            event_json = event.to_json()
            if event.kind == EventKind.OBSERVATION:
                # Keep the journal bounded in size without changing the live
                # observation delivered to cognition.  Nearby terrain is
                # reconstructed from the bridge on demand and is not needed
                # for event replay or trusted action verification.
                payload = {
                    key: event.payload[key]
                    for key in self._COMPACT_OBSERVATION_FIELDS
                    if key in event.payload
                }
                compact = {**event.to_dict(), "payload": payload}
                event_json = json.dumps(compact, separators=(",", ":"), sort_keys=True)
            cursor = self._db.execute("INSERT OR IGNORE INTO events(event_id,kind,timestamp,session_id,world_id,event_json) VALUES(?,?,?,?,?,?)",
                (event.id, event.kind.value, event.timestamp, event.session_id, event.world_id, event_json))
            if cursor.rowcount == 0:
                row = self._db.execute("SELECT sequence FROM events WHERE event_id=?", (event.id,)).fetchone()
                return int(row[0])
            return int(cursor.lastrowid)

    def create_objective(self, objective: Objective) -> bool:
        """Persist a new objective and report whether it was inserted.

        Fabric's bounded event journal is intentionally replayed after a local
        runtime restart.  Objective IDs are the idempotency key: replaying an
        already recorded event must not crash the persistent agent loop or
        relaunch a completed task.
        """
        with self._lock, self._db:
            cursor = self._db.execute("""INSERT OR IGNORE INTO objectives(
                objective_id,text,requested_by,created_at,status,reason,action_count,
                model_call_count,started_at,finished_at,objective_json
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (objective.objective_id, objective.text, objective.requested_by, objective.created_at, "queued", None, 0, 0, None, None, json.dumps(objective.to_dict(), sort_keys=True)))
            return cursor.rowcount == 1

    def set_objective_status(self, objective_id: str, status: str, reason: str | None = None) -> None:
        finished = utc_now() if status in {"succeeded", "failed", "cancelled", "impossible", "budget_exhausted"} else None
        started = utc_now() if status == "running" else None
        with self._lock, self._db:
            self._db.execute("UPDATE objectives SET status=?, reason=?, started_at=COALESCE(started_at,?), finished_at=COALESCE(?,finished_at) WHERE objective_id=?",
                (status, reason, started, finished, objective_id))

    def increment(self, objective_id: str, field: str) -> int:
        if field not in {"action_count", "model_call_count", "replan_count"}:
            raise ValueError("invalid counter")
        with self._lock, self._db:
            self._db.execute(f"UPDATE objectives SET {field}={field}+1 WHERE objective_id=?", (objective_id,))
            return int(self._db.execute(f"SELECT {field} FROM objectives WHERE objective_id=?", (objective_id,)).fetchone()[0])

    def active_objective(self, *, include_paused: bool = False) -> Objective | None:
        row = self._db.execute("""SELECT objective_json FROM objectives
            WHERE status IN ('queued','planning','running','executing','verifying','paused','waiting_for_model','waiting_for_world')
              AND (status != 'paused' OR ?)
            ORDER BY CASE status WHEN 'queued' THEN 0 WHEN 'paused' THEN 2 ELSE 1 END, created_at LIMIT 1""", (include_paused,)).fetchone()
        return Objective.from_dict(json.loads(row[0])) if row else None

    def objective_status(self, objective_id: str) -> Mapping[str, Any] | None:
        row = self._db.execute("SELECT * FROM objectives WHERE objective_id=?", (objective_id,)).fetchone()
        return dict(row) if row else None

    def latest_objective_status(self) -> Mapping[str, Any] | None:
        row = self._db.execute("SELECT * FROM objectives ORDER BY created_at DESC, rowid DESC LIMIT 1").fetchone()
        return dict(row) if row else None

    def set_state(self, key: str, value: Any) -> None:
        with self._lock, self._db:
            self._db.execute("INSERT INTO runtime_state VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,updated_at=excluded.updated_at",
                (key, json.dumps(value, sort_keys=True), utc_now()))

    def get_state(self, key: str, default: Any = None) -> Any:
        row = self._db.execute("SELECT value_json FROM runtime_state WHERE key=?", (key,)).fetchone()
        return default if not row else json.loads(row[0])

    def begin_action(self, action_id: str, objective_id: str, plan_version: int | None, milestone_id: str | None,
                     before: Mapping[str, Any], alternatives: Any, prediction: Any, command: Mapping[str, Any],
                     provenance: Mapping[str, Any] | None = None) -> None:
        provenance = dict(provenance or {})
        with self._lock, self._db:
            self._db.execute("""INSERT INTO action_transactions(
                action_id,objective_id,plan_version,milestone_id,before_json,
                alternatives_json,prediction_json,command_json,result_json,after_json,
                reward_json,created_at,completed_at,actor_id,actor_name,
                embodiment_mode,observation_sequence,session_id,world_id,
                provenance_json,reward_schema_version
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (action_id, objective_id, plan_version, milestone_id, json.dumps(before, sort_keys=True), json.dumps(alternatives, sort_keys=True),
                 json.dumps(prediction, sort_keys=True), json.dumps(command, sort_keys=True), None, None, None, utc_now(), None,
                 provenance.get("controlled_actor_id"), provenance.get("controlled_actor_name"),
                 str(provenance.get("embodiment_mode") or "legacy_unspecified"),
                 provenance.get("observation_sequence"), provenance.get("session_id"),
                 provenance.get("world_id"), json.dumps(provenance, sort_keys=True), "1.0.0"))

    def finish_action(self, action_id: str, result: Mapping[str, Any], after: Mapping[str, Any], reward: Mapping[str, Any]) -> None:
        with self._lock, self._db:
            self._db.execute("UPDATE action_transactions SET result_json=?,after_json=?,reward_json=?,completed_at=? WHERE action_id=?",
                (json.dumps(result, sort_keys=True), json.dumps(after, sort_keys=True), json.dumps(reward, sort_keys=True), utc_now(), action_id))

    def audit(self, category: str, summary: str, detail: Mapping[str, Any] | None = None, severity: str = "info") -> None:
        with self._lock, self._db:
            self._db.execute("INSERT INTO audit_log(timestamp,category,severity,summary,detail_json) VALUES(?,?,?,?,?)",
                (utc_now(), category, severity, summary, json.dumps(detail or {}, sort_keys=True)))

    def recent_activity(self, limit: int = 50) -> list[dict[str, Any]]:
        rows = self._db.execute("SELECT sequence,timestamp,category,severity,summary,detail_json FROM audit_log ORDER BY sequence DESC LIMIT ?", (min(limit, 500),)).fetchall()
        return [{**dict(row), "detail": json.loads(row["detail_json"])} for row in rows]

    def dashboard_counts(self) -> dict[str, int]:
        return {
            "events": int(self._db.execute("SELECT count(*) FROM events").fetchone()[0]),
            "actions": int(self._db.execute("SELECT count(*) FROM action_transactions").fetchone()[0]),
            "completed_actions": int(self._db.execute("SELECT count(*) FROM action_transactions WHERE completed_at IS NOT NULL").fetchone()[0]),
        }

    def action_transaction(self, action_id: str) -> Mapping[str, Any] | None:
        row = self._db.execute(
            "SELECT * FROM action_transactions WHERE action_id=?", (action_id,)
        ).fetchone()
        if not row:
            return None
        decoded = dict(row)
        decoded["provenance"] = json.loads(str(row["provenance_json"]))
        return decoded

    def close(self) -> None:
        self._db.close()

