from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
import time
from typing import Any, Mapping
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from minemind_protocol import ActionCommand, ActionResult, EventKind, Objective, Observation, TrustClass, new_envelope
from .bridge import BridgeStatus
from .store import RuntimeStore


_ACTION_NAMES = {
    "break": "BREAK", "mine": "MINE", "interact": "INTERACT", "communicate": "COMMUNICATE",
    "inventory": "INVENTORY", "equip": "EQUIP", "navigate": "NAVIGATE",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


class HttpBridgeClient:
    """Polls the Minecraft-owned authenticated HTTP bridge without blocking cognition."""

    def __init__(self, host: str, port: int, store: RuntimeStore, token: str | None = None,
                 token_file: Path | None = None, poll_interval: float = 0.2) -> None:
        if host not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError("Minecraft HTTP bridge must be loopback")
        self.host, self.port, self.store = host, port, store
        self._configured_token, self.token_file = token, token_file
        self.poll_interval = poll_interval
        self.base_url = f"http://{host}:{port}"
        self.objectives: asyncio.Queue[Any] = asyncio.Queue()
        self.controls: asyncio.Queue[Any] = asyncio.Queue()
        self.connected = asyncio.Event()
        self._task: asyncio.Task[Any] | None = None
        self._stopping = asyncio.Event()
        self._last_observation: Observation | None = None
        self._last_sequence = -1
        self._event_cursor = 0
        self._server_session_id: str | None = None
        self._observation_condition = asyncio.Condition()
        self._result_waiters: dict[str, asyncio.Future[ActionResult]] = {}
        self._action_started: dict[str, str] = {}
        self._session_id = f"minecraft-http-{int(time.time())}"
        self._world_id: str | None = None
        self._mod_version: str | None = None
        self._capabilities: dict[str, str] = {}
        self._last_error: str | None = None
        self._embodiment: dict[str, Any] = {}
        self._controlled_actor: dict[str, Any] = {}
        self._human_players: tuple[Mapping[str, Any], ...] = ()
        self._human_control_possible = True
        self._bot_ready = False

    async def start(self) -> None:
        self._task = asyncio.create_task(self._poll(), name="minecraft-http-bridge")

    async def stop(self) -> None:
        self._stopping.set()
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
        self.connected.clear()
        for waiter in self._result_waiters.values():
            if not waiter.done():
                waiter.set_exception(ConnectionError("Minecraft bridge stopped"))

    def _token(self) -> str | None:
        if self._configured_token:
            return self._configured_token
        if not self.token_file or not self.token_file.is_file():
            return None
        try:
            value = json.loads(self.token_file.read_text(encoding="utf-8"))
            token = value.get("authenticationToken")
            return str(token) if token else None
        except (OSError, ValueError, TypeError):
            return None

    async def _request(self, method: str, path: str, body: Mapping[str, Any] | None = None, *, authenticated: bool = True) -> Mapping[str, Any]:
        token = self._token()
        if authenticated and not token:
            raise ConnectionError(f"Minecraft bridge token unavailable; launch the MineMind profile to create {self.token_file or 'config/minemind.json'}")
        def send() -> Mapping[str, Any]:
            headers = {"Accept": "application/json"}
            if token:
                headers["Authorization"] = f"Bearer {token}"
            data = None
            if body is not None:
                data = json.dumps(body, separators=(",", ":")).encode("utf-8")
                headers["Content-Type"] = "application/json"
            request = Request(self.base_url + path, data=data, headers=headers, method=method)
            try:
                with urlopen(request, timeout=3) as response:
                    decoded = json.loads(response.read().decode("utf-8"))
                    if not isinstance(decoded, dict):
                        raise ConnectionError("Minecraft bridge response was not an object")
                    return decoded
            except HTTPError as exc:
                detail = exc.read(4096).decode("utf-8", errors="replace")
                raise ConnectionError(f"Minecraft bridge HTTP {exc.code}: {detail}") from exc
            except (URLError, TimeoutError, json.JSONDecodeError) as exc:
                raise ConnectionError(f"Minecraft bridge request failed: {exc}") from exc
        return await asyncio.to_thread(send)

    async def _poll(self) -> None:
        was_connected = False
        while not self._stopping.is_set():
            try:
                health = await self._request("GET", "/v1/health", authenticated=False)
                if str(health.get("protocolVersion", "")).split(".", 1)[0] != "1":
                    raise ConnectionError(f"unsupported Minecraft bridge protocol {health.get('protocolVersion')}")
                self._select_server_session(health)
                capabilities = await self._request("GET", "/v1/capabilities")
                self._capabilities = {str(k).lower(): str(v) for k, v in capabilities.get("atomicActions", {}).items()}
                self._update_embodiment(health, capabilities)
                await self._poll_events()
                await self._refresh_observation()
                self._mod_version = str(capabilities.get("protocolVersion", "1.0"))
                self.connected.set()
                self._last_error = None
                if not was_connected:
                    self.store.audit("bridge", "Connected to Minecraft HTTP embodiment", {"url": self.base_url})
                was_connected = True
            except Exception as exc:
                self._last_error = str(exc)
                self.connected.clear()
                if was_connected:
                    self.store.audit("bridge", "Minecraft HTTP embodiment disconnected", {"error": str(exc)}, severity="warning")
                was_connected = False
            try:
                await asyncio.wait_for(self._stopping.wait(), timeout=self.poll_interval if was_connected else 1.0)
            except asyncio.TimeoutError:
                pass

    async def _poll_events(self) -> None:
        page = await self._request("GET", f"/v1/events?after={self._event_cursor}&limit=500")
        latest = int(page.get("latestSequence", 0))
        if self._event_cursor > latest:
            # The same managed world started a new integrated-server session,
            # so its in-memory journal sequence restarted from zero.
            self._event_cursor = 0
            page = await self._request("GET", "/v1/events?after=0&limit=500")
        initial_cursor = self._event_cursor
        for event in page.get("events", []):
            sequence = int(event.get("sequence", 0))
            self._event_cursor = max(self._event_cursor, sequence)
            event_type, payload = str(event.get("type", "")), event.get("payload", {})
            if event_type == "objective.accepted" and isinstance(payload, Mapping):
                controlled = payload.get("controlledActor")
                if isinstance(controlled, Mapping) and not self._is_controlled_actor(controlled):
                    self.store.audit(
                        "security",
                        "Rejected objective with mismatched controlled actor",
                        {"controlled_actor": dict(controlled), "expected": dict(self._controlled_actor)},
                        severity="warning",
                    )
                    continue
                objective = Objective(
                    objective_id=str(payload.get("id")), text=str(payload.get("objective", "")),
                    requested_by=str(payload.get("authorizedPlayerName") or payload.get("authorizedPlayerId") or "authorized-player"),
                    created_at=str(payload.get("createdAt") or _now()),
                )
                # Preserve the trusted origin separately from the input mode.
                # An explicit ``@mind`` line is still a human chat message and
                # should receive an acknowledgement plus execution; dashboard
                # submissions are local bridge objectives and must not be
                # mistaken for conversational text.
                event_payload = {
                    **objective.to_dict(),
                    "input_mode": str(payload.get("inputMode") or "EXPLICIT_TASK").lower(),
                    "origin": str(payload.get("origin") or "LOCAL_BRIDGE").lower(),
                }
                envelope = new_envelope(EventKind.OBJECTIVE, event_payload, source="minecraft-http",
                    session_id=self._session_id, world_id=self._world_id, trust=TrustClass.AUTHORIZED_USER)
                self.store.append_event(envelope)
                await self.objectives.put(envelope)
            elif event_type == "action.completed" and isinstance(payload, Mapping):
                result = self._action_result(payload)
                waiter = self._result_waiters.pop(result.action_id, None)
                if waiter and not waiter.done():
                    waiter.set_result(result)
            elif event_type == "control.changed" and isinstance(payload, Mapping):
                mode = str(payload.get("mode", "")).lower()
                operation = {"paused": "pause", "running": "resume", "emergency_stopped": "emergency_stop"}.get(mode, mode)
                envelope = new_envelope(EventKind.CONTROL, {"operation": operation}, source="minecraft-http",
                    session_id=self._session_id, world_id=self._world_id, trust=TrustClass.SYSTEM)
                await self.controls.put(envelope)
            elif event_type == "world_text.observed" and isinstance(payload, Mapping):
                envelope = new_envelope(EventKind.AUDIT, {**dict(payload), "instructionEligible": False}, source="minecraft-http",
                    session_id=self._session_id, world_id=self._world_id, trust=TrustClass.EXTERNAL_UNTRUSTED)
                self.store.append_event(envelope)
        if self._event_cursor != initial_cursor and self._server_session_id:
            self.store.set_state(self._cursor_key(self._server_session_id), {"cursor": self._event_cursor})

    def _select_server_session(self, health: Mapping[str, Any]) -> None:
        session = str(health.get("worldSessionId") or health.get("worldId") or "").strip()
        if not session or session == self._server_session_id:
            return
        self._server_session_id = session
        saved = self.store.get_state(self._cursor_key(session), {})
        try:
            self._event_cursor = max(0, int(saved.get("cursor", 0))) if isinstance(saved, Mapping) else 0
        except (TypeError, ValueError):
            self._event_cursor = 0

    @staticmethod
    def _cursor_key(session: str) -> str:
        return "minecraft_http.event_cursor:" + session

    async def _refresh_observation(self) -> None:
        raw = await self._request("GET", "/v1/observation")
        sequence = int(raw.get("sequence", 0))
        if sequence <= self._last_sequence:
            return
        normalized = self._normalize_observation(raw, self._embodiment, self._human_control_possible)
        self._controlled_actor = dict(normalized.controlled_actor)
        self._human_players = normalized.human_players
        self._embodiment = dict(normalized.embodiment)
        self._bot_ready = (
            str(self._embodiment.get("status", "")).upper() == "READY"
            and bool(self._embodiment.get("connected", False))
        )
        self._last_sequence = normalized.sequence
        # Never use the player UUID as a world identity: doing so would merge
        # spatial evidence from unrelated saves. Older bridge builds without a
        # stable worldId are intentionally scoped to this runtime session.
        self._world_id = str(raw.get("worldId") or raw.get("worldSessionId") or ("session:" + self._session_id))
        envelope = new_envelope(EventKind.OBSERVATION, normalized, source="minecraft-http",
            session_id=self._session_id, world_id=self._world_id, trust=TrustClass.GAME_OBSERVATION)
        self.store.append_event(envelope)
        async with self._observation_condition:
            self._last_observation = normalized
            self._observation_condition.notify_all()

    @staticmethod
    def _normalize_observation(
        raw: Mapping[str, Any],
        bridge_embodiment: Mapping[str, Any] | None = None,
        human_control_possible: bool = True,
    ) -> Observation:
        player = dict(raw.get("player", {}))
        ai_raw = raw.get("aiPlayer")
        if not isinstance(ai_raw, Mapping):
            raise ConnectionError("separate-player observation is missing aiPlayer")
        ai_player = dict(ai_raw)
        embodiment_raw = raw.get("embodiment", bridge_embodiment or {})
        if not isinstance(embodiment_raw, Mapping):
            raise ConnectionError("separate-player observation has invalid embodiment metadata")
        embodiment = dict(embodiment_raw)
        mode = str(embodiment.get("mode", "")).upper()
        if mode not in {"SEPARATE_LOCAL_PLAYER", "MINEFLAYER_NETWORK_CLIENT", "DEDICATED_FABRIC_CLIENT"}:
            raise ConnectionError(f"refusing legacy embodiment mode {mode or 'unspecified'}; human control is forbidden")
        declared_human_control = embodiment.get("humanControlPossible", human_control_possible)
        if declared_human_control is not False:
            raise ConnectionError("embodiment did not prove humanControlPossible=false")
        player_id = _identity(player)
        ai_id = _identity(ai_player)
        bot_id = str(embodiment.get("botUuid") or ai_id)
        if not player_id or not ai_id or player_id != ai_id or (bot_id and ai_id != bot_id):
            raise ConnectionError("player/aiPlayer/botUuid identities are missing or inconsistent")
        human_raw = raw.get("humanPlayers", ())
        if not isinstance(human_raw, (list, tuple)):
            raise ConnectionError("humanPlayers must be an array")
        human_players = tuple(dict(item) for item in human_raw if isinstance(item, Mapping))
        if any(_identity(item) == ai_id for item in human_players):
            raise ConnectionError("MineMind controlled actor is also listed as a human player")
        # The explicit AI copy is authoritative. Equality of identity is checked
        # above; using it prevents accidental leakage of a legacy human snapshot.
        player = ai_player
        if "food" in player and "hunger" not in player:
            player["hunger"] = player["food"]
        for source, target in (
            ("inWater", "in_water"), ("inLava", "in_lava"), ("onGround", "on_ground"),
            ("onFire", "on_fire"), ("fallDistance", "fall_distance"),
            ("remainingFireTicks", "remaining_fire_ticks"), ("hurtTime", "hurt_time"),
            ("hurtDuration", "hurt_duration"), ("lastDamageType", "last_damage_type"),
        ):
            if source in player:
                player[target] = player[source]
        environment = dict(raw.get("environment", {}))
        environment["success_signals"] = dict(raw.get("successSignals", {}))
        world_text = tuple({"type": "world_text", "trust": "external_untrusted", "instruction_eligible": False, **dict(item)}
                           for item in raw.get("untrustedWorldText", []) if isinstance(item, Mapping))
        sounds = tuple({"type": "sound", "trust": "game_observation", "instruction_eligible": False, **dict(item)}
                       for item in raw.get("recentSounds", []) if isinstance(item, Mapping))
        damage = tuple({"type": "damage", "trust": "game_observation", "instruction_eligible": False, **dict(item)}
                       for item in raw.get("recentDamage", []) if isinstance(item, Mapping))
        container = raw.get("container")
        return Observation(
            tick=int(raw.get("serverTick", 0)), sequence=int(raw.get("sequence", 0)), player=player,
            environment=environment, inventory=tuple(raw.get("inventory", ())),
            nearby_blocks=tuple(raw.get("nearbyBlocks", ())), nearby_entities=tuple(raw.get("nearbyEntities", ())),
            events=(*world_text, *sounds, *damage), interfaces=(dict(container),) if isinstance(container, Mapping) else (), full=True,
            controlled_actor={
                "id": ai_id,
                "uuid": ai_id,
                "name": str(embodiment.get("botName") or ai_player.get("name") or "MineMind"),
                "role": "minemind_ai",
            },
            human_players=human_players,
            embodiment={**embodiment, "mode": mode, "humanControlPossible": False},
        )

    def _update_embodiment(self, health: Mapping[str, Any], capabilities: Mapping[str, Any]) -> None:
        candidates = (health.get("embodiment"), capabilities.get("embodiment"))
        merged: dict[str, Any] = {}
        for candidate in candidates:
            if isinstance(candidate, Mapping):
                merged.update(candidate)
        if "humanControlPossible" in capabilities:
            merged["humanControlPossible"] = capabilities["humanControlPossible"]
        self._embodiment = merged
        self._human_control_possible = merged.get("humanControlPossible") is not False
        bot_id = str(merged.get("botUuid") or "")
        bot_name = str(merged.get("botName") or "MineMind")
        self._controlled_actor = {
            "id": bot_id,
            "uuid": bot_id,
            "name": bot_name,
            "role": "minemind_ai",
        } if bot_id else {}
        self._bot_ready = (
            str(merged.get("status", "")).upper() == "READY"
            and bool(merged.get("connected", health.get("botReady", False)))
            and not self._human_control_possible
        )

    def _is_controlled_actor(self, actor: Mapping[str, Any]) -> bool:
        expected = _identity(self._controlled_actor)
        return bool(expected and _identity(actor) == expected)

    @staticmethod
    def _translate(command: ActionCommand) -> tuple[str, dict[str, Any], bool]:
        kind = _ACTION_NAMES.get(command.kind.value, command.kind.value.upper())
        params = dict(command.parameters)
        target = params.pop("target", None)
        if isinstance(target, Mapping):
            params.update({key: target[key] for key in ("x", "y", "z", "entityId", "id") if key in target})
            if "id" in params and "entityId" not in params and isinstance(params["id"], int):
                params["entityId"] = params.pop("id")
        if command.kind.value == "move" and "direction" in params:
            direction = str(params.pop("direction")).lower()
            vectors = {"forward": (1, 0), "back": (-1, 0), "backward": (-1, 0), "left": (0, -1), "right": (0, 1), "stop": (0, 0)}
            forward, strafe = vectors.get(direction, (0, 0))
            params.setdefault("forward", forward); params.setdefault("strafe", strafe)
        if command.kind.value == "swim" and "direction" in params:
            params["vertical"] = {"up": 0.2, "down": -0.15}.get(str(params.pop("direction")).lower(), 0.08)
        if command.kind.value == "sneak" and "enabled" in params:
            params["active"] = bool(params.pop("enabled"))
        if command.kind.value == "query" and "selector" in params:
            selector = str(params.pop("selector")).lower()
            params["kind"] = {"local_state": "LATEST_OBSERVATION", "latest_observation": "LATEST_OBSERVATION",
                              "block": "BLOCK_AT", "entity": "ENTITY_BY_ID"}.get(selector, selector.upper())
        destructive = bool(command.requires_confirmation or params.pop("destructive_confirmed", False))
        return kind, params, destructive

    def _action_result(self, payload: Mapping[str, Any]) -> ActionResult:
        action_id = str(payload.get("id", ""))
        status_raw = str(payload.get("status", "FAILED")).lower()
        status = "succeeded" if status_raw == "succeeded" else status_raw
        evidence = payload.get("evidence", {})
        effects = tuple({"path": str(key), "value": value} for key, value in evidence.items()) if isinstance(evidence, Mapping) else ()
        error = None if status == "succeeded" else {"code": str(payload.get("code", status)), "message": str(payload.get("message", ""))}
        return ActionResult(action_id, status, self._action_started.pop(action_id, _now()), str(payload.get("completedAt") or _now()), effects, error)

    async def execute(self, command: ActionCommand, timeout: float) -> ActionResult:
        actor_id = _identity(self._controlled_actor)
        if not self._bot_ready or not actor_id or self._human_control_possible:
            return ActionResult(
                command.action_id, "safety_stop", _now(), _now(), (),
                {"code": "separate_player_not_ready", "message": "MineMind separate player identity is not ready; refusing any human-player fallback"},
            )
        mod_kind, parameters, destructive = self._translate(command)
        capability = self._capabilities.get(mod_kind.lower())
        if capability == "CAPABILITY_GAP" or mod_kind == "NAVIGATE" and capability is None:
            return ActionResult(command.action_id, "capability_gap", _now(), _now(), (),
                                {"code": "capability_gap", "message": f"Minecraft mod does not implement {mod_kind}"})
        loop = asyncio.get_running_loop()
        waiter: asyncio.Future[ActionResult] = loop.create_future()
        self._result_waiters[command.action_id] = waiter
        self._action_started[command.action_id] = _now()
        body = {"id": command.action_id, "actor": actor_id, "type": mod_kind, "parameters": parameters,
                "expectedObservationSequence": max(0, self._last_sequence), "destructiveConfirmed": destructive}
        try:
            queued = await self._request("POST", "/v1/actions", body)
            if str(queued.get("status", "")).upper() != "QUEUED":
                return self._action_result(queued)
            return await asyncio.wait_for(waiter, timeout=timeout)
        finally:
            self._result_waiters.pop(command.action_id, None)
            self._action_started.pop(command.action_id, None)

    async def submit_objective(self, text: str, actor: str = "active") -> Mapping[str, Any]:
        issuer = actor or "active"
        return await self._request(
            "POST", "/v1/objectives",
            {"objective": text, "actor": issuer, "issuedBy": issuer},
        )

    async def send_control(self, operation: str, reason: str = "runtime control") -> Mapping[str, Any]:
        kind = {"pause": "PAUSE", "resume": "RESUME", "emergency_stop": "EMERGENCY_STOP", "stop": "EMERGENCY_STOP",
                "cancel": "PAUSE",
                "clear_emergency_stop": "CLEAR_EMERGENCY_STOP"}.get(operation, operation.upper())
        return await self._request("POST", "/v1/control", {"type": kind, "reason": reason})

    async def wait_observation(self, after_sequence: int = -1, timeout: float = 30) -> Observation:
        async with self._observation_condition:
            await asyncio.wait_for(self._observation_condition.wait_for(
                lambda: self._last_observation is not None and self._last_observation.sequence > after_sequence), timeout)
            assert self._last_observation is not None
            return self._last_observation

    @property
    def latest_observation(self) -> Observation | None:
        return self._last_observation

    def status(self) -> BridgeStatus:
        return BridgeStatus(
            self.connected.is_set(), self._session_id if self.connected.is_set() else None,
            self._world_id, self._mod_version, self._last_sequence,
            _identity(self._controlled_actor) or None,
            str(self._controlled_actor.get("name")) if self._controlled_actor.get("name") else None,
            str(self._embodiment.get("mode", "legacy_unspecified")),
            str(self._embodiment.get("status", "unknown")),
            self._bot_ready, self._human_control_possible,
        )

    def action_provenance(self) -> dict[str, Any]:
        return {
            "session_id": self._session_id,
            "world_id": self._world_id,
            "controlled_actor_id": _identity(self._controlled_actor) or None,
            "controlled_actor_name": self._controlled_actor.get("name"),
            "embodiment_mode": self._embodiment.get("mode"),
            "embodiment_status": self._embodiment.get("status"),
            "observation_sequence": self._last_sequence,
            "human_control_possible": self._human_control_possible,
            "source": "minecraft_http_bridge",
        }

    def capability_gaps(self) -> tuple[Mapping[str, Any], ...]:
        return tuple(
            {
                "capability": capability,
                "evidence": f"Minecraft embodiment reports {state} for atomic action {capability}.",
                "occurrences": 1,
            }
            for capability, state in sorted(self._capabilities.items())
            if state.upper() != "IMPLEMENTED"
        ) + (() if self._bot_ready and not self._human_control_possible else ({
            "capability": "separate_player_embodiment",
            "evidence": self._last_error or "MineMind bot identity is not ready or human control has not been disproved.",
            "occurrences": 1,
        },))


def _identity(value: Mapping[str, Any]) -> str:
    return str(value.get("uuid") or value.get("id") or "")
