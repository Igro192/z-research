from __future__ import annotations

import asyncio
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import inspect
import re
import time
from typing import Any, Mapping, Sequence
from uuid import uuid4

from minemind_model_router import RouterError
from minemind_learning_system import RewardCalculator, RewardSignals
from minemind_orchestrator import AgentProposal, CognitiveOrchestrator, Role
from minemind_planner import HierarchicalPlanner, Milestone, MilestoneStatus, Plan
from minemind_protocol import ActionCommand, ActionKind, EventKind, Objective, Observation, TrustClass, new_envelope
from minemind_world_model import WorldModel

from .bridge import BridgeServer
from .cognition import CHAT_INTENT_SCHEMA, DeterministicCognition, INTENT_SCHEMA, ModelCognition
from .config import RuntimeConfig
from .store import RuntimeStore
from .monitoring import capability_gaps, evaluation_status, training_status
from .fast_path import compile_direct_skill, direct_postcondition_met


@dataclass(slots=True)
class RuntimeServices:
    memory: Any = None
    skills: Any = None
    learning: Any = None
    evaluation: Any = None
    training: Any = None


@dataclass(slots=True, frozen=True)
class SafetyDecision:
    allowed: bool
    reason: str
    requires_confirmation: bool = False


class SafetyGate:
    def __init__(self, config: RuntimeConfig) -> None:
        self.config = config

    def evaluate(self, command: ActionCommand, observation: Observation) -> SafetyDecision:
        params = command.parameters
        target = params.get("target", {})
        target_id = str(target.get("id", "")) if isinstance(target, Mapping) else str(target)
        target_type = str(target.get("type", "")) if isinstance(target, Mapping) else ""
        if command.risk >= self.config.budgets.confirmation_risk_threshold or command.requires_confirmation:
            return SafetyDecision(False, "risk threshold requires authorized confirmation", True)
        if command.kind == ActionKind.ATTACK and target_type == "player":
            return SafetyDecision(False, "attacking players requires explicit confirmation", True)
        if target_id in self.config.safety.protected_entities or target_id in self.config.safety.protected_blocks:
            return SafetyDecision(False, f"target {target_id} is protected")
        return SafetyDecision(True, "within configured sandbox")


class EvidenceEvaluator:
    @staticmethod
    def _resolve(document: Any, path: str) -> tuple[bool, Any]:
        current = document
        if not path:
            return True, current
        for part in path.split("."):
            if isinstance(current, Mapping) and part in current:
                current = current[part]
            elif isinstance(current, Sequence) and not isinstance(current, (str, bytes)) and part.isdigit() and int(part) < len(current):
                current = current[int(part)]
            else:
                return False, None
        return True, current

    @classmethod
    def matches(cls, criteria: Sequence[Mapping[str, Any]], document: Mapping[str, Any]) -> bool:
        if not criteria:
            return False
        for criterion in criteria:
            exists, actual = cls._resolve(document, str(criterion.get("path", "")))
            op, expected = str(criterion.get("op", "==")), criterion.get("value")
            if op == "exists":
                matched = exists == bool(expected if expected is not None else True)
            elif not exists:
                matched = False
            elif op == "==":
                matched = actual == expected
            elif op == "!=":
                matched = actual != expected
            elif op == ">":
                matched = actual > expected
            elif op == ">=":
                matched = actual >= expected
            elif op == "<":
                matched = actual < expected
            elif op == "<=":
                matched = actual <= expected
            elif op == "contains":
                matched = expected in actual
            elif op in {"any", "count_eq"}:
                where = criterion.get("where", {})
                if not isinstance(actual, Sequence) or isinstance(actual, (str, bytes)) or not isinstance(where, Mapping):
                    matched = False
                else:
                    matched_items = [
                        item for item in actual
                        if isinstance(item, Mapping) and cls._matches_where(item, where)
                    ]
                    required_count = int(criterion.get("count_gte", 1))
                    observed_count = sum(int(item.get("count", 1)) for item in matched_items)
                    matched = observed_count == expected if op == "count_eq" else observed_count >= required_count
            else:
                matched = False
            if not matched:
                return False
        return True

    @staticmethod
    def _matches_where(item: Mapping[str, Any], where: Mapping[str, Any]) -> bool:
        """Match exact fields plus bounded string predicates from the evidence DSL.

        Small local models sometimes describe a resource category (``log``)
        instead of hallucinating an exact variant (``oak_log``).  Suffix
        operators remain observation-only and generic: they inspect trusted
        item identifiers and do not encode a task solution.
        """
        for key, expected in where.items():
            field = str(key)
            if field.endswith("_contains"):
                actual = item.get(field[:-9])
                if not isinstance(actual, str) or str(expected) not in actual:
                    return False
            elif field.endswith("_starts_with"):
                actual = item.get(field[:-12])
                if not isinstance(actual, str) or not actual.startswith(str(expected)):
                    return False
            elif field.endswith("_ends_with"):
                actual = item.get(field[:-10])
                if not isinstance(actual, str) or not actual.endswith(str(expected)):
                    return False
            elif item.get(field) != expected:
                return False
        return True


async def _call_optional(target: Any, method: str, *args: Any, default: Any = None, **kwargs: Any) -> Any:
    if target is None or not hasattr(target, method):
        return default
    result = getattr(target, method)(*args, **kwargs)
    return await result if inspect.isawaitable(result) else result


def _nonnegative(value: Any) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return 0.0
    return max(0.0, float(value))


def _belief_value(state: Mapping[str, Any], key: str) -> Mapping[str, Any]:
    direct = state.get(key)
    if isinstance(direct, Mapping):
        return direct
    beliefs = state.get("beliefs", {})
    wrapper = beliefs.get(key, {}) if isinstance(beliefs, Mapping) else {}
    value = wrapper.get("value", {}) if isinstance(wrapper, Mapping) else {}
    return value if isinstance(value, Mapping) else {}


def _player_number(state: Mapping[str, Any], key: str) -> float:
    value = _belief_value(state, "player").get(key)
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else 0.0


def _aggregate_uncertainty(state: Mapping[str, Any]) -> float:
    beliefs = state.get("beliefs", {})
    if not isinstance(beliefs, Mapping):
        return 0.0
    values = [
        float(item["uncertainty"])
        for item in beliefs.values()
        if isinstance(item, Mapping)
        and isinstance(item.get("uncertainty"), (int, float))
        and not isinstance(item.get("uncertainty"), bool)
    ]
    return sum(values) / len(values) if values else 0.0


class _SkillAtomicExecutor:
    """Adapts a promoted graph node to a fully journaled embodiment action."""

    def __init__(self, runtime: "AgentLoop", objective: Objective, plan: Plan, milestone: Milestone, skill_id: str, risk: float) -> None:
        self.runtime, self.objective, self.plan, self.milestone = runtime, objective, plan, milestone
        self.skill_id, self.risk = skill_id, risk

    async def execute(self, capability: str, arguments: Mapping[str, Any]):
        from minemind_skill_engine import ActionResult as SkillActionResult
        observation = self.runtime.bridge.latest_observation
        if observation is None:
            return SkillActionResult(False, {}, "no current observation", 0.0)
        try:
            command = ActionCommand.create(ActionKind(capability), dict(arguments), risk=self.risk, plan_step_id=self.milestone.id)
        except ValueError as exc:
            return SkillActionResult(False, {}, str(exc), 0.0)
        safety = self.runtime.safety.evaluate(command, observation)
        if not safety.allowed:
            return SkillActionResult(False, {}, "safety gate: " + safety.reason, 0.0)
        world_id = self.runtime.bridge.status().world_id or "unknown"
        before = self.runtime.world_model.compact_summary(world_id, observation.tick)
        try:
            result, after, _, reward = await self.runtime._execute_action(
                self.objective, self.plan, self.milestone, observation, before, command, (), (), selected_skill=self.skill_id
            )
        except Exception as exc:
            return SkillActionResult(False, {}, str(exc), 0.0)
        return SkillActionResult(result.status in {"success", "succeeded"}, dict(after),
                                 None if result.status in {"success", "succeeded"} else str(result.error or result.status),
                                 abs(float(reward.get("total", 0))))


class AgentLoop:
    """Persistent hierarchical control loop with emergency preemption."""

    def __init__(self, config: RuntimeConfig, store: RuntimeStore, bridge: BridgeServer,
                 world_model: WorldModel, planner: HierarchicalPlanner,
                 orchestrator: CognitiveOrchestrator, cognition: ModelCognition | DeterministicCognition,
                 services: RuntimeServices | None = None) -> None:
        self.config, self.store, self.bridge = config, store, bridge
        self.world_model, self.planner, self.orchestrator, self.cognition = world_model, planner, orchestrator, cognition
        self.services = services or RuntimeServices()
        self.safety = SafetyGate(config)
        self.reward_calculator = RewardCalculator()
        self.paused = asyncio.Event()
        self.paused.set()
        self.cancelled = asyncio.Event()
        self.stopping = asyncio.Event()
        self._objective_task: asyncio.Task[Any] | None = None
        self._active_objective: Objective | None = None
        self._active_plan: Plan | None = None
        self._last_decision: Mapping[str, Any] = {}
        self._compiled_actions: dict[str, ActionCommand] = {}
        roles = getattr(self.orchestrator, "roles", tuple(Role))
        self._agent_activity: dict[str, dict[str, Any]] = {
            role.value: {"status": "idle", "currentTask": "Ready", "latencyMs": None}
            for role in roles
        }
        self._recent_actions: list[str] = []
        self._pending_user_feedback: float | None = None
        self._background: set[asyncio.Task[Any]] = set()
        self._interrupted_objectives: list[Objective] = []
        self._last_chat_result: dict[str, Any] = {
            "category": "conversation", "reply": "MineMind is starting.",
            "task_text": "", "actionable": False,
        }
        # Emergency actions are evaluated on every fresh observation. Keep a
        # failed food/escape action from being dispatched once per tick when
        # the underlying state has not changed; that feedback loop can starve
        # the server and make the whole client appear frozen.
        self._last_reactive_signature: tuple[Any, ...] | None = None
        self._last_reactive_at = 0.0

    async def run(self) -> None:
        recovered = self.store.active_objective()
        if recovered:
            self.store.audit("recovery", "Recovered unfinished objective", {"objective_id": recovered.objective_id})
            self._launch_objective(recovered)
        while not self.stopping.is_set():
            objective_get = asyncio.create_task(self.bridge.objectives.get())
            control_get = asyncio.create_task(self.bridge.controls.get())
            stop_wait = asyncio.create_task(self.stopping.wait())
            done, pending = await asyncio.wait({objective_get, control_get, stop_wait}, return_when=asyncio.FIRST_COMPLETED)
            for task in pending:
                task.cancel()
            await asyncio.gather(*pending, return_exceptions=True)
            if stop_wait in done:
                break
            if control_get in done:
                try:
                    await self.handle_control(control_get.result().payload)
                except Exception as error:
                    self.store.audit("runtime", "Control event dispatch failed; listener remains active", {"error": repr(error)}, severity="error")
            if objective_get in done:
                try:
                    await self.accept_objective_event(objective_get.result())
                except Exception as error:
                    self.store.audit("runtime", "Objective event dispatch failed; listener remains active", {"error": repr(error)}, severity="error")

    async def stop(self) -> None:
        self.stopping.set()
        if self._objective_task:
            self.cancelled.set()
            self._objective_task.cancel()
            await asyncio.gather(self._objective_task, return_exceptions=True)
        for task in self._background:
            task.cancel()
        await asyncio.gather(*self._background, return_exceptions=True)

    async def accept_objective_event(self, event: Any) -> None:
        if event.trust != TrustClass.AUTHORIZED_USER:
            self.store.audit("security", "Rejected objective from untrusted game text", {"source": event.source, "trust": event.trust.value}, severity="warning")
            return
        player = str(event.payload.get("requested_by", ""))
        if self.config.safety.authorized_players and player not in self.config.safety.authorized_players:
            self.store.audit("security", "Rejected objective from unauthorized player", {"player": player}, severity="warning")
            return
        input_mode = str(event.payload.get("input_mode", "explicit_task")).lower()
        origin = str(event.payload.get("origin", "")).lower()
        if input_mode == "natural_chat" or origin == "player_chat":
            routed = await self._route_natural_chat(str(event.payload.get("text", "")), player)
            if routed is None:
                return
            event.payload["text"] = routed
        try:
            objective = Objective.from_dict(event.payload) if "objective_id" in event.payload else Objective.create(str(event.payload["text"]), player)
        except (KeyError, ValueError) as exc:
            self.store.audit("objective", "Rejected invalid objective", {"error": str(exc)}, severity="warning")
            return
        await self.submit_objective(objective)

    @staticmethod
    def _safe_chat_fallback(text: str) -> tuple[str, str, str]:
        """Fail closed for social chat when the local model is unavailable."""
        normalized = " ".join(text.lower().strip().split())
        if re.search(r"\b(stop|cancel|never mind|nevermind)\b", normalized):
            return "cancel", "Okay, stopping.", ""
        if re.search(r"\bpause\b", normalized):
            return "pause", "Okay, pausing.", ""
        if re.search(r"\b(resume|continue)\b", normalized):
            return "resume", "Sure, continuing.", ""
        if re.search(r"\b(what are you doing|status|how much longer|progress|are you stuck|"
                     r"how much (?:do you have|have you (?:got|collected|gathered)))\b", normalized):
            return "status", "", ""
        if (not normalized or normalized.endswith("?")
                or re.match(r"^(hi|hey|hello|yo|thanks|thank you|how are you|good morning|good night)\b", normalized)):
            return "conversation", "Hey! What are we working on?", ""
        return "task", "Sure, I'll work on that.", text.strip()

    @staticmethod
    def _contains_action_language(text: str) -> bool:
        """Detect an explicit state-changing request before asking the model.

        Small local models occasionally produce a friendly acknowledgement but
        classify a sentence containing an imperative ("get wood and craft it
        into sticks") as conversation. This lexical guard does not plan the
        task; it only guarantees that an explicit Minecraft verb reaches the
        existing planner while preserving normal greetings/questions.
        """
        normalized = " ".join(text.lower().strip().split())
        if not normalized:
            return False
        # A question about a mechanic is conversation, not an imperative.  In
        # particular, the compact local models often label “how do I get
        # wood?” as a task because it contains the verb “get”.
        if re.match(r"^(?:how|what|why|when|where|which|who|are|is|do|does|did)\b", normalized):
            return False
        # Polite imperatives and direct imperatives are the only lexical fast
        # path.  The planner still resolves the target and all dependencies;
        # this guard merely prevents a command from being downgraded to chat.
        imperative = (
            r"^(?:please\s+|can you\s+|could you\s+|would you\s+|will you\s+|"
            r"i need you to\s+|i want you to\s+|hey[, ]+)?"
            r"(?:get|collect|gather|obtain|fetch|mine|harvest|craft|make|create|place|put|use|"
            r"equip|wear|follow|come|bring|build|smelt|cook|kill|attack|hunt|defeat|"
            r"trade|enchant|brew|deposit|withdraw|store|retrieve|explore|go|reach|"
            r"find|locate|enter|leave|survive|beat)\b"
        )
        if re.search(imperative, normalized):
            return True
        # Compound imperatives may begin with context (“we need wood, then
        # craft sticks”).  Require an action verb followed by a plausible
        # object, rather than matching a verb in an explanatory sentence.
        return bool(re.search(
            r"\b(?:and then\s+|then\s+|after that\s+)?(?:get|collect|gather|obtain|fetch|mine|"
            r"harvest|craft|make|create|place|put|use|equip|wear|follow|come|bring|build|smelt|"
            r"cook|kill|attack|hunt|defeat|trade|enchant|brew|deposit|withdraw|store|retrieve|"
            r"explore|go|reach|find|locate|enter|leave|survive|beat)\s+(?:some|the|a|an|your|"
            r"my|me|it|them|that|this|[a-z0-9])",
            normalized,
        ))

    @classmethod
    def _enforce_chat_intent(cls, text: str, category: str, reply: str,
                             task_text: str) -> tuple[str, str, str]:
        """Apply deterministic safety rails around a fallible local classifier.

        The model still writes the friendly reply and interprets novel input,
        but it cannot turn an obvious greeting into a status request, swallow a
        stop command, or acknowledge an imperative without scheduling it.
        """
        fallback_category, fallback_reply, _ = cls._safe_chat_fallback(text)
        if cls._contains_action_language(text) and category not in {"cancel", "pause", "resume"}:
            return "task", reply, text.strip()
        if fallback_category in {"cancel", "pause", "resume", "status"}:
            return fallback_category, reply or fallback_reply, ""
        if fallback_category == "conversation":
            safe_category = category if category in {"conversation", "question"} else "conversation"
            return safe_category, reply or fallback_reply, ""
        return category, reply, task_text

    @staticmethod
    def _clean_chat_reply(reply: str) -> str:
        """Remove compact-model formatting debris without rewriting its answer."""
        cleaned = " ".join(str(reply).strip().split())[:240]
        # Small local models sometimes append a prompt-channel token such as
        # ``minecraft:`` (occasionally preceded by an emoji). It is not part
        # of the message and looks broken in both game chat and the app.
        return re.sub(r"\s*[^\w\s.,!?'-]*minecraft:\s*$", "", cleaned, flags=re.I).strip()

    async def _route_natural_chat(self, text: str, player: str) -> str | None:
        category, reply, task_text = self._safe_chat_fallback(text)
        self._set_agent_activity(Role.EXECUTIVE, "active", f"Understanding {player}'s message")
        try:
            observation = self.bridge.latest_observation
            objective_context = self.snapshot().get("objective")
            if isinstance(objective_context, Mapping) and str(objective_context.get("status", "")).lower() not in {
                "queued", "planning", "running", "executing", "verifying",
                "paused", "waiting_for_model", "waiting_for_world",
            }:
                objective_context = None
            context = {
                "message": text,
                "authorized_player": player,
                "current_objective": objective_context,
                "bot_state": ({
                    "health": observation.player.get("health"),
                    "hunger": observation.player.get("hunger"),
                    "dimension": observation.player.get("dimension"),
                    "inventory": list(observation.inventory)[:24],
                } if observation else {}),
            }
            value = await self.cognition.call(Role.EXECUTIVE, context, CHAT_INTENT_SCHEMA)
            category = str(value.get("category", category))
            reply = self._clean_chat_reply(str(value.get("reply", reply)))
            task_text = str(value.get("task_text", task_text)).strip()[:512]
            confidence = float(value.get("confidence", 0))
            if confidence < 0.45:
                category, reply, task_text = self._safe_chat_fallback(text)
            # The model supplies natural language, while deterministic intent
            # rails guarantee greetings remain chat, controls remain controls,
            # and explicit commands always become executable objectives.
            category, reply, task_text = self._enforce_chat_intent(
                text, category, reply, task_text
            )
            model = value.get("_model", {}) if isinstance(value.get("_model"), Mapping) else {}
            self._set_agent_activity(Role.EXECUTIVE, "idle", f"Classified as {category}",
                                     str(model.get("model")) if model.get("model") else None,
                                     float(model["latency_ms"]) if isinstance(model.get("latency_ms"), (int, float)) else None)
        except Exception as exc:
            self._set_agent_activity(Role.EXECUTIVE, "idle", f"Used safe local classification: {category}")
            self.store.audit("conversation", "Intent model unavailable; used safe fallback", {
                "error": str(exc), "category": category,
            }, severity="warning")
        reply = self._clean_chat_reply(reply)
        effective_reply = reply
        if category in {"cancel", "pause", "resume"}:
            operation = "cancel" if category == "cancel" else category
            await self.handle_control({"operation": operation})
            effective_reply = reply or {"cancel": "Okay, stopping.", "pause": "Okay, pausing.", "resume": "Sure, continuing."}[category]
            self._record_chat_result(player, text, category, effective_reply, "")
            await self._communicate(effective_reply)
            return None
        if category == "status":
            # Status answers are grounded in observed runtime state instead of
            # trusting a conversational model to estimate progress or counts.
            effective_reply = self._grounded_status_reply(text)
            self._record_chat_result(player, text, category, effective_reply, "")
            await self._communicate(effective_reply)
            return None
        if category in {"conversation", "question"}:
            effective_reply = reply or "I'm here. What would you like to do?"
            self._record_chat_result(player, text, category, effective_reply, "")
            await self._communicate(effective_reply)
            return None
        if category != "task" or not task_text:
            effective_reply = reply or "I didn't find an actionable task in that message."
            self._record_chat_result(player, text, category, effective_reply, "")
            await self._communicate(effective_reply)
            return None
        effective_reply = reply or "Sure, I'll work on that."
        self._record_chat_result(player, text, category, effective_reply, task_text)
        await self._communicate(effective_reply)
        return task_text

    def _record_chat_result(self, player: str, message: str, category: str,
                            reply: str, task_text: str) -> None:
        self._last_chat_result = {
            "category": category, "reply": reply, "task_text": task_text,
            "actionable": category == "task" and bool(task_text),
        }
        self.store.audit("conversation", "Authorized chat classified", {
            "player": player, "message": message[:512], "category": category,
            "reply": reply[:240], "task_text": task_text[:512],
            "actionable": self._last_chat_result["actionable"],
        })

    def _grounded_status_reply(self, message: str) -> str:
        status = self.snapshot().get("objective") or {}
        observation = self.bridge.latest_observation
        normalized = " ".join(message.lower().split())
        if observation and re.search(r"\bhow much\b|\bcollected\b|\binventory\b", normalized):
            inventory = [
                f"{str(item.get('id', 'item')).removeprefix('minecraft:').replace('_', ' ')} x{int(item.get('count', 0))}"
                for item in observation.inventory if int(item.get("count", 0)) > 0
            ]
            return "I currently have " + (", ".join(inventory[:8]) if inventory else "an empty inventory") + "."
        execution = self.store.get_state("execution_progress", {})
        phase = str(execution.get("phase", "")) if isinstance(execution, Mapping) else ""
        active_states = {
            "queued", "planning", "running", "executing", "verifying",
            "paused", "waiting_for_model", "waiting_for_world",
        }
        objective_state = str(status.get("status", "")).lower() if status else ""
        if status and objective_state in active_states:
            detail = str(status.get("reason") or phase or status.get("status") or "working").replace("_", " ")
            return f"I'm {detail}: {status.get('text', 'the current task')}."
        if status:
            label = objective_state.replace("_", " ") or "finished"
            return f"I'm ready. My last task, {status.get('text', 'the previous task')}, {label}."
        return "I'm ready for a task."

    async def submit_chat_message(self, text: str, player: str = "dashboard") -> Mapping[str, Any]:
        """Process dashboard text through the same chat/intent path as game chat."""
        task_text = await self._route_natural_chat(text, player)
        result = dict(self._last_chat_result)
        if task_text:
            objective = Objective.create(task_text, player)
            await self.submit_objective(objective)
            status = self.store.objective_status(objective.objective_id) or {}
            result.update({
                "objective_id": objective.objective_id,
                "status": str(status.get("status", "queued")),
            })
        else:
            result.update({"objective_id": None, "status": "answered"})
        return result

    async def submit_objective(self, objective: Objective) -> None:
        if not self.store.create_objective(objective):
            self.store.audit("objective", "Ignored replayed objective event", {"objective_id": objective.objective_id})
            return
        if self._objective_task and not self._objective_task.done():
            active = self.store.objective_status(self._active_objective.objective_id) if self._active_objective else None
            active_status = str(active.get("status", "")) if active else ""
            # A successful/failed objective can spend a few more seconds in
            # reflection and memory consolidation after its trusted terminal
            # status is written.  Do not make a new human request wait behind
            # that post-task work: cancel the tail, preserve its terminal
            # record, and launch the new request immediately.  Reflection is
            # best-effort and must never make chat objectives appear ignored.
            if active_status in {"succeeded", "failed", "impossible", "budget_exhausted", "cancelled"}:
                self.store.audit("objective", "Preempted terminal reflection for newer objective", {
                    "completed_objective_id": self._active_objective.objective_id if self._active_objective else None,
                    "new_objective_id": objective.objective_id,
                    "completed_status": active_status,
                })
                self.paused.clear()
                self._objective_task.cancel()
                await asyncio.gather(self._objective_task, return_exceptions=True)
                self._objective_task = None
                self._active_objective = None
                self._active_plan = None
                self._compiled_actions = {}
                self._launch_objective(objective)
                return
            # A direct human request always interrupts autonomous work. Save
            # the exact Objective object so the previous hierarchy can resume
            # after the interruption instead of disappearing into a queue.
            interrupted = self._active_objective
            if interrupted is not None:
                self.store.set_objective_status(
                    interrupted.objective_id, "paused",
                    f"interrupted by {objective.objective_id}",
                )
                # Keep interruption robust for restored/lightweight loop
                # instances as well as the normal constructor path.  A
                # partially restored runtime must never drop a new user
                # request merely because its in-memory resume stack has not
                # been materialized yet.
                if not hasattr(self, "_interrupted_objectives"):
                    self._interrupted_objectives = []
                self._interrupted_objectives.append(interrupted)
            self.store.audit("objective", "Preempting active objective for human request", {
                "paused_objective_id": interrupted.objective_id if interrupted else None,
                "new_objective_id": objective.objective_id,
            })
            if not hasattr(self, "paused"):
                self.paused = asyncio.Event()
            self.paused.clear()
            self.cancelled.set()
            self._objective_task.cancel()
            await asyncio.gather(self._objective_task, return_exceptions=True)
            self._objective_task = None
            self._active_objective = None
            self._active_plan = None
            self._compiled_actions = {}
            self._launch_objective(objective)
            return
        self._launch_objective(objective)

    def _launch_objective(self, objective: Objective) -> None:
        self.cancelled.clear()
        self.paused.set()
        self._objective_task = asyncio.create_task(self._run_objective(objective), name=f"objective:{objective.objective_id}")
        self._objective_task.add_done_callback(lambda _: self._launch_next_queued())

    def _launch_next_queued(self) -> None:
        # Restored/test-minimal loop objects can be created without the full
        # constructor. Treat missing lifecycle events as their safe defaults;
        # a callback from a completed objective must never raise and poison
        # the event loop.
        stopping = getattr(self, "stopping", None)
        paused = getattr(self, "paused", None)
        if (stopping is not None and stopping.is_set()) or (paused is not None and not paused.is_set()):
            return
        queued = self.store.active_objective()
        if queued and (self._active_objective is None or queued.objective_id != self._active_objective.objective_id):
            self._launch_objective(queued)
        elif getattr(self, "_interrupted_objectives", None):
            interrupted = self._interrupted_objectives.pop()
            self.store.set_objective_status(interrupted.objective_id, "queued", "resuming after user interruption")
            self._launch_objective(interrupted)

    async def handle_control(self, control: Mapping[str, Any]) -> None:
        operation = str(control.get("operation") or control.get("command") or "")
        active_status = self.store.objective_status(self._active_objective.objective_id) if self._active_objective else None
        active_live = active_status and active_status.get("status") not in {
            "cancelled", "succeeded", "failed", "impossible", "budget_exhausted",
        }
        if operation == "pause":
            self.paused.clear()
            if active_live:
                self.store.set_objective_status(self._active_objective.objective_id, "paused", "user pause")
        elif operation in {"resume", "clear_emergency_stop"}:
            self.paused.set()
            if active_live:
                self.store.set_objective_status(self._active_objective.objective_id, "running")
            elif not self._objective_task or self._objective_task.done():
                queued = self.store.active_objective(include_paused=True)
                if queued:
                    self._launch_objective(queued)
        elif operation in {"cancel", "stop", "emergency_stop"}:
            self.cancelled.set()
            self.paused.clear()
            if active_live:
                self.store.set_objective_status(self._active_objective.objective_id, "cancelled", operation)
            if self._objective_task and not self._objective_task.done():
                # Interrupt an in-flight local model request immediately. The
                # network transport runs outside the game process, so this is
                # safe and leaves the emergency controller responsive.
                self._objective_task.cancel()
            self.store.audit("safety", "Immediate stop applied", {"operation": operation}, severity="warning")
        elif operation == "feedback":
            value = control.get("value")
            if not isinstance(value, (int, float)) or isinstance(value, bool) or not -1 <= float(value) <= 1:
                self.store.audit("learning", "Rejected invalid user preference feedback", {"value": value}, severity="warning")
            else:
                self._pending_user_feedback = float(value)
                self.store.audit("learning", "Accepted explicit user preference feedback", {"value": value})
        else:
            self.store.audit("control", "Ignored unknown control operation", {"operation": operation}, severity="warning")

    async def cancel_objective(self, objective_id: str, reason: str) -> bool:
        """Cancel only the correlated objective, never a later unrelated goal."""
        if not self._active_objective or self._active_objective.objective_id != objective_id:
            self.store.audit("control", "Refused uncorrelated objective cancellation", {"objective_id": objective_id, "reason": reason}, severity="warning")
            return False
        self.cancelled.set()
        self.paused.set()
        self.store.set_objective_status(objective_id, "cancelled", reason)
        if self._objective_task and not self._objective_task.done():
            self._objective_task.cancel()
        self.store.audit("safety", "Objective-scoped cancellation applied", {"objective_id": objective_id, "reason": reason}, severity="warning")
        return True

    async def _run_objective(self, objective: Objective) -> None:
        self._active_objective = objective
        bridge_status = self.bridge.status() if hasattr(self.bridge, "status") else None
        initial_status = "running" if bool(getattr(bridge_status, "connected", False)) else "waiting_for_world"
        initial_reason = None if initial_status == "running" else "Minecraft world is not connected yet"
        self.store.set_objective_status(objective.objective_id, initial_status, initial_reason)
        self.store.audit("objective", "Objective started", {"objective_id": objective.objective_id, "text": objective.text})
        started = time.monotonic()
        plan: Plan | None = self.planner.store.active(objective.objective_id)
        last_sequence = -1
        last_belief: Mapping[str, Any] = {}
        terminal_recorded = False
        fast_path_attempted = False
        bounded_compiler_attempted = False
        model_failures = 0
        model_retry_not_before = 0.0
        try:
            self._set_agent_activity(Role.EXECUTIVE, "active", f"Maintaining objective: {objective.text[:80]}")
            self._set_agent_activity(Role.REACTIVE_CONTROLLER, "acting", "Monitoring survival emergencies at game speed")
            while not self.cancelled.is_set():
                await self.paused.wait()
                if time.monotonic() - started > self.config.budgets.max_wall_seconds_per_objective:
                    self.store.set_objective_status(objective.objective_id, "budget_exhausted", "wall time")
                    break
                status = self.store.objective_status(objective.objective_id) or {}
                if int(status.get("action_count", 0)) >= self.config.budgets.max_actions_per_objective:
                    self.store.set_objective_status(objective.objective_id, "budget_exhausted", "action count")
                    break
                try:
                    observation = await self.bridge.wait_observation(last_sequence, self.config.tick_timeout_seconds)
                except (asyncio.TimeoutError, ConnectionError):
                    self.store.set_objective_status(objective.objective_id, "waiting_for_world", "no fresh observation")
                    await self.bridge.connected.wait()
                    continue
                last_sequence = observation.sequence
                world_id = self.bridge.status().world_id or "unknown"
                self.world_model.ingest_observation(world_id, observation.to_dict(), f"observation:{observation.sequence}")
                belief = self.world_model.compact_summary(world_id, observation.tick)
                last_belief = belief
                prompt_belief = self._prompt_belief(belief)
                prompt_belief["nearby_blocks"] = self._compact_perception(observation)["nearest_block_by_type"]
                self._set_agent_activity(Role.WORLD_MODEL, "active", f"Updated belief from observation {observation.sequence}")

                # Directly expressible generic skills must not wait for a model
                # or ask an LLM to invent movement one tick at a time.
                if plan is None and not fast_path_attempted:
                    fast_path_attempted = True
                    direct = compile_direct_skill(objective.text, objective.objective_id, observation)
                    if direct is not None:
                        self.store.set_objective_status(objective.objective_id, "executing", direct.skill_id)
                        self.store.audit("skill", "Executing deterministic generic fast path", {
                            "objective_id": objective.objective_id,
                            "skill_id": direct.skill_id,
                            "kind": direct.command.kind.value,
                        })
                        try:
                            result, after, _, _ = await self._execute_action(
                                objective, None, None, observation, belief, direct.command,
                                direct.command.predicted_effects, (), selected_skill=direct.skill_id,
                            )
                        except (asyncio.TimeoutError, ConnectionError) as exc:
                            fast_path_attempted = False
                            self.store.set_objective_status(objective.objective_id, "waiting_for_world", str(exc))
                            self.store.audit("bridge", "Direct skill interrupted by embodiment disconnect", {
                                "objective_id": objective.objective_id, "error": str(exc),
                            }, severity="warning")
                            continue
                        self.store.set_objective_status(objective.objective_id, "verifying", direct.skill_id)
                        if direct_postcondition_met(direct, result.to_dict()):
                            self.store.set_objective_status(objective.objective_id, "succeeded", "generic skill postcondition verified")
                            await self._record_outcome_transition(
                                objective, after, outcome="succeeded", terminal=True, verified=True,
                                achieved_goals=(objective.text,),
                            )
                            terminal_recorded = True
                            self.store.audit("verification", "Direct skill objective verified", {
                                "objective_id": objective.objective_id,
                                "skill_id": direct.skill_id,
                                "evidence": list(result.actual_effects),
                            })
                            break
                        self.store.set_objective_status(objective.objective_id, "planning", "generic skill needs model-guided recovery")
                        await self._record_outcome_transition(
                            objective, after, outcome="action_failed", terminal=False, verified=False,
                        )
                        self.store.audit("skill", "Generic skill failed; escalating to planning", {
                            "objective_id": objective.objective_id,
                            "skill_id": direct.skill_id,
                            "result": result.to_dict(),
                        }, severity="warning")
                        bounded_compiler_attempted = True
                        continue

                # A compact model may compile a short natural-language request
                # into a generic, persisted action graph. This covers novel
                # combinations such as craft+place without an objective string
                # handler, while long-horizon goals continue to the hierarchy.
                if plan is None and not bounded_compiler_attempted:
                    bounded_compiler_attempted = True
                    try:
                        compiled = await self._compile_bounded_objective(objective, observation)
                    except (RouterError, RuntimeError, ValueError) as exc:
                        self.store.audit("model", "Bounded objective compiler unavailable; using strategic planner", {
                            "objective_id": objective.objective_id, "error": str(exc),
                        }, severity="warning")
                        compiled = None
                    if compiled is not None:
                        plan, actions = compiled
                        self._compiled_actions = actions
                        self._active_plan = plan
                        self.store.set_objective_status(objective.objective_id, "planning", "model-compiled generic action graph")
                        self.store.audit("plan", "Executive compiled bounded objective", {
                            "objective_id": objective.objective_id, "plan_id": plan.plan_id,
                            "steps": [node.description for node in plan.milestones],
                        })

                emergency = self.orchestrator.reactive(observation.to_dict(), self._resume_token(plan))
                if emergency:
                    player_state = observation.player if isinstance(observation.player, Mapping) else {}
                    position = player_state.get("position", {}) if isinstance(player_state, Mapping) else {}
                    signature = (
                        emergency.emergency,
                        round(float(player_state.get("health", 0) or 0), 1),
                        int(player_state.get("hunger", 0) or 0),
                        round(float(position.get("x", 0) or 0)),
                        round(float(position.get("y", 0) or 0)),
                        round(float(position.get("z", 0) or 0)),
                    )
                    now = time.monotonic()
                    if signature != self._last_reactive_signature or now - self._last_reactive_at >= 15.0:
                        self._last_reactive_signature = signature
                        self._last_reactive_at = now
                        await self._execute_emergency(objective, observation, belief, emergency.action, emergency.emergency)
                    else:
                        self.store.audit("safety", "Suppressed duplicate emergency action", {
                            "emergency": emergency.emergency,
                            "cooldown_seconds": round(15.0 - (now - self._last_reactive_at), 1),
                        })
                    continue

                memories = await self._recall(objective, belief)
                skills = await self._skills(belief)
                if plan is None:
                    remaining_backoff = model_retry_not_before - time.monotonic()
                    if remaining_backoff > 0:
                        self.store.set_objective_status(
                            objective.objective_id, "waiting_for_model",
                            f"model retry in {remaining_backoff:.0f}s",
                        )
                        await asyncio.sleep(min(2.0, remaining_backoff))
                        continue
                    try:
                        self._set_agent_activity(Role.STRATEGIC_PLANNER, "active", "Creating long-horizon milestone graph")
                        self._count_model(objective)
                        plan = await self.planner.create_plan(objective, prompt_belief, memories, skills)
                        # A single-model 8-GiB preset keeps low-impact, compact
                        # plans responsive.  Complex/high-uncertainty plans are
                        # still independently criticized before execution.
                        if (len(plan.milestones) >= 3
                                or max((node.uncertainty for node in plan.milestones), default=0) >= 0.85):
                            await self._critique_plan(objective, plan, prompt_belief)
                        self._active_plan = plan
                        model_failures = 0
                        model_retry_not_before = 0.0
                        self._set_agent_activity(Role.STRATEGIC_PLANNER, "idle", f"Created plan {plan.plan_id[:8]}")
                        self.store.audit("plan", "Created milestone plan", {"plan_id": plan.plan_id, "version": plan.version, "milestones": len(plan.milestones)})
                    except (RouterError, RuntimeError) as exc:
                        model_failures += 1
                        retry_delay = min(120.0, 5.0 * (2 ** min(model_failures - 1, 5)))
                        model_retry_not_before = time.monotonic() + retry_delay
                        self.store.set_objective_status(objective.objective_id, "waiting_for_model", str(exc))
                        self.store.audit("model", "Planning model unavailable", {
                            "error": str(exc), "retry_in_seconds": retry_delay,
                            "consecutive_failures": model_failures,
                        }, severity="warning")
                        continue

                plan, completed_any, achieved_milestones = self._apply_milestone_evidence(
                    plan, observation.to_dict()
                )
                self._active_plan = plan
                if completed_any:
                    await self._record_outcome_transition(
                        objective,
                        belief,
                        outcome="milestone_achieved",
                        terminal=False,
                        verified=True,
                        achieved_goals=achieved_milestones,
                        retrieved_memories=memories,
                    )
                if all(node.status == MilestoneStatus.ACHIEVED for node in plan.milestones):
                    if await self._verify_completion(objective, plan, observation):
                        self.store.set_objective_status(objective.objective_id, "succeeded", "independently verified")
                        await self._record_outcome_transition(
                            objective,
                            belief,
                            outcome="succeeded",
                            terminal=True,
                            verified=True,
                            achieved_goals=(objective.text,),
                            retrieved_memories=memories,
                        )
                        terminal_recorded = True
                        await self._reflect(objective, "succeeded", belief)
                        break
                    await self._record_outcome_transition(
                        objective,
                        belief,
                        outcome="verification_rejected",
                        terminal=False,
                        verified=False,
                        false_success_claim=True,
                        retrieved_memories=memories,
                    )
                    plan = await self._replan(objective, belief, "final verification rejected", [{"type": "verification_rejected"}], memories, skills)
                    continue
                ready = plan.ready()
                if not ready:
                    plan = await self._replan(objective, belief, "no executable milestone", [{"type": "plan_deadlock"}], memories, skills)
                    continue
                milestone = sorted(ready, key=lambda item: (-item.priority, item.uncertainty))[0]
                compiled_command = self._compiled_actions.get(milestone.id)
                if compiled_command is not None:
                    self._last_decision = {
                        "summary": "Executing an executive-model step through a generic verified actuator.",
                        "proposals": [{
                            "proposal_id": f"compiled-{milestone.id}", "role": Role.EXECUTIVE.value,
                            "summary": milestone.description, "choice": {"action": {
                                "kind": compiled_command.kind.value, "parameters": dict(compiled_command.parameters),
                            }}, "confidence": 0.9, "risk": compiled_command.risk, "estimated_cost": 1.0,
                            "selected": True,
                        }],
                        "rejected": [],
                    }
                    self._set_agent_activity(Role.EXECUTIVE, "acting", milestone.description)
                    self.store.set_objective_status(objective.objective_id, "executing", milestone.description)
                    safety = self.safety.evaluate(compiled_command, observation)
                    if not safety.allowed:
                        self.store.audit("safety", "Compiled action blocked", {"reason": safety.reason}, severity="warning")
                        plan = await self._replan(objective, belief, "compiled action blocked by safety", [{"reason": safety.reason}], memories, skills)
                        self._compiled_actions.pop(milestone.id, None)
                        continue
                    result, after, comparison, _ = await self._execute_action(
                        objective, plan, milestone, observation, belief, compiled_command,
                        compiled_command.predicted_effects, (), retrieved_memories=memories,
                    )
                    self._recent_actions.append(f"{compiled_command.kind.value}:{compiled_command.parameters}")
                    self._recent_actions = self._recent_actions[-5:]
                    if result.status not in {"succeeded", "success"} or comparison.error > 0.5:
                        surprise = [{"type": "compiled step failed", "action": compiled_command.to_dict(),
                                     "result": result.to_dict(), "prediction_error": comparison.error}]
                        self._compiled_actions.pop(milestone.id, None)
                        plan = await self._replan(objective, after, "compiled step failed", surprise, memories, skills)
                    else:
                        trusted = getattr(self.bridge, "latest_observation", None)
                        if trusted is not None and EvidenceEvaluator.matches(milestone.completion_evidence, trusted.to_dict()):
                            plan = self.planner.update_milestone(plan, milestone.id, MilestoneStatus.ACHIEVED)
                            self._active_plan = plan
                            self._compiled_actions.pop(milestone.id, None)
                            self._set_agent_activity(Role.VERIFIER, "idle", f"Verified: {milestone.description}")
                            self.store.audit("verification", "Compiled milestone verified by fresh game state", {
                                "objective_id": objective.objective_id, "milestone_id": milestone.id,
                                "observation_sequence": trusted.sequence,
                            })
                        else:
                            surprise = [{"type": "trusted postcondition absent", "action": compiled_command.to_dict()}]
                            self._compiled_actions.pop(milestone.id, None)
                            plan = await self._replan(objective, after, "trusted postcondition absent", surprise, memories, skills)
                    continue
                try:
                    self._set_agent_activity(Role.TACTICAL_PLANNER, "active", f"Selecting next action for: {milestone.description[:80]}")
                    context = {
                               "instruction": "The current objective and current MineMind_AI observation override recalled history. Select exactly one supported atomic action. Navigate into ordinary interaction reach before mining or breaking a distant block. Mine or interact only when the target's observed id directly advances the current milestone; if the needed target is absent, navigate to expand perception. Never use placeholder values and include every required parameter.",
                               "objective": objective.to_dict(), "milestone": asdict(milestone), "belief": prompt_belief,
                               "local_perception": self._compact_perception(observation),
                               "memories": memories, "skills": skills, "atomic_actions": self._atomic_action_catalog()}
                    self._count_model(objective)
                    decision = await self.orchestrator.decide(Role.TACTICAL_PLANNER, context, uncertainty=milestone.uncertainty, impact=0.7)
                    self.store.set_objective_status(objective.objective_id, "running")
                    self._last_decision = {"summary": decision.decision_summary, "proposals": [asdict(item) for item in decision.proposals], "rejected": list(decision.rejected)}
                    self._set_agent_activity(Role.TACTICAL_PLANNER, "idle", decision.decision_summary[:120])
                except (RouterError, RuntimeError) as exc:
                    self.store.set_objective_status(objective.objective_id, "waiting_for_model", str(exc))
                    await asyncio.sleep(2)
                    continue
                if not decision.selected:
                    self.paused.clear()
                    self.store.set_objective_status(objective.objective_id, "paused", decision.decision_summary)
                    await self._communicate("MineMind needs clarification or safer evidence: " + decision.decision_summary)
                    continue
                skill_choice = decision.selected.choice.get("skill")
                if isinstance(skill_choice, Mapping):
                    skill_id = str(skill_choice.get("id", ""))
                    parameters = skill_choice.get("parameters", {})
                    if not skill_id or not isinstance(parameters, Mapping) or self.services.skills is None:
                        plan = await self._replan(objective, belief, "invalid or unavailable promoted skill", [{"choice": dict(skill_choice)}], memories, skills)
                        continue
                    execution = await self._execute_skill(objective, plan, milestone, belief, skill_id, parameters, decision.selected.risk)
                    if str(execution.status.value) != "succeeded":
                        failures = [{"type": "skill_failed", "skill_id": skill_id, "error": execution.error, "trace": list(execution.trace)}]
                        self._schedule_skill_gap(objective, milestone, failures)
                        plan = await self._replan(objective, belief, "promoted skill failed", failures, memories, skills)
                    continue
                try:
                    command, predicted, alternatives = self._command_from_proposal(decision.selected, milestone.id)
                except ValueError as exc:
                    plan = await self._replan(objective, belief, "invalid tactical action", [{"error": str(exc)}], memories, skills)
                    continue
                safety = self.safety.evaluate(command, observation)
                if not safety.allowed:
                    self.store.audit("safety", "Action blocked", {"action_id": command.action_id, "reason": safety.reason}, severity="warning")
                    if safety.requires_confirmation:
                        self.paused.clear()
                        self.store.set_state("pending_confirmation", command.to_dict())
                        await self._communicate("MineMind paused for confirmation: " + safety.reason)
                    else:
                        plan = await self._replan(objective, belief, "safety policy blocked action", [{"reason": safety.reason}], memories, skills)
                    continue
                result, after, comparison, reward = await self._execute_action(
                    objective, plan, milestone, observation, belief, command, predicted,
                    alternatives, retrieved_memories=memories
                )
                self._recent_actions.append(f"{command.kind.value}:{command.parameters}")
                self._recent_actions = self._recent_actions[-5:]
                stuck = len(self._recent_actions) >= 3 and len(set(self._recent_actions[-3:])) == 1
                failed = result.status not in {"succeeded", "success"}
                if failed or comparison.error > 0.5 or stuck:
                    reason = "action failed" if failed else ("prediction contradicted" if comparison.error > 0.5 else "repeated action loop")
                    surprises = [{"type": reason, "action": command.to_dict(), "result": result.to_dict(), "prediction_error": comparison.error}]
                    self._schedule_skill_gap(objective, milestone, surprises)
                    plan = await self._replan(objective, after, reason, surprises, memories, skills)
            if not terminal_recorded:
                status = self.store.objective_status(objective.objective_id) or {}
                outcome = str(status.get("status", "cancelled" if self.cancelled.is_set() else "failed"))
                if outcome in {"cancelled", "failed", "impossible", "budget_exhausted"}:
                    await self._record_outcome_transition(
                        objective, last_belief, outcome=outcome, terminal=True, verified=False
                    )
                    terminal_recorded = True
                    await self._reflect(objective, outcome, last_belief)
        except asyncio.CancelledError:
            current = self.store.objective_status(objective.objective_id) or {}
            current_status = str(current.get("status", ""))
            if current_status not in {"paused", "cancelled", "failed", "succeeded", "impossible", "budget_exhausted"}:
                reason = "runtime stopping" if self.stopping.is_set() else "cancelled by control"
                self.store.set_objective_status(objective.objective_id, "cancelled", reason)
            if not terminal_recorded and current_status != "paused":
                await self._record_outcome_transition(
                    objective, last_belief, outcome="cancelled", terminal=True, verified=False
                )
            raise
        except Exception as exc:
            self.store.set_objective_status(objective.objective_id, "failed", f"runtime error: {exc}")
            self.store.audit("runtime", "Objective loop crashed", {"objective_id": objective.objective_id, "error": repr(exc)}, severity="error")
            if not terminal_recorded:
                await self._record_outcome_transition(
                    objective, last_belief or {"error": str(exc)}, outcome="failed",
                    terminal=True, verified=False
                )
            await self._reflect(objective, "failed", {"error": str(exc)})
        finally:
            for role in getattr(getattr(self, "orchestrator", None), "roles", {}):
                self._set_agent_activity(role, "idle", "Ready for the next objective")
            self._active_objective = None
            self._active_plan = None
            self._compiled_actions = {}

    def _count_model(self, objective: Objective) -> None:
        count = self.store.increment(objective.objective_id, "model_call_count")
        if count > self.config.budgets.max_model_calls_per_objective:
            raise RuntimeError("model-call budget exhausted")

    def _set_agent_activity(self, role: Role | str, status: str, task: str,
                            model: str | None = None, latency_ms: float | None = None) -> None:
        name = role.value if isinstance(role, Role) else str(role)
        activity = getattr(self, "_agent_activity", None)
        if activity is None:
            activity = {}
            self._agent_activity = activity
        previous = activity.get(name, {})
        activity[name] = {
            "status": status,
            "currentTask": task,
            "latencyMs": latency_ms if latency_ms is not None else previous.get("latencyMs"),
            **({"model": model} if model else {}),
        }

    @staticmethod
    def _namespaced(value: str) -> str:
        normalized = value.strip().lower().replace(" ", "_").replace("-", "_")
        # Keep common natural-language plurals aligned with real vanilla item
        # ids.  The dedicated AutoClef adapter still receives the semantic
        # selector separately (for example ``wood`` -> ``logs``), while plan
        # evidence must use identifiers that can actually appear in inventory.
        normalized = {
            "sticks": "stick",
            "furnaces": "furnace",
            "crafting_tables": "crafting_table",
            "chests": "chest",
            "barrels": "barrel",
            "torches": "torch",
            "buckets": "bucket",
            "boats": "boat",
            "beds": "bed",
            "crafting_table": "crafting_table",
            "workbench": "crafting_table",
        }.get(normalized, normalized)
        for plural in ("pickaxes", "shovels", "swords", "hoes", "axes"):
            if normalized.endswith("_" + plural):
                normalized = normalized[:-1]
                break
        return normalized if ":" in normalized else f"minecraft:{normalized}"

    @staticmethod
    def _expand_item_group(value: str) -> tuple[str, ...]:
        """Expand a vanilla item family, not a task-specific walkthrough.

        AutoClef resolves every returned item's recipes and resource
        prerequisites. This layer only gives plural natural-language item
        groups the same meaning they have in the vanilla creative inventory.
        """
        normalized = " ".join(value.lower().replace("_", " ").replace("-", " ").split())
        match = re.fullmatch(
            r"(?:a |one |full )?(wood(?:en)?|stone|iron|gold(?:en)?|diamond|netherite) "
            r"(?:set of )?(tools?|tool set)", normalized,
        )
        if match:
            tier = {"wood": "wooden", "gold": "golden"}.get(match.group(1), match.group(1))
            return tuple(f"{tier}_{tool}" for tool in ("pickaxe", "axe", "shovel", "sword", "hoe"))
        match = re.fullmatch(
            r"(?:a |one |full )?(leather|chainmail|iron|gold(?:en)?|diamond|netherite) "
            r"(?:set of )?(?:armor|armour|armor set|armour set)", normalized,
        )
        if match:
            tier = "golden" if match.group(1) == "gold" else match.group(1)
            return tuple(f"{tier}_{piece}" for piece in ("helmet", "chestplate", "leggings", "boots"))
        return (value,)

    @staticmethod
    def _inventory_selector(value: str) -> str:
        """Return a conservative suffix selector for semantic inventory goals."""
        normalized = value.strip().lower().replace(" ", "_").replace("-", "_")
        if normalized in {"wood", "log", "logs", "wood_logs"} or normalized.endswith(("_log", "_stem", "_wood", "_hyphae")):
            return "log"
        if normalized in {"stick", "sticks"} or normalized.endswith("_stick"):
            return "stick"
        if normalized in {"plank", "planks", "wood_planks"} or normalized.endswith("_planks"):
            return "plank"
        return normalized

    @staticmethod
    def _requested_verbs(text: str) -> list[str]:
        """Return explicitly requested supported effects in textual order."""
        markers = {
            "acquire": ("collect", "get", "gather", "obtain", "fetch"),
            "craft": ("craft", "make", "create"),
            "place": ("place", "put", "set"),
            "use": ("use", "eat", "drink"),
            "equip": ("equip", "wear", "hold"),
            "follow": ("follow",),
            "communicate": ("say", "report", "tell"),
            "smelt": ("smelt", "cook"),
            "attack": ("kill", "attack", "hunt", "defeat"),
            "container": ("deposit", "withdraw", "store", "retrieve"),
            "trade": ("trade",),
            "enchant": ("enchant",),
            "brew": ("brew",),
        }
        normalized = text.lower()
        found: list[tuple[int, str]] = []
        for verb, aliases in markers.items():
            positions = [match.start() for alias in aliases
                         for match in re.finditer(rf"\b{re.escape(alias)}\b", normalized)]
            if positions:
                found.append((min(positions), verb))
        return [verb for _, verb in sorted(found)]

    @classmethod
    def _explicitly_requests(cls, text: str, verbs: Sequence[str]) -> bool:
        """Reject a small-model compiler that invents unrelated bounded work."""
        requested = set(cls._requested_verbs(text))
        return bool(requested) and all(verb in requested for verb in verbs)

    @staticmethod
    def _explicit_target(text: str, verb: str) -> str | None:
        """Recover the object of a compound imperative when the model uses a pronoun.

        This is deliberately a narrow linguistic repair, not a task handler:
        the resulting semantic item still goes through the normal AutoClef
        catalogue and recipe/dependency resolver.
        """
        normalized = " ".join(text.lower().strip().split())
        if verb == "craft":
            match = re.search(
                r"\b(?:into|as)\s+(?:a|an|some|\d+)?\s*"
                r"([a-z][a-z0-9 _-]*?)(?:[,.!?]|$)",
                normalized,
            )
            if match:
                value = re.split(r"\b(?:right now|now|for me|please|then)\b", match.group(1), maxsplit=1)[0].strip()
                if value and value not in {"it", "them", "that", "this"}:
                    return value
        return None

    @classmethod
    def _fallback_bounded_steps(cls, text: str) -> list[Mapping[str, Any]] | None:
        """Compile a small compound imperative when the local model is unsure.

        This is intentionally a generic linguistic fallback, not a Minecraft
        walkthrough: it only preserves explicit verbs and their nearby object
        phrases.  The normal dependency resolver/AutoClef catalogue still
        decides how an item is obtained.  Its main purpose is to prevent a
        lightweight model from acknowledging a command and dropping the
        executable part of a sentence.
        """
        normalized = re.sub(r"^@mind\s+", "", text.strip(), flags=re.I)
        normalized = re.sub(r"[.!?]+$", "", normalized)
        if not normalized or re.match(r"^(?:how|what|why|when|where|which|who|are|is|do|does|did)\b", normalized, re.I):
            return None
        aliases = {
            "acquire": ("collect", "gather", "obtain", "fetch", "get"),
            "craft": ("craft", "make", "create"),
            "place": ("place", "put", "set"),
            "use": ("use", "eat", "drink"),
            "equip": ("equip", "wear", "hold"),
            "follow": ("follow",),
            "communicate": ("say", "report", "tell"),
            "smelt": ("smelt", "cook"),
            "attack": ("kill", "attack", "hunt", "defeat"),
            "container": ("deposit", "withdraw", "store", "retrieve"),
        }
        matches: list[tuple[int, int, str]] = []
        for verb, words in aliases.items():
            for word in words:
                match = re.search(rf"\b{re.escape(word)}\b", normalized, re.I)
                if match:
                    matches.append((match.start(), match.end(), verb))
        if not matches:
            return None
        matches.sort(key=lambda item: (item[0], -(item[1] - item[0])))
        # Keep the first occurrence of each text span; overlapping aliases
        # (e.g. ``get``/``gather``) must not duplicate a step.
        selected: list[tuple[int, int, str]] = []
        for item in matches:
            if selected and item[0] < selected[-1][1]:
                continue
            selected.append(item)
        if len(selected) > 8:
            return None
        number_words = {
            "a": 1, "an": 1, "one": 1, "some": 1, "two": 2, "three": 3,
            "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8,
            "nine": 9, "ten": 10, "stack": 64,
        }
        previous_target: str | None = None
        steps: list[Mapping[str, Any]] = []
        for index, (start, end, verb) in enumerate(selected):
            segment_end = selected[index + 1][0] if index + 1 < len(selected) else len(normalized)
            segment = normalized[end:segment_end].strip(" ,;:")
            segment = re.sub(r"^(?:and\s+then|then|and)\s+", "", segment, flags=re.I)
            segment = re.sub(r"\s+(?:and|then)\s*$", "", segment, flags=re.I)
            pronoun_target = bool(re.match(r"^(?:it|them|that|this|there|here)\b", segment, re.I))
            segment = re.sub(r"^(?:me|my|your|the)\s+", "", segment, flags=re.I)
            count = 1
            stack_match = re.match(r"^(?:a|one)\s+stack(?:\s+of)?\s+", segment, re.I)
            if stack_match:
                count = 64
                segment = segment[stack_match.end():]
            count_match = re.match(r"^(\d+|[a-z]+)\s+", segment, re.I)
            token = count_match.group(1).lower() if count_match else ""
            numeric_token = token.isdigit() and 1 <= int(token) <= 64
            if count == 1 and count_match and (token in number_words or numeric_token):
                count = int(token) if token.isdigit() else number_words[token]
                segment = segment[count_match.end():]
                segment = re.sub(r"^of\s+", "", segment, flags=re.I)
            segment = re.sub(r"^(?:for\s+me|for\s+us)\s+", "", segment, flags=re.I)
            if verb == "craft":
                into = re.search(r"\b(?:into|as)\s+(?:a|an|some|\d+)?\s*([a-z][a-z0-9 _-]*)", segment, re.I)
                if into:
                    segment = into.group(1)
            segment = re.split(r"\b(?:right now|now|please|for me|for us|down)\b", segment, maxsplit=1, flags=re.I)[0]
            target = re.sub(r"\s+", " ", segment).strip(" ,;:")
            if target.lower() in {"it", "them", "that", "this", "there", "here"} and previous_target:
                target = previous_target
            if not target:
                return None
            target = target.replace("-", " ")
            previous_target = target
            steps.append({"id": f"fallback-{index + 1}", "verb": verb, "target": target, "count": max(1, min(64, count)), "parameters": {}})
        requested = cls._requested_verbs(normalized)
        compiled = [str(step["verb"]) for step in steps]
        return steps if requested and compiled == requested else None

    async def _compile_bounded_objective(
        self, objective: Objective, observation: Observation
    ) -> tuple[Plan, dict[str, ActionCommand]] | None:
        self._set_agent_activity(Role.EXECUTIVE, "active", "Interpreting the request into reusable generic skills")
        self.store.set_objective_status(objective.objective_id, "planning", "executive model is compiling the objective")
        self._count_model(objective)
        requested_verbs = self._requested_verbs(objective.text)
        raw = await self.cognition.call(Role.EXECUTIVE, {
            "instruction": (
                "Classify and compile only the explicitly requested effects. "
                "If scope is bounded, steps must use required_step_verbs exactly once in the supplied order."
            ),
            "objective_text": objective.text,
            "available_step_verbs": ["acquire", "collect", "craft", "place", "use", "equip", "follow", "communicate", "smelt", "attack", "container", "trade", "enchant", "brew"],
            "required_step_verbs": requested_verbs,
            "inventory": [{"id": item.get("id"), "count": item.get("count")} for item in observation.inventory],
            "parameter_help": {
                "smelt": "target is the resulting item; parameters.output same item; optional input/fuel/station=furnace|blast_furnace|smoker",
                "attack": "target is an observed mob type; never target a player",
                "container": "target is item; parameters.operation=deposit|withdraw, container=chest|barrel",
                "use": "target is held item; optional parameters.target={x,y,z} block, consume=true for food",
            },
        }, INTENT_SCHEMA)
        model = raw.get("_model", {}) if isinstance(raw.get("_model"), Mapping) else {}
        self._set_agent_activity(
            Role.EXECUTIVE, "idle", str(raw.get("summary", "Objective classified"))[:120],
            str(model.get("model")) if model.get("model") else None,
            float(model["latency_ms"]) if isinstance(model.get("latency_ms"), (int, float)) else None,
        )
        fallback_steps = self._fallback_bounded_steps(objective.text)
        if raw.get("scope") != "bounded":
            if fallback_steps is None:
                return None
            self.store.audit("executive", "Used generic imperative fallback after model chose open-ended scope", {
                "objective_id": objective.objective_id,
                "steps": [dict(step) for step in fallback_steps],
            }, severity="warning")
            steps = fallback_steps
        else:
            steps = raw.get("steps")
            if not isinstance(steps, list) or not steps:
                if fallback_steps is None:
                    raise ValueError("bounded objective compiler returned no steps")
                steps = fallback_steps
        compiled_verbs = [str(item.get("verb", "")).strip().lower() for item in steps if isinstance(item, Mapping)]
        # Small local models can preserve targets/order yet substitute one verb.
        # Reconcile only when there is an exact one-to-one match with verbs
        # literally present in the user's request; this cannot invent work.
        if (requested_verbs and len(compiled_verbs) == len(requested_verbs)
                and compiled_verbs != requested_verbs
                and len({self._namespaced(str(item.get('target', ''))) for item in steps if isinstance(item, Mapping)}) == 1):
            repaired_steps: list[Mapping[str, Any]] = []
            for item, requested_verb in zip(steps, requested_verbs, strict=True):
                if not isinstance(item, Mapping):
                    break
                repaired_steps.append({**dict(item), "verb": requested_verb})
            if len(repaired_steps) == len(steps):
                self.store.audit("executive", "Reconciled compiler verbs to explicit user effects", {
                    "objective_id": objective.objective_id,
                    "model_verbs": compiled_verbs,
                    "requested_verbs": requested_verbs,
                })
                steps = repaired_steps
                compiled_verbs = requested_verbs
        if (len(compiled_verbs) != len(steps)
                or not self._explicitly_requests(objective.text, compiled_verbs)
                or not set(requested_verbs).issubset(compiled_verbs)):
            if fallback_steps is None:
                self.store.audit("executive", "Rejected ungrounded bounded compilation; escalating to hierarchy", {
                    "objective_id": objective.objective_id, "compiled_verbs": compiled_verbs,
                }, severity="warning")
                return None
            steps = fallback_steps
            compiled_verbs = [str(item["verb"]) for item in steps]
            self.store.audit("executive", "Replaced ungrounded bounded compilation with generic imperative fallback", {
                "objective_id": objective.objective_id, "compiled_verbs": compiled_verbs,
            }, severity="warning")
        expanded_steps: list[Mapping[str, Any]] = []
        for value in steps:
            if not isinstance(value, Mapping):
                raise ValueError("compiled step is not an object")
            verb = str(value.get("verb", "")).strip().lower()
            target = str(value.get("target", ""))
            explicit_target = self._explicit_target(objective.text, verb)
            if explicit_target:
                target = explicit_target
                self.store.audit("executive", "Grounded compound-task target", {
                    "objective_id": objective.objective_id,
                    "verb": verb,
                    "target": target,
                })
            targets = self._expand_item_group(target) if verb in {"acquire", "collect", "craft"} else (target,)
            for group_index, target in enumerate(targets):
                expanded = {**dict(value), "target": target}
                if len(targets) > 1:
                    expanded["id"] = f"{str(value.get('id') or 'step')}-{group_index + 1}"
                    expanded["count"] = 1
                expanded_steps.append(expanded)
        steps = expanded_steps
        milestones: list[Milestone] = []
        actions: dict[str, ActionCommand] = {}
        previous_id: str | None = None
        for index, value in enumerate(steps[:8]):
            if not isinstance(value, Mapping):
                raise ValueError("compiled step is not an object")
            verb = str(value.get("verb", "")).strip().lower()
            target = str(value.get("target", "")).strip()
            count = max(1, min(64, int(value.get("count", 1))))
            supplied = value.get("parameters", {})
            parameters = dict(supplied) if isinstance(supplied, Mapping) else {}
            milestone_id = str(value.get("id") or f"step-{index + 1}")
            milestone_id = "".join(character for character in milestone_id if character.isalnum() or character in "-_")[:32] or f"step-{index + 1}"
            if milestone_id in actions:
                milestone_id = f"{milestone_id}-{index + 1}"
            item_id = self._namespaced(target)
            inventory_selector = self._inventory_selector(target)
            before_count = sum(
                int(item.get("count", 0)) for item in observation.inventory
                if isinstance(item, Mapping)
                and self._inventory_selector(str(item.get("id", "")).removeprefix("minecraft:")) == inventory_selector
            )
            if verb == "acquire":
                kind = ActionKind.ACQUIRE
                parameters = {"selector": target, "count": count, **parameters}
                evidence = ({"path": "inventory", "op": "any", "where": {"id_contains": inventory_selector}, "count_gte": before_count + count},)
                deadline = 240_000
            elif verb == "collect":
                kind = ActionKind.COLLECT
                parameters = {"selector": target, "count": count, **parameters}
                evidence = ({"path": "inventory", "op": "any", "where": {"id_contains": inventory_selector}, "count_gte": before_count + count},)
                deadline = 90_000
            elif verb == "craft":
                kind = ActionKind.CRAFT
                parameters = {"recipe": item_id, "count": count, "allow_intermediates": True, **parameters}
                evidence = ({"path": "inventory", "op": "any", "where": {"id": item_id}, "count_gte": count},)
                deadline = 35_000
            elif verb == "place":
                kind = ActionKind.PLACE
                parameters = {"item": item_id, "target": {"semantic": "safe_nearby"}, **parameters}
                evidence = ({"path": "nearby_blocks", "op": "any", "where": {"id": item_id}, "count_gte": 1},)
                deadline = 25_000
            elif verb == "equip":
                kind = ActionKind.EQUIP
                parameters = {"item": item_id, **parameters}
                evidence = ({"path": "player.equipment", "op": "contains", "value": item_id},)
                deadline = 10_000
            elif verb == "use":
                kind = ActionKind.USE
                parameters = {"selector": target, **parameters}
                evidence = ({"path": "sequence", "op": ">", "value": observation.sequence},)
                deadline = 15_000
            elif verb == "follow":
                kind = ActionKind.FOLLOW
                parameters = {"target": "authorized_player", "distance": 2, **parameters}
                evidence = ({"path": "human_players", "op": "exists", "value": True},)
                deadline = 10_000
            elif verb == "communicate":
                kind = ActionKind.COMMUNICATE
                parameters = {"message": target, **parameters}
                evidence = ({"path": "sequence", "op": ">", "value": observation.sequence},)
                deadline = 5_000
            elif verb == "smelt":
                kind = ActionKind.SMELT
                parameters = {"output": item_id, "count": count, **parameters}
                evidence = ({"path": "inventory", "op": "any", "where": {"id": item_id}, "count_gte": before_count + count},)
                deadline = min(180_000, 20_000 + count * 12_000)
            elif verb == "attack":
                kind = ActionKind.ATTACK
                parameters = {"target": target, "until_dead": True, **parameters}
                evidence = ({"path": "player.mobKills", "op": ">=", "value": int(observation.player.get("mobKills", 0)) + count},)
                deadline = 60_000
            elif verb == "container":
                kind = ActionKind.CONTAINER
                parameters = {"item": item_id, "count": count, **parameters}
                operation = str(parameters.get("operation", ""))
                if operation not in {"deposit", "withdraw"}:
                    raise ValueError("container requires deposit or withdraw operation")
                expected = before_count + (count if operation == "withdraw" else -count)
                # Count==0 is expressed by a bounded inventory aggregate, not
                # by list absence which could hide a missing observation.
                evidence = ({"path": "inventory", "op": "count_eq", "where": {"id": item_id}, "value": expected},)
                deadline = 30_000
            elif verb in {"trade", "enchant", "brew"}:
                # These need recipe/offer-specific evidence; use the hierarchy
                # instead of inventing a success condition in the translator.
                return None
            else:
                raise ValueError(f"unsupported compiled verb {verb}")
            command = ActionCommand.create(
                kind, parameters, deadline_ms=deadline, predicted_effects=evidence,
                risk=0.15, plan_step_id=milestone_id,
            )
            actions[milestone_id] = command
            milestones.append(Milestone(
                milestone_id, f"{verb} {target}".strip(), tuple(evidence),
                (previous_id,) if previous_id else (), MilestoneStatus.PENDING,
                priority=len(steps) - index, uncertainty=0.15,
            ))
            previous_id = milestone_id
        plan = Plan(
            str(uuid4()), objective.objective_id, 1,
            datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            "executive model compiled bounded generic action graph", (), tuple(milestones), None,
        )
        self.planner.store.save(plan)
        self._last_decision = {
            "summary": str(raw.get("summary", "Compiled bounded objective")),
            "proposals": [{
                "proposal_id": f"compiled-{node.id}", "role": Role.EXECUTIVE.value,
                "summary": node.description, "choice": {"action": {
                    "kind": actions[node.id].kind.value, "parameters": dict(actions[node.id].parameters),
                }}, "confidence": 0.9, "risk": actions[node.id].risk,
                "estimated_cost": 1.0, "selected": index == 0,
            } for index, node in enumerate(milestones)],
            "rejected": [],
        }
        return plan, actions

    @staticmethod
    def _resume_token(plan: Plan | None) -> str:
        return "no-plan" if plan is None else f"plan:{plan.version}"

    async def _execute_emergency(self, objective: Objective, observation: Observation, belief: Mapping[str, Any], command: ActionCommand, emergency: str) -> None:
        self.store.audit("safety", "Reactive controller preempted plan", {"emergency": emergency, "action": command.to_dict()}, severity="warning")
        try:
            await self._execute_action(objective, self._active_plan, None, observation, belief, command, command.predicted_effects, ())
        except Exception as exc:
            self.store.audit("safety", "Emergency action failed", {"error": str(exc)}, severity="error")

    async def _execute_action(self, objective: Objective, plan: Plan | None, milestone: Milestone | None, observation: Observation,
                              before: Mapping[str, Any], command: ActionCommand, predicted: Sequence[Mapping[str, Any]], alternatives: Any,
                              selected_skill: str | None = None,
                              retrieved_memories: Sequence[Mapping[str, Any]] = ()):
        await self.paused.wait()
        if self.cancelled.is_set():
            raise asyncio.CancelledError
        self.store.increment(objective.objective_id, "action_count")
        provenance = self._action_provenance(observation)
        self.store.begin_action(command.action_id, objective.objective_id, plan.version if plan else None, milestone.id if milestone else None,
                                before, alternatives, predicted, command.to_dict(), provenance)
        self.store.audit("action", "Dispatching atomic action", {
            "kind": command.kind.value, "action_id": command.action_id,
            "controlled_actor_id": provenance.get("controlled_actor_id"),
            "embodiment_mode": provenance.get("embodiment_mode"),
        })
        result = await self.bridge.execute(command, command.deadline_ms / 1000 + 5)
        try:
            after_observation = await self.bridge.wait_observation(observation.sequence, self.config.tick_timeout_seconds)
            world_id = self.bridge.status().world_id or "unknown"
            self.world_model.ingest_observation(world_id, after_observation.to_dict(), f"observation:{after_observation.sequence}")
            after = self.world_model.compact_summary(world_id, after_observation.tick)
        except asyncio.TimeoutError:
            after = before
        comparison = self.world_model.compare_prediction(command.action_id, predicted, result.actual_effects)
        self.world_model.update_causality(command.kind.value, [str(effect.get("path")) for effect in predicted], result.status in {"success", "succeeded"})
        signature = f"{command.kind.value}:{command.parameters}"
        repeated = bool(self._recent_actions and self._recent_actions[-1] == signature)
        previous_error_key = f"prediction_error:{objective.objective_id}:{command.kind.value}"
        previous_error = float(self.store.get_state(previous_error_key, comparison.error))
        self.store.set_state(previous_error_key, comparison.error)
        user_feedback = self._consume_user_feedback()
        reward = self._reward(
            result.to_dict(), previous_error, comparison.error, before, after,
            repeated_action=repeated, user_feedback=user_feedback
        )
        self.store.finish_action(command.action_id, result.to_dict(), after, reward)
        record = {"objective": objective.to_dict(), "subgoal": milestone.description if milestone else f"emergency:{command.kind.value}",
                  "before_state": before, "uncertainty": milestone.uncertainty if milestone else 0,
                  "retrieved_memory_ids": [str(item["memory_id"]) for item in retrieved_memories if item.get("memory_id")],
                  "selected_skill": selected_skill, "alternatives": alternatives,
                  "predicted_result": list(predicted), "executed_action": command.to_dict(), "actual_result": result.to_dict(),
                  "after_state": after, "next_state": after, "reward": reward,
                  "errors_and_recovery": result.error, "recovery": (),
                  "resource_and_time_cost": result.resource_cost,
                  "user_feedback": user_feedback, "verification_result": None,
                  "terminal": False, "achieved_goals": (),
                  "novel_discoveries": list(comparison.surprises),
                  "provenance": provenance, "reward_schema_version": "1.0.0"}
        await _call_optional(self.services.learning, "record", record)
        await _call_optional(self.services.memory, "store_experience", record)
        return result, after, comparison, reward

    async def _execute_skill(self, objective: Objective, plan: Plan, milestone: Milestone, belief: Mapping[str, Any],
                             skill_id: str, parameters: Mapping[str, Any], risk: float):
        self.store.audit("skill", "Executing promoted skill", {"skill_id": skill_id, "milestone_id": milestone.id})
        executor = _SkillAtomicExecutor(self, objective, plan, milestone, skill_id, risk)
        execution = await self.services.skills.execute(skill_id, parameters, belief, executor, self.cancelled)
        self.store.audit("skill", "Promoted skill execution finished", {"skill_id": skill_id, "status": execution.status.value,
                                                                         "actions": execution.actions, "error": execution.error},
                         severity="info" if execution.status.value == "succeeded" else "warning")
        return execution

    def _consume_user_feedback(self) -> float | None:
        value = self._pending_user_feedback
        self._pending_user_feedback = None
        return value

    async def _record_outcome_transition(
        self,
        objective: Objective,
        belief: Mapping[str, Any],
        *,
        outcome: str,
        terminal: bool,
        verified: bool,
        achieved_goals: Sequence[str] = (),
        false_success_claim: bool = False,
        retrieved_memories: Sequence[Mapping[str, Any]] = (),
    ) -> None:
        """Record milestone/task outcomes as real learning transitions, not prose only."""

        user_feedback = self._consume_user_feedback()
        signals = RewardSignals(
            task_progress=1.0 if achieved_goals else 0.0,
            task_completion=terminal and verified and outcome == "succeeded",
            competence_improvement=min(1.0, 0.1 * len(achieved_goals)),
            false_success_claim=false_success_claim,
            user_feedback=user_feedback or 0.0,
        )
        reward = self.reward_calculator.calculate(signals).to_dict()
        reward["total"] = sum(reward.values())
        record = {
            "objective": objective.to_dict(),
            "subgoal": outcome,
            "before_state": dict(belief),
            "next_state": dict(belief),
            "before_uncertainty": {"aggregate": _aggregate_uncertainty(belief)},
            "retrieved_memory_ids": [
                str(item["memory_id"]) for item in retrieved_memories if item.get("memory_id")
            ],
            "selected_skill": None,
            "alternatives": (),
            "predicted_result": {"outcome": outcome},
            "executed_action": {"kind": "task_outcome", "outcome": outcome},
            "actual_result": {
                "status": "verified" if verified else outcome,
                "false_success_claim": false_success_claim,
            },
            "after_state": dict(belief),
            "reward": reward,
            "resource_and_time_cost": {},
            "user_feedback": user_feedback,
            "verification_result": verified,
            "terminal": terminal,
            "achieved_goals": tuple(achieved_goals),
            "novel_discoveries": (),
            "recovery": (),
            "provenance": self._action_provenance(getattr(self.bridge, "latest_observation", None)),
            "reward_schema_version": "1.0.0",
        }
        await _call_optional(self.services.learning, "record", record)
        await _call_optional(self.services.memory, "store_experience", record)

    def _reward(
        self,
        result: Mapping[str, Any],
        prediction_error_before: float,
        prediction_error_after: float,
        before: Mapping[str, Any],
        after: Mapping[str, Any],
        *,
        repeated_action: bool,
        user_feedback: float | None,
    ) -> dict[str, float]:
        succeeded = result.get("status") in {"success", "succeeded"}
        error_value = result.get("error") or {}
        error = error_value if isinstance(error_value, Mapping) else {"message": str(error_value)}
        effects = result.get("actual_effects", []) if isinstance(result.get("actual_effects", []), Sequence) else []
        effect_damage = sum(
            _nonnegative(item.get("amount")) for item in effects
            if isinstance(item, Mapping) and item.get("type") == "damage"
        )
        health_damage = max(0.0, _player_number(before, "health") - _player_number(after, "health"))
        damage = max(effect_damage, health_damage)
        novelty = min(
            1.0,
            len({str(item.get("path")) for item in effects if isinstance(item, Mapping)}) * 0.05,
        )
        information_gain = max(0.0, _aggregate_uncertainty(before) - _aggregate_uncertainty(after))
        resource_costs = result.get("resource_cost", {})
        resources_lost = sum(
            _nonnegative(value) for key, value in resource_costs.items()
            if isinstance(resource_costs, Mapping) and key not in {"time", "time_seconds", "elapsed_seconds"}
        ) if isinstance(resource_costs, Mapping) else 0.0
        competence = sum(
            _nonnegative(item.get("amount", item.get("value", 0)))
            for item in effects
            if isinstance(item, Mapping) and item.get("type") == "competence_improvement"
        )
        died = bool(error.get("code") == "player_died") or (
            _player_number(before, "health") > 0 and _player_number(after, "health") <= 0
        )
        signals = RewardSignals(
            task_progress=0.0,
            novelty=novelty,
            information_gain=information_gain,
            competence_improvement=competence,
            prediction_error_before=prediction_error_before,
            prediction_error_after=prediction_error_after,
            died=died,
            damage=damage,
            resources_lost=resources_lost,
            repeated_action=repeated_action,
            unsafe_action=bool(error.get("code") == "unsafe" or result.get("status") == "safety_stop"),
            unnecessary_actions=int(not succeeded or repeated_action),
            user_feedback=user_feedback or 0.0,
        )
        components = self.reward_calculator.calculate(signals).to_dict()
        components["total"] = sum(components.values())
        return components

    def _action_provenance(self, observation: Observation | None) -> dict[str, Any]:
        provider = getattr(self.bridge, "action_provenance", None)
        if callable(provider):
            value = provider()
            provenance = dict(value) if isinstance(value, Mapping) else {}
        else:
            status = self.bridge.status() if hasattr(self.bridge, "status") else None
            provenance = {
                "world_id": getattr(status, "world_id", None),
                "session_id": getattr(status, "session_id", None),
                "controlled_actor_id": getattr(status, "controlled_actor_id", None),
                "controlled_actor_name": getattr(status, "controlled_actor_name", None),
                "embodiment_mode": getattr(status, "embodiment_mode", "legacy_unspecified"),
                "source": "runtime_adapter",
            }
        if observation is not None:
            provenance.setdefault("observation_sequence", observation.sequence)
            actor = observation.controlled_actor
            provenance.setdefault("controlled_actor_id", actor.get("uuid") or actor.get("id"))
            provenance.setdefault("controlled_actor_name", actor.get("name"))
            provenance.setdefault("embodiment_mode", observation.embodiment.get("mode"))
        provenance["human_control_targeted"] = False
        return provenance

    @staticmethod
    def _command_from_proposal(proposal: AgentProposal, milestone_id: str) -> tuple[ActionCommand, tuple[Mapping[str, Any], ...], Any]:
        choice = proposal.choice
        raw = choice.get("action", choice)
        # Tolerate the common compact local-model spelling
        # {"action":"mine","parameters":{...}} without guessing any task
        # semantics.  Parameters still pass protocol and mod validation.
        if isinstance(raw, str) and isinstance(choice.get("parameters"), Mapping):
            raw = {"kind": raw, "parameters": choice["parameters"]}
        if not isinstance(raw, Mapping) or "kind" not in raw:
            raise ValueError("selected proposal does not contain an atomic action")
        predicted = tuple(choice.get("predicted_effects", proposal.choice.get("effects", ())))
        kind = ActionKind(str(raw["kind"]))
        # Actuator time budgets describe mechanics, never objective solutions.
        # Furnaces and navigation cannot complete under the old 10s default.
        deadlines = {"collect": 90000, "acquire": 300000, "navigate": 45000, "travel": 1200000,
                     "build_portal": 900000,
                     "craft": 45000, "smelt": 180000, "brew": 90000,
                     "attack": 60000, "container": 30000, "place": 25000}
        command = ActionCommand.create(kind, dict(raw.get("parameters", {})),
                                       deadline_ms=deadlines.get(kind.value, 15000),
                                       predicted_effects=predicted, risk=proposal.risk, plan_step_id=milestone_id)
        return command, predicted, choice.get("alternatives", ())

    def _apply_milestone_evidence(
        self, plan: Plan, observation: Mapping[str, Any]
    ) -> tuple[Plan, bool, tuple[str, ...]]:
        changed = False
        achieved: list[str] = []
        while True:
            matched = next((node for node in plan.ready() if EvidenceEvaluator.matches(node.completion_evidence, observation)), None)
            if matched is None:
                break
            plan = self.planner.update_milestone(plan, matched.id, MilestoneStatus.ACHIEVED)
            changed = True
            achieved.append(matched.description)
            self.store.audit("verification", "Milestone evidence matched", {"milestone_id": matched.id, "plan_version": plan.version})
        return plan, changed, tuple(achieved)

    @staticmethod
    def _compact_perception(observation: Observation) -> Mapping[str, Any]:
        """Bound current perception for local-model prompts without hiding targets."""
        blocks = sorted(
            (dict(item) for item in observation.nearby_blocks if isinstance(item, Mapping)),
            key=lambda item: float(item.get("distanceSquared", item.get("distance_squared", 1e9))),
        )
        counts: dict[str, int] = {}
        nearest: dict[str, Mapping[str, Any]] = {}
        for block in blocks:
            block_id = str(block.get("id", "unknown"))
            counts[block_id] = counts.get(block_id, 0) + 1
            nearest.setdefault(block_id, {key: block[key] for key in ("id", "x", "y", "z", "distanceSquared") if key in block})
        player_keys = (
            "name", "uuid", "position", "x", "y", "z", "yaw", "pitch", "health",
            "hunger", "air", "experience", "dimension", "onGround", "on_ground",
            "effects", "equipment", "selectedSlot", "mobKills", "food",
        )
        return {
            "observation_sequence": observation.sequence,
            "tick": observation.tick,
            "player": {key: observation.player[key] for key in player_keys if key in observation.player},
            "inventory": [
                {key: item[key] for key in ("id", "item", "count", "slot", "durability") if key in item}
                for item in observation.inventory[:36]
            ],
            "block_counts": dict(sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:24]),
            "nearest_block_by_type": list(nearest.values())[:24],
            "nearby_entities": [
                {key: item[key] for key in ("id", "entityId", "uuid", "type", "name", "x", "y", "z", "distanceSquared") if key in item}
                for item in observation.nearby_entities[:8]
            ],
            "human_players": [
                {key: item[key] for key in ("id", "uuid", "name", "x", "y", "z", "position", "distanceSquared") if key in item}
                for item in observation.human_players[:4]
            ],
            "environment": {
                key: observation.environment[key]
                for key in ("biome", "dimension", "weather", "time", "light", "isDay", "difficulty")
                if key in observation.environment
            },
            "interfaces": [
                {key: item[key] for key in ("type", "title", "slots") if key in item}
                for item in observation.interfaces[:2]
            ],
        }

    @staticmethod
    def _prompt_belief(belief: Mapping[str, Any]) -> Mapping[str, Any]:
        """Remove database provenance bulk while keeping confidence and uncertainty."""
        # WorldModel.compact_summary publishes `beliefs`. The old adapter read
        # only `facts`, silently giving the strategic planner an empty state.
        facts = belief.get("facts", belief.get("beliefs", {}))
        if not isinstance(facts, Mapping):
            facts = {}
        compact_facts: dict[str, Any] = {}
        for path, raw in list(facts.items())[:96]:
            if isinstance(raw, Mapping):
                value = raw.get("value")
                if path == "player" and isinstance(value, Mapping):
                    value = {key: value[key] for key in ("position", "health", "hunger", "food", "dimension", "equipment") if key in value}
                elif path == "inventory" and isinstance(value, (list, tuple)):
                    value = [{key: item[key] for key in ("id", "count") if key in item}
                             for item in value if isinstance(item, Mapping)]
                compact_facts[str(path)] = {
                    **{key: raw[key] for key in ("confidence", "uncertainty", "kind") if key in raw},
                    "value": value,
                }
            else:
                compact_facts[str(path)] = raw
        result = {
            key: belief[key] for key in ("world_id", "tick", "uncertainty", "summary") if key in belief
        }
        result["facts"] = compact_facts
        predictions = belief.get("predictions", ())
        if isinstance(predictions, Sequence) and not isinstance(predictions, (str, bytes)):
            result["predictions"] = list(predictions[:8])
        return result

    @staticmethod
    def _atomic_action_catalog() -> Mapping[str, Any]:
        """The general embodiment contract, never a high-level task recipe."""
        return {
            "query": "selector=local_state|block|entity",
            "collect": "selector=item/block concept; count=positive integer; navigates, mines, and verifies inventory delta",
            "acquire": "selector=item concept; count=positive integer; recursively resolves recipes, tools, workstations, cooking and block drops",
            "follow": "target=authorized_player; distance?",
            "navigate": "target={x,y,z} or {entity:authorized_player}; range=1",
            "travel": "dimension=overworld|the_nether|the_end; enter an observed active portal and verify the transition",
            "build_portal": "dimension=the_nether; acquire prerequisites, cast a verified frame, clear it, and ignite it",
            "move": "direction=forward|back|left|right|stop; sprint?",
            "look": "yaw=-180..180; pitch=-90..90",
            "jump": "no parameters", "swim": "direction=up|manual",
            "sneak": "enabled=boolean",
            "mine": "target={integer x,y,z}; omit phase to finish one block",
            "break": "target={integer x,y,z}; omit phase to finish one block",
            "place": "item=id; reference={x,y,z} support; face={x,y,z} adjacent unit vector; omit reference for nearby placement",
            "interact": "target={x,y,z} block or {entityId}; operation=sleep|wake optional",
            "attack": "target={entityId} or mob type; until_dead=true; weapon=id optional; protected players excluded",
            "use": "item=id; target={x,y,z} block for ignition/fluid/eye; aim={x,y,z}, hold_ms for projectiles; consume=true for food",
            "defend": "hold_ms=2000 (offhand shield)",
            "inventory": "operation=select_hotbar|swap_slots|drop_item; item=id; count=1",
            "equip": "item=namespaced id", "craft": "recipe=namespaced output id; count=positive integer; registry resolves craftable intermediates",
            "smelt": "output=id; count=1; input/fuel optional; station=furnace|blast_furnace|smoker",
            "trade": "offer=index; count=1; requires observed villager offer and resources",
            "enchant": "item=id; choice=0..2; lapis and experience required",
            "brew": "ingredient=id; fuel=blaze_powder; bottles supplied; changes verified after brewing",
            "container": "operation=deposit|withdraw; container=chest|barrel; item=id; count=1; target={x,y,z} optional",
            "mount": "target=boat|horse; operation=mount|dismount|steer; forward/sideways numbers",
            "respawn": "no parameters",
            "communicate": "message<=256 chars", "cancel": "no parameters",
        }

    async def _critique_plan(self, objective: Objective, plan: Plan, belief: Mapping[str, Any]) -> None:
        self._set_agent_activity(Role.CRITIC, "active", "Checking plan safety and unsupported assumptions")
        self._count_model(objective)
        raw = await self.cognition.call(Role.CRITIC, {"instruction": "Inspect the milestone graph for unsafe, circular, unsupported, or unverifiable claims.",
            "objective": objective.to_dict(), "plan": self.planner.store._encode(plan), "belief": belief})
        metadata = raw.get("_model", {}) if isinstance(raw.get("_model"), Mapping) else {}
        self._set_agent_activity(Role.CRITIC, "idle", str(raw.get("summary", "Plan reviewed"))[:120],
                                 str(metadata.get("model")) if metadata.get("model") else None,
                                 float(metadata["latency_ms"]) if isinstance(metadata.get("latency_ms"), (int, float)) else None)
        self.store.audit("critic", str(raw.get("summary", "Plan reviewed")), {"verdict": raw.get("choice", {}).get("verdict", "unknown")})

    async def _verify_completion(self, objective: Objective, plan: Plan, observation: Observation) -> bool:
        self._set_agent_activity(Role.VERIFIER, "active", "Checking final trusted game-state evidence")
        self._count_model(objective)
        document = observation.to_dict()
        relevant_ids = {
            str(criterion.get("where", {}).get("id"))
            for node in plan.milestones for criterion in node.completion_evidence
            if isinstance(criterion.get("where"), Mapping) and criterion["where"].get("id")
        }
        # Preserve the exact evidence the verifier needs within a small local
        # model's context. Hundreds of terrain blocks previously crowded out
        # the final target and the already verified intermediate milestones.
        evidence = [{
            "source": "server_verifier", "sequence": observation.sequence,
            "inventory": [{"id": item.get("id"), "count": item.get("count")} for item in observation.inventory],
            "nearby_blocks": [block for block in observation.nearby_blocks if block.get("id") in relevant_ids][:8],
            "environment": {key: value for key, value in observation.environment.items()
                            if key in {"dimension", "success_signals"}},
        }, {"verified_milestones": [{
            "description": node.description, "status": node.status.value,
            "completion_evidence": list(node.completion_evidence),
            "holds_now": EvidenceEvaluator.matches(node.completion_evidence, document),
        } for node in plan.milestones]}]
        proposal = await self.orchestrator.verify({
            "objective": objective.text, "objective_id": objective.objective_id,
            "instruction": "Check that the verified steps satisfy the request. Earlier steps may consume their outputs in later steps. Cite current observable evidence for the final effects; do not require consumed intermediate items to remain in inventory.",
        }, evidence)
        trivial_paths = {
            "", "tick", "sequence", "player.alive", "player.onGround", "player.on_ground",
            "player.health", "player.hunger", "controlled_actor", "embodiment",
        }
        substantive = tuple(
            item for item in proposal.evidence
            if isinstance(item, Mapping) and str(item.get("path", "")) not in trivial_paths
        )
        evidence_matches = bool(substantive) and EvidenceEvaluator.matches(substantive, observation.to_dict())
        # A bounded command graph has exact requested effects and each stage
        # was already checked against server state. Crafting then placing an
        # item consumes it: a verifier's redundant inventory predicate must not
        # erase the independently observed crafting and placement transitions.
        # The final effects must still hold now, and the model must independently
        # agree that the graph covers the user's request.
        compiled_graph = plan.reason == "executive model compiled bounded generic action graph"
        if not compiled_graph:
            try:
                compiled_graph = any(
                    revision.reason == "executive model compiled bounded generic action graph"
                    for revision in self.planner.store.revisions(objective.objective_id)
                )
            except (AttributeError, OSError, ValueError):
                compiled_graph = False
        dependencies = {dependency for node in plan.milestones for dependency in node.dependencies}
        final_nodes = [node for node in plan.milestones if node.id not in dependencies]
        verified_graph_effects = (compiled_graph and bool(final_nodes)
            and all(node.status == MilestoneStatus.ACHIEVED for node in plan.milestones))
        evidence_matches = evidence_matches or verified_graph_effects
        verified = bool(proposal.choice.get("verified", False)) and proposal.confidence >= 0.7 and evidence_matches
        self.store.audit("verification", "Final objective verification", {
            "verified": verified, "summary": proposal.summary, "confidence": proposal.confidence,
            "observable_evidence_matches": evidence_matches,
            "verified_graph_effects": verified_graph_effects,
            "proposed_evidence": list(proposal.evidence),
        })
        self._set_agent_activity(Role.VERIFIER, "idle", "Verified objective" if verified else "Rejected unsupported completion claim")
        return verified

    async def _replan(self, objective: Objective, belief: Mapping[str, Any], reason: str, surprises: Sequence[Mapping[str, Any]], memories: Sequence[Mapping[str, Any]], skills: Sequence[Mapping[str, Any]]) -> Plan:
        self._set_agent_activity(Role.STRATEGIC_PLANNER, "active", f"Replanning after: {reason[:80]}")
        self._count_model(objective)
        plan = await self.planner.replan(objective, self._prompt_belief(belief), reason, surprises, memories, skills)
        self.store.increment(objective.objective_id, "replan_count")
        self._active_plan = plan
        self.store.audit("replan", "Plan revised", {"reason": reason, "version": plan.version, "surprises": list(surprises)}, severity="warning")
        self._set_agent_activity(Role.STRATEGIC_PLANNER, "idle", f"Replanned to version {plan.version}")
        return plan

    async def _recall(self, objective: Objective, belief: Mapping[str, Any]) -> list[Mapping[str, Any]]:
        self._set_agent_activity(Role.MEMORY_LIBRARIAN, "active", f"Retrieving experience for: {objective.text[:70]}")
        result = await _call_optional(self.services.memory, "retrieve", {"objective": objective.text, "belief": belief}, limit=8, default=[])
        compact: list[Mapping[str, Any]] = []
        for item in list(result or [])[:6]:
            if not isinstance(item, Mapping):
                continue
            payload = item.get("payload", {})
            selected_payload: dict[str, Any] = {}
            if isinstance(payload, Mapping):
                for key in (
                    "objective", "subgoal", "executed_action", "actual_result",
                    "verification_result", "reward", "errors", "recovery",
                ):
                    if key in payload:
                        selected_payload[key] = payload[key]
            compact.append({
                key: item[key] for key in (
                    "memory_id", "kind", "summary", "confidence", "uncertainty",
                    "status", "score", "authority",
                ) if key in item
            } | {"payload": selected_payload})
        self._set_agent_activity(Role.MEMORY_LIBRARIAN, "idle", f"Retrieved {len(compact)} relevant memories")
        return compact

    async def _skills(self, belief: Mapping[str, Any]) -> list[Mapping[str, Any]]:
        self._set_agent_activity(Role.SKILL_INVENTOR, "active", "Checking reusable promoted skills")
        result = await _call_optional(self.services.skills, "applicable", belief, default=[])
        allowed = {
            "skill_id", "id", "name", "purpose", "applicability", "parameters",
            "preconditions", "expected_effects", "confidence", "known_failure_cases",
            "dependencies", "version", "status",
        }
        compact = [
            {str(key): value for key, value in item.items() if str(key) in allowed}
            for item in list(result or [])[:8] if isinstance(item, Mapping)
        ]
        self._set_agent_activity(Role.SKILL_INVENTOR, "idle", f"Found {len(compact)} applicable skills")
        return compact

    def _schedule_skill_gap(self, objective: Objective, milestone: Milestone, failures: Sequence[Mapping[str, Any]]) -> None:
        if self.services.skills is None:
            return
        task = asyncio.create_task(_call_optional(self.services.skills, "propose_for_gap", {"objective": objective.to_dict(), "milestone": asdict(milestone), "failures": list(failures)}))
        self._background.add(task)
        task.add_done_callback(self._skill_task_done)

    def _skill_task_done(self, task: asyncio.Task[Any]) -> None:
        self._background.discard(task)
        try:
            result = task.result()
            self.store.audit("skill", "Capability-gap proposal completed", dict(result or {}))
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self.store.audit("skill", "Capability-gap proposal failed", {"error": str(exc)}, severity="warning")

    async def _reflect(self, objective: Objective, outcome: str, belief: Mapping[str, Any]) -> None:
        try:
            self._set_agent_activity(Role.LEARNING, "active", f"Consolidating {outcome} trajectory")
            self._count_model(objective)
            reflection = await self.cognition.call(Role.LEARNING, {"instruction": "Produce concise post-task consolidation: worked, failed, wrong assumptions, generalizable knowledge, skill changes, retained memories, and targeted practice.",
                "objective": objective.to_dict(), "outcome": outcome, "final_belief": belief,
                "recent_activity": self.store.recent_activity(30)})
            await _call_optional(self.services.memory, "consolidate_task", objective.to_dict(), outcome, reflection)
            await _call_optional(self.services.learning, "finish_task", objective.to_dict(), outcome, reflection)
            self.store.audit("learning", "Post-task reflection completed", {"summary": reflection.get("summary", "")})
            self._set_agent_activity(Role.LEARNING, "idle", str(reflection.get("summary", "Trajectory consolidated"))[:120])
        except Exception as exc:
            self._set_agent_activity(Role.LEARNING, "idle", "Reflection deferred")
            self.store.audit("learning", "Post-task reflection failed", {"error": str(exc)}, severity="warning")

    async def _communicate(self, message: str) -> None:
        if not self.bridge.status().session_id:
            return
        command = ActionCommand.create(ActionKind.COMMUNICATE, {"message": message}, deadline_ms=2_000)
        try:
            await self.bridge.execute(command, 5)
        except Exception as exc:
            self.store.audit("communication", "Could not send in-game status", {"error": str(exc)}, severity="warning")

    def snapshot(self) -> dict[str, Any]:
        stored = (self.store.objective_status(self._active_objective.objective_id)
                  if self._active_objective else self.store.latest_objective_status())
        objective = ({key: stored.get(key) for key in (
            "objective_id", "text", "requested_by", "status", "reason", "created_at",
            "started_at", "finished_at", "action_count", "model_call_count", "replan_count",
        )} if stored else None)
        plan = self._active_plan or (self.planner.store.active(str(objective["objective_id"])) if objective else None)
        bridge_status = asdict(self.bridge.status())
        world = {}
        if bridge_status.get("world_id") and self.bridge.latest_observation:
            world = self.world_model.compact_summary(str(bridge_status["world_id"]), self.bridge.latest_observation.tick)
        evaluation = evaluation_status(self.config, self.store)
        training = training_status(self.config, self.store)
        objective_state = str(objective.get("status", "")).lower() if objective else ""
        execution = self.store.get_state("execution_progress", {})
        if objective_state not in {
            "queued", "planning", "running", "executing", "verifying",
            "paused", "waiting_for_model", "waiting_for_world",
        }:
            execution = {}
        return {
            "protocolVersion": "1.0", "generatedAt": datetime.now(timezone.utc).isoformat(),
            "build": {
                "id": os.environ.get("MINEMIND_BUILD_ID", "development"),
                "minecraft": os.environ.get("MINEMIND_MINECRAFT_VERSION", "unknown"),
                "executor": os.environ.get("MINEMIND_EXECUTOR_NAME", "unknown"),
                "dedicatedClient": "connected" if bool(bridge_status.get("bot_ready")) else "disconnected",
                "planner": "connected",
                "llm": "connected" if not self.config.deterministic else "deterministic-test-mode",
            },
            "mode": "deterministic" if self.config.deterministic else "live",
            "connection": bridge_status, "objective": objective,
            "actors": self._actor_snapshot(),
            "milestones": [asdict(node) for node in plan.milestones] if plan else [], "world": world,
            "agents": [{
                "role": role.value,
                "model": self._agent_activity.get(role.value, {}).get("model", spec.model_selector),
                "status": self._agent_activity.get(role.value, {}).get("status", "idle"),
                "currentTask": self._agent_activity.get(role.value, {}).get("currentTask", "Ready"),
                "latencyMs": self._agent_activity.get(role.value, {}).get("latencyMs"),
            } for role, spec in self.orchestrator.roles.items()],
            "proposals": list(self._last_decision.get("proposals", [])), "activity": self.store.recent_activity(40),
            "execution": execution,
            "skills": (self.services.skills.status().get("active", []) if self.services.skills and hasattr(self.services.skills, "status") else []),
            "memory": {"status": "connected" if self.services.memory else "unavailable"},
            "learning": {"status": "connected" if self.services.learning else "unavailable", **self.store.dashboard_counts(),
                         **(self.services.learning.status() if self.services.learning and hasattr(self.services.learning, "status") else {})},
            "benchmarks": evaluation["benchmarks"], "evaluation": evaluation,
            "training": training, "capability_gaps": capability_gaps(self.bridge, self.services),
            "compute": {}, "safety": {"paused": not self.paused.is_set(), "recent": [item for item in self.store.recent_activity(20) if item["category"] == "safety"]},
        }

    def _actor_snapshot(self) -> dict[str, Any]:
        observation = self.bridge.latest_observation
        status = self.bridge.status()
        if observation is None:
            return {
                "controlled": {
                    "role": "minemind_ai",
                    "id": getattr(status, "controlled_actor_id", None),
                    "name": getattr(status, "controlled_actor_name", None) or "MineMind",
                    "ready": bool(getattr(status, "bot_ready", False)),
                },
                "humans": [],
                "embodiment": {
                    "mode": getattr(status, "embodiment_mode", "legacy_unspecified"),
                    "status": getattr(status, "embodiment_status", "unknown"),
                    "humanControlPossible": getattr(status, "human_control_possible", True),
                },
            }
        actor = {
            **dict(observation.controlled_actor),
            "role": "minemind_ai",
            "ready": bool(getattr(status, "bot_ready", False)),
            "state": dict(observation.player),
            "inventory": [dict(item) for item in observation.inventory],
        }
        return {
            "controlled": actor,
            "humans": [dict(item) for item in observation.human_players],
            "embodiment": dict(observation.embodiment),
        }
