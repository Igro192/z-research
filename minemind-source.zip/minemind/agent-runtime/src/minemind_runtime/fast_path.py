from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any, Mapping

from minemind_protocol import ActionCommand, ActionKind, Observation


_NUMBER_WORDS = {
    "a": 1, "an": 1, "one": 1, "some": 1, "couple": 2, "two": 2,
    "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8,
}


@dataclass(slots=True, frozen=True)
class DirectSkill:
    skill_id: str
    command: ActionCommand
    completion: Mapping[str, Any]


def _count(value: str | None) -> int:
    if not value:
        return 1
    if value.isdigit():
        return max(1, min(64, int(value)))
    return _NUMBER_WORDS.get(value.lower(), 1)


def compile_direct_skill(text: str, objective_id: str, observation: Observation) -> DirectSkill | None:
    """Compile a single generic skill call; never decompose complex objectives.

    This is deliberately vocabulary-level and registry-driven. It cannot encode
    a Minecraft walkthrough and returns ``None`` as soon as sequencing or an
    ambiguous long-horizon request is present.
    """

    normalized = re.sub(r"^@mind\s+", "", text.strip(), flags=re.I)
    normalized = re.sub(r"[.!?]+$", "", normalized)
    match = re.fullmatch(
        r"(?:please\s+)?(?:get|collect|gather|obtain|fetch|mine|harvest)\s+"
        r"(?:(\d+|a|an|one|some|couple|two|three|four|five|six|seven|eight)\s+)?(.+?)",
        normalized,
        flags=re.I,
    )
    if match:
        selector = re.sub(r"\b(?:block|blocks|item|items)\b", "", match.group(2), flags=re.I)
        selector = re.sub(r"\s+", " ", selector).strip()
        if selector and not re.search(r"\b(?:and|then|after|before|until|while|armor|shelter|house|portal)\b", selector, re.I):
            count = _count(match.group(1))
            command = ActionCommand.create(
                # A direct collection request is represented as COLLECT for
                # compatibility with the generic skill contract.  The
                # dedicated AutoClef adapter intentionally maps both COLLECT
                # and ACQUIRE through its catalogue, so this does not weaken
                # the executor or introduce a task-specific handler.
                ActionKind.COLLECT,
                {"selector": selector, "count": count, "max_distance": 64},
                deadline_ms=90_000,
                objective_id=objective_id,
                actor_id="minemind_player",
                before_state_revision=observation.sequence,
                expected_postconditions=({"path": "inventory.count", "op": "delta_gte", "value": count},),
                predicted_effects=({"path": "inventory.count", "delta": count},),
                plan_step_id="direct:collect",
            )
            return DirectSkill("builtin.generic.collect", command, {"inventory_delta_gte": count})

    if re.fullmatch(r"(?:please\s+)?follow\s+(?:me|the player)", normalized, flags=re.I):
        command = ActionCommand.create(
            ActionKind.FOLLOW, {"target": "authorized_player", "distance": 2},
            deadline_ms=5_000, objective_id=objective_id, actor_id="minemind_player",
            before_state_revision=observation.sequence, plan_step_id="direct:follow",
        )
        return DirectSkill("builtin.generic.follow", command, {"actuator_status": "succeeded"})

    if re.fullmatch(r"(?:please\s+)?(?:come here|come to me)", normalized, flags=re.I):
        command = ActionCommand.create(
            ActionKind.NAVIGATE, {"target": {"entity": "authorized_player"}, "range": 2},
            deadline_ms=30_000, objective_id=objective_id, actor_id="minemind_player",
            before_state_revision=observation.sequence, plan_step_id="direct:come_here",
        )
        return DirectSkill("builtin.generic.navigate_to_entity", command, {"actuator_status": "succeeded"})
    return None


def direct_postcondition_met(skill: DirectSkill, result: Mapping[str, Any]) -> bool:
    if str(result.get("status", "")).lower() not in {"success", "succeeded"}:
        return False
    required = skill.completion.get("inventory_delta_gte")
    if required is None:
        return True
    for effect in result.get("actual_effects", ()):
        if isinstance(effect, Mapping) and effect.get("path") == "inventory.count":
            delta = effect.get("delta")
            return isinstance(delta, (int, float)) and not isinstance(delta, bool) and delta >= required
    return False
