from __future__ import annotations

import asyncio
from dataclasses import dataclass
import logging
from pathlib import Path
import signal
from typing import Any

from minemind_model_router import ModelRouter
from minemind_orchestrator import CognitiveOrchestrator, Role
from minemind_planner import HierarchicalPlanner, PlanStore
from minemind_world_model import WorldModel

from .api import ApiServer
from .bridge import BridgeServer
from .cognition import DeterministicCognition, ModelCognition
from .config import RuntimeConfig
from .loop import AgentLoop, RuntimeServices
from .integrations import build_default_services
from .http_bridge import HttpBridgeClient
from .hybrid_bridge import HybridBridge
from .store import RuntimeStore


class RuntimeApplication:
    def __init__(self, config: RuntimeConfig, services: RuntimeServices | None = None) -> None:
        self.config = config
        config.data_dir.mkdir(parents=True, exist_ok=True)
        database = config.data_dir / "minemind.db"
        self.store = RuntimeStore(database)
        self.router = ModelRouter(config.endpoints, max_concurrent=config.max_concurrent_model_calls)
        self.cognition = DeterministicCognition() if config.deterministic else ModelCognition(self.router, config.role_selectors)
        async def propose(role: str, context: dict[str, Any]):
            return await self.cognition.call(role, context)
        async def invoke(role: Role, context: dict[str, Any]):
            return await self.cognition.call(role, context)
        self.world_model = WorldModel(database)
        self.planner = HierarchicalPlanner(propose, PlanStore(database))
        self.orchestrator = CognitiveOrchestrator(
            invoke,
            max_concurrent=config.max_concurrent_model_calls,
            economy_mode=config.max_concurrent_model_calls == 1,
        )
        for role, selector in config.role_selectors.items():
            try:
                self.orchestrator.roles[Role(role)] = type(self.orchestrator.roles[Role(role)])(Role(role), selector)
            except ValueError:
                self.store.audit("config", "Ignored unknown role selector", {"role": role}, severity="warning")
        if config.bridge.transport == "http":
            self.bridge = HttpBridgeClient(
                config.bridge.host, config.bridge.port, self.store,
                config.bridge_token, config.bridge.token_file,
            )
        else:
            actuator = BridgeServer(config.bridge.host, config.bridge.port, self.store, config.bridge_token)
            if config.verifier is None:
                self.bridge = actuator
            else:
                verifier = HttpBridgeClient(
                    config.verifier.host, config.verifier.port, self.store,
                    token_file=config.verifier.token_file,
                )
                self.bridge = HybridBridge(actuator, verifier)
        self.services = services or build_default_services(str(database), self.cognition)
        self.loop = AgentLoop(config, self.store, self.bridge, self.world_model, self.planner, self.orchestrator, self.cognition, self.services)
        self.api = ApiServer(config.api.host, config.api.port, self.loop, self.bridge, self.store, self.router.status)
        self._loop_task: asyncio.Task[Any] | None = None
        self._training_task: asyncio.Task[Any] | None = None
        self._closed = False

    async def start(self) -> None:
        await self.bridge.start()
        await self.api.start()
        self._loop_task = asyncio.create_task(self.loop.run(), name="agent-loop")
        self.store.audit("runtime", "MineMind runtime started", {"bridge": f"{self.config.bridge.host}:{self.config.bridge.port}", "api": f"{self.config.api.host}:{self.config.api.port}"})
        if not self.config.deterministic:
            await self.router.discover()
        # Interactive packages deliberately ship with training.enabled=false.
        # The previous unconditional worker ignored that setting and created a
        # challenger checkpoint every 30 seconds while Minecraft was running,
        # competing with the game and Ollama on memory-constrained machines.
        if (
            bool(self.config.training.get("enabled", False))
            and self.services.learning
            and hasattr(self.services.learning, "train_if_ready")
        ):
            self._training_task = asyncio.create_task(self._training_worker(), name="offline-learning-worker")

    async def stop(self) -> None:
        if self._closed:
            return
        await self.loop.stop()
        if self._training_task:
            await asyncio.gather(self._training_task, return_exceptions=True)
        if self._loop_task:
            self._loop_task.cancel()
            await asyncio.gather(self._loop_task, return_exceptions=True)
        await self.api.stop()
        await self.bridge.stop()
        for resource in (
            self.services.memory,
            self.services.skills,
            self.services.learning,
            self.services.evaluation,
            self.services.training,
            self.world_model,
            self.planner.store,
        ):
            close = getattr(resource, "close", None)
            if close:
                try:
                    close()
                except Exception as error:
                    self.store.audit("shutdown", "Resource close failed", {"resource": type(resource).__name__, "error": str(error)}, severity="warning")
        self.store.close()
        self._closed = True

    async def _training_worker(self) -> None:
        while not self.loop.stopping.is_set():
            try:
                result = await self.services.learning.train_if_ready()
                if result:
                    self.store.audit("training", "Created evaluated-pending challenger checkpoint", result)
            except Exception as exc:
                self.store.audit("training", "Offline learner iteration failed", {"error": str(exc)}, severity="warning")
            try:
                await asyncio.wait_for(self.loop.stopping.wait(), timeout=30)
            except asyncio.TimeoutError:
                pass

    async def run_until_stopped(self) -> None:
        await self.start()
        stopped = asyncio.Event()
        active_loop = asyncio.get_running_loop()
        for signum in (signal.SIGINT, signal.SIGTERM):
            try:
                active_loop.add_signal_handler(signum, stopped.set)
            except NotImplementedError:
                pass
        await stopped.wait()
        await self.stop()
