from __future__ import annotations

from dataclasses import dataclass, field
import os
from pathlib import Path
import tomllib
import json
from typing import Any, Mapping

from minemind_model_router import Endpoint


@dataclass(slots=True, frozen=True)
class Address:
    host: str
    port: int


@dataclass(slots=True, frozen=True)
class BridgeConfig:
    host: str
    port: int
    transport: str = "http"
    token_file: Path | None = None


@dataclass(slots=True, frozen=True)
class VerifierConfig:
    host: str
    port: int
    token_file: Path | None = None


@dataclass(slots=True, frozen=True)
class Budgets:
    max_actions_per_objective: int = 10_000
    max_model_calls_per_objective: int = 2_000
    max_wall_seconds_per_objective: int = 21_600
    max_storage_mb: int = 4_096
    confirmation_risk_threshold: float = 0.8


@dataclass(slots=True, frozen=True)
class SafetyConfig:
    authorized_players: tuple[str, ...] = ()
    protected_players: tuple[str, ...] = ()
    protected_entities: tuple[str, ...] = ()
    protected_items: tuple[str, ...] = ()
    protected_blocks: tuple[str, ...] = ()
    protected_regions: tuple[Mapping[str, Any], ...] = ()
    require_confirmation_for: tuple[str, ...] = ()
    accept_objectives_from: tuple[str, ...] = ("authorized_chat", "dashboard")


@dataclass(slots=True, frozen=True)
class RuntimeConfig:
    root: Path
    data_dir: Path
    log_level: str
    deterministic: bool
    tick_timeout_seconds: float
    max_concurrent_model_calls: int
    bridge: BridgeConfig
    api: Address
    bridge_token: str | None
    budgets: Budgets
    endpoints: tuple[Endpoint, ...]
    role_selectors: Mapping[str, str]
    safety: SafetyConfig
    training: Mapping[str, Any] = field(default_factory=dict)
    evaluation: Mapping[str, Any] = field(default_factory=dict)
    verifier: VerifierConfig | None = None


def _resolve(root: Path, value: str) -> Path:
    path = Path(value).expanduser()
    return path if path.is_absolute() else root / path


def load_config(path: str | Path) -> RuntimeConfig:
    config_path = Path(path).resolve()
    with config_path.open("rb") as stream:
        raw = tomllib.load(stream)
    root = config_path.parent.parent
    runtime = raw.get("runtime", {})
    bridge = raw.get("bridge", {})
    verifier = raw.get("verifier", {})
    api = raw.get("api", {})
    model_config = raw.get("models", {})
    endpoint_values = model_config.get("endpoints", [])
    endpoints: list[Endpoint] = []
    for value in endpoint_values:
        secret = os.getenv(str(value.get("api_key_env", ""))) or None
        endpoints.append(Endpoint(
            id=str(value["id"]), kind=str(value.get("kind", "openai_compatible")),
            base_url=str(value["base_url"]).rstrip("/"), priority=int(value.get("priority", 100)),
            api_key=secret, max_concurrency=int(value.get("max_concurrency", 1)),
            timeout_seconds=float(value.get("timeout_seconds", model_config.get("request_timeout_seconds", 90))),
        ))
    if not endpoints:
        raise ValueError("configuration requires at least one model endpoint")
    budget_values = raw.get("budgets", {})
    budgets = Budgets(**{key: budget_values[key] for key in Budgets.__dataclass_fields__ if key in budget_values})
    if not 0 <= budgets.confirmation_risk_threshold <= 1:
        raise ValueError("confirmation risk threshold must be a probability")
    safety_values = raw.get("safety", {})
    safety = SafetyConfig(
        authorized_players=tuple(map(str, safety_values.get("authorized_players", ()))),
        protected_players=tuple(map(str, safety_values.get("protected_players", ()))),
        protected_entities=tuple(map(str, safety_values.get("protected_entities", ()))),
        protected_items=tuple(map(str, safety_values.get("protected_items", ()))),
        protected_blocks=tuple(map(str, safety_values.get("protected_blocks", ()))),
        protected_regions=tuple(safety_values.get("protected_regions", ())),
        require_confirmation_for=tuple(map(str, safety_values.get("require_confirmation_for", ()))),
        accept_objectives_from=tuple(map(str, safety_values.get("accept_objectives_from", ()))),
    )
    token_env = str(bridge.get("shared_token_env", "MINEMIND_BRIDGE_TOKEN"))
    api_host = str(api.get("host", "127.0.0.1"))
    if api_host not in {"127.0.0.1", "::1", "localhost"} and os.getenv("MINEMIND_ALLOW_REMOTE_API") != "1":
        raise ValueError("refusing non-loopback API bind; set MINEMIND_ALLOW_REMOTE_API=1 only with an external auth proxy")
    transport = str(bridge.get("transport", "http")).lower()
    if transport not in {"http", "websocket"}:
        raise ValueError("bridge.transport must be http or websocket")
    token_file_value = str(bridge.get("token_file", "")).strip()
    token_file = _resolve(root, token_file_value) if token_file_value else None
    configured_token = os.getenv(token_env) or None
    if configured_token is None and token_file and token_file.is_file():
        try:
            token_payload = json.loads(token_file.read_text(encoding="utf-8"))
            configured_token = str(token_payload.get("authenticationToken") or "") or None
        except (OSError, ValueError, TypeError):
            configured_token = None
    verifier_token_value = str(verifier.get("token_file", "")).strip()
    verifier_token_file = _resolve(root, verifier_token_value) if verifier_token_value else None
    verifier_config = None
    if transport == "websocket" and bool(verifier.get("enabled", False)):
        verifier_host = str(verifier.get("host", "127.0.0.1"))
        if verifier_host not in {"127.0.0.1", "::1", "localhost"}:
            raise ValueError("verifier.host must be loopback")
        verifier_config = VerifierConfig(verifier_host, int(verifier.get("port", 8767)), verifier_token_file)
    return RuntimeConfig(
        root=root, data_dir=_resolve(root, str(runtime.get("data_dir", "data"))),
        log_level=str(runtime.get("log_level", "INFO")), deterministic=bool(runtime.get("deterministic", False)),
        tick_timeout_seconds=float(runtime.get("tick_timeout_seconds", 30)),
        # One in-flight generation is the safe default for unified-memory
        # laptops. Larger machines can opt into concurrency explicitly.
        max_concurrent_model_calls=int(runtime.get("max_concurrent_model_calls", 1)),
        bridge=BridgeConfig(str(bridge.get("host", "127.0.0.1")), int(bridge.get("port", 8765)), transport, token_file),
        api=Address(api_host, int(api.get("port", 8080))),
        bridge_token=configured_token, budgets=budgets, endpoints=tuple(endpoints),
        role_selectors={str(k): str(v) for k, v in raw.get("roles", {}).items()}, safety=safety,
        training=dict(raw.get("training", {})),
        evaluation=dict(raw.get("evaluation", {})),
        verifier=verifier_config,
    )
