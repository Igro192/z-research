from __future__ import annotations

import asyncio
from dataclasses import asdict
import json
import time
from typing import Any, Mapping, Sequence

from minemind_learning_system import (
    CheckpointManager,
    ContextualBandit,
    LearningCoordinator,
    LinearValueModel,
    OfflineTrainer,
    PrioritizedReplayBuffer,
    Transition,
)
from minemind_memory_system import DeletionScope, EpistemicStatus, MemoryInput, MemoryKind, MemoryStore, Provenance
from minemind_orchestrator import Role
from minemind_protocol import ActionKind, Objective
from minemind_skill_engine import (
    IsolatedEvaluationAuthority,
    SkillEvaluationQueue,
    SkillLifecycle,
    SkillManifest,
    SkillRegistry,
    SkillRuntime,
    SkillStore,
)


def state_features(state: Mapping[str, Any]) -> tuple[float, ...]:
    beliefs = state.get("beliefs", {}) if isinstance(state, Mapping) else {}
    player_wrapper = beliefs.get("player", {}) if isinstance(beliefs, Mapping) else {}
    player = player_wrapper.get("value", player_wrapper) if isinstance(player_wrapper, Mapping) else {}
    inventory_wrapper = beliefs.get("inventory", {}) if isinstance(beliefs, Mapping) else {}
    inventory = inventory_wrapper.get("value", inventory_wrapper) if isinstance(inventory_wrapper, Mapping) else []
    entities = state.get("nearby_entity_predictions", []) if isinstance(state, Mapping) else []
    uncertainty_values = [float(item.get("uncertainty", 1)) for item in beliefs.values() if isinstance(item, Mapping)] if isinstance(beliefs, Mapping) else [1]
    return (
        float(player.get("health", 0)) / 20.0 if isinstance(player, Mapping) else 0.0,
        float(player.get("hunger", 0)) / 20.0 if isinstance(player, Mapping) else 0.0,
        float(player.get("air", 0)) / 300.0 if isinstance(player, Mapping) else 0.0,
        min(1.0, len(inventory) / 36.0) if isinstance(inventory, Sequence) else 0.0,
        min(1.0, len(entities) / 16.0) if isinstance(entities, Sequence) else 0.0,
        float(state.get("tick", 0) % 24_000) / 24_000.0 if isinstance(state, Mapping) else 0.0,
        sum(uncertainty_values) / max(1, len(uncertainty_values)),
        1.0,
    )


class MemoryService:
    def __init__(self, database: str) -> None:
        self.store = MemoryStore(database)

    def retrieve(self, context: Mapping[str, Any], *, limit: int = 8) -> list[dict[str, Any]]:
        query = str(context.get("objective", ""))
        belief = context.get("belief", {})
        world_id = str(belief.get("world_id")) if isinstance(belief, Mapping) and belief.get("world_id") else None
        found = self.store.retrieve(query, world_id=world_id, limit=limit)
        return [{
            "memory_id": item.record.memory_id, "kind": item.record.item.kind.value,
            "text": item.record.item.text, "payload": dict(item.record.item.payload),
            "confidence": item.record.item.confidence, "uncertainty": item.record.item.uncertainty,
            "epistemic_status": item.record.item.status.value, "score": item.score,
            "instruction_authority": item.record.instruction_authority,
            "provenance": asdict(item.record.item.provenance),
        } for item in found]

    def inspect(self, query: str, *, limit: int = 50) -> list[dict[str, Any]]:
        return self.retrieve({"objective": query}, limit=max(1, min(200, limit)))

    def export(self, destination: str, scope: Mapping[str, Any]) -> int:
        return self.store.export_jsonl(destination, _deletion_scope(scope, default_all=True))

    def delete(self, scope: Mapping[str, Any]) -> int:
        return self.store.delete(_deletion_scope(scope, default_all=False))

    def store_experience(self, record: Mapping[str, Any]) -> str:
        objective = record.get("objective", {})
        world_id = record.get("before_state", {}).get("world_id") if isinstance(record.get("before_state"), Mapping) else None
        provenance = record.get("provenance", {})
        provenance = provenance if isinstance(provenance, Mapping) else {}
        item = MemoryInput(
            kind=MemoryKind.EPISODIC,
            text=f"{objective.get('text', '')}: {record.get('subgoal', '')}", payload=dict(record),
            provenance=Provenance(
                "runtime_transition",
                str(record.get("executed_action", {}).get("action_id", "unknown")),
                time.time(),
                actor=str(provenance.get("controlled_actor_id") or "unknown-minemind-actor"),
                trust=1.0 if provenance.get("human_control_targeted") is False else 0.0,
            ),
            status=EpistemicStatus.OBSERVED, confidence=1.0, uncertainty=0.0, salience=0.7,
            world_id=world_id, objective_id=objective.get("objective_id"), tags=("transition",),
        )
        return self.store.remember(item).memory_id

    def consolidate_task(self, objective: Mapping[str, Any], outcome: str, reflection: Mapping[str, Any]) -> str:
        item = MemoryInput(
            kind=MemoryKind.AUTOBIOGRAPHICAL, text=f"{objective.get('text', '')} -> {outcome}",
            payload={"objective": dict(objective), "outcome": outcome, "reflection": dict(reflection)},
            provenance=Provenance("task_reflection", str(objective.get("objective_id", "unknown")), time.time()),
            status=EpistemicStatus.INFERRED, confidence=float(reflection.get("confidence", 0.6)), uncertainty=0.4,
            salience=0.9, objective_id=objective.get("objective_id"), tags=("reflection", outcome),
        )
        return self.store.remember(item).memory_id

    def close(self) -> None:
        self.store.close()


class LearningService:
    def __init__(self, database: str, dimensions: int = 8) -> None:
        self.replay = PrioritizedReplayBuffer(database)
        self.bandit = ContextualBandit(dimensions)
        self.value = LinearValueModel(dimensions)
        self.coordinator = LearningCoordinator(self.replay, self.bandit, self.value)
        self.offline = OfflineTrainer(self.replay, self.value, state_features)
        self.checkpoints = CheckpointManager(database)
        self.updates = 0
        self.last_update: Mapping[str, Any] = {}
        self.last_checkpoint_id: str | None = None

    def record(self, record: Mapping[str, Any]) -> Mapping[str, Any]:
        before = dict(record.get("before_state", {}))
        after = dict(record.get("next_state") or record.get("after_state") or before)
        reward = {str(k): float(v) for k, v in record.get("reward", {}).items() if k != "total"}
        result = record.get("actual_result", {})
        error = result.get("error") if isinstance(result, Mapping) else None
        costs = record.get("resource_and_time_cost", {})
        costs = costs if isinstance(costs, Mapping) else {}
        time_cost = sum(
            float(value) for key, value in costs.items()
            if key in {"time", "time_seconds", "elapsed_seconds"}
            and isinstance(value, (int, float)) and not isinstance(value, bool)
        )
        resource_cost = sum(
            float(value) for key, value in costs.items()
            if key not in {"time", "time_seconds", "elapsed_seconds"}
            and isinstance(value, (int, float)) and not isinstance(value, bool)
        )
        transition = Transition(
            objective=str(record.get("objective", {}).get("text", "")), subgoal=str(record.get("subgoal", "")),
            before_state=before, before_uncertainty={"aggregate": state_features(before)[6]},
            retrieved_memory_ids=tuple(str(item) for item in record.get("retrieved_memory_ids", ())),
            selected_skill=record.get("selected_skill"),
            proposed_alternatives=tuple(json.dumps(item, sort_keys=True, default=str) for item in record.get("alternatives", ())),
            predicted_result={"effects": list(record.get("predicted_result", ()))},
            action=dict(record.get("executed_action", {})), actual_result=dict(result), reward_components=reward,
            next_state=after, terminal=bool(record.get("terminal", False)), achieved_goals=tuple(record.get("achieved_goals", ())),
            errors=(() if not error else (str(error),)), recovery=tuple(record.get("recovery", ())),
            resource_cost=resource_cost,
            time_cost_seconds=time_cost,
            user_feedback=record.get("user_feedback"), verification_result=record.get("verification_result"),
            novel_discoveries=tuple(map(str, record.get("novel_discoveries", ()))),
            provenance=dict(record.get("provenance", {})) if isinstance(record.get("provenance"), Mapping) else {},
            reward_schema_version=str(record.get("reward_schema_version", "legacy_unspecified")),
        )
        update = self.coordinator.learn_transition(transition, state_features(before), state_features(after))
        self.updates += 1
        self.last_update = asdict(update)
        return self.last_update

    def finish_task(self, objective: Mapping[str, Any], outcome: str, reflection: Mapping[str, Any]) -> None:
        # Task-level consolidation is retained in memory. Learning promotion still
        # requires benchmark evaluation and is never inferred from reflection text.
        self.last_update = {**self.last_update, "last_task": objective.get("objective_id"), "outcome": outcome}

    async def train_if_ready(self, minimum_replay: int = 32) -> Mapping[str, Any] | None:
        if len(self.replay) < minimum_replay:
            return None
        metrics = await asyncio.to_thread(self.offline.train, batches=4, batch_size=16, beta=0.6)
        checkpoint = self.checkpoints.create("value_model", self.value.state_dict(), self.updates)
        self.last_checkpoint_id = checkpoint.checkpoint_id
        # The checkpoint stays challenger until EvaluationRunner supplies paired
        # seeded scores and CheckpointManager.consider_promotion accepts it.
        return {"metrics": dict(metrics), "checkpoint_id": checkpoint.checkpoint_id, "stage": checkpoint.stage}

    def status(self) -> dict[str, Any]:
        champion = self.checkpoints.champion("value_model")
        return {"replay_size": len(self.replay), "online_updates": self.updates,
                "last_update": dict(self.last_update), "last_challenger": self.last_checkpoint_id,
                "champion": champion.checkpoint_id if champion else None}

    def close(self) -> None:
        for resource in (self.replay, self.checkpoints):
            close = getattr(resource, "close", None)
            if close:
                close()


class SkillService:
    def __init__(self, database: str, cognition: Any) -> None:
        self.store = SkillStore(database)
        self.registry = SkillRegistry(self.store)
        self.runtime = SkillRuntime({kind.value for kind in ActionKind}, skill_resolver=self.registry.resolve)
        self.lifecycle = SkillLifecycle(self.store, self.runtime)
        self.evaluation_queue = SkillEvaluationQueue(self.store, self.lifecycle)
        self.cognition = cognition
        self.last_gap: Mapping[str, Any] | None = None

    def applicable(self, belief: Mapping[str, Any]) -> list[dict[str, Any]]:
        self.registry.reload()
        return [manifest.to_dict() for manifest in self.registry.snapshot()]

    async def execute(self, skill_id: str, parameters: Mapping[str, Any], state: Mapping[str, Any], executor: Any, cancelled: asyncio.Event):
        self.registry.reload()
        manifest = self.registry.resolve(skill_id)
        result = await self.runtime.run(manifest, executor, parameters, state, cancelled=cancelled, emergency_stop=cancelled.is_set)
        self.lifecycle.record_live_outcome(skill_id, success=result.status.value == "succeeded", safe=result.status.value != "safety_stop",
                                           actions=result.actions, cost=sum(float(item.get("cost", 0)) for item in result.trace),
                                           context={"state": dict(state)})
        return result

    async def propose_for_gap(self, gap: Mapping[str, Any]) -> Mapping[str, Any]:
        self.last_gap = dict(gap)
        raw = await self.cognition.call(Role.SKILL_INVENTOR, {
            "instruction": "Create one generic reusable SkillManifest candidate for the repeated capability gap. Include isolated tests. Use only listed atomic capabilities. Do not encode the whole objective.",
            "gap": dict(gap), "atomic_capabilities": [kind.value for kind in ActionKind],
            "manifest_contract": {"skill_id": "namespaced.id", "version": "0.1.0", "purpose": "", "applicability": "True", "parameters": {},
                "required_resources": [], "expected_effects": [], "root": {}, "safety_constraints": [], "recovery": None,
                "tests": [], "dependencies": {}, "provenance": {}, "confidence": 0.0, "known_failures": []},
        })
        manifest_raw = raw.get("manifest", raw.get("choice", {}).get("manifest"))
        if not isinstance(manifest_raw, Mapping):
            return {"stage": "capability_gap", "reason": "skill inventor supplied no executable manifest"}
        manifest = SkillManifest.from_dict(manifest_raw)
        self.lifecycle.submit(manifest)
        job_id = self.evaluation_queue.enqueue(manifest.skill_id, manifest.version)
        return {"stage": "candidate_queued", "skill_id": manifest.skill_id,
                "version": manifest.version, "evaluation_job_id": job_id,
                "reason": "awaiting a configured trusted isolated evaluator and independent critic"}

    def configure_isolated_evaluator(self, authority: IsolatedEvaluationAuthority) -> None:
        """Attach an explicit training-world executor; no live-world fallback exists."""

        self.evaluation_queue = SkillEvaluationQueue(self.store, self.lifecycle, authority)

    async def evaluate_queued_candidate(self) -> Mapping[str, Any] | None:
        return await self.evaluation_queue.run_once()

    def status(self) -> dict[str, Any]:
        self.registry.reload()
        return {"generation": self.store.generation,
                "active": [item.to_dict() for item in self.registry.snapshot()],
                "evaluation_jobs": list(self.store.list_evaluation_jobs()), "last_gap": self.last_gap}

    def close(self) -> None:
        self.store.close()


def build_default_services(database: str, cognition: Any):
    from .loop import RuntimeServices
    return RuntimeServices(memory=MemoryService(database), skills=SkillService(database, cognition), learning=LearningService(database))


def _deletion_scope(raw: Mapping[str, Any], *, default_all: bool) -> DeletionScope:
    memory_ids = raw.get("memory_ids", ())
    kinds = raw.get("kinds", ())
    if not isinstance(memory_ids, (list, tuple)) or not all(isinstance(item, str) and item for item in memory_ids):
        raise ValueError("memory_ids must be an array of non-empty strings")
    if not isinstance(kinds, (list, tuple)) or not all(isinstance(item, str) for item in kinds):
        raise ValueError("memory kinds must be an array of strings")
    return DeletionScope(
        memory_ids=tuple(memory_ids),
        kinds=tuple(MemoryKind(item) for item in kinds),
        world_id=str(raw["world_id"]) if raw.get("world_id") is not None else None,
        objective_id=str(raw["objective_id"]) if raw.get("objective_id") is not None else None,
        before=float(raw["before"]) if raw.get("before") is not None else None,
        include_all=bool(raw.get("include_all", default_all)),
    )
