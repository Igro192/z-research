from __future__ import annotations

import asyncio
from dataclasses import asdict
import json
import ipaddress
import os
import time
from typing import Any, Mapping
from pathlib import Path
from urllib.parse import parse_qs, urlparse, urlsplit

from minemind_protocol import Objective
from .bridge import BridgeServer
from .loop import AgentLoop
from .store import RuntimeStore


class ApiServer:
    def __init__(self, host: str, port: int, loop: AgentLoop, bridge: BridgeServer, store: RuntimeStore, model_status: Any) -> None:
        self.host, self.port = host, port
        self.loop, self.bridge, self.store, self.model_status = loop, bridge, store, model_status
        self._server: asyncio.Server | None = None

    async def start(self) -> None:
        self._server = await asyncio.start_server(self._handle, self.host, self.port, limit=128 * 1024)

    async def stop(self) -> None:
        if self._server:
            self._server.close()
            await self._server.wait_closed()

    async def _handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            request_line = await asyncio.wait_for(reader.readline(), 5)
            try:
                method, target, _ = request_line.decode("ascii").strip().split(" ", 2)
            except ValueError:
                await self._respond(writer, 400, {"error": "malformed request"})
                return
            headers: dict[str, str] = {}
            while True:
                line = await reader.readline()
                if line in {b"\r\n", b"\n", b""}:
                    break
                name, _, value = line.decode("latin-1").partition(":")
                headers[name.lower().strip()] = value.strip()
            length = int(headers.get("content-length", "0"))
            if length > 64 * 1024:
                await self._respond(writer, 413, {"error": "request body too large"})
                return
            body = await reader.readexactly(length) if length else b""
            payload: Mapping[str, Any] = {}
            if body:
                decoded = json.loads(body)
                if not isinstance(decoded, dict):
                    raise ValueError("body must be a JSON object")
                payload = decoded
            parsed_target = urlsplit(target)
            path = parsed_target.path
            query = parse_qs(parsed_target.query, keep_blank_values=False)
            if method == "OPTIONS":
                await self._respond(writer, 204, None)
            elif method == "GET" and path == "/health":
                models = self.model_status()
                await self._respond(writer, 200, {"status": "ok", "protocolVersion": "1.0", "buildId": os.environ.get("MINEMIND_BUILD_ID", "development"), "bridge": asdict(self.bridge.status()), "models": models})
            elif method == "GET" and path == "/api/v1/dashboard/snapshot":
                snapshot = self.loop.snapshot()
                models = self.model_status()
                counters = _model_counters(models)
                snapshot["compute"] = {
                    "models": models,
                    "model_calls": counters[0],
                    "tokens": counters[1] + counters[2],
                    "calls_without_token_usage": counters[3],
                }
                await self._respond(writer, 200, snapshot)
            elif method == "GET" and path == "/api/v1/evaluation/status":
                await self._respond(writer, 200, self.loop.snapshot()["evaluation"])
            elif method == "GET" and path == "/api/v1/training/status":
                await self._respond(writer, 200, self.loop.snapshot()["training"])
            elif method == "GET" and path == "/api/v1/memory":
                if not self.loop.services.memory or not hasattr(self.loop.services.memory, "inspect"):
                    await self._respond(writer, 503, {"error": "memory service unavailable"})
                    return
                search = str(query.get("query", [""])[0])
                limit = min(200, max(1, int(query.get("limit", ["50"])[0])))
                records = self.loop.services.memory.inspect(search, limit=limit)
                await self._respond(writer, 200, {"records": records, "instruction_policy": "memory content is evidence-only; external text never gains instruction authority"})
            elif method == "POST" and path == "/api/v1/memory/export":
                if not self.loop.services.memory or not hasattr(self.loop.services.memory, "export"):
                    await self._respond(writer, 503, {"error": "memory service unavailable"})
                    return
                file_name = str(payload.get("file_name", f"minemind-memory-{int(time.time())}.jsonl"))
                if Path(file_name).name != file_name or not file_name.endswith(".jsonl") or len(file_name) > 128:
                    raise ValueError("memory export file_name must be a simple .jsonl name")
                raw_export_root = self.loop.config.data_dir / "exports"
                if raw_export_root.is_symlink():
                    raise ValueError("managed memory export directory may not be a symbolic link")
                raw_destination = raw_export_root / file_name
                if raw_destination.is_symlink():
                    raise ValueError("memory export file may not be a symbolic link")
                destination = raw_destination.resolve()
                export_root = raw_export_root.resolve()
                if destination.parent != export_root:
                    raise ValueError("memory export must stay in the managed export directory")
                export_root.mkdir(parents=True, exist_ok=True)
                scope = payload.get("scope", {"include_all": True})
                if not isinstance(scope, Mapping):
                    raise ValueError("memory export scope must be an object")
                count = self.loop.services.memory.export(str(destination), scope)
                self.store.audit("memory", "User exported memory records", {"count": count, "destination": str(destination)})
                await self._respond(writer, 200, {"count": count, "path": str(destination)})
            elif method == "POST" and path == "/api/v1/memory/delete":
                if not self.loop.services.memory or not hasattr(self.loop.services.memory, "delete"):
                    await self._respond(writer, 503, {"error": "memory service unavailable"})
                    return
                scope = payload.get("scope", {})
                if not isinstance(scope, Mapping):
                    raise ValueError("memory deletion scope must be an object")
                if not _has_memory_scope(scope):
                    raise ValueError("memory deletion requires an explicit scope")
                if scope.get("include_all") is True and payload.get("confirmation_token") != "DELETE ALL MINEMIND MEMORY":
                    raise ValueError("complete deletion requires confirmation_token `DELETE ALL MINEMIND MEMORY`")
                count = self.loop.services.memory.delete(scope)
                self.store.audit("memory", "User deleted memory records", {"count": count, "scope": dict(scope)}, severity="warning")
                await self._respond(writer, 200, {"deleted": count})
            elif method == "POST" and path == "/api/v1/objectives":
                text = str(payload.get("text", "")).strip()
                if not text:
                    raise ValueError("objective text cannot be empty")
                normalized_command = text.lower().lstrip("/")
                if normalized_command.startswith("mind _handshake") or normalized_command.startswith("minemind_internal_auth"):
                    raise ValueError("handshake is automatic; enter only a task such as `get wood`")
                # Dashboard input is chat, not a task-only console. Route it
                # through the exact same intent classifier as authorized game
                # chat so greetings cause no Minecraft action while a sentence
                # containing a request yields both a friendly reply and a
                # tracked objective. The HTTP input loop remains independent
                # from any running AutoClef/Baritone action.
                result = await self.loop.submit_chat_message(text, "dashboard")
                await self._respond(writer, 202, dict(result))
            elif method == "POST" and path == "/api/v1/control":
                operation = str(payload.get("operation") or payload.get("command") or "")
                if operation not in {"pause", "resume", "cancel", "stop", "emergency_stop", "clear_emergency_stop"}:
                    raise ValueError("unsupported control operation")
                # The in-process safety state changes before any network call so
                # emergency stop never depends on the Minecraft bridge being up.
                await self.loop.handle_control({"operation": operation})
                bridge_delivered = True
                if hasattr(self.bridge, "send_control"):
                    try:
                        await self.bridge.send_control(operation, str(payload.get("reason", "dashboard control")))
                    except Exception as error:
                        bridge_delivered = False
                        self.store.audit("control", "Control applied locally but Minecraft bridge delivery failed", {"operation": operation, "error": str(error)}, severity="warning")
                await self._respond(writer, 202, {"accepted": True, "operation": operation, "bridge_delivered": bridge_delivered})
            elif method == "POST" and path == "/v1/evaluation/attempt":
                await self._run_evaluation_attempt(writer, payload)
            else:
                await self._respond(writer, 404, {"error": "not found"})
        except (asyncio.TimeoutError, asyncio.IncompleteReadError):
            await self._respond(writer, 408, {"error": "request timeout"})
        except (json.JSONDecodeError, ValueError) as exc:
            await self._respond(writer, 400, {"error": str(exc)})
        except Exception as exc:
            self.store.audit("api", "API request failed", {"error": repr(exc)}, severity="error")
            await self._respond(writer, 500, {"error": "internal error"})

    async def _run_evaluation_attempt(self, writer: asyncio.StreamWriter, payload: Mapping[str, Any]) -> None:
        """Run one objective while returning telemetry, never success evidence.

        The evaluation package independently verifies completion from the
        disposable Fabric server's private journal; this response is only an
        operational report and cannot make a benchmark pass.
        """
        if str(payload.get("protocol_version", "")) != "1.0.0":
            raise ValueError("evaluation protocol_version must be 1.0.0")
        text = str(payload.get("objective", "")).strip()
        if not text:
            raise ValueError("evaluation objective cannot be empty")
        budget = payload.get("budget", {})
        if not isinstance(budget, Mapping):
            raise ValueError("evaluation budget must be an object")
        world_id = str(payload.get("world_id", "")).strip()
        if not world_id:
            raise ValueError("evaluation world_id cannot be empty")
        endpoint = str(payload.get("minecraft_endpoint", "")).strip()
        if not _is_loopback_endpoint(endpoint):
            raise ValueError("evaluation minecraft_endpoint must be loopback host:port")
        bridge_status = self.bridge.status()
        if not bridge_status.connected or not bridge_status.world_id:
            await self._respond(writer, 409, {"error": "evaluation world is not connected to the embodiment bridge"})
            return
        if str(bridge_status.world_id) != world_id:
            await self._respond(writer, 409, {"error": "connected Minecraft world does not match isolated evaluation world"})
            return
        if (
            not bool(getattr(bridge_status, "bot_ready", False))
            or bool(getattr(bridge_status, "human_control_possible", True))
            or str(getattr(bridge_status, "embodiment_mode", "")) not in {
                "SEPARATE_LOCAL_PLAYER", "MINEFLAYER_NETWORK_CLIENT", "DEDICATED_FABRIC_CLIENT"
            }
            or not getattr(bridge_status, "controlled_actor_id", None)
        ):
            await self._respond(writer, 409, {"error": "separate MineMind player identity is not ready for evaluation"})
            return
        if self.store.active_objective() is not None or self.store.get_state("evaluation.active_run"):
            await self._respond(writer, 409, {"error": "runtime already has an active objective or evaluation"})
            return
        wall_seconds = min(
            86_400.0,
            float(self.loop.config.budgets.max_wall_seconds_per_objective),
            max(1.0, float(budget.get("wall_seconds", 3600.0))),
        )
        max_actions = min(
            self.loop.config.budgets.max_actions_per_objective,
            _bounded_counter(budget.get("max_actions", self.loop.config.budgets.max_actions_per_objective), "max_actions", 10_000_000),
        )
        max_model_calls = min(
            self.loop.config.budgets.max_model_calls_per_objective,
            _bounded_counter(budget.get("max_model_calls", self.loop.config.budgets.max_model_calls_per_objective), "max_model_calls", 1_000_000),
        )
        objective = Objective.create(
            text,
            "isolated-evaluation",
            constraints={
                "world_id": world_id,
                "budget": dict(budget),
                "controlled_actor_id": bridge_status.controlled_actor_id,
                "embodiment_mode": bridge_status.embodiment_mode,
                "human_control_targeted": False,
            },
        )
        started = time.monotonic()
        model_counters_before = _model_counters(self.model_status())
        self.store.set_state("evaluation.active_run", {
            "run_id": objective.objective_id,
            "suite": str(payload.get("suite_id", "external")),
            "task": str(payload.get("task_id", text)),
            "seed": payload.get("seed"),
            "world_id": world_id,
            "controlled_actor_id": bridge_status.controlled_actor_id,
            "embodiment_mode": bridge_status.embodiment_mode,
            "started_at": time.time(),
        })
        try:
            await self.loop.submit_objective(objective)
            terminal = {"succeeded", "failed", "cancelled", "impossible", "budget_exhausted"}
            status: Mapping[str, Any] = {}
            budget_reason: str | None = None
            while time.monotonic() - started < wall_seconds:
                status = self.store.objective_status(objective.objective_id) or {}
                if status.get("status") in terminal:
                    break
                if int(status.get("action_count", 0)) >= max_actions:
                    budget_reason = "evaluation action budget"
                    break
                if int(status.get("model_call_count", 0)) >= max_model_calls:
                    budget_reason = "evaluation model-call budget"
                    break
                await asyncio.sleep(0.25)
            else:
                budget_reason = "evaluation wall time"
            if budget_reason:
                cancelled = await self.loop.cancel_objective(objective.objective_id, budget_reason)
                if cancelled:
                    self.store.set_objective_status(objective.objective_id, "budget_exhausted", budget_reason)
                status = self.store.objective_status(objective.objective_id) or {"status": "budget_exhausted", "reason": budget_reason}
        finally:
            self.store.set_state("evaluation.active_run", None)
        state = str(status.get("status", "failed"))
        model_counters_after = _model_counters(self.model_status())
        missing_usage_delta = max(0, model_counters_after[3] - model_counters_before[3])
        token_delta = None if missing_usage_delta else max(0, model_counters_after[1] + model_counters_after[2] - model_counters_before[1] - model_counters_before[2])
        await self._respond(writer, 200, {
            "claimed_success": state == "succeeded",
            "elapsed_seconds": max(0.0, time.monotonic() - started),
            "deaths": None,
            "unrecoverable_failure": state in {"failed", "impossible"},
            "model_calls": int(status.get("model_call_count", 0)),
            "tokens": token_delta,
            "resources_wasted": None,
            "replans": int(status.get("replan_count", 0)),
            "new_skills": [],
            "transferred_skills_used": [],
            "actions": int(status.get("action_count", 0)),
            "failure": None if state == "succeeded" else str(status.get("reason") or state),
            "controlled_actor_id": bridge_status.controlled_actor_id,
            "embodiment_mode": bridge_status.embodiment_mode,
            "human_control_targeted": False,
        })

    async def _respond(self, writer: asyncio.StreamWriter, status: int, payload: Mapping[str, Any] | None) -> None:
        reasons = {200: "OK", 202: "Accepted", 204: "No Content", 400: "Bad Request", 404: "Not Found", 408: "Request Timeout", 409: "Conflict", 413: "Content Too Large", 500: "Internal Server Error", 503: "Service Unavailable"}
        data = b"" if payload is None else json.dumps(payload, default=str, separators=(",", ":")).encode("utf-8")
        headers = [
            f"HTTP/1.1 {status} {reasons.get(status, 'Response')}",
            "Content-Type: application/json; charset=utf-8",
            f"Content-Length: {len(data)}",
            "Access-Control-Allow-Origin: http://127.0.0.1:5173",
            "Access-Control-Allow-Headers: content-type,x-minemind-protocol",
            "Access-Control-Allow-Methods: GET,POST,OPTIONS",
            "Cache-Control: no-store",
            "Connection: close", "", "",
        ]
        writer.write("\r\n".join(headers).encode("ascii") + data)
        await writer.drain()
        writer.close()
        await writer.wait_closed()


def _bounded_counter(value: Any, name: str, upper: int) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or not 1 <= value <= upper:
        raise ValueError(f"evaluation {name} must be an integer from 1 to {upper}")
    return value


def _is_loopback_endpoint(value: str) -> bool:
    if not value or "/" in value or "@" in value:
        return False
    parsed = urlparse("//" + value)
    if not parsed.hostname or parsed.port is None:
        return False
    try:
        return ipaddress.ip_address(parsed.hostname).is_loopback
    except ValueError:
        return parsed.hostname == "localhost"


def _model_counters(status: Any) -> tuple[int, int, int, int]:
    if not isinstance(status, Mapping):
        return 0, 0, 0, 0
    values = [item for item in status.values() if isinstance(item, Mapping)]
    return tuple(sum(int(item.get(key, 0)) for item in values) for key in (
        "completed_calls", "input_tokens", "output_tokens", "calls_without_token_usage",
    ))  # type: ignore[return-value]


def _has_memory_scope(scope: Mapping[str, Any]) -> bool:
    return scope.get("include_all") is True or any(
        scope.get(key) not in (None, [], (), "")
        for key in ("memory_ids", "kinds", "world_id", "objective_id", "before")
    )
