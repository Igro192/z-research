from __future__ import annotations

import argparse
import asyncio
from dataclasses import asdict
import json

from minemind_model_router import detect_hardware, recommend_preset
from .app import RuntimeApplication
from .config import load_config


def main() -> None:
    parser = argparse.ArgumentParser(prog="minemind-runtime")
    sub = parser.add_subparsers(dest="command", required=True)
    serve = sub.add_parser("serve", help="start bridge, cognition loop, and local API")
    serve.add_argument("--config", default="config/minemind.toml")
    sub.add_parser("hardware", help="print detected hardware and recommended preset")
    args = parser.parse_args()
    if args.command == "hardware":
        profile = detect_hardware()
        print(json.dumps({"hardware": asdict(profile), "preset": recommend_preset(profile)}, indent=2))
        return
    asyncio.run(RuntimeApplication(load_config(args.config)).run_until_stopped())


if __name__ == "__main__":
    main()
