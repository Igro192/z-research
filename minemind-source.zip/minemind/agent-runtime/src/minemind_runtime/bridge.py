from __future__ import annotations

import asyncio
from dataclasses import dataclass
import hmac
import time
from typing import Any

from minemind_protocol import ActionCommand, ActionResult, Envelope, EventKind, Observation, ProtocolError, TrustClass, new_envelope
from .store import RuntimeStore


@dataclass(slots=True, frozen=True)
class BridgeStatus:
    connected: bool
    session_id: str | None
    world_id: str | None
    mod_version: str | None
    last_sequence: int
    controlled_actor_id: str | None = None
    controlled_actor_name: str | None = None
    embodiment_mode: str = "DEDICATED_FABRIC_CLIENT"
    embodiment_status: str = "WAITING_FOR_WORLD"
    bot_ready: bool = False
    human_control_possible: bool = False


class BridgeServer:
    def __init__(self, host: str, port: int, store: RuntimeStore, token: str | None = None) -> None:
        self.host, self.port, self.store, self.token = host, port, store, token
        self._server: Any = None
        self._connection: Any = None
        self._session_id: str | None = None
        self._world_id: str | None = None
        self._mod_version: str | None = None
        self._last_observation: Observation | None = None
        self._last_sequence = -1
        self._controlled_actor_id: str | None = None
        self._controlled_actor_name: str | None = None
        self._embodiment_mode = "DEDICATED_FABRIC_CLIENT"
        self._embodiment_status = "WAITING_FOR_WORLD"
        self._bot_ready = False
        self._human_control_possible = False
        self._capabilities: dict[str, str] = {}
        self._capability_gaps: list[str] = []
        self._last_progress_key: tuple[str, str] | None = None
        self._last_progress_write = 0.0
        self._observation_condition = asyncio.Condition()
        self.objectives: asyncio.Queue[Envelope] = asyncio.Queue()
        self.controls: asyncio.Queue[Envelope] = asyncio.Queue()
        self._result_waiters: dict[str, asyncio.Future[ActionResult]] = {}
        self.connected = asyncio.Event()

    async def start(self) -> None:
        from websockets.asyncio.server import serve
        self._server = await serve(self._handler, self.host, self.port, max_size=2 * 1024 * 1024, ping_interval=10, ping_timeout=10, origins=None)

    async def stop(self) -> None:
        if self._server:
            self._server.close()
            await self._server.wait_closed()
        await self._disconnect("server stopping")

    async def _handler(self, connection: Any) -> None:
        path = getattr(getattr(connection, "request", None), "path", "")
        if path and path != "/bridge":
            await connection.close(1008, "invalid path")
            return
        try:
            raw = await asyncio.wait_for(connection.recv(), timeout=5)
            hello = Envelope.from_json(raw)
            if hello.kind != EventKind.HELLO:
                raise ProtocolError("first bridge event must be hello")
            supplied_token = str(hello.payload.get("token", ""))
            if self.token is not None and not hmac.compare_digest(supplied_token, self.token):
                await connection.close(1008, "authentication failed")
                self.store.audit("security", "Rejected mod bridge authentication", severity="warning")
                return
            if self._connection is not None:
                await self._connection.close(1012, "replaced by new Minecraft session")
            self._connection = connection
            self._session_id, self._world_id = hello.session_id, hello.world_id
            self._mod_version = str(hello.payload.get("mod_version", "unknown"))
            embodiment = hello.payload.get("embodiment", {})
            if isinstance(embodiment, dict):
                self._embodiment_mode = str(embodiment.get("mode", self._embodiment_mode))
                self._embodiment_status = str(embodiment.get("status", self._embodiment_status))
                self._controlled_actor_id = _optional_text(embodiment.get("botUuid"))
                self._controlled_actor_name = _optional_text(embodiment.get("botName"))
                self._bot_ready = (
                    bool(embodiment.get("connected", False))
                    and self._embodiment_status.upper() == "READY"
                )
                self._human_control_possible = bool(embodiment.get("humanControlPossible", True))
            self.store.append_event(hello)
            self.store.audit("bridge", "Minecraft embodiment connected", {"session_id": hello.session_id, "world_id": hello.world_id})
            self.connected.set()
            async for raw in connection:
                await self._receive(Envelope.from_json(raw))
        except (asyncio.TimeoutError, ProtocolError) as exc:
            self.store.audit("bridge", "Rejected malformed bridge connection", {"error": str(exc)}, severity="warning")
            await connection.close(1008, "protocol error")
        except Exception as exc:
            self.store.audit("bridge", "Bridge connection failed", {"error": str(exc)}, severity="error")
        finally:
            if self._connection is connection:
                await self._disconnect("connection closed")

    async def _disconnect(self, reason: str) -> None:
        self._connection = None
        self.connected.clear()
        self.store.audit("bridge", "Minecraft embodiment disconnected", {"reason": reason}, severity="warning")
        for waiter in self._result_waiters.values():
            if not waiter.done():
                waiter.set_exception(ConnectionError(reason))
        self._result_waiters.clear()

    async def _receive(self, event: Envelope) -> None:
        if self._session_id and event.session_id != self._session_id:
            raise ProtocolError("session id changed within connection")
        self.store.append_event(event)
        if event.kind == EventKind.OBSERVATION:
            observation = Observation.from_dict(event.payload)
            if observation.sequence <= self._last_sequence:
                return
            self._last_sequence = observation.sequence
            async with self._observation_condition:
                self._last_observation = observation
                self._observation_condition.notify_all()
            embodiment = observation.embodiment
            if isinstance(embodiment, dict):
                self._embodiment_mode = str(embodiment.get("mode", self._embodiment_mode))
                self._embodiment_status = str(embodiment.get("status", self._embodiment_status))
                self._bot_ready = bool(embodiment.get("connected", False)) and self._embodiment_status.upper() == "READY"
                self._human_control_possible = bool(embodiment.get("humanControlPossible", False))
            if observation.controlled_actor:
                self._controlled_actor_id = _optional_text(observation.controlled_actor.get("uuid") or observation.controlled_actor.get("id"))
                self._controlled_actor_name = _optional_text(observation.controlled_actor.get("name"))
        elif event.kind == EventKind.OBJECTIVE:
            await self.objectives.put(event)
        elif event.kind == EventKind.CONTROL:
            await self.controls.put(event)
        elif event.kind in {EventKind.ACTION_RESULT, EventKind.ACTUATOR_RESULT}:
            result = ActionResult.from_dict(event.payload)
            waiter = self._result_waiters.pop(result.action_id, None)
            if waiter and not waiter.done():
                waiter.set_result(result)
        elif event.kind == EventKind.ACTUATOR_PROGRESS:
            progress = dict(event.payload)
            progress["received_at"] = event.timestamp
            # Movement can report progress once per game second.  Persisting
            # every heartbeat made SQLite and the dashboard compete with the
            # Minecraft client on low-memory Macs.  Phase changes are always
            # stored; identical running heartbeats are coalesced to 2 Hz.
            key = (str(progress.get("action_id", "")), str(progress.get("phase", "running")))
            now = time.monotonic()
            phase_changed = key != self._last_progress_key
            if phase_changed or now - self._last_progress_write >= 0.5:
                self.store.set_state("execution_progress", progress)
                self._last_progress_write = now
            if phase_changed:
                self.store.audit("progress", key[1], {
                    "action_id": key[0], "details": progress.get("details", {}),
                })
                self._last_progress_key = key
        elif event.kind == EventKind.CAPABILITY_REPORT:
            self._capabilities = {str(item): "IMPLEMENTED" for item in event.payload.get("implemented", ())}
            self._capability_gaps = [str(item) for item in event.payload.get("capability_gaps", ())]
        elif event.kind == EventKind.STATUS:
            status = str(event.payload.get("status", "unknown"))
            self._embodiment_status = status
            self._bot_ready = status.upper() == "READY"
            self._controlled_actor_id = _optional_text(event.payload.get("uuid")) or self._controlled_actor_id

    async def send(self, event: Envelope) -> None:
        if not self._connection:
            raise ConnectionError("Minecraft embodiment is not connected")
        self.store.append_event(event)
        await self._connection.send(event.to_json())

    async def execute(self, command: ActionCommand, timeout: float) -> ActionResult:
        if not self._session_id:
            raise ConnectionError("Minecraft embodiment is not connected")
        loop = asyncio.get_running_loop()
        waiter: asyncio.Future[ActionResult] = loop.create_future()
        self._result_waiters[command.action_id] = waiter
        event = new_envelope(EventKind.ACTUATOR_EXECUTE, command, source="agent-runtime", session_id=self._session_id,
                             world_id=self._world_id, trust=TrustClass.SYSTEM)
        try:
            await self.send(event)
            return await asyncio.wait_for(waiter, timeout=timeout)
        except asyncio.TimeoutError:
            try:
                await self.send(new_envelope(
                    EventKind.CONTROL_CANCEL,
                    {"operation": "cancel", "action_id": command.action_id, "reason": "runtime deadline"},
                    source="agent-runtime", session_id=self._session_id, world_id=self._world_id,
                    correlation_id=command.action_id, trust=TrustClass.SYSTEM,
                ))
            except ConnectionError:
                pass
            raise
        finally:
            self._result_waiters.pop(command.action_id, None)

    async def send_control(self, operation: str, reason: str = "runtime control") -> dict[str, str]:
        if not self._session_id:
            raise ConnectionError("Minecraft embodiment is not connected")
        await self.send(new_envelope(
            EventKind.CONTROL,
            {"operation": operation, "reason": reason},
            source="agent-runtime", session_id=self._session_id, world_id=self._world_id,
            trust=TrustClass.SYSTEM,
        ))
        return {"status": "queued", "operation": operation}

    async def wait_observation(self, after_sequence: int = -1, timeout: float = 30) -> Observation:
        async with self._observation_condition:
            await asyncio.wait_for(self._observation_condition.wait_for(
                lambda: self._last_observation is not None and self._last_observation.sequence > after_sequence), timeout)
            assert self._last_observation is not None
            return self._last_observation

    @property
    def latest_observation(self) -> Observation | None:
        return self._last_observation

    def status(self) -> BridgeStatus:
        return BridgeStatus(
            self._connection is not None, self._session_id, self._world_id,
            self._mod_version, self._last_sequence, self._controlled_actor_id,
            self._controlled_actor_name, self._embodiment_mode,
            self._embodiment_status, self._bot_ready,
            self._human_control_possible,
        )

    def action_provenance(self) -> dict[str, Any]:
        return {
            "session_id": self._session_id,
            "world_id": self._world_id,
            "controlled_actor_id": self._controlled_actor_id,
            "controlled_actor_name": self._controlled_actor_name,
            "embodiment_mode": self._embodiment_mode,
            "observation_sequence": self._last_sequence,
            "source": "websocket_bridge",
        }

    def capability_gaps(self) -> tuple[dict[str, Any], ...]:
        gaps = tuple({
            "capability": item,
            "evidence": f"The connected embodiment explicitly reports {item} as unavailable.",
            "occurrences": 1,
        } for item in self._capability_gaps)
        if self._bot_ready and not self._human_control_possible:
            return gaps
        return gaps + ({
            "capability": "separate_player_embodiment",
            "evidence": "MineMind_AI is not connected as an independently controlled Minecraft client.",
            "occurrences": 1,
        },)


def _optional_text(value: Any) -> str | None:
    return str(value) if value not in (None, "") else None
