from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import statistics
from typing import Any, Mapping
from urllib.parse import quote

from .config import RuntimeConfig
from .store import RuntimeStore


def evaluation_status(config: RuntimeConfig, store: RuntimeStore) -> dict[str, Any]:
    database = _configured_path(config, config.evaluation, "results_database", config.data_dir / "evaluation.db")
    active = store.get_state("evaluation.active_run")
    definitions = _suite_definitions()
    rows: list[sqlite3.Row] = []
    columns: set[str] = set()
    read_error: str | None = None
    if database.is_file():
        try:
            connection = _read_only(database)
            try:
                table = connection.execute(
                    "SELECT 1 FROM sqlite_master WHERE type='table' AND name='evaluation_results'"
                ).fetchone()
                if table:
                    columns = {str(row[1]) for row in connection.execute("PRAGMA table_info(evaluation_results)")}
                    rows = connection.execute("SELECT * FROM evaluation_results ORDER BY recorded_at DESC").fetchall()
            finally:
                connection.close()
        except (OSError, sqlite3.Error) as error:
            read_error = f"{type(error).__name__}: {error}"

    by_suite: dict[str, list[tuple[sqlite3.Row, Mapping[str, Any]]]] = defaultdict(list)
    simulated: dict[str, int] = defaultdict(int)
    unverified: dict[str, int] = defaultdict(int)
    recent: list[dict[str, Any]] = []
    for row in rows:
        telemetry = _telemetry(row)
        suite_id = str(row["suite_id"])
        real = "real_minecraft_measured" in columns and bool(row["real_minecraft_measured"])
        is_simulated = "simulated" in columns and bool(row["simulated"])
        if real:
            by_suite[suite_id].append((row, telemetry))
        elif is_simulated:
            simulated[suite_id] += 1
        else:
            # Legacy and infrastructure-only rows are deliberately not upgraded
            # to benchmark evidence by inference.
            unverified[suite_id] += 1
        recent.append(_recent_evaluation(row, telemetry, real=real, simulated=is_simulated, columns=columns))

    suite_ids = list(definitions)
    for suite_id in (*by_suite, *simulated, *unverified):
        if suite_id not in suite_ids:
            suite_ids.append(suite_id)
    suites: list[dict[str, Any]] = []
    benchmarks: list[dict[str, Any]] = []
    for suite_id in suite_ids:
        entries = by_suite.get(suite_id, [])
        definition = definitions.get(suite_id, {"label": suite_id, "task_count": None})
        successes = [item for item in entries if bool(item[0]["verified_success"])]
        elapsed = [float(item[1].get("elapsed_seconds", 0.0)) for item in successes]
        attempts_by_index: dict[int, list[bool]] = defaultdict(list)
        for row, _ in entries:
            attempts_by_index[int(row["attempt_index"])].append(bool(row["verified_success"]))
        rates = [sum(values) / len(values) for _, values in sorted(attempts_by_index.items())]
        trend = rates[-1] - rates[-2] if len(rates) > 1 else 0.0
        measurement = "measured" if entries else "not_measured"
        completion = len(successes) / len(entries) if entries else None
        recorded = max((float(item[0]["recorded_at"]) for item in entries), default=None)
        suite = {
            "suite_id": suite_id,
            "label": str(definition["label"]),
            "task_count": definition["task_count"],
            "measurement_status": measurement,
            "attempts": len(entries),
            "completion_rate": completion,
            "median_completion_seconds": statistics.median(elapsed) if elapsed else None,
            "deaths": _optional_sum(item[1].get("deaths") for item in entries),
            "false_success_claims": sum(bool(item[0]["false_success"]) for item in entries),
            "budget_exhaustions": sum(bool(item[0]["budget_exhausted"]) for item in entries),
            "simulated_attempts": simulated.get(suite_id, 0),
            "unverified_attempts": unverified.get(suite_id, 0),
            "last_recorded_at": recorded,
            "trend": trend,
        }
        suites.append(suite)
        benchmarks.append({
            "suite_id": suite_id,
            "name": str(definition["label"]),
            "measurement_status": measurement,
            "attempts": len(entries),
            "completion_rate": completion,
            "median_completion_seconds": suite["median_completion_seconds"],
            "trend": trend,
            "simulated_attempts": suite["simulated_attempts"],
        })

    if active:
        overall = "running"
    elif read_error:
        overall = "error"
    elif any(item["measurement_status"] == "measured" for item in suites):
        overall = "measured"
    else:
        overall = "not_measured"
    next_action = (
        "Monitor the active isolated evaluation run."
        if active else
        "Repair evaluation result access before trusting benchmark metrics."
        if read_error else
        "Run `minemind benchmark init`, review the EULA/template, then run the diagnostics suite."
        if overall == "not_measured" else
        "Run a new attempt index on unseen seeds and compare against prior verified results."
    )
    return {
        "measurement_status": overall,
        "database": str(database),
        "active_run": active,
        "suites": suites,
        "recent_runs": recent[:20],
        "simulated_attempts": sum(simulated.values()),
        "unverified_attempts": sum(unverified.values()),
        "read_error": read_error,
        "next_action": next_action,
        "benchmarks": benchmarks,
    }


def training_status(config: RuntimeConfig, store: RuntimeStore) -> dict[str, Any]:
    database = _configured_path(config, config.training, "results_database", config.data_dir / "training.db")
    enabled = bool(config.training.get("enabled", False))
    active = store.get_state("training.active_run")
    rows: list[sqlite3.Row] = []
    read_error: str | None = None
    if database.is_file():
        try:
            connection = _read_only(database)
            try:
                table = connection.execute(
                    "SELECT 1 FROM sqlite_master WHERE type='table' AND name='training_episodes'"
                ).fetchone()
                if table:
                    rows = connection.execute("SELECT * FROM training_episodes ORDER BY finished_at DESC").fetchall()
            finally:
                connection.close()
        except (OSError, sqlite3.Error) as error:
            read_error = f"{type(error).__name__}: {error}"

    capability: dict[str, dict[str, Any]] = {}
    for row in reversed(rows):
        try:
            tags = json.loads(str(row["capability_tags_json"]))
        except (TypeError, ValueError):
            tags = []
        for raw_tag in tags if isinstance(tags, list) else []:
            tag = str(raw_tag)
            item = capability.setdefault(tag, {"capability": tag, "successes": 0, "failures": 0, "last_practiced_at": None})
            succeeded = bool(row["success"]) and not bool(row["budget_exhausted"])
            item["successes" if succeeded else "failures"] += 1
            item["last_practiced_at"] = float(row["finished_at"])
    matrix = []
    for item in sorted(capability.values(), key=lambda value: value["capability"]):
        total = item["successes"] + item["failures"]
        matrix.append({**item, "mastery": (item["successes"] + 1) / (total + 2), "attempts": total})
    measurement = "error" if read_error else "running" if active else "measured" if rows else "not_measured"
    next_action = (
        "Enable `[training].enabled` after configuring an isolated disposable-world backend."
        if not enabled else
        "Repair training result access before scheduling more practice."
        if read_error else
        "Monitor the current curriculum episode."
        if active else
        "Start curriculum practice; no completed episodes are recorded."
        if not rows else
        "Practice the lowest-mastery or highest-uncertainty capability, then run regression checks."
    )
    return {
        "enabled": enabled,
        "state": "disabled" if not enabled and not active else "running" if active else "idle",
        "measurement_status": measurement,
        "database": str(database),
        "active_run": active,
        "episodes": len(rows),
        "verified_success_rate": (sum(bool(row["success"]) and not bool(row["budget_exhausted"]) for row in rows) / len(rows)) if rows else None,
        "budget_exhaustions": sum(bool(row["budget_exhausted"]) for row in rows),
        "capability_matrix": matrix,
        "last_episode_at": float(rows[0]["finished_at"]) if rows else None,
        "read_error": read_error,
        "next_action": next_action,
    }


def capability_gaps(bridge: Any, services: Any) -> list[dict[str, Any]]:
    now = datetime.now(timezone.utc).isoformat()
    gaps: list[dict[str, Any]] = []
    if hasattr(bridge, "capability_gaps"):
        for raw in bridge.capability_gaps():
            capability = str(raw.get("capability", "unknown"))
            evidence = str(raw.get("evidence", "Embodiment reported a missing atomic capability."))
            gaps.append(_gap(capability, "runtime", "open", evidence, int(raw.get("occurrences", 1)), now))
    if services.skills and hasattr(services.skills, "status"):
        status = services.skills.status()
        last_gap = status.get("last_gap") if isinstance(status, Mapping) else None
        if isinstance(last_gap, Mapping):
            milestone = last_gap.get("milestone", {})
            capability = str(last_gap.get("capability") or (milestone.get("description") if isinstance(milestone, Mapping) else None) or "repeated action failure")
            evidence = str(last_gap.get("reason") or "Skill engine observed a repeated capability gap.")
            gaps.append(_gap(capability, "skill_engine", "testing", evidence, max(1, len(last_gap.get("failures", ())) if isinstance(last_gap.get("failures"), (list, tuple)) else 1), now))
    unique: dict[str, dict[str, Any]] = {}
    for item in gaps:
        unique[item["gap_id"]] = item
    return list(unique.values())


def _suite_definitions() -> dict[str, dict[str, Any]]:
    try:
        from minemind_evaluation import available_suites

        return {
            suite.suite_id: {"label": alias.replace("-", " ").title(), "task_count": len(suite.tasks)}
            for alias, suite in available_suites().items()
        }
    except (ImportError, AttributeError, TypeError, ValueError):
        return {}


def _configured_path(config: RuntimeConfig, section: Mapping[str, Any], key: str, default: Path) -> Path:
    value = Path(str(section.get(key, default))).expanduser()
    return value.resolve() if value.is_absolute() else (config.root / value).resolve()


def _read_only(path: Path) -> sqlite3.Connection:
    connection = sqlite3.connect(f"file:{quote(path.as_posix())}?mode=ro", uri=True, timeout=0.25)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    return connection


def _telemetry(row: sqlite3.Row) -> Mapping[str, Any]:
    try:
        value = json.loads(str(row["telemetry_json"]))
        return value if isinstance(value, dict) else {}
    except (TypeError, ValueError):
        return {}


def _recent_evaluation(row: sqlite3.Row, telemetry: Mapping[str, Any], *, real: bool, simulated: bool, columns: set[str]) -> dict[str, Any]:
    if real:
        evidence_scope = "real_minecraft"
        status = "verified" if bool(row["verified_success"]) else "budget_exhausted" if bool(row["budget_exhausted"]) else "failed"
    elif simulated:
        evidence_scope, status = "simulated", "simulated"
    else:
        evidence_scope, status = "unverified", "unverified"
    run_mode = str(row["run_mode"]) if "run_mode" in columns else "legacy_unspecified"
    return {
        "run_id": f"{row['suite_id']}:{row['task_id']}:{row['seed']}:{row['attempt_index']}",
        "suite_id": str(row["suite_id"]),
        "task_id": str(row["task_id"]),
        "seed": int(row["seed"]),
        "attempt_index": int(row["attempt_index"]),
        "verified_success": bool(row["verified_success"]) if real else False,
        "false_success": bool(row["false_success"]) if real else False,
        "budget_exhausted": bool(row["budget_exhausted"]) if real else False,
        "verification_reason": str(row["verification_reason"]),
        "recorded_at": float(row["recorded_at"]),
        "elapsed_seconds": float(telemetry.get("elapsed_seconds", 0.0)),
        "status": status,
        "evidence_scope": evidence_scope,
        "run_mode": run_mode,
    }


def _optional_sum(values: Any) -> int | float | None:
    materialized = list(values)
    if not materialized or any(value is None for value in materialized):
        return None
    return sum(float(value) for value in materialized)


def _gap(capability: str, source: str, status: str, evidence: str, occurrences: int, last_seen: str) -> dict[str, Any]:
    gap_id = hashlib.sha256(f"{source}:{capability}".encode("utf-8")).hexdigest()[:16]
    return {"gap_id": gap_id, "capability": capability, "source": source, "status": status, "evidence": evidence, "occurrences": occurrences, "last_seen": last_seen}
