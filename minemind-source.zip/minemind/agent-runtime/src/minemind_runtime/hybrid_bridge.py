from __future__ import annotations

import asyncio
from dataclasses import replace
from typing import Any, Mapping

from minemind_protocol import ActionCommand, ActionKind, ActionResult, Observation

from .bridge import BridgeServer, BridgeStatus
from .http_bridge import HttpBridgeClient


class HybridBridge:
    """Join the real bot actuator to the trusted Fabric verifier.

    The dedicated AutoClef client owns controls and action execution through
    real embedded Baritone. The Fabric HTTP bridge owns chat authorization and authoritative observations. The
    runtime is considered ready only when both describe the same AI identity;
    there is deliberately no fallback to the human client player.
    """

    def __init__(self, actuator: BridgeServer, verifier: HttpBridgeClient) -> None:
        self.actuator = actuator
        self.verifier = verifier
        self.objectives: asyncio.Queue[Any] = asyncio.Queue()
        self.controls: asyncio.Queue[Any] = asyncio.Queue()
        self.connected = asyncio.Event()
        self._tasks: set[asyncio.Task[Any]] = set()
        self._stopping = asyncio.Event()

    async def start(self) -> None:
        await self.actuator.start()
        await self.verifier.start()
        self._spawn(self._forward(self.verifier.objectives, self.objectives), "fabric-objectives")
        self._spawn(self._forward_controls(), "fabric-controls")
        # The network client can see chat, but it cannot establish who is an
        # authorized human. Drain these copies so only Fabric-authorized chat
        # can become an objective or control command.
        self._spawn(self._discard_untrusted(self.actuator.objectives, "objective"), "discard-bot-objectives")
        self._spawn(self._discard_untrusted(self.actuator.controls, "control"), "discard-bot-controls")
        self._spawn(self._monitor_readiness(), "hybrid-readiness")

    async def stop(self) -> None:
        self._stopping.set()
        for task in self._tasks:
            task.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()
        self.connected.clear()
        await asyncio.gather(self.verifier.stop(), self.actuator.stop(), return_exceptions=True)

    def _spawn(self, coroutine: Any, name: str) -> None:
        task = asyncio.create_task(coroutine, name=name)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def _forward(self, source: asyncio.Queue[Any], destination: asyncio.Queue[Any]) -> None:
        while not self._stopping.is_set():
            await destination.put(await source.get())

    async def _forward_controls(self) -> None:
        while not self._stopping.is_set():
            event = await self.verifier.controls.get()
            # Chat controls originate in Fabric. Deliver to the actual movement
            # actuator as well as cognition, without echoing back into Fabric.
            await self.controls.put(event)
            operation = str(event.payload.get("operation", ""))
            try:
                await self.actuator.send_control(operation, "authorized Minecraft chat control")
            except ConnectionError:
                self.actuator.store.audit("control", "Bot control pending: actuator disconnected", {
                    "operation": operation,
                }, severity="warning")

    async def _discard_untrusted(self, source: asyncio.Queue[Any], event_kind: str) -> None:
        while not self._stopping.is_set():
            event = await source.get()
            self.actuator.store.audit(
                "security",
                f"Ignored {event_kind} copied from bot-visible chat; Fabric authorization is required",
                {"event_id": getattr(event, "id", None)},
                severity="warning",
            )

    async def _monitor_readiness(self) -> None:
        while not self._stopping.is_set():
            if self._identities_agree():
                self.connected.set()
            else:
                self.connected.clear()
            try:
                await asyncio.wait_for(self._stopping.wait(), timeout=0.1)
            except asyncio.TimeoutError:
                pass

    def _identities_agree(self) -> bool:
        actuator = self.actuator.status()
        verifier = self.verifier.status()
        return bool(
            actuator.connected
            and actuator.bot_ready
            and not actuator.human_control_possible
            and verifier.connected
            and verifier.bot_ready
            and not verifier.human_control_possible
            and actuator.controlled_actor_id
            and actuator.controlled_actor_id == verifier.controlled_actor_id
        )

    @property
    def latest_observation(self) -> Observation | None:
        # Server state, including inventory and damage, is authoritative.
        return self.verifier.latest_observation

    async def wait_observation(self, after_sequence: int = -1, timeout: float = 30) -> Observation:
        return await self.verifier.wait_observation(after_sequence, timeout)

    async def execute(self, command: ActionCommand, timeout: float) -> ActionResult:
        before = self.verifier.latest_observation
        result = await self.actuator.execute(command, timeout)
        if result.status not in {"success", "succeeded"} or before is None:
            return result
        try:
            # The newest observation during a long action may still predate
            # its last inventory packet. Require a snapshot after it completes.
            async with asyncio.timeout(min(timeout, 5.0)):
                latest = self.verifier.latest_observation or before
                after = await self.verifier.wait_observation(latest.sequence, min(timeout, 5.0))
                # A snapshot published just after the client response may have
                # been captured before the server processed its final packet.
                # Wait for the authoritative effect, not merely a new sequence.
                while not _server_effect_visible(command, result, before, after):
                    after = await self.verifier.wait_observation(after.sequence, min(timeout, 5.0))
        except (asyncio.TimeoutError, ConnectionError):
            return replace(
                result,
                status="verification_pending",
                error={"code": "server_verification_timeout", "message": "Fabric did not publish a post-action observation in time"},
            )
        effects = [{**dict(effect), "source": "server_verifier"}
                   if effect.get("path") == "world.block" and command.kind == ActionKind.PLACE
                   else dict(effect) for effect in result.actual_effects]
        effects.append({
            "path": "server.player.position",
            "value": dict(after.player.get("position", {})),
            "source": "server_verifier",
        })
        selector = command.parameters.get("selector") or command.parameters.get("item") or command.parameters.get("recipe")
        if selector:
            before_count = _inventory_count(before, str(selector))
            after_count = _inventory_count(after, str(selector))
            effects = [item for item in effects if item.get("path") != "inventory.count"]
            effects.append({
                "path": "inventory.count",
                "value": after_count,
                "delta": after_count - before_count,
                "source": "server_verifier",
            })
        return replace(result, actual_effects=tuple(effects))

    async def submit_objective(self, text: str, actor: str = "active") -> Mapping[str, Any]:
        return await self.verifier.submit_objective(text, actor)

    async def send_control(self, operation: str, reason: str = "runtime control") -> Mapping[str, Any]:
        deliveries = await asyncio.gather(
            self.actuator.send_control(operation, reason),
            self.verifier.send_control(operation, reason),
            return_exceptions=True,
        )
        delivered = [not isinstance(item, BaseException) for item in deliveries]
        if not any(delivered):
            raise ConnectionError("control could not reach either MineMind bridge")
        return {"status": "queued", "operation": operation, "bot": delivered[0], "server": delivered[1]}

    def status(self) -> BridgeStatus:
        actuator = self.actuator.status()
        verifier = self.verifier.status()
        ready = self._identities_agree()
        return BridgeStatus(
            connected=ready,
            session_id=actuator.session_id,
            world_id=verifier.world_id or actuator.world_id,
            mod_version=verifier.mod_version,
            last_sequence=verifier.last_sequence,
            controlled_actor_id=actuator.controlled_actor_id,
            controlled_actor_name=actuator.controlled_actor_name,
            embodiment_mode="DEDICATED_FABRIC_CLIENT",
            embodiment_status="READY" if ready else _combined_status(actuator, verifier),
            bot_ready=ready,
            human_control_possible=False,
        )

    def action_provenance(self) -> dict[str, Any]:
        status = self.status()
        return {
            "session_id": status.session_id,
            "world_id": status.world_id,
            "controlled_actor_id": status.controlled_actor_id,
            "controlled_actor_name": status.controlled_actor_name,
            "embodiment_mode": status.embodiment_mode,
            "observation_sequence": status.last_sequence,
            "source": "autoclef_baritone_dedicated_client+fabric_server_verifier",
            "server_verifier_connected": self.verifier.status().connected,
            "human_control_targeted": False,
        }

    def capability_gaps(self) -> tuple[Mapping[str, Any], ...]:
        gaps = tuple(self.actuator.capability_gaps())
        if self.verifier.status().connected:
            return gaps
        return gaps + ({
            "capability": "server_verification",
            "evidence": "Fabric's trusted local HTTP verifier is not connected.",
            "occurrences": 1,
        },)


def _combined_status(actuator: BridgeStatus, verifier: BridgeStatus) -> str:
    if not actuator.connected or not actuator.bot_ready:
        return "WAITING_FOR_BOT"
    if not verifier.connected:
        return "WAITING_FOR_SERVER_VERIFIER"
    if not verifier.bot_ready:
        return "WAITING_FOR_BOT_HANDSHAKE"
    if actuator.controlled_actor_id != verifier.controlled_actor_id:
        return "IDENTITY_MISMATCH"
    return "NOT_READY"


def _inventory_count(observation: Observation, selector: str) -> int:
    query = selector.lower().removeprefix("minecraft:").replace("-", "_").replace(" ", "_")
    if query.endswith("s") and query not in {"planks", "glass", "grass"}:
        query = query[:-1]
    total = 0
    for item in observation.inventory:
        name = str(item.get("id") or item.get("name") or "").lower().removeprefix("minecraft:")
        matches = name == query or query in name
        if query == "wood":
            matches = name.endswith("_log") or name.endswith("_wood") or name.endswith("_stem") or name.endswith("_hyphae")
        elif query == "log":
            matches = name.endswith("_log") or name.endswith("_stem")
        if matches:
            total += max(0, int(item.get("count", 0)))
    return total


def _server_effect_visible(command: ActionCommand, result: ActionResult,
                           before: Observation, after: Observation) -> bool:
    parameters = command.parameters
    if command.kind in {ActionKind.COLLECT, ActionKind.ACQUIRE, ActionKind.CRAFT, ActionKind.SMELT}:
        selector = parameters.get("output") or parameters.get("selector") or parameters.get("item") or parameters.get("recipe")
        if selector:
            expected = int(parameters.get("count", 1))
            return _inventory_count(after, str(selector)) - _inventory_count(before, str(selector)) >= expected
    if command.kind == ActionKind.PLACE:
        placed = next((effect.get("value") for effect in result.actual_effects if effect.get("path") == "world.block"), None)
        if not isinstance(placed, Mapping) or not isinstance(placed.get("position"), Mapping):
            return False
        position = placed["position"]
        return any(block.get("id") == placed.get("id") and all(
            (block.get("position", {}) if isinstance(block.get("position"), Mapping) else block).get(axis) == position.get(axis)
            for axis in ("x", "y", "z")) for block in after.nearby_blocks)
    if command.kind == ActionKind.BUILD_PORTAL:
        return any(str(block.get("id", "")).endswith(":nether_portal") for block in after.nearby_blocks)
    if command.kind == ActionKind.TRAVEL:
        requested = str(parameters.get("dimension", "")).lower().removeprefix("minecraft:")
        target = "the_nether" if requested in {"nether", "the_nether"} else "the_end" if requested == "end" else "overworld"
        current = str(after.player.get("dimension") or after.environment.get("dimension") or "").lower().removeprefix("minecraft:")
        return current == target
    if command.kind == ActionKind.ATTACK:
        return int(after.player.get("mobKills", 0)) > int(before.player.get("mobKills", 0))
    if command.kind == ActionKind.NAVIGATE and isinstance(parameters.get("target"), Mapping):
        target = parameters["target"]
        position = after.player.get("position", {})
        if all(isinstance(target.get(axis), (int, float)) and isinstance(position.get(axis), (int, float)) for axis in ("x", "y", "z")):
            distance = sum((float(position[axis]) - float(target[axis])) ** 2 for axis in ("x", "y", "z")) ** 0.5
            return distance <= float(parameters.get("range", 1)) + 0.75
    return True
