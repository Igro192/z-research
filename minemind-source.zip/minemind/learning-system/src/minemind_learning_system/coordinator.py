from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

from .bandit import ContextualBandit, LinearValueModel
from .replay import PrioritizedReplayBuffer
from .transition import Transition


@dataclass(frozen=True, slots=True)
class LearningUpdate:
    td_error: float
    replay_size: int
    skill_updated: str | None


class LearningCoordinator:
    """Low-cost online updates; heavyweight replay training runs separately."""

    def __init__(
        self,
        replay: PrioritizedReplayBuffer,
        bandit: ContextualBandit,
        value: LinearValueModel,
    ) -> None:
        self.replay = replay
        self.bandit = bandit
        self.value = value

    def learn_transition(
        self,
        transition: Transition,
        state_features: Sequence[float],
        next_state_features: Sequence[float],
    ) -> LearningUpdate:
        td_error = self.value.update(
            state_features, transition.reward, next_state_features, transition.terminal
        )
        self.replay.add(transition, td_error)
        if transition.selected_skill:
            self.bandit.update(transition.selected_skill, state_features, transition.reward)
        return LearningUpdate(td_error, len(self.replay), transition.selected_skill)

