from __future__ import annotations

import json
import math
import random
import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from .transition import Transition


@dataclass(frozen=True, slots=True)
class ReplaySample:
    transition: Transition
    probability: float
    importance_weight: float


class PrioritizedReplayBuffer:
    """Persistent proportional prioritized replay with bounded FIFO capacity."""

    def __init__(
        self,
        database: str | Path,
        *,
        capacity: int = 250_000,
        alpha: float = 0.6,
        epsilon: float = 1e-3,
        seed: int = 0,
    ) -> None:
        if capacity < 1 or not 0 <= alpha <= 1 or epsilon <= 0:
            raise ValueError("invalid replay configuration")
        self.database = str(database)
        self.capacity = capacity
        self.alpha = alpha
        self.epsilon = epsilon
        self._random = random.Random(seed)
        self._local = threading.local()
        self._migrate()

    def _connection(self) -> sqlite3.Connection:
        connection = getattr(self._local, "connection", None)
        if connection is None:
            connection = sqlite3.connect(self.database, timeout=10, isolation_level=None)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA journal_mode=WAL")
            self._local.connection = connection
        return connection

    def _migrate(self) -> None:
        self._connection().executescript(
            """
            CREATE TABLE IF NOT EXISTS replay_schema_version(version INTEGER PRIMARY KEY);
            INSERT OR IGNORE INTO replay_schema_version(version) VALUES(1);
            CREATE TABLE IF NOT EXISTS replay(
                sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                transition_id TEXT NOT NULL UNIQUE,
                payload_json TEXT NOT NULL,
                priority REAL NOT NULL CHECK(priority > 0),
                inserted_at REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS replay_priority ON replay(priority);
            """
        )

    def add(self, transition: Transition, td_error: float | None = None) -> None:
        connection = self._connection()
        if td_error is None:
            row = connection.execute("SELECT MAX(priority) AS value FROM replay").fetchone()
            priority = max(self.epsilon, float(row["value"] or 1.0))
        else:
            priority = (abs(td_error) + self.epsilon) ** self.alpha
        connection.execute(
            """INSERT INTO replay(transition_id,payload_json,priority,inserted_at) VALUES(?,?,?,?)
               ON CONFLICT(transition_id) DO UPDATE SET payload_json=excluded.payload_json,
                 priority=excluded.priority""",
            (transition.transition_id, json.dumps(transition.to_dict(), sort_keys=True), priority, time.time()),
        )
        overflow = len(self) - self.capacity
        if overflow > 0:
            connection.execute(
                "DELETE FROM replay WHERE sequence IN (SELECT sequence FROM replay ORDER BY sequence LIMIT ?)",
                (overflow,),
            )

    def sample(self, batch_size: int, *, beta: float = 0.4) -> tuple[ReplaySample, ...]:
        if batch_size < 1 or not 0 <= beta <= 1:
            raise ValueError("invalid sample configuration")
        rows = self._connection().execute("SELECT * FROM replay ORDER BY sequence").fetchall()
        if not rows:
            return ()
        total = sum(float(row["priority"]) for row in rows)
        probabilities = [float(row["priority"]) / total for row in rows]
        selected: list[int] = []
        available = list(range(len(rows)))
        available_weights = list(probabilities)
        for _ in range(min(batch_size, len(rows))):
            choice = self._random.choices(available, weights=available_weights, k=1)[0]
            at = available.index(choice)
            selected.append(choice)
            available.pop(at)
            available_weights.pop(at)
        raw_weights = [(len(rows) * probabilities[index]) ** (-beta) for index in selected]
        maximum = max(raw_weights)
        return tuple(
            ReplaySample(
                Transition.from_dict(json.loads(rows[index]["payload_json"])),
                probabilities[index],
                raw_weight / maximum,
            )
            for index, raw_weight in zip(selected, raw_weights, strict=True)
        )

    def update_priorities(self, transition_ids: Sequence[str], td_errors: Sequence[float]) -> None:
        if len(transition_ids) != len(td_errors):
            raise ValueError("transition ids and errors must have the same length")
        connection = self._connection()
        connection.execute("BEGIN IMMEDIATE")
        try:
            for transition_id, error in zip(transition_ids, td_errors, strict=True):
                priority = (abs(error) + self.epsilon) ** self.alpha
                cursor = connection.execute(
                    "UPDATE replay SET priority=? WHERE transition_id=?", (priority, transition_id)
                )
                if cursor.rowcount != 1:
                    raise KeyError(f"unknown replay transition {transition_id}")
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise

    def __len__(self) -> int:
        return int(self._connection().execute("SELECT COUNT(*) FROM replay").fetchone()[0])

    @property
    def priority_mass(self) -> float:
        return float(self._connection().execute("SELECT COALESCE(SUM(priority),0) FROM replay").fetchone()[0])

    def close(self) -> None:
        connection = getattr(self._local, "connection", None)
        if connection is not None:
            connection.close()
            self._local.connection = None

    def __enter__(self) -> "PrioritizedReplayBuffer":
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()
