from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class Transition:
    objective: str
    subgoal: str
    before_state: Mapping[str, Any]
    before_uncertainty: Mapping[str, float]
    retrieved_memory_ids: tuple[str, ...]
    selected_skill: str | None
    proposed_alternatives: tuple[str, ...]
    predicted_result: Mapping[str, Any]
    action: Mapping[str, Any]
    actual_result: Mapping[str, Any]
    reward_components: Mapping[str, float]
    next_state: Mapping[str, Any]
    terminal: bool
    achieved_goals: tuple[str, ...] = ()
    errors: tuple[str, ...] = ()
    recovery: tuple[str, ...] = ()
    resource_cost: float = 0.0
    time_cost_seconds: float = 0.0
    user_feedback: float | None = None
    verification_result: bool | None = None
    novel_discoveries: tuple[str, ...] = ()
    provenance: Mapping[str, Any] = field(default_factory=dict)
    reward_schema_version: str = "1.0.0"
    transition_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: float = field(default_factory=time.time)

    @property
    def reward(self) -> float:
        return float(sum(self.reward_components.values()))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "Transition":
        converted = dict(raw)
        for key in (
            "retrieved_memory_ids",
            "proposed_alternatives",
            "achieved_goals",
            "errors",
            "recovery",
            "novel_discoveries",
        ):
            converted[key] = tuple(converted.get(key, ()))
        return cls(**converted)
