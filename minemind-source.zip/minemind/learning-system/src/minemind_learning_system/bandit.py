from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Mapping, Sequence


Vector = Sequence[float]


def _check(features: Vector, dimensions: int) -> None:
    if len(features) != dimensions:
        raise ValueError(f"expected {dimensions} features, received {len(features)}")
    if not all(math.isfinite(float(value)) for value in features):
        raise ValueError("features must be finite")


@dataclass(slots=True)
class _Arm:
    precision: list[float]
    reward_sum: list[float]
    pulls: int = 0


class ContextualBandit:
    """Diagonal LinUCB skill selector with online, uncertainty-aware updates."""

    def __init__(self, dimensions: int, exploration: float = 0.8, regularization: float = 1.0) -> None:
        if dimensions < 1 or exploration < 0 or regularization <= 0:
            raise ValueError("invalid bandit configuration")
        self.dimensions = dimensions
        self.exploration = exploration
        self.regularization = regularization
        self.arms: dict[str, _Arm] = {}

    def _arm(self, name: str) -> _Arm:
        return self.arms.setdefault(
            name,
            _Arm([self.regularization] * self.dimensions, [0.0] * self.dimensions),
        )

    def score(self, name: str, features: Vector) -> float:
        _check(features, self.dimensions)
        arm = self._arm(name)
        estimate = sum(
            (arm.reward_sum[i] / arm.precision[i]) * float(features[i]) for i in range(self.dimensions)
        )
        uncertainty = math.sqrt(
            sum(float(features[i]) ** 2 / arm.precision[i] for i in range(self.dimensions))
        )
        return estimate + self.exploration * uncertainty

    def select(self, candidates: Sequence[str], features: Vector) -> str:
        if not candidates:
            raise ValueError("skill selection requires candidates")
        return max(sorted(set(candidates)), key=lambda name: self.score(name, features))

    def update(self, name: str, features: Vector, reward: float, weight: float = 1.0) -> None:
        _check(features, self.dimensions)
        if weight <= 0 or not math.isfinite(reward):
            raise ValueError("invalid bandit update")
        arm = self._arm(name)
        for index, feature in enumerate(features):
            value = float(feature)
            arm.precision[index] += weight * value * value
            arm.reward_sum[index] += weight * reward * value
        arm.pulls += 1

    def state_dict(self) -> dict[str, object]:
        return {
            "dimensions": self.dimensions,
            "exploration": self.exploration,
            "regularization": self.regularization,
            "arms": {
                name: {"precision": arm.precision, "reward_sum": arm.reward_sum, "pulls": arm.pulls}
                for name, arm in self.arms.items()
            },
        }


class LinearValueModel:
    """Small trainable TD(0) value estimator suitable for online updates."""

    def __init__(self, dimensions: int, learning_rate: float = 0.02, discount: float = 0.99, l2: float = 1e-5) -> None:
        if dimensions < 1 or learning_rate <= 0 or not 0 <= discount <= 1 or l2 < 0:
            raise ValueError("invalid value model configuration")
        self.dimensions = dimensions
        self.learning_rate = learning_rate
        self.discount = discount
        self.l2 = l2
        self.weights = [0.0] * dimensions
        self.updates = 0

    def predict(self, features: Vector) -> float:
        _check(features, self.dimensions)
        return sum(weight * float(value) for weight, value in zip(self.weights, features, strict=True))

    def update(
        self,
        features: Vector,
        reward: float,
        next_features: Vector,
        terminal: bool,
        *,
        importance_weight: float = 1.0,
    ) -> float:
        _check(features, self.dimensions)
        _check(next_features, self.dimensions)
        prediction = self.predict(features)
        target = reward if terminal else reward + self.discount * self.predict(next_features)
        error = target - prediction
        for index, value in enumerate(features):
            gradient = error * float(value) - self.l2 * self.weights[index]
            self.weights[index] += self.learning_rate * importance_weight * gradient
        self.updates += 1
        return error

    def state_dict(self) -> dict[str, object]:
        return {"weights": self.weights, "updates": self.updates, "discount": self.discount}


class PreferenceLearner:
    """Online Bradley-Terry reward model for explicit pairwise user feedback."""

    def __init__(self, dimensions: int, learning_rate: float = 0.05, l2: float = 1e-4) -> None:
        self.dimensions = dimensions
        self.learning_rate = learning_rate
        self.l2 = l2
        self.weights = [0.0] * dimensions

    def score(self, features: Vector) -> float:
        _check(features, self.dimensions)
        return sum(a * float(b) for a, b in zip(self.weights, features, strict=True))

    def update(self, preferred: Vector, rejected: Vector) -> float:
        _check(preferred, self.dimensions)
        _check(rejected, self.dimensions)
        difference = [float(a) - float(b) for a, b in zip(preferred, rejected, strict=True)]
        logit = sum(weight * delta for weight, delta in zip(self.weights, difference, strict=True))
        probability = 1.0 / (1.0 + math.exp(-max(-40.0, min(40.0, logit))))
        for index, delta in enumerate(difference):
            self.weights[index] += self.learning_rate * ((1.0 - probability) * delta - self.l2 * self.weights[index])
        return -math.log(max(probability, 1e-12))

