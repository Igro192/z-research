from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence


@dataclass(frozen=True, slots=True)
class Checkpoint:
    checkpoint_id: str
    component: str
    state: Mapping[str, object]
    training_steps: int
    parent_id: str | None
    stage: str
    created_at: float


@dataclass(frozen=True, slots=True)
class PromotionDecision:
    promoted: bool
    candidate_mean: float
    champion_mean: float | None
    mean_improvement: float
    worst_regression: float
    reason: str


class CheckpointManager:
    """Transactional champion/challenger gate with per-seed regression protection."""

    def __init__(self, database: str | Path) -> None:
        self.database = str(database)
        self._local = threading.local()
        self._migrate()

    def _connection(self) -> sqlite3.Connection:
        connection = getattr(self._local, "connection", None)
        if connection is None:
            connection = sqlite3.connect(self.database, timeout=10, isolation_level=None)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA journal_mode=WAL")
            self._local.connection = connection
        return connection

    def _migrate(self) -> None:
        self._connection().executescript(
            """
            CREATE TABLE IF NOT EXISTS checkpoint_schema_version(version INTEGER PRIMARY KEY);
            INSERT OR IGNORE INTO checkpoint_schema_version(version) VALUES(1);
            CREATE TABLE IF NOT EXISTS checkpoints(
              checkpoint_id TEXT PRIMARY KEY,
              component TEXT NOT NULL,
              state_json TEXT NOT NULL,
              training_steps INTEGER NOT NULL,
              parent_id TEXT,
              stage TEXT NOT NULL,
              created_at REAL NOT NULL,
              updated_at REAL NOT NULL,
              FOREIGN KEY(parent_id) REFERENCES checkpoints(checkpoint_id)
            );
            CREATE UNIQUE INDEX IF NOT EXISTS champion_per_component
              ON checkpoints(component) WHERE stage='champion';
            CREATE TABLE IF NOT EXISTS checkpoint_evaluations(
              checkpoint_id TEXT NOT NULL,
              suite TEXT NOT NULL,
              seed INTEGER NOT NULL,
              score REAL NOT NULL,
              measured_at REAL NOT NULL,
              PRIMARY KEY(checkpoint_id,suite,seed),
              FOREIGN KEY(checkpoint_id) REFERENCES checkpoints(checkpoint_id)
            );
            """
        )
        self._migrate_legacy_evaluations(self._connection())

    @staticmethod
    def _migrate_legacy_evaluations(connection: sqlite3.Connection) -> None:
        columns = {
            str(row[1]) for row in connection.execute("PRAGMA table_info(evaluations)").fetchall()
        }
        expected = {"checkpoint_id", "suite", "seed", "score", "measured_at"}
        if expected.issubset(columns):
            connection.execute(
                """INSERT OR IGNORE INTO checkpoint_evaluations(
                     checkpoint_id,suite,seed,score,measured_at
                   ) SELECT checkpoint_id,suite,seed,score,measured_at FROM evaluations"""
            )

    def create(self, component: str, state: Mapping[str, object], training_steps: int) -> Checkpoint:
        champion = self.champion(component)
        checkpoint_id = str(uuid.uuid4())
        now = time.time()
        self._connection().execute(
            "INSERT INTO checkpoints VALUES(?,?,?,?,?,?,?,?)",
            (
                checkpoint_id, component, json.dumps(state, sort_keys=True), training_steps,
                champion.checkpoint_id if champion else None, "challenger", now, now,
            ),
        )
        return self.get(checkpoint_id)

    def record_evaluation(self, checkpoint_id: str, suite: str, seed_scores: Mapping[int, float]) -> None:
        if not seed_scores:
            raise ValueError("evaluation must contain seeded scores")
        connection = self._connection()
        connection.execute("BEGIN IMMEDIATE")
        try:
            for seed, score in seed_scores.items():
                connection.execute(
                    """INSERT INTO checkpoint_evaluations(checkpoint_id,suite,seed,score,measured_at) VALUES(?,?,?,?,?)
                       ON CONFLICT(checkpoint_id,suite,seed) DO UPDATE SET score=excluded.score,measured_at=excluded.measured_at""",
                    (checkpoint_id, suite, int(seed), float(score), time.time()),
                )
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise

    def consider_promotion(
        self,
        checkpoint_id: str,
        suite: str,
        *,
        minimum_improvement: float = 0.01,
        maximum_seed_regression: float = 0.1,
        minimum_seeds: int = 3,
    ) -> PromotionDecision:
        candidate = self.get(checkpoint_id)
        candidate_scores = self._scores(checkpoint_id, suite)
        if len(candidate_scores) < minimum_seeds:
            return PromotionDecision(False, self._mean(candidate_scores), None, 0.0, 0.0, "insufficient seeded evaluations")
        champion = self.champion(candidate.component)
        if champion is None:
            decision = PromotionDecision(True, self._mean(candidate_scores), None, float("inf"), 0.0, "first validated champion")
            self._promote(candidate)
            return decision
        champion_scores = self._scores(champion.checkpoint_id, suite)
        common = sorted(set(candidate_scores) & set(champion_scores))
        if len(common) < minimum_seeds:
            return PromotionDecision(False, self._mean(candidate_scores), self._mean(champion_scores), 0.0, 0.0, "champion and challenger lack paired seeds")
        improvements = [candidate_scores[seed] - champion_scores[seed] for seed in common]
        mean_improvement = sum(improvements) / len(improvements)
        worst_regression = min(improvements)
        promoted = mean_improvement >= minimum_improvement and worst_regression >= -maximum_seed_regression
        reason = "measurable improvement without excessive regression" if promoted else "challenger failed improvement or regression threshold"
        decision = PromotionDecision(
            promoted,
            self._mean(candidate_scores),
            self._mean(champion_scores),
            mean_improvement,
            worst_regression,
            reason,
        )
        if promoted:
            self._promote(candidate)
        else:
            self._connection().execute(
                "UPDATE checkpoints SET stage='rejected',updated_at=? WHERE checkpoint_id=?",
                (time.time(), checkpoint_id),
            )
        return decision

    def rollback(self, component: str) -> Checkpoint:
        champion = self.champion(component)
        if not champion or not champion.parent_id:
            raise LookupError(f"no rollback checkpoint for {component}")
        parent = self.get(champion.parent_id)
        connection = self._connection()
        connection.execute("BEGIN IMMEDIATE")
        try:
            connection.execute(
                "UPDATE checkpoints SET stage='rolled_back',updated_at=? WHERE checkpoint_id=?",
                (time.time(), champion.checkpoint_id),
            )
            connection.execute(
                "UPDATE checkpoints SET stage='champion',updated_at=? WHERE checkpoint_id=?",
                (time.time(), parent.checkpoint_id),
            )
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise
        return self.get(parent.checkpoint_id)

    def audit_and_rollback(
        self,
        component: str,
        suite: str,
        *,
        maximum_mean_regression: float = 0.05,
        minimum_paired_seeds: int = 3,
    ) -> Checkpoint | None:
        """Atomically restores the parent when the live champion measurably regresses."""
        champion = self.champion(component)
        if not champion or not champion.parent_id:
            return None
        current = self._scores(champion.checkpoint_id, suite)
        parent = self._scores(champion.parent_id, suite)
        common = set(current) & set(parent)
        if len(common) < minimum_paired_seeds:
            return None
        mean_delta = sum(current[seed] - parent[seed] for seed in common) / len(common)
        if mean_delta < -maximum_mean_regression:
            return self.rollback(component)
        return None

    def champion(self, component: str) -> Checkpoint | None:
        row = self._connection().execute(
            "SELECT * FROM checkpoints WHERE component=? AND stage='champion'", (component,)
        ).fetchone()
        return self._decode(row) if row else None

    def get(self, checkpoint_id: str) -> Checkpoint:
        row = self._connection().execute(
            "SELECT * FROM checkpoints WHERE checkpoint_id=?", (checkpoint_id,)
        ).fetchone()
        if not row:
            raise KeyError(f"unknown checkpoint {checkpoint_id}")
        return self._decode(row)

    def _promote(self, candidate: Checkpoint) -> None:
        connection = self._connection()
        connection.execute("BEGIN IMMEDIATE")
        try:
            connection.execute(
                "UPDATE checkpoints SET stage='archived',updated_at=? WHERE component=? AND stage='champion'",
                (time.time(), candidate.component),
            )
            connection.execute(
                "UPDATE checkpoints SET stage='champion',updated_at=? WHERE checkpoint_id=?",
                (time.time(), candidate.checkpoint_id),
            )
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise

    def _scores(self, checkpoint_id: str, suite: str) -> dict[int, float]:
        rows = self._connection().execute(
            "SELECT seed,score FROM checkpoint_evaluations WHERE checkpoint_id=? AND suite=?", (checkpoint_id, suite)
        ).fetchall()
        return {int(row["seed"]): float(row["score"]) for row in rows}

    @staticmethod
    def _mean(scores: Mapping[int, float]) -> float:
        return sum(scores.values()) / len(scores) if scores else 0.0

    @staticmethod
    def _decode(row: sqlite3.Row) -> Checkpoint:
        return Checkpoint(
            str(row["checkpoint_id"]), str(row["component"]), json.loads(row["state_json"]),
            int(row["training_steps"]), row["parent_id"], str(row["stage"]), float(row["created_at"]),
        )

    def close(self) -> None:
        connection = getattr(self._local, "connection", None)
        if connection is not None:
            connection.close()
            self._local.connection = None

    def __enter__(self) -> "CheckpointManager":
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()
