from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Mapping


@dataclass(frozen=True, slots=True)
class RewardSignals:
    task_progress: float = 0.0
    task_completion: bool = False
    novelty: float = 0.0
    information_gain: float = 0.0
    competence_improvement: float = 0.0
    prediction_error_before: float = 0.0
    prediction_error_after: float = 0.0
    died: bool = False
    damage: float = 0.0
    resources_lost: float = 0.0
    repeated_action: bool = False
    unsafe_action: bool = False
    unnecessary_actions: int = 0
    false_success_claim: bool = False
    user_feedback: float = 0.0


@dataclass(frozen=True, slots=True)
class RewardComponents:
    extrinsic: float
    novelty: float
    information_gain: float
    competence: float
    prediction_error_reduction: float
    user_preference: float
    death_penalty: float
    damage_penalty: float
    resource_penalty: float
    repetition_penalty: float
    unsafe_penalty: float
    inefficiency_penalty: float
    false_success_penalty: float

    @property
    def total(self) -> float:
        return sum(asdict(self).values())

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


class RewardCalculator:
    DEFAULT_WEIGHTS: Mapping[str, float] = {
        "task_progress": 2.0,
        "task_completion": 20.0,
        "novelty": 0.4,
        "information_gain": 0.7,
        "competence": 1.0,
        "prediction_error_reduction": 0.6,
        "user_feedback": 2.0,
        "death": -20.0,
        "damage": -0.4,
        "resources_lost": -0.2,
        "repetition": -0.5,
        "unsafe": -5.0,
        "unnecessary_action": -0.05,
        "false_success": -15.0,
    }

    def __init__(self, weights: Mapping[str, float] | None = None) -> None:
        self.weights = dict(self.DEFAULT_WEIGHTS)
        if weights:
            self.weights.update(weights)

    def calculate(self, signals: RewardSignals) -> RewardComponents:
        reduction = signals.prediction_error_before - signals.prediction_error_after
        return RewardComponents(
            extrinsic=self.weights["task_progress"] * signals.task_progress
            + self.weights["task_completion"] * float(signals.task_completion),
            novelty=self.weights["novelty"] * max(0.0, signals.novelty),
            information_gain=self.weights["information_gain"] * max(0.0, signals.information_gain),
            competence=self.weights["competence"] * signals.competence_improvement,
            prediction_error_reduction=self.weights["prediction_error_reduction"] * reduction,
            user_preference=self.weights["user_feedback"] * signals.user_feedback,
            death_penalty=self.weights["death"] * float(signals.died),
            damage_penalty=self.weights["damage"] * max(0.0, signals.damage),
            resource_penalty=self.weights["resources_lost"] * max(0.0, signals.resources_lost),
            repetition_penalty=self.weights["repetition"] * float(signals.repeated_action),
            unsafe_penalty=self.weights["unsafe"] * float(signals.unsafe_action),
            inefficiency_penalty=self.weights["unnecessary_action"] * max(0, signals.unnecessary_actions),
            false_success_penalty=self.weights["false_success"] * float(signals.false_success_claim),
        )

