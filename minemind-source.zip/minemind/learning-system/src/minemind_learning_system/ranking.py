from __future__ import annotations

import math
from typing import Mapping, Sequence


def _validate(features: Sequence[float], dimensions: int) -> list[float]:
    if len(features) != dimensions:
        raise ValueError(f"expected {dimensions} features")
    result = [float(value) for value in features]
    if not all(math.isfinite(value) for value in result):
        raise ValueError("features must be finite")
    return result


class PlanRanker:
    """Online pairwise plan ranker trained from verified outcomes or imitation."""

    def __init__(self, dimensions: int, learning_rate: float = 0.03, l2: float = 1e-4) -> None:
        self.dimensions = dimensions
        self.learning_rate = learning_rate
        self.l2 = l2
        self.weights = [0.0] * dimensions
        self.examples = 0

    def score(self, features: Sequence[float]) -> float:
        values = _validate(features, self.dimensions)
        return sum(weight * value for weight, value in zip(self.weights, values, strict=True))

    def rank(self, candidates: Mapping[str, Sequence[float]]) -> tuple[str, ...]:
        return tuple(sorted(candidates, key=lambda key: (-self.score(candidates[key]), key)))

    def update_pair(self, better: Sequence[float], worse: Sequence[float], weight: float = 1.0) -> float:
        positive = _validate(better, self.dimensions)
        negative = _validate(worse, self.dimensions)
        delta = [a - b for a, b in zip(positive, negative, strict=True)]
        logit = max(-40.0, min(40.0, sum(w * x for w, x in zip(self.weights, delta, strict=True))))
        probability = 1.0 / (1.0 + math.exp(-logit))
        for index, value in enumerate(delta):
            gradient = weight * (1.0 - probability) * value - self.l2 * self.weights[index]
            self.weights[index] += self.learning_rate * gradient
        self.examples += 1
        return -math.log(max(probability, 1e-12))

    def state_dict(self) -> dict[str, object]:
        return {"weights": self.weights, "examples": self.examples}


class FailurePredictor:
    """Calibratable online logistic predictor for action/plan failure risk."""

    def __init__(self, dimensions: int, learning_rate: float = 0.02, l2: float = 1e-4) -> None:
        self.dimensions = dimensions
        self.learning_rate = learning_rate
        self.l2 = l2
        self.weights = [0.0] * dimensions
        self.bias = 0.0
        self.examples = 0

    def probability(self, features: Sequence[float]) -> float:
        values = _validate(features, self.dimensions)
        logit = max(-40.0, min(40.0, self.bias + sum(w * x for w, x in zip(self.weights, values, strict=True))))
        return 1.0 / (1.0 + math.exp(-logit))

    def update(self, features: Sequence[float], failed: bool, weight: float = 1.0) -> float:
        values = _validate(features, self.dimensions)
        probability = self.probability(values)
        target = float(failed)
        error = target - probability
        for index, value in enumerate(values):
            self.weights[index] += self.learning_rate * (weight * error * value - self.l2 * self.weights[index])
        self.bias += self.learning_rate * weight * error
        self.examples += 1
        return -(target * math.log(max(probability, 1e-12)) + (1 - target) * math.log(max(1 - probability, 1e-12)))

    def state_dict(self) -> dict[str, object]:
        return {"weights": self.weights, "bias": self.bias, "examples": self.examples}

