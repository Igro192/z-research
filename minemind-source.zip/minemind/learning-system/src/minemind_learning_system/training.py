from __future__ import annotations

from dataclasses import replace
from typing import Callable, Mapping, Sequence

from .bandit import LinearValueModel
from .replay import PrioritizedReplayBuffer
from .transition import Transition


FeatureEncoder = Callable[[Mapping[str, object]], Sequence[float]]


def hindsight_relabel(transition: Transition) -> tuple[Transition, ...]:
    """HER: treat each actually achieved goal as the intended subgoal.

    Relabeled experiences receive completion reward but retain all original costs
    and penalties, preventing hindsight from erasing unsafe behavior.
    """

    result: list[Transition] = []
    for achieved in transition.achieved_goals:
        if achieved == transition.subgoal:
            continue
        components = dict(transition.reward_components)
        components["hindsight_completion"] = 1.0
        result.append(
            replace(
                transition,
                subgoal=achieved,
                reward_components=components,
                verification_result=True,
                transition_id=f"{transition.transition_id}:her:{len(result)}",
            )
        )
    return tuple(result)


class OfflineTrainer:
    """Runs replay-based value learning asynchronously from the game control loop."""

    def __init__(self, replay: PrioritizedReplayBuffer, model: LinearValueModel, encoder: FeatureEncoder) -> None:
        self.replay = replay
        self.model = model
        self.encoder = encoder

    def train(self, *, batches: int, batch_size: int, beta: float = 0.6) -> Mapping[str, float]:
        errors: list[float] = []
        examples = 0
        for _ in range(batches):
            samples = self.replay.sample(batch_size, beta=beta)
            if not samples:
                break
            ids: list[str] = []
            batch_errors: list[float] = []
            for sample in samples:
                transition = sample.transition
                error = self.model.update(
                    self.encoder(transition.before_state),
                    transition.reward,
                    self.encoder(transition.next_state),
                    transition.terminal,
                    importance_weight=sample.importance_weight,
                )
                ids.append(transition.transition_id)
                batch_errors.append(error)
                errors.append(abs(error))
                examples += 1
            self.replay.update_priorities(ids, batch_errors)
        return {
            "examples": float(examples),
            "mean_absolute_td_error": sum(errors) / len(errors) if errors else 0.0,
        }

    def ingest_demonstrations(self, demonstrations: Sequence[Transition], *, priority_boost: float = 2.0) -> int:
        """Imitation hook: successful verified plans enter replay at higher priority."""
        accepted = 0
        for transition in demonstrations:
            if transition.verification_result is True and transition.reward > 0:
                self.replay.add(transition, td_error=max(priority_boost, abs(transition.reward)))
                accepted += 1
        return accepted

