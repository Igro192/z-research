import sqlite3
import tempfile
import unittest
from pathlib import Path

from minemind_learning_system import CheckpointManager, PrioritizedReplayBuffer
from minemind_memory_system import MemoryStore
from minemind_skill_engine import BehaviorNode, NodeKind, SkillManifest, SkillStore


class SharedDatabaseTest(unittest.TestCase):
    def test_components_use_independent_schema_and_evaluation_tables(self):
        with tempfile.TemporaryDirectory() as directory:
            database = Path(directory) / "runtime.sqlite3"
            with MemoryStore(database) as memory, SkillStore(database) as skills, PrioritizedReplayBuffer(database) as replay, CheckpointManager(database) as checkpoints:
                manifest = SkillManifest(
                    skill_id="shared.database",
                    version="1.0.0",
                    purpose="Verify shared database migrations",
                    applicability="True",
                    parameters={},
                    required_resources=(),
                    expected_effects=(),
                    root=BehaviorNode(NodeKind.SUCCEED, "done"),
                    safety_constraints=(),
                )
                skills.put(manifest)
                skills.record_evaluation(manifest.skill_id, manifest.version, {
                    "success_rate": 1.0,
                    "safety_rate": 1.0,
                    "mean_actions": 0.0,
                    "mean_cost": 0.0,
                })
                checkpoint = checkpoints.create("value", {"weights": [0.0]}, 1)
                checkpoints.record_evaluation(checkpoint.checkpoint_id, "shared", {1: 0.5})
                self.assertEqual(len(replay), 0)

            connection = sqlite3.connect(database)
            try:
                tables = {
                    row[0]
                    for row in connection.execute(
                        "SELECT name FROM sqlite_master WHERE type='table'"
                    )
                }
                self.assertNotIn("schema_version", tables)
                self.assertTrue({
                    "memory_schema_version",
                    "skill_schema_version",
                    "replay_schema_version",
                    "checkpoint_schema_version",
                    "skill_evaluations",
                    "checkpoint_evaluations",
                }.issubset(tables))
                self.assertEqual(connection.execute("SELECT COUNT(*) FROM skill_evaluations").fetchone()[0], 1)
                self.assertEqual(connection.execute("SELECT COUNT(*) FROM checkpoint_evaluations").fetchone()[0], 1)
            finally:
                connection.close()


if __name__ == "__main__":
    unittest.main()
