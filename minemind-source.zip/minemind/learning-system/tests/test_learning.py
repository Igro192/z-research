import tempfile
import unittest
from pathlib import Path

from minemind_learning_system import (
    CheckpointManager,
    ContextualBandit,
    LearningCoordinator,
    LinearValueModel,
    OfflineTrainer,
    FailurePredictor,
    PlanRanker,
    PreferenceLearner,
    PrioritizedReplayBuffer,
    RewardCalculator,
    RewardSignals,
    Transition,
    hindsight_relabel,
)


def transition(index=0, *, achieved=(), selected="mine"):
    reward = RewardCalculator().calculate(RewardSignals(task_progress=0.5, novelty=0.2)).to_dict()
    return Transition(
        objective="obtain resource",
        subgoal="get stone",
        before_state={"x": float(index)},
        before_uncertainty={"x": 0.1},
        retrieved_memory_ids=(),
        selected_skill=selected,
        proposed_alternatives=("explore",),
        predicted_result={"stone": 1},
        action={"kind": "skill", "id": selected},
        actual_result={"stone": 1},
        reward_components=reward,
        next_state={"x": float(index + 1)},
        terminal=False,
        achieved_goals=tuple(achieved),
        verification_result=True,
    )


class LearningTest(unittest.TestCase):
    def test_reward_has_real_penalties(self):
        reward = RewardCalculator().calculate(RewardSignals(task_completion=True, died=True, false_success_claim=True))
        self.assertLess(reward.death_penalty, 0)
        self.assertLess(reward.false_success_penalty, 0)
        self.assertNotEqual(reward.total, reward.extrinsic)

    def test_replay_online_and_offline_learning(self):
        with tempfile.TemporaryDirectory() as directory:
            replay = PrioritizedReplayBuffer(Path(directory) / "replay.sqlite3", seed=3)
            self.addCleanup(replay.close)
            value = LinearValueModel(1, learning_rate=0.05)
            bandit = ContextualBandit(1)
            coordinator = LearningCoordinator(replay, bandit, value)
            for index in range(6):
                coordinator.learn_transition(transition(index), [float(index + 1)], [float(index + 2)])
            self.assertEqual(len(replay), 6)
            self.assertEqual(bandit.arms["mine"].pulls, 6)
            trainer = OfflineTrainer(replay, value, lambda state: [float(state["x"]) + 1.0])
            metrics = trainer.train(batches=2, batch_size=3)
            self.assertEqual(metrics["examples"], 6.0)

    def test_hindsight_and_preference_learning(self):
        relabeled = hindsight_relabel(transition(achieved=("found cave",)))
        self.assertEqual(relabeled[0].subgoal, "found cave")
        learner = PreferenceLearner(2)
        initial = learner.score([1, 0])
        for _ in range(10):
            learner.update([1, 0], [0, 1])
        self.assertGreater(learner.score([1, 0]), initial)
        ranker = PlanRanker(2)
        for _ in range(10):
            ranker.update_pair([1, 0], [0, 1])
        self.assertEqual(ranker.rank({"good": [1, 0], "bad": [0, 1]})[0], "good")
        failure = FailurePredictor(1)
        before = failure.probability([1])
        for _ in range(10):
            failure.update([1], True)
        self.assertGreater(failure.probability([1]), before)

    def test_champion_challenger_and_rollback(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = CheckpointManager(Path(directory) / "checkpoints.sqlite3")
            self.addCleanup(manager.close)
            first = manager.create("value", {"weights": [0]}, 10)
            manager.record_evaluation(first.checkpoint_id, "regression", {1: 0.5, 2: 0.5, 3: 0.5})
            self.assertTrue(manager.consider_promotion(first.checkpoint_id, "regression").promoted)
            second = manager.create("value", {"weights": [1]}, 20)
            manager.record_evaluation(second.checkpoint_id, "regression", {1: 0.7, 2: 0.7, 3: 0.7})
            self.assertTrue(manager.consider_promotion(second.checkpoint_id, "regression").promoted)
            self.assertEqual(manager.rollback("value").checkpoint_id, first.checkpoint_id)

    def test_live_checkpoint_regression_auto_rolls_back(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = CheckpointManager(Path(directory) / "checkpoints.sqlite3")
            self.addCleanup(manager.close)
            first = manager.create("policy", {"weights": [0]}, 10)
            manager.record_evaluation(first.checkpoint_id, "suite", {1: 0.5, 2: 0.5, 3: 0.5})
            manager.consider_promotion(first.checkpoint_id, "suite")
            second = manager.create("policy", {"weights": [1]}, 20)
            manager.record_evaluation(second.checkpoint_id, "suite", {1: 0.7, 2: 0.7, 3: 0.7})
            manager.consider_promotion(second.checkpoint_id, "suite")
            manager.record_evaluation(second.checkpoint_id, "suite", {1: 0.2, 2: 0.2, 3: 0.2})
            restored = manager.audit_and_rollback("policy", "suite")
            self.assertEqual(restored.checkpoint_id, first.checkpoint_id)


if __name__ == "__main__":
    unittest.main()
