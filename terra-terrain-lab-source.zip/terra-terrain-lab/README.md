# Terrain Lab — browser editor

Original obstacle editor recovered from TERRA Terrain Lab and adapted to run without a backend. Open index.html in a browser, add boxes/stairs/ramps, orbit the view and download actual terrain JSON. It uses canvas rendering and no dependencies, network calls, credentials or model downloads.

Export uses half-extents and XY ground coordinates with upward Z. It produces authored terrain geometry; trained TERRA playback requires the separate upstream runtime, compatible motions and licensed assets. No learned navigation is demonstrated. Upstream TERRA: https://github.com/amathislab/terra

Changes in this snapshot: local JSON download replaces the local API; unavailable native/model controls are removed; stair insertion respects the 80-box limit.
