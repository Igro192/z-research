#!/usr/bin/env python3
"""Replace only the AI add-on entry; preserve the Steam game, preferences and other scripts."""
from pathlib import Path
import datetime,json,re,shutil
ROOT=Path(__file__).resolve().parent
DATA=Path.home()/'Library/Application Support/Steam/steamapps/common/Powder/userdata'
backups=ROOT/'backups';backups.mkdir(exist_ok=True)
autorun=DATA/'autorun.lua';old=autorun.read_text() if autorun.exists() else ''
snapshot=backups/('before-template-install-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));snapshot.mkdir(exist_ok=True)
for name in ('autorun.lua','powder_ai.lua','powder.pref'):
 p=DATA/name
 if p.exists():shutil.copy2(p,snapshot/name)
text=re.sub(r'\n?-- POWDER_AI_BRIDGE\s*\n\s*dofile\([^\n]*\)\s*\n?','\n',old)
text=re.sub(r'\n?-- POWDER_TEMPLATES_LIBRARY\s*\n\s*dofile\([^\n]*\)\s*\n?','\n',text)
script=(ROOT/'templates.lua').read_text().replace('__ROOT__',str(ROOT).replace("'","\\'"))
(DATA/'powder_templates.lua').write_text(script)
(ROOT/'installed-templates.lua').write_text(script)
stamps=DATA/'stamps';stamps.mkdir(exist_ok=True)
catalog=json.loads((ROOT/'catalog.json').read_text())
for project in catalog['projects']:
 target=ROOT/project['file'];link=stamps/('powder-template-'+str(project['id'])+'.stm')
 if link.is_symlink():
  if link.resolve()!=target.resolve():raise SystemExit('Conflicting template link: '+str(link))
 elif link.exists():raise SystemExit('Existing file conflicts with template alias: '+str(link))
 else:link.symlink_to(target)
text+='\n-- POWDER_TEMPLATES_LIBRARY\ndofile('+json.dumps(str(DATA/'powder_templates.lua'))+')\n';autorun.write_text(text)
if (DATA/'powder_ai.lua').exists():shutil.move(str(DATA/'powder_ai.lua'),str(snapshot/'retired-powder_ai.lua'))
config={'game_data':str(DATA),'game_app':str(DATA.parent/'The Powder Toy.app'),'python':'/Library/Frameworks/Python.framework/Versions/3.13/bin/python3'}
(ROOT/'config.json').write_text(json.dumps(config,indent=2))
print('Templates add-on installed. The AI add-on is retired; Steam executable and settings preserved.')
