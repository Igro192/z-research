# Community projects

Original authors and official source saves. All projects are available offline in the in-game Templates browser.

## Human body & biology

- [BODY V5](https://powdertoy.co.uk/Browse/View.html?ID=1477357) — Loadstar; 4015 upvotes; 32402 particles.
- [Human body](https://powdertoy.co.uk/Browse/View.html?ID=143074) — PHYSICMAN; 631 upvotes; 32532 particles.
- [BODY V6 (UPGRADED BODY V5)](https://powdertoy.co.uk/Browse/View.html?ID=2503762) — FadeHD; 337 upvotes; 32325 particles.
- [Functioning Android (Update 1)](https://powdertoy.co.uk/Browse/View.html?ID=1069572) — jmmartyn; 327 upvotes; 40370 particles.
- [BODY V4](https://powdertoy.co.uk/Browse/View.html?ID=1473016) — Loadstar; 292 upvotes; 27355 particles.
- [amoeba](https://powdertoy.co.uk/Browse/View.html?ID=2307277) — kittenruler; 289 upvotes; 12624 particles.
- [Burner Organism + GUI](https://powdertoy.co.uk/Browse/View.html?ID=2413224) — SuperJoshiDuff; 289 upvotes; 49404 particles.
- [Human Body](https://powdertoy.co.uk/Browse/View.html?ID=260663) — zuko52; 263 upvotes; legacy particles.
- [Living Organism](https://powdertoy.co.uk/Browse/View.html?ID=1281282) — jmmartyn; 257 upvotes; 65276 particles.
- [REALISTIC BODY V5](https://powdertoy.co.uk/Browse/View.html?ID=2895764) — BunkerStrikerUA; 216 upvotes; 29091 particles.
- [Realistic Human V4.0](https://powdertoy.co.uk/Browse/View.html?ID=2845491) — Trem; 198 upvotes; 53182 particles.
- [Aqua!](https://powdertoy.co.uk/Browse/View.html?ID=2454561) — LtDunn; 195 upvotes; 164287 particles.
- [Human Body V1](https://powdertoy.co.uk/Browse/View.html?ID=1951001) — Frankonlaptopin120p; 194 upvotes; 51527 particles.
- [Living Organism WIP](https://powdertoy.co.uk/Browse/View.html?ID=1283256) — jm211; 190 upvotes; 32142 particles.
- [Biomes](https://powdertoy.co.uk/Browse/View.html?ID=1827992) — ROHANman; 182 upvotes; 67036 particles.
- [Semi-realistic skin](https://powdertoy.co.uk/Browse/View.html?ID=2636786) — Balala7567; 166 upvotes; 88305 particles.
- [Dummy of Human Body](https://powdertoy.co.uk/Browse/View.html?ID=166054) — i80r; 165 upvotes; 27628 particles.
- [self healing skin](https://powdertoy.co.uk/Browse/View.html?ID=2310171) — cjun0416; 162 upvotes; 31005 particles.
- [Realistic working heart 1.0](https://powdertoy.co.uk/Browse/View.html?ID=3422457) — Rons; 46 upvotes; 22029 particles.

## Computers & processors

- [Synergy Computer (29-bit)](https://powdertoy.co.uk/Browse/View.html?ID=1761441) — Synergy; 1491 upvotes; 50378 particles.
- [Computer (no wifi! :D)](https://powdertoy.co.uk/Browse/View.html?ID=427363) — mark2222; 1019 upvotes; 52479 particles.
- [R216K2A](https://powdertoy.co.uk/Browse/View.html?ID=2303519) — LBPHacker; 684 upvotes; 46024 particles.
- [Particle Accelerator/Collider](https://powdertoy.co.uk/Browse/View.html?ID=1881004) — DiScXrD; 496 upvotes; 10295 particles.
- [processor](https://powdertoy.co.uk/Browse/View.html?ID=4260) — devast8a; 478 upvotes; legacy particles.
- [Computer (mapS)](https://powdertoy.co.uk/Browse/View.html?ID=975033) — drakide; 455 upvotes; 22362 particles.
- [HD Subframe Animation](https://powdertoy.co.uk/Browse/View.html?ID=2188230) — Draco712; 403 upvotes; 54404 particles.
- [Programmable computer (4 bit)](https://powdertoy.co.uk/Browse/View.html?ID=335175) — Crionis; 378 upvotes; legacy particles.
- [Micro Computer v2.1](https://powdertoy.co.uk/Browse/View.html?ID=1599945) — RockerM4NHUN; 354 upvotes; 102974 particles.
- [LightPC (0.6 Hz computer)](https://powdertoy.co.uk/Browse/View.html?ID=1570768) — mark2222; 340 upvotes; 115096 particles.
- [Smallest Computer Ever](https://powdertoy.co.uk/Browse/View.html?ID=2169745) — NoVIcE; 324 upvotes; 27657 particles.
- [3-IN-1](https://powdertoy.co.uk/Browse/View.html?ID=2920545) — Qweryntino; 297 upvotes; 74367 particles.
- [R16K1S60](https://powdertoy.co.uk/Browse/View.html?ID=1932845) — LBPHacker; 296 upvotes; 38178 particles.
- [8 bit CPU with RAM no WIFI](https://powdertoy.co.uk/Browse/View.html?ID=1559619) — A_Real_Genius; 170 upvotes; 75409 particles.
- [C4C 1 8-bit Computer](https://powdertoy.co.uk/Browse/View.html?ID=2148569) — Cool4Cool; 67 upvotes; 84752 particles.
- [Working FILT computer v.4 with mini-"OS"](https://powdertoy.co.uk/Browse/View.html?ID=3235632) — 12034056; 28 upvotes; 71854 particles.
- [Powder Toy Turing Machine](https://powdertoy.co.uk/Browse/View.html?ID=1045867) — bimmo_devices; 20 upvotes; 105884 particles.

## Electronic circuits

- [Electronic things](https://powdertoy.co.uk/Browse/View.html?ID=6076) — Mur; 2091 upvotes; 31244 particles.
- [Lightwriter](https://powdertoy.co.uk/Browse/View.html?ID=385086) — arK; 1389 upvotes; 18900 particles.
- [Chronometer](https://powdertoy.co.uk/Browse/View.html?ID=2013167) — Qweryntino; 705 upvotes; 12521 particles.
- [Super-long maze ARAY](https://powdertoy.co.uk/Browse/View.html?ID=945534) — 12vladis12; 633 upvotes; 19471 particles.
- [Exo-Flux Lunar Cannon X-3](https://powdertoy.co.uk/Browse/View.html?ID=979741) — HowlsChaos; 557 upvotes; 45774 particles.
- [Electronic Bomb Tester](https://powdertoy.co.uk/Browse/View.html?ID=677869) — Minishooz; 544 upvotes; legacy particles.
- [Usefull electronics](https://powdertoy.co.uk/Browse/View.html?ID=977825) — mecha-man; 444 upvotes; 43494 particles.
- [Calculator v2.0 + - x](https://powdertoy.co.uk/Browse/View.html?ID=372304) — scratcher; 439 upvotes; 37465 particles.

## Trains & transport

- [Small Town with Tron Trains](https://powdertoy.co.uk/Browse/View.html?ID=800101) — TBone02; 380 upvotes; 63187 particles.
- [Steam Train Boiler](https://powdertoy.co.uk/Browse/View.html?ID=2254917) — Drizziie; 247 upvotes; 20901 particles.
- [Mountain Railroad](https://powdertoy.co.uk/Browse/View.html?ID=2885073) — Matera_the_Mad; 228 upvotes; 182577 particles.
- [Thermite Rail Welding](https://powdertoy.co.uk/Browse/View.html?ID=2331465) — maksimum; 182 upvotes; 10519 particles.
- [Passage of time](https://powdertoy.co.uk/Browse/View.html?ID=2145303) — LBPHacker; 164 upvotes; 3979 particles.
- [train animation](https://powdertoy.co.uk/Browse/View.html?ID=622795) — lolescapebroswe; 130 upvotes; legacy particles.
- [Loopy Trains](https://powdertoy.co.uk/Browse/View.html?ID=2305163) — LBPHacker; 111 upvotes; 42536 particles.
- [Autonomous Diesel Locomotive](https://powdertoy.co.uk/Browse/View.html?ID=2282277) — NottRegular; 103 upvotes; 42422 particles.
- [......](https://powdertoy.co.uk/Browse/View.html?ID=3054635) — tirranium; 97 upvotes; 20557 particles.
- [Weasel transport mk1](https://powdertoy.co.uk/Browse/View.html?ID=1754778) — FuriousWeasel; 90 upvotes; 13701 particles.
- [Steam train](https://powdertoy.co.uk/Browse/View.html?ID=2555163) — angry_carpet; 65 upvotes; 7002 particles.
- [Train Simulator 2.0!](https://powdertoy.co.uk/Browse/View.html?ID=1568124) — RagingHammer; 65 upvotes; 34027 particles.
- [British Rail 7mt Britannia Class](https://powdertoy.co.uk/Browse/View.html?ID=3042201) — sarcia24; 59 upvotes; 57592 particles.

## Chemical reactions

- [Cozy satelite lab](https://powdertoy.co.uk/Browse/View.html?ID=164673) — wasyathepuss; 758 upvotes; 96588 particles.
- [adjustable bunson burner](https://powdertoy.co.uk/Browse/View.html?ID=1413301) — brodyrulz; 441 upvotes; 2132 particles.
- [New Way to Create H2O](https://powdertoy.co.uk/Browse/View.html?ID=1164544) — Aloysius1234; 267 upvotes; 7715 particles.
- [STAR IN A JAR](https://powdertoy.co.uk/Browse/View.html?ID=1372426) — mccafferty2; 239 upvotes; 8897 particles.
- [Iron -> Metal Converter](https://powdertoy.co.uk/Browse/View.html?ID=451149) — Catelite; 206 upvotes; legacy particles.
- [Complete PTNM Tutorial](https://powdertoy.co.uk/Browse/View.html?ID=2746112) — Cracker1000; 201 upvotes; 15979 particles.
- [I love science](https://powdertoy.co.uk/Browse/View.html?ID=2219210) — HapyMetal; 190 upvotes; 62731 particles.
- [DSTW->O2->LO2 Electrolysis](https://powdertoy.co.uk/Browse/View.html?ID=92716) — Benassi; 181 upvotes; legacy particles.
- [Atom formation](https://powdertoy.co.uk/Browse/View.html?ID=2347457) — VII; 143 upvotes; 1212 particles.
- [Covalent bonding model](https://powdertoy.co.uk/Browse/View.html?ID=1010772) — Sailnir; 133 upvotes; 17203 particles.
- [Element-Maze](https://powdertoy.co.uk/Browse/View.html?ID=2077046) — HapyMetal; 129 upvotes; 79453 particles.
- [Periodic table explained](https://powdertoy.co.uk/Browse/View.html?ID=2590655) — plutoniumfusion; 129 upvotes; 88764 particles.
- [Water electrolysis: Particles counter](https://powdertoy.co.uk/Browse/View.html?ID=1257871) — samrrr; 127 upvotes; 18398 particles.

## Worlds & planets

- [Realistic Planet & Moon](https://powdertoy.co.uk/Browse/View.html?ID=1278891) — RadianceOfThought; 3418 upvotes; 45806 particles.
- [colony on planet](https://powdertoy.co.uk/Browse/View.html?ID=279834) — hacker97; 2115 upvotes; 120117 particles.
- [The World Without Humans](https://powdertoy.co.uk/Browse/View.html?ID=576449) — InfernoIVIVIV; 1570 upvotes; legacy particles.
- [Mario](https://powdertoy.co.uk/Browse/View.html?ID=5136) — edep; 1367 upvotes; 109764 particles.
- [England WII](https://powdertoy.co.uk/Browse/View.html?ID=141853) — whalezor; 1215 upvotes; 24885 particles.
- [Asteroid Impact Art](https://powdertoy.co.uk/Browse/View.html?ID=970792) — Demplex; 603 upvotes; 66421 particles.
- [Matrix World](https://powdertoy.co.uk/Browse/View.html?ID=520528) — Erreur-404; 581 upvotes; 71951 particles.
- [Into the Death Star](https://powdertoy.co.uk/Browse/View.html?ID=1758598) — MG99; 550 upvotes; 32149 particles.
- [Make your world!](https://powdertoy.co.uk/Browse/View.html?ID=1253965) — samrrr; 545 upvotes; 20055 particles.
- [Planet War](https://powdertoy.co.uk/Browse/View.html?ID=169264) — whalezor; 443 upvotes; 39543 particles.
- [world generator](https://powdertoy.co.uk/Browse/View.html?ID=1618716) — andytheepic; 382 upvotes; 15828 particles.
- [jacob1](https://powdertoy.co.uk/Browse/View.html?ID=2218247) — VIP84; 374 upvotes; 227107 particles.
- [(insert uncreative title here)](https://powdertoy.co.uk/Browse/View.html?ID=2289637) — VIP84; 371 upvotes; 227104 particles.
- [Milky Way from Earth](https://powdertoy.co.uk/Browse/View.html?ID=2168724) — VIP84; 329 upvotes; 145698 particles.
- [the moon (redone)](https://powdertoy.co.uk/Browse/View.html?ID=1475478) — jward212; 325 upvotes; 41400 particles.
- [The rotation of the planet](https://powdertoy.co.uk/Browse/View.html?ID=2765152) — Ura_Octostar; 320 upvotes; 76838 particles.
- [space colony animation](https://powdertoy.co.uk/Browse/View.html?ID=271634) — hacker97; 302 upvotes; legacy particles.
- [Earth, Sun and stars.](https://powdertoy.co.uk/Browse/View.html?ID=1905454) — MAS2015; 300 upvotes; 119432 particles.
- [Earth's Magnetic Field](https://powdertoy.co.uk/Browse/View.html?ID=2060496) — powderskye; 291 upvotes; 22114 particles.
- [Space Station](https://powdertoy.co.uk/Browse/View.html?ID=1618431) — ThePiksu; 279 upvotes; 62034 particles.
- [The World of Terraria](https://powdertoy.co.uk/Browse/View.html?ID=3105280) — Gabe09; 255 upvotes; 113526 particles.

## Cities & architecture

- [Destroyable city 5 (wth metro)](https://powdertoy.co.uk/Browse/View.html?ID=2198) — dima-gord; 8423 upvotes; legacy particles.
- [City](https://powdertoy.co.uk/Browse/View.html?ID=303800) — Tanatos; 3797 upvotes; 58642 particles.
- [Arctic City 2](https://powdertoy.co.uk/Browse/View.html?ID=159265) — Fast-Driver; 2610 upvotes; 75021 particles.
- [Destroyable city 5 (wth QRTZ)](https://powdertoy.co.uk/Browse/View.html?ID=121412) — dima-gord; 1855 upvotes; legacy particles.
- [Bunker City.](https://powdertoy.co.uk/Browse/View.html?ID=1404583) — thespazz; 1381 upvotes; 99538 particles.
- [SciFi City](https://powdertoy.co.uk/Browse/View.html?ID=166627) — whalezor; 1014 upvotes; 57859 particles.
- [Downtown City](https://powdertoy.co.uk/Browse/View.html?ID=228602) — jamjam13; 981 upvotes; legacy particles.
- [WARPED Destroyable City 5](https://powdertoy.co.uk/Browse/View.html?ID=1895806) — DRKV; 906 upvotes; 76811 particles.
- [Desert City 5](https://powdertoy.co.uk/Browse/View.html?ID=151327) — Dwotci; 896 upvotes; legacy particles.
- [Imperatus City District 5](https://powdertoy.co.uk/Browse/View.html?ID=1226981) — Imperatus; 880 upvotes; 81094 particles.
- [Bomb Test Building](https://powdertoy.co.uk/Browse/View.html?ID=1257691) — McBono; 845 upvotes; 49021 particles.
- [Desert City 6](https://powdertoy.co.uk/Browse/View.html?ID=441267) — Dwotci; 820 upvotes; legacy particles.
- [Desert City 3](https://powdertoy.co.uk/Browse/View.html?ID=14393) — Dwotci; 819 upvotes; legacy particles.
- [The Glass Shard](https://powdertoy.co.uk/Browse/View.html?ID=502588) — jamjam13; 805 upvotes; legacy particles.
- [Sad city and Nyan cat Power](https://powdertoy.co.uk/Browse/View.html?ID=511818) — Flopciak; 738 upvotes; legacy particles.
- [W.P.Town](https://powdertoy.co.uk/Browse/View.html?ID=240702) — Dwotci; 727 upvotes; legacy particles.
- [City](https://powdertoy.co.uk/Browse/View.html?ID=852070) — FiveToOne; 722 upvotes; 73676 particles.
- [Earthscape 1.0 (city)](https://powdertoy.co.uk/Browse/View.html?ID=289323) — ivel236; 717 upvotes; 98924 particles.
- [Motion in the dark](https://powdertoy.co.uk/Browse/View.html?ID=2269875) — VIP84; 717 upvotes; 216225 particles.
- [City Sunset](https://powdertoy.co.uk/Browse/View.html?ID=1090154) — Tatr629000; 692 upvotes; 197579 particles.
- [BIG Destroyable Bunker](https://powdertoy.co.uk/Browse/View.html?ID=23861) — MaciejB; 616 upvotes; 94157 particles.
- [Incredibly detailed house](https://powdertoy.co.uk/Browse/View.html?ID=76299) — the-dude; 567 upvotes; legacy particles.
- [City with volcano](https://powdertoy.co.uk/Browse/View.html?ID=45656) — Anmol444; 558 upvotes; legacy particles.
- [Medieval Farmer's House](https://powdertoy.co.uk/Browse/View.html?ID=922996) — FilipT; 542 upvotes; 62356 particles.
- [Hidden Bunker](https://powdertoy.co.uk/Browse/View.html?ID=731661) — poop3; 487 upvotes; 104704 particles.
- [traction city](https://powdertoy.co.uk/Browse/View.html?ID=942797) — sentinal-5; 427 upvotes; 85197 particles.
- [Desert City 2](https://powdertoy.co.uk/Browse/View.html?ID=10053) — Dwotci; 362 upvotes; legacy particles.
- [Motor City](https://powdertoy.co.uk/Browse/View.html?ID=134476) — XxX-wolf-XxX; 282 upvotes; legacy particles.
- [Dynamic City](https://powdertoy.co.uk/Browse/View.html?ID=2713450) — whalezor; 273 upvotes; 73051 particles.
- [Bunker Island 4.3](https://powdertoy.co.uk/Browse/View.html?ID=264450) — Chch515; 226 upvotes; legacy particles.
- [building the people](https://powdertoy.co.uk/Browse/View.html?ID=1768444) — CodeWolfG1; 190 upvotes; 66334 particles.
- [Bacteria City](https://powdertoy.co.uk/Browse/View.html?ID=2844160) — Technologic; 160 upvotes; 12272 particles.
- [Dam City & collapse](https://powdertoy.co.uk/Browse/View.html?ID=2643949) — FunButMad; 140 upvotes; 87914 particles.
- [Edragy City Destroyable(W.I.P)](https://powdertoy.co.uk/Browse/View.html?ID=539899) — edragy; 73 upvotes; 78006 particles.
- [City (construction completed)](https://powdertoy.co.uk/Browse/View.html?ID=1115895) — Tiphox; 67 upvotes; 82266 particles.

## Bombs & explosions

- [Realistic grenade](https://powdertoy.co.uk/Browse/View.html?ID=103770) — jma1111; 2517 upvotes; 28010 particles.
- [Bunker Smasher](https://powdertoy.co.uk/Browse/View.html?ID=291031) — Amphealy; 1580 upvotes; 118560 particles.
- [Bomb Testing Town](https://powdertoy.co.uk/Browse/View.html?ID=1014500) — TheElectricSalad; 779 upvotes; 31760 particles.
- [Nuke Factory](https://powdertoy.co.uk/Browse/View.html?ID=781178) — Platypus5; 759 upvotes; 43483 particles.
- [Heartless bomb](https://powdertoy.co.uk/Browse/View.html?ID=92719) — Crionesis; 646 upvotes; legacy particles.
- [Mountain Base](https://powdertoy.co.uk/Browse/View.html?ID=1818680) — laughingape; 620 upvotes; 54763 particles.
- [various grenades](https://powdertoy.co.uk/Browse/View.html?ID=397693) — alecnotalex; 503 upvotes; legacy particles.
- [Automatic homing explosive](https://powdertoy.co.uk/Browse/View.html?ID=1819432) — Qwert_Yuiop; 469 upvotes; 11357 particles.
- [Micro Nuke Test](https://powdertoy.co.uk/Browse/View.html?ID=316040) — Amphealy; 459 upvotes; legacy particles.
- [Nuclear missile silo complex](https://powdertoy.co.uk/Browse/View.html?ID=2338067) — Greendragon; 421 upvotes; 78470 particles.
- [Bomb Test Site](https://powdertoy.co.uk/Browse/View.html?ID=1242349) — Rocketrad; 337 upvotes; 28285 particles.
- [BOMB MAKER 3000](https://powdertoy.co.uk/Browse/View.html?ID=2161504) — Bender_; 331 upvotes; 5072 particles.
- [Anti-Armor explosive (shape charge)](https://powdertoy.co.uk/Browse/View.html?ID=2591013) — DrBronnor; 320 upvotes; 69873 particles.
- [Nuke in Slowmotion](https://powdertoy.co.uk/Browse/View.html?ID=2038367) — HapyMetal; 316 upvotes; 226948 particles.
- [Incendiary Liquid](https://powdertoy.co.uk/Browse/View.html?ID=1466416) — FilipT; 302 upvotes; 54688 particles.
- [Explosive City](https://powdertoy.co.uk/Browse/View.html?ID=1146000) — Finalflash50; 285 upvotes; 82605 particles.
- [Nuke Factory Detailed](https://powdertoy.co.uk/Browse/View.html?ID=2230573) — NoVIcE; 285 upvotes; 14780 particles.
- [Laser Guidance Missile System](https://powdertoy.co.uk/Browse/View.html?ID=2567651) — lamyipfu; 272 upvotes; 24450 particles.
- [Automated Bomb Factory](https://powdertoy.co.uk/Browse/View.html?ID=2160723) — DUC; 245 upvotes; 23497 particles.
- [M1A1 Abrams](https://powdertoy.co.uk/Browse/View.html?ID=2258973) — Haruunn; 241 upvotes; 50968 particles.
- [Explosion Animation](https://powdertoy.co.uk/Browse/View.html?ID=1723023) — MangoAfterDark; 237 upvotes; 74000 particles.

## Nuclear & power plants

- [Nuclear bunker](https://powdertoy.co.uk/Browse/View.html?ID=696065) — CommanderInuYasha; 3937 upvotes; 74849 particles.
- [PWR nuclear power plant](https://powdertoy.co.uk/Browse/View.html?ID=5170) — 321boom; 3047 upvotes; 72023 particles.
- [Realistic Nuclear Reactor Core](https://powdertoy.co.uk/Browse/View.html?ID=78400) — ven1x; 3007 upvotes; 41941 particles.
- [Realistic Nuclear Reactor mk.2](https://powdertoy.co.uk/Browse/View.html?ID=257313) — ven1x; 1682 upvotes; 83782 particles.
- [The Life Cycle of a Star](https://powdertoy.co.uk/Browse/View.html?ID=1693900) — agustrusher; 1643 upvotes; 35091 particles.
- [Universe?](https://powdertoy.co.uk/Browse/View.html?ID=1387121) — Dobraya_Dusha; 1590 upvotes; 10653 particles.
- [Nuclear fusor](https://powdertoy.co.uk/Browse/View.html?ID=23905) — Mur; 1477 upvotes; legacy particles.
- [Highpower channel type reactor](https://powdertoy.co.uk/Browse/View.html?ID=22367) — den_koshkin; 1444 upvotes; 11100 particles.
- [Nuclear Reactor](https://powdertoy.co.uk/Browse/View.html?ID=212604) — lucas; 1383 upvotes; 62888 particles.
- [Fully Manual Nucluar PWR](https://powdertoy.co.uk/Browse/View.html?ID=199128) — Hellome; 1251 upvotes; legacy particles.
- [The REAL RBMK1000 Reactor](https://powdertoy.co.uk/Browse/View.html?ID=2001108) — den_koshkin; 1197 upvotes; 89263 particles.
- [Nuclear Fission Power Plant](https://powdertoy.co.uk/Browse/View.html?ID=2396223) — Nuculus; 1140 upvotes; 76450 particles.
- [Micro Universe Simulator](https://powdertoy.co.uk/Browse/View.html?ID=1698132) — agustrusher; 1105 upvotes; 130809 particles.
- [Nuclear Powered Plane](https://powdertoy.co.uk/Browse/View.html?ID=9880) — RedFlash; 1014 upvotes; 41409 particles.
- [Deuterium Nuclear Reactor](https://powdertoy.co.uk/Browse/View.html?ID=341879) — iggyfigs; 996 upvotes; legacy particles.
- [Power plant art](https://powdertoy.co.uk/Browse/View.html?ID=832536) — BuysDB; 990 upvotes; 134215 particles.
- [Rocket + nuclear engine](https://powdertoy.co.uk/Browse/View.html?ID=1448557) — MichanPotasu123; 984 upvotes; 9304 particles.
- [Advanced Thermite Reactor](https://powdertoy.co.uk/Browse/View.html?ID=214245) — JA; 729 upvotes; legacy particles.
- [Boiling water reactor BETA](https://powdertoy.co.uk/Browse/View.html?ID=1186972) — BuysDB; 703 upvotes; 93631 particles.
- [Uran reactor](https://powdertoy.co.uk/Browse/View.html?ID=895042) — BuysDB; 698 upvotes; 76448 particles.
- [Deuterium Reactor](https://powdertoy.co.uk/Browse/View.html?ID=1468603) — ivel236; 598 upvotes; 58019 particles.
- [Uranium Power Plant v1.0](https://powdertoy.co.uk/Browse/View.html?ID=1289009) — HowlsChaos; 550 upvotes; 129953 particles.
- [Reactor.](https://powdertoy.co.uk/Browse/View.html?ID=259948) — Vou; 425 upvotes; legacy particles.
- [Destroyable Fusion Reactor](https://powdertoy.co.uk/Browse/View.html?ID=2097682) — ZeFeeshyFish; 341 upvotes; 45698 particles.
- [Coal Power Plant](https://powdertoy.co.uk/Browse/View.html?ID=218388) — Benassi; 306 upvotes; legacy particles.
- [destroyable nuclear plant](https://powdertoy.co.uk/Browse/View.html?ID=117560) — Qbix; 300 upvotes; legacy particles.
- [Deut reactor with automation](https://powdertoy.co.uk/Browse/View.html?ID=741206) — Luuzuk; 287 upvotes; 70639 particles.
- [fusion machine](https://powdertoy.co.uk/Browse/View.html?ID=2528995) — guitou; 279 upvotes; 65338 particles.
- [Deuterium Reactor 2](https://powdertoy.co.uk/Browse/View.html?ID=1566348) — hermankronfeld; 273 upvotes; 91818 particles.
- [Boiling water reactor beta 2](https://powdertoy.co.uk/Browse/View.html?ID=1751067) — BuysDB; 272 upvotes; 96232 particles.
- [Deutrium Power Plant](https://powdertoy.co.uk/Browse/View.html?ID=2465674) — FradsMan; 257 upvotes; 78075 particles.
- [INFINITE Fusion how to](https://powdertoy.co.uk/Browse/View.html?ID=2333126) — jdreid444; 215 upvotes; 9644 particles.
- [SLTW Fusion Reactor](https://powdertoy.co.uk/Browse/View.html?ID=2173776) — Euanwhitehead; 196 upvotes; 54648 particles.
- [Metal Fusion Factory](https://powdertoy.co.uk/Browse/View.html?ID=892276) — Catelite; 141 upvotes; 4830 particles.
- [fusion reactor/chemical plant](https://powdertoy.co.uk/Browse/View.html?ID=1329214) — wolle; 131 upvotes; 70690 particles.

## Factories & automation

- [Mineral Refinery](https://powdertoy.co.uk/Browse/View.html?ID=94444) — Benassi; 3389 upvotes; legacy particles.
- [CITYBUILDER](https://powdertoy.co.uk/Browse/View.html?ID=1497260) — Loadstar; 671 upvotes; 45810 particles.
- [Artillery Shell Factory](https://powdertoy.co.uk/Browse/View.html?ID=1429117) — cj646464; 650 upvotes; 15253 particles.
- [Mimic Melt Refinery](https://powdertoy.co.uk/Browse/View.html?ID=95984) — Catelite; 507 upvotes; 19288 particles.
- [Realistic PSTN elevator](https://powdertoy.co.uk/Browse/View.html?ID=1233067) — panettone; 492 upvotes; 29461 particles.
- [Factory](https://powdertoy.co.uk/Browse/View.html?ID=1119756) — Amphealy; 411 upvotes; 23030 particles.
- [Sus Alien Installation](https://powdertoy.co.uk/Browse/View.html?ID=2944844) — Jerehmia; 364 upvotes; 38189 particles.
- [Yo dawg, so I heard you like factories...](https://powdertoy.co.uk/Browse/View.html?ID=1632590) — Qwert_Yuiop; 364 upvotes; 977 particles.
- [Glass Maker](https://powdertoy.co.uk/Browse/View.html?ID=41441) — SAMSTER5; 339 upvotes; legacy particles.
- [Deuterium synthesis plant](https://powdertoy.co.uk/Browse/View.html?ID=527612) — BuysDB; 306 upvotes; legacy particles.
- [Stone factory](https://powdertoy.co.uk/Browse/View.html?ID=647696) — Crionis; 303 upvotes; legacy particles.
- [Self aiming autoturret.](https://powdertoy.co.uk/Browse/View.html?ID=2147843) — the_new_powder99999; 264 upvotes; 514 particles.
- [Deuterium factory](https://powdertoy.co.uk/Browse/View.html?ID=733444) — Minishooz; 252 upvotes; legacy particles.
- [DEUT Multiplication Factory](https://powdertoy.co.uk/Browse/View.html?ID=1814087) — Catelite; 247 upvotes; 6304 particles.
- [Gun Factory](https://powdertoy.co.uk/Browse/View.html?ID=1436844) — Darkn1883r; 246 upvotes; 14902 particles.
- [EXOT from nothing](https://powdertoy.co.uk/Browse/View.html?ID=2888589) — miner_sd; 234 upvotes; 59152 particles.

## Engines & machinery

- [EHOLE Star Generator](https://powdertoy.co.uk/Browse/View.html?ID=1888612) — jBot-42; 1466 upvotes; 32190 particles.
- [Fast ARAY copy machine](https://powdertoy.co.uk/Browse/View.html?ID=105749) — Pilihp64; 1455 upvotes; 6595 particles.
- [ Jet Engine 3.0](https://powdertoy.co.uk/Browse/View.html?ID=447970) — LorDXEORUS; 1255 upvotes; 41653 particles.
- [Realistic engine](https://powdertoy.co.uk/Browse/View.html?ID=1451939) — panettone; 766 upvotes; 36368 particles.
- [6-Cyl Inline Engine](https://powdertoy.co.uk/Browse/View.html?ID=731319) — mbrice07; 574 upvotes; 23069 particles.
- [helicopter with working engine](https://powdertoy.co.uk/Browse/View.html?ID=179578) — sparkjet; 468 upvotes; legacy particles.
- [F-1 rocket engine](https://powdertoy.co.uk/Browse/View.html?ID=337687) — shikari_rock; 392 upvotes; 8432 particles.
- [Slot Machine V2 Lucky 7](https://powdertoy.co.uk/Browse/View.html?ID=231512) — Benassi; 386 upvotes; legacy particles.
- [NiCoal High Power Engine](https://powdertoy.co.uk/Browse/View.html?ID=155515) — tothemyers; 374 upvotes; 16243 particles.
- [Nuclear engine](https://powdertoy.co.uk/Browse/View.html?ID=2391104) — Matvey123; 368 upvotes; 10694 particles.
- [4-Stage Rocket To The Moon!](https://powdertoy.co.uk/Browse/View.html?ID=1059938) — slug14; 362 upvotes; 31091 particles.
- [Dr.Mario's Smoke Machine](https://powdertoy.co.uk/Browse/View.html?ID=770629) — gruisman; 350 upvotes; 43969 particles.
- [Car engine](https://powdertoy.co.uk/Browse/View.html?ID=197423) — lucas; 303 upvotes; 9883 particles.
- [Volkswagen Golf](https://powdertoy.co.uk/Browse/View.html?ID=283717) — FDCC; 294 upvotes; legacy particles.
- [Afterburning Turbojet](https://powdertoy.co.uk/Browse/View.html?ID=1055986) — SmiteZero; 274 upvotes; 31759 particles.
- [Gas-generator cycle rocket engine](https://powdertoy.co.uk/Browse/View.html?ID=2431616) — docRoboRobert; 265 upvotes; 41112 particles.
- [4c engine](https://powdertoy.co.uk/Browse/View.html?ID=131819) — Crionis; 261 upvotes; legacy particles.
- [GPU running GoL (SIMD16S)](https://powdertoy.co.uk/Browse/View.html?ID=2046454) — mark2222; 259 upvotes; 32888 particles.
- [M4 Sherman](https://powdertoy.co.uk/Browse/View.html?ID=1401201) — Hanoj; 255 upvotes; 26840 particles.
- [Petrol Engine](https://powdertoy.co.uk/Browse/View.html?ID=1059446) — samtm77; 255 upvotes; 26239 particles.
- [Rocket Engine 5.0](https://powdertoy.co.uk/Browse/View.html?ID=474430) — Tommymmot; 239 upvotes; 6420 particles.
- [Clockwork Arachnid](https://powdertoy.co.uk/Browse/View.html?ID=728456) — slug14; 229 upvotes; 8694 particles.
- [UPDATED wave generator v3 by mr salite](https://powdertoy.co.uk/Browse/View.html?ID=1409459) — 987tails; 204 upvotes; 34509 particles.
- [wave generator v2](https://powdertoy.co.uk/Browse/View.html?ID=431474) — mrsalit0s; 171 upvotes; 26340 particles.
- [Thomas the war engine](https://powdertoy.co.uk/Browse/View.html?ID=2136456) — fish123; 65 upvotes; 49960 particles.

## Vehicles & aircraft

- [Spirit of Fire](https://powdertoy.co.uk/Browse/View.html?ID=429432) — AviatorGuy; 992 upvotes; legacy particles.
- [IJN FUSO](https://powdertoy.co.uk/Browse/View.html?ID=687598) — BuysDB; 667 upvotes; legacy particles.
- [Space ship](https://powdertoy.co.uk/Browse/View.html?ID=969176) — kandiejoe2002; 578 upvotes; 56119 particles.
- [Lock for a Canal](https://powdertoy.co.uk/Browse/View.html?ID=1981088) — TheExus; 482 upvotes; 71082 particles.
- [Joint Strike Fighter](https://powdertoy.co.uk/Browse/View.html?ID=846812) — Armada93; 474 upvotes; 51092 particles.
- [Realistic Airplane Interior](https://powdertoy.co.uk/Browse/View.html?ID=1626784) — jBot-42; 379 upvotes; 12735 particles.
- [HMS Battleship](https://powdertoy.co.uk/Browse/View.html?ID=769080) — Minishooz; 332 upvotes; legacy particles.
- [spaceship](https://powdertoy.co.uk/Browse/View.html?ID=9566) — codefeenix; 317 upvotes; legacy particles.
- [The Sphinx, anti-fighter cruiser.](https://powdertoy.co.uk/Browse/View.html?ID=1263491) — the_new_powder99999; 317 upvotes; 110879 particles.
- [warping aurora](https://powdertoy.co.uk/Browse/View.html?ID=2357242) — rudstar; 292 upvotes; 8623 particles.
- [Venator-class Star Destroyer](https://powdertoy.co.uk/Browse/View.html?ID=2241110) — Seekez; 291 upvotes; 29163 particles.
- [SS_Unicorn](https://powdertoy.co.uk/Browse/View.html?ID=1121831) — LTT12; 289 upvotes; 51666 particles.
- [Conqueror-class super dreadnought](https://powdertoy.co.uk/Browse/View.html?ID=2208359) — Seekez; 288 upvotes; 36138 particles.
- [Project Chimera](https://powdertoy.co.uk/Browse/View.html?ID=913526) — RustyNinja; 287 upvotes; 62003 particles.
- [Functioning Galaga Ship](https://powdertoy.co.uk/Browse/View.html?ID=192331) — andrewdavidloftus; 285 upvotes; legacy particles.
- [Vacuum of space](https://powdertoy.co.uk/Browse/View.html?ID=1501195) — Hg201; 285 upvotes; 23267 particles.
- [USS Enterprise USS Defiant](https://powdertoy.co.uk/Browse/View.html?ID=898558) — Halsey; 278 upvotes; 33547 particles.
- [WWII Airplane Battle](https://powdertoy.co.uk/Browse/View.html?ID=1510583) — slug14; 270 upvotes; 21313 particles.
- [ship](https://powdertoy.co.uk/Browse/View.html?ID=248396) — hacker97; 264 upvotes; 67702 particles.
- [Ship Gun](https://powdertoy.co.uk/Browse/View.html?ID=1107352) — Pilihp64; 262 upvotes; 1173 particles.
- [plane under fire](https://powdertoy.co.uk/Browse/View.html?ID=2047500) — Hanzen; 257 upvotes; 227104 particles.
- [aircraft rapid decompression simulation](https://powdertoy.co.uk/Browse/View.html?ID=2003286) — boomtish214; 253 upvotes; 52462 particles.
- [Invincible-class super dreadnought](https://powdertoy.co.uk/Browse/View.html?ID=2739557) — Seekez; 249 upvotes; 55303 particles.
- [Multi-Purpose Space Cruiser (M.P.S.C.)](https://powdertoy.co.uk/Browse/View.html?ID=1421932) — Anonymous100; 221 upvotes; 51414 particles.

## Volcanoes & disasters

- [Volcano Maker](https://powdertoy.co.uk/Browse/View.html?ID=322483) — Amphealy; 2326 upvotes; legacy particles.
- [fire club volcano](https://powdertoy.co.uk/Browse/View.html?ID=787253) — aerostriker911; 1116 upvotes; 40640 particles.
- [Desert City with volcano](https://powdertoy.co.uk/Browse/View.html?ID=40186) — Anmol444; 739 upvotes; 66974 particles.
- [Volcanic Island Maker](https://powdertoy.co.uk/Browse/View.html?ID=422352) — Radi6tion; 580 upvotes; 34616 particles.
- [My first volcano ;)](https://powdertoy.co.uk/Browse/View.html?ID=2202793) — sunny1saturday; 394 upvotes; 62991 particles.
- [METEOR hits ISLAND](https://powdertoy.co.uk/Browse/View.html?ID=1354564) — oldstones; 329 upvotes; 58124 particles.
- [Volcano Simulation](https://powdertoy.co.uk/Browse/View.html?ID=462542) — gruisman; 308 upvotes; 45188 particles.
- [Tsunami!](https://powdertoy.co.uk/Browse/View.html?ID=435075) — swordmaster1121; 287 upvotes; 28883 particles.
- [Realistic volcano simulation](https://powdertoy.co.uk/Browse/View.html?ID=1276849) — st1nkst1efel; 275 upvotes; 63267 particles.
- [Realistic tsunami](https://powdertoy.co.uk/Browse/View.html?ID=1272905) — Kikinicij; 272 upvotes; 30767 particles.
- [volcano (realistic)](https://powdertoy.co.uk/Browse/View.html?ID=193696) — Lotus; 243 upvotes; legacy particles.
- [Vulcano EXPLODIVE!](https://powdertoy.co.uk/Browse/View.html?ID=820408) — kolec007; 235 upvotes; 70571 particles.
- [PLant City with volcano IDK](https://powdertoy.co.uk/Browse/View.html?ID=65435) — Anmol444; 200 upvotes; legacy particles.
- [realistic volcano](https://powdertoy.co.uk/Browse/View.html?ID=697100) — aerostriker911; 194 upvotes; legacy particles.
- [Earthquake simulator](https://powdertoy.co.uk/Browse/View.html?ID=828695) — bbdest; 177 upvotes; 9577 particles.
- [Realistic vulcan  ](https://powdertoy.co.uk/Browse/View.html?ID=260337) — xcrazy; 175 upvotes; 90429 particles.
- [Chernobyl Disaster](https://powdertoy.co.uk/Browse/View.html?ID=370469) — NukeEmAll; 172 upvotes; legacy particles.
- [Tsunami](https://powdertoy.co.uk/Browse/View.html?ID=1049308) — PlatinumTechno; 164 upvotes; 23886 particles.
- [Desert City with volcano EXT..](https://powdertoy.co.uk/Browse/View.html?ID=61733) — Anmol444; 160 upvotes; legacy particles.
- [Mount Vesuvius](https://powdertoy.co.uk/Browse/View.html?ID=1683771) — Ulrik54; 160 upvotes; 89841 particles.
- [Desert Magma Serpent](https://powdertoy.co.uk/Browse/View.html?ID=2598030) — Wasteland; 158 upvotes; 40144 particles.

## Waterworks & boilers

- [Virtual Aquarium](https://powdertoy.co.uk/Browse/View.html?ID=215434) — mrsalit0s; 1231 upvotes; 21374 particles.
- [Water purifier](https://powdertoy.co.uk/Browse/View.html?ID=37968) — Raindan1257; 750 upvotes; legacy particles.
- [Lightning storm](https://powdertoy.co.uk/Browse/View.html?ID=556034) — ivel236; 575 upvotes; 52073 particles.
- [The Ultra Dam](https://powdertoy.co.uk/Browse/View.html?ID=2678463) — SpikeViper; 540 upvotes; 59456 particles.
- [Simple water-maker](https://powdertoy.co.uk/Browse/View.html?ID=271352) — Fast-Driver; 477 upvotes; legacy particles.
- [Minecraft | Build your own!](https://powdertoy.co.uk/Browse/View.html?ID=2700848) — TheExus; 347 upvotes; 189045 particles.
- [Rainy Night](https://powdertoy.co.uk/Browse/View.html?ID=2181543) — VIP84; 345 upvotes; 227123 particles.
- [Products of Water](https://powdertoy.co.uk/Browse/View.html?ID=363294) — CLawston14; 298 upvotes; 58663 particles.
- [Strange Water Purifier](https://powdertoy.co.uk/Browse/View.html?ID=2057400) — fish123; 259 upvotes; 2879 particles.
- [Random Water Splash v2](https://powdertoy.co.uk/Browse/View.html?ID=465391) — mrsalit0s; 246 upvotes; 12452 particles.
- [Proton Maze v1.0](https://powdertoy.co.uk/Browse/View.html?ID=1672710) — Sandwichlizard; 243 upvotes; 23055 particles.
- [low temperature of water](https://powdertoy.co.uk/Browse/View.html?ID=1682938) — glenmiron; 236 upvotes; 2248 particles.
- [Lighting test](https://powdertoy.co.uk/Browse/View.html?ID=2273407) — Ecstasy; 231 upvotes; 28087 particles.
- [Amazing New FIRE show](https://powdertoy.co.uk/Browse/View.html?ID=2813630) — Roweno; 230 upvotes; 31129 particles.
- [Automated water sprinkler](https://powdertoy.co.uk/Browse/View.html?ID=2373181) — zqasd; 197 upvotes; 351 particles.
- [Soapworm Heat Pipe](https://powdertoy.co.uk/Browse/View.html?ID=2610779) — Windspren; 179 upvotes; 1211 particles.
- ["Water" simulator](https://powdertoy.co.uk/Browse/View.html?ID=2035162) — dyaomaster; 172 upvotes; 16817 particles.

## Games & displays

- [HD Video](https://powdertoy.co.uk/Browse/View.html?ID=1488087) — drakide; 4198 upvotes; 73295 particles.
- [8x6 line text display](https://powdertoy.co.uk/Browse/View.html?ID=17758) — jacksonmj; 2692 upvotes; legacy particles.
- [Tic-Tac-Toe with AI  v.0.5.](https://powdertoy.co.uk/Browse/View.html?ID=247423) — GeNiE; 1718 upvotes; legacy particles.
- [Video](https://powdertoy.co.uk/Browse/View.html?ID=860170) — chcole48; 1440 upvotes; 13711 particles.
- [Scrolling Text Display](https://powdertoy.co.uk/Browse/View.html?ID=828603) — benthecrazy; 1178 upvotes; 26646 particles.
- [TPT Racer Game](https://powdertoy.co.uk/Browse/View.html?ID=260035) — Benassi; 1100 upvotes; legacy particles.
- [RGB Display](https://powdertoy.co.uk/Browse/View.html?ID=109980) — andrewdavidloftus; 966 upvotes; legacy particles.
- [Bad Apple!!](https://powdertoy.co.uk/Browse/View.html?ID=2308246) — leafox; 941 upvotes; 222701 particles.
- [my grandpa's TV](https://powdertoy.co.uk/Browse/View.html?ID=1553949) — PhotonPhysics; 684 upvotes; 16393 particles.
- [Photon Reflections](https://powdertoy.co.uk/Browse/View.html?ID=306596) — Pilihp64; 623 upvotes; legacy particles.
- [Compact Hi-Res Color Screen](https://powdertoy.co.uk/Browse/View.html?ID=2305687) — mark2222; 582 upvotes; 106408 particles.
- [Christmas Window Display](https://powdertoy.co.uk/Browse/View.html?ID=1905644) — Matera_the_Mad; 562 upvotes; 174849 particles.
- [First Stickman Game](https://powdertoy.co.uk/Browse/View.html?ID=7246) — jar555; 530 upvotes; 7927 particles.
- [movie theater #6](https://powdertoy.co.uk/Browse/View.html?ID=161963) — btrab1; 430 upvotes; legacy particles.
- [Pixelic Video](https://powdertoy.co.uk/Browse/View.html?ID=2113960) — jammpark; 430 upvotes; 40267 particles.
- [pacman VS stickman!](https://powdertoy.co.uk/Browse/View.html?ID=233729) — igorigrik; 382 upvotes; legacy particles.
- [Game of Life](https://powdertoy.co.uk/Browse/View.html?ID=865481) — Kalabasa; 368 upvotes; 69577 particles.
- [STKM Escape](https://powdertoy.co.uk/Browse/View.html?ID=1523763) — Toborcio; 356 upvotes; 11672 particles.
- [decimal number display+timer](https://powdertoy.co.uk/Browse/View.html?ID=60) — dnRoyston; 310 upvotes; legacy particles.
- [Whack-a-sign v2](https://powdertoy.co.uk/Browse/View.html?ID=1674452) — Isidor10; 305 upvotes; 11330 particles.
- [3D Maze Game](https://powdertoy.co.uk/Browse/View.html?ID=2568600) — csavas; 303 upvotes; 72001 particles.
- [Snake game](https://powdertoy.co.uk/Browse/View.html?ID=2067131) — Qweryntino; 296 upvotes; 47283 particles.
- [4444 Long Street](https://powdertoy.co.uk/Browse/View.html?ID=12719) — codefeenix; 292 upvotes; legacy particles.
- [8x8 lcd ](https://powdertoy.co.uk/Browse/View.html?ID=7551) — codefeenix; 274 upvotes; legacy particles.
- [Video Game with Screen](https://powdertoy.co.uk/Browse/View.html?ID=1821544) — HardPowda; 257 upvotes; 38262 particles.
- [Reader](https://powdertoy.co.uk/Browse/View.html?ID=874466) — arK; 253 upvotes; 13138 particles.
- [Hangman game](https://powdertoy.co.uk/Browse/View.html?ID=2449957) — csavas; 241 upvotes; 31473 particles.
- [Teh SNAKE](https://powdertoy.co.uk/Browse/View.html?ID=1307826) — arK; 234 upvotes; 10488 particles.

## Robots & complex machines

- [terminator type robot](https://powdertoy.co.uk/Browse/View.html?ID=166966) — tako1259; 649 upvotes; legacy particles.
- [Mass Photon Storage Demo](https://powdertoy.co.uk/Browse/View.html?ID=2201761) — mad-cow; 534 upvotes; 61947 particles.
- [Steampunk walker](https://powdertoy.co.uk/Browse/View.html?ID=717817) — slug14; 507 upvotes; 52588 particles.
- [Instant copier](https://powdertoy.co.uk/Browse/View.html?ID=1634598) — drlemon; 494 upvotes; 3384 particles.
- [Double Speed Aray Copier](https://powdertoy.co.uk/Browse/View.html?ID=875764) — Pilihp64; 461 upvotes; 10003 particles.
- [AutoLabSolve](https://powdertoy.co.uk/Browse/View.html?ID=1403685) — pilotnotflying; 452 upvotes; 10128 particles.
- [3D(ish) printer](https://powdertoy.co.uk/Browse/View.html?ID=1912471) — Qwert_Yuiop; 426 upvotes; 21518 particles.
- [Encoded PHOT Radar](https://powdertoy.co.uk/Browse/View.html?ID=2306942) — lamyipfu; 362 upvotes; 39295 particles.
- [Color Printer (4096 Colors!)](https://powdertoy.co.uk/Browse/View.html?ID=2229844) — mark2222; 334 upvotes; 57781 particles.
- [you control the robot](https://powdertoy.co.uk/Browse/View.html?ID=232149) — xcrazy; 323 upvotes; 69680 particles.
- [deployable shield!](https://powdertoy.co.uk/Browse/View.html?ID=1323671) — G-LinuxorU; 272 upvotes; 4328 particles.
- [self duplicator move robot automatic](https://powdertoy.co.uk/Browse/View.html?ID=2771938) — I8I8I; 272 upvotes; 2523 particles.
- [Longest PSTN animation (template)](https://powdertoy.co.uk/Browse/View.html?ID=1732622) — mniip; 271 upvotes; 100308 particles.
- [Electron Entanglement?](https://powdertoy.co.uk/Browse/View.html?ID=2124020) — jojofishfishing; 259 upvotes; 55458 particles.
- [EVE from WALL-E](https://powdertoy.co.uk/Browse/View.html?ID=245398) — ZeroPrizrak; 254 upvotes; legacy particles.
- [Li-Fi Printer](https://powdertoy.co.uk/Browse/View.html?ID=2574182) — Saika; 252 upvotes; 4078 particles.
- [Lunar Lander](https://powdertoy.co.uk/Browse/View.html?ID=2932691) — Isidor10; 239 upvotes; 35458 particles.
- [30Hz Temperature Grapher](https://powdertoy.co.uk/Browse/View.html?ID=2527032) — mad-cow; 235 upvotes; 30917 particles.
- [AutoLabSolve2](https://powdertoy.co.uk/Browse/View.html?ID=1410073) — pilotnotflying; 234 upvotes; 4568 particles.
- [Sorting algorithms](https://powdertoy.co.uk/Browse/View.html?ID=2368015) — LBPHacker; 232 upvotes; 51519 particles.
- [PSTN CRAY 3 Color Printer](https://powdertoy.co.uk/Browse/View.html?ID=1103335) — Amphealy; 227 upvotes; 21047 particles.

