# Powder Templates

Original Lua/Python offline project browser for The Powder Toy. Community save files, game binaries, local config and user state are excluded; the catalog preserves author attribution.

## Run

See templates.lua, curate.py and install.py. Requires a separate The Powder Toy installation.

This is a source snapshot from Z. Research. No license is granted for third-party content or trademarks.
