-- Offline community-save browser. No language model, Python service, or generated code.
local ROOT='__ROOT__'
if powderAI and powderAI.shutdown then pcall(powderAI.shutdown) end
powderAI=nil
if powderTemplates and powderTemplates.shutdown then powderTemplates.shutdown() end
local T={projects={},categories={'All projects'},category='All projects',page=1,selected=nil,status='Choose a category or search',open=false}
powderTemplates=T
local function read(path) local f=io.open(path,'rb');if not f then return nil end;local s=f:read('*a');f:close();return s end
T.lastCommand=read(ROOT..'/verification/command.txt')
local function write(path,s) local f=assert(io.open(path..'.tmp','wb'));f:write(s);f:close();assert(os.rename(path..'.tmp',path)) end
local function split(s) local t={} for v in (s..'\t'):gmatch('(.-)\t') do t[#t+1]=v end;return t end
local function esc(s) return '"'..tostring(s):gsub('[%z\1-\31\\"]',function(c) if c=='"' then return '\\"' elseif c=='\\' then return '\\\\' else return string.format('\\u%04x',c:byte()) end end)..'"' end
local function json(v)
 if type(v)=='table' then local r={} for k,x in pairs(v) do r[#r+1]=esc(k)..':'..json(x) end;return '{'..table.concat(r,',')..'}'
 elseif type(v)=='number' or type(v)=='boolean' then return tostring(v) else return esc(v or '') end
end
local seen={}
for line in (read(ROOT..'/catalog.tsv') or ''):gmatch('[^\n]+') do
 local v=split(line);local id=tonumber(v[1]);if id and #v>=24 then
  local p={id=id,category=v[2],title=v[3],author=v[4],votes=tonumber(v[5]),particles=tonumber(v[6]),description=v[7],url=v[8],settings={}}
  for i=9,24 do p.settings[i-8]=tonumber(v[i]) or 0 end
  T.projects[#T.projects+1]=p
  if not seen[p.category] then seen[p.category]=true;T.categories[#T.categories+1]=p.category end
 end
end
local function count() return sim.partCount() end
local function currentSettings()
 local cx,cy=sim.customGravity();local ex,ey=sim.edgeVelocity()
 return {sim.gravityMode(),sim.airMode(),sim.edgeMode(),sim.heatSim() and 0 or 1,sim.newtonianGravity() and 1 or 0,sim.ambientHeatSim() and 1 or 0,sim.waterEqualization(),sim.paused() and 1 or 0,sim.ambientAirTemp(),cx,cy,sim.edgePressure(),ex,ey,sim.vorticityCoeff(),sim.convectionMode()}
end
local function apply(s)
 sim.gravityMode(s[1]);sim.airMode(s[2]);sim.edgeMode(s[3]);sim.heatSim(s[4]==0);sim.newtonianGravity(s[5]==1);sim.ambientHeatSim(s[6]==1);sim.waterEqualization(s[7]);sim.ambientAirTemp(s[9]);sim.customGravity(s[10],s[11]);sim.edgePressure(s[12]);sim.edgeVelocity(s[13],s[14]);sim.vorticityCoeff(s[15]);sim.convectionMode(s[16])
end
local function backup()
 local s=currentSettings();local stamp=sim.saveStamp(0,0,611,383,1);assert(stamp and #stamp>0,'Could not back up current canvas');T.previous={stamp=stamp,settings=s};write(ROOT..'/last-canvas-backup.json',json(T.previous))
end
local function restore()
 assert(T.previous,'No previous canvas available');sim.paused(true);sim.clearSim();assert(sim.loadStamp(T.previous.stamp,0,0,false,0,1)==1,'Could not restore previous canvas');apply(T.previous.settings);sim.paused(T.previous.settings[8]==1)
end
local function loadProject(p,testing)
 assert(p,'Select a project first');local path=ROOT..'/saves/'..p.id..'.cps';local f=assert(io.open(path,'rb'),'Local save file is missing');f:close()
 if not testing then backup() end
 sim.paused(true);sim.clearSim();local ok,err=sim.loadStamp('powder-template-'..p.id,0,0,false,0,1);assert(ok==1,err or 'Game could not load save');apply(p.settings)
 local particles=count();assert(particles>0,'Save loaded no particles')
 T.current=p;T.status=p.title..'  /  '..p.author;T.selected=p
 if testing then sim.paused(true) else sim.paused(p.settings[8]==1) end
 return particles
end
local function short(s,n) if #s<=n then return s end;return s:sub(1,n-3)..'...' end
local function wrap(s,width,maxLines)
 local lines={};local current=''
 for word in tostring(s):gmatch('%S+') do if #current+#word+1>width then lines[#lines+1]=current;current=word;if #lines>=maxLines then break end else current=current=='' and word or current..' '..word end end
 if #lines<maxLines and current~='' then lines[#lines+1]=current end
 return table.concat(lines,'\n')
end
local refresh,show
local function close() if T.window then ui.closeWindow(T.window) end;T.open=false end
local function loadSelected()
 local ok,err=pcall(loadProject,T.selected,false)
 if ok then close() else pcall(restore);T.status='Load failed: '..tostring(err);refresh() end
end
refresh=function()
 if not T.window then return end
 local q=(T.search:text() or ''):lower();local filtered={}
 for _,p in ipairs(T.projects) do
  if (T.category=='All projects' or p.category==T.category) and (q=='' or (p.title..' '..p.author..' '..p.category..' '..p.description):lower():find(q,1,true)) then filtered[#filtered+1]=p end
 end
 T.filtered=filtered;local pages=math.max(1,math.ceil(#filtered/9));T.page=math.max(1,math.min(pages,T.page))
 for i,b in ipairs(T.categoryButtons) do local cat=T.categories[i];b:text((T.category==cat and '> ' or '')..short(cat,23)) end
 for i,b in ipairs(T.rows) do
  local p=filtered[(T.page-1)*9+i];b:visible(p~=nil)
  if p then b:text((T.selected==p and '> ' or '')..short(p.title,58));b:action(function() T.selected=p;refresh() end) end
 end
 T.pageLabel:text(#filtered..' projects  |  '..T.page..' / '..pages)
 T.previousPage:enabled(T.page>1);T.nextPage:enabled(T.page<pages)
 if T.selected then
  local p=T.selected;T.title:text(short(p.title,61));T.credit:text('By '..short(p.author,25)..'  |  '..p.votes..' upvotes  |  '..p.particles..' particles')
  T.description:text(wrap(p.description~='' and p.description or 'Follow the instructions and controls included inside this save.',68,3));T.load:enabled(true)
 else T.title:text('Select a project');T.credit:text('Downloaded community saves. Author credits preserved.');T.description:text('Loads the real project directly into your current game.\nYour previous canvas is backed up before loading.');T.load:enabled(false) end
 T.footer:text(short(T.status,49))
end
show=function()
 if T.window then T.open=true;refresh();ui.showWindow(T.window);return end
 local w=Window:new(-1,-1,600,368);T.window=w;T.open=true
 w:addComponent(Label:new(12,7,576,20,'Templates  /  '..#T.projects..' community projects  /  offline'))
 T.search=Textbox:new(170,32,418,23,'','Search projects, authors, or topics');w:addComponent(T.search);T.search:onTextChanged(function() T.page=1;refresh() end)
 T.categoryButtons={};for i,cat in ipairs(T.categories) do local categoryName=cat;local b=Button:new(10,33+(i-1)*17,150,17,short(cat,23));b:action(function() T.category=categoryName;T.page=1;T.selected=nil;refresh() end);w:addComponent(b);T.categoryButtons[i]=b end
 T.rows={};for i=1,9 do local b=Button:new(170,63+(i-1)*19,418,19,'');w:addComponent(b);T.rows[i]=b end
 T.previousPage=Button:new(170,237,48,20,'<');T.previousPage:action(function() T.page=T.page-1;refresh() end);w:addComponent(T.previousPage)
 T.pageLabel=Label:new(224,238,306,18,'');w:addComponent(T.pageLabel)
 T.nextPage=Button:new(540,237,48,20,'>');T.nextPage:action(function() T.page=T.page+1;refresh() end);w:addComponent(T.nextPage)
 T.title=Label:new(170,264,418,17,'');T.credit=Label:new(170,282,418,15,'');T.description=Label:new(170,299,418,34,'');w:addComponent(T.title);w:addComponent(T.credit);w:addComponent(T.description)
 T.footer=Label:new(170,345,313,16,'');w:addComponent(T.footer)
 T.load=Button:new(497,340,91,22,'Load project');T.load:action(loadSelected);w:addComponent(T.load)
 w:onTryExit(close);w:onTryOkay(loadSelected);refresh();ui.showWindow(w)
end
function T.show() show() end
function T.load(id) for _,p in ipairs(T.projects) do if p.id==id then return loadProject(p,false) end end;error('Unknown project') end
function T.undo() return restore() end
local position=read(ROOT..'/button-position.txt') or '527 355';local px,py=position:match('(%d+) (%d+)');T.x=tonumber(px) or 527;T.y=tonumber(py) or 355
local function down(x,y,b) if b==1 and x>=T.x and x<=T.x+76 and y>=T.y and y<=T.y+20 then T.drag={x=x,y=y,px=T.x,py=T.y,moved=false};return false end end
local function move(x,y) if T.drag then local d=T.drag;if math.abs(x-d.x)+math.abs(y-d.y)>3 then d.moved=true end;T.x=math.floor(math.max(4,math.min(531,d.px+x-d.x)));T.y=math.floor(math.max(4,math.min(359,d.py+y-d.y)));return false end end
local function up(x,y,b) if T.drag then local d=T.drag;T.drag=nil;write(ROOT..'/button-position.txt',T.x..' '..T.y);if not d.moved then show() end;return false end end
local function draw() gfx.fillRect(T.x,T.y,77,21,22,27,33,245);gfx.drawRect(T.x,T.y,77,21,98,158,205,255);gfx.drawText(T.x+9,T.y+7,'Templates',207,227,242,255) end
local function key(k,scan,repeatKey,shift,ctrl,alt)
 if k==1073741889 then show();return false end
 if ctrl and shift and k==122 then local ok,err=pcall(restore);T.status=ok and 'Previous canvas restored' or tostring(err);return false end
end
local function aftersim() if T.verify and T.verify.running then T.verify.frames=T.verify.frames+1 end end
local function tick()
 if not T.heartbeat or T.heartbeat~=os.time() then T.heartbeat=os.time();write(ROOT..'/verification/heartbeat.json',json({time=os.time(),count=#T.projects,current=T.current and T.current.id or 0,button_x=T.x,button_y=T.y})) end
 local command=read(ROOT..'/verification/command.txt')
 if command and command~=T.lastCommand then
  T.lastCommand=command;local action,arg=command:match('^(%w+)%s*(%d*)')
  if action=='SHOW' then show()
  elseif action=='LOAD' then local ok,err=pcall(T.load,tonumber(arg));write(ROOT..'/verification/load-result.json',json({ok=ok,result=err,id=tonumber(arg),particles=count()}))
  elseif action=='VERIFY' then
   close();backup();T.verify={index=1,frames=0,running=false,results={},started=os.time()};T.status='Verifying local projects'
  elseif action=='PAUSE' then sim.paused(true)
  elseif action=='PLAY' then sim.paused(false)
  elseif action=='REFRESH' then dofile(ROOT..'/installed-templates.lua');return
  end
 end
 local v=T.verify
 if v then
  if not v.running then
   local p=T.projects[v.index]
   if not p then
    write(ROOT..'/verification/game-load-tests.json',json(v.results));write(ROOT..'/verification/completed.json',json({count=#T.projects,finished=os.time(),seconds=os.time()-v.started}));T.verify=nil;pcall(restore);T.status='Library verified in the game'
   else
    local began=os.clock();local ok,n=pcall(loadProject,p,true)
    v.result={id=p.id,title=p.title,ok=ok,load_seconds=os.clock()-began,particles=ok and n or 0,error=ok and '' or tostring(n)}
    if not ok then v.results[tostring(p.id)]=v.result;v.index=v.index+1 else v.frames=0;v.running=true;sim.paused(false) end
   end
  elseif v.frames>=2 then
   sim.paused(true);v.result.after_frames=count();v.result.frames=v.frames;v.result.ok=v.result.ok and v.result.after_frames>0;v.results[tostring(v.result.id)]=v.result;v.index=v.index+1;v.running=false
   if v.index%20==0 then write(ROOT..'/verification/progress.json',json({done=v.index-1,total=#T.projects})) end
  end
 end
end
evt.register(evt.TICK,tick);evt.register(evt.TICK,draw);evt.register(evt.KEYPRESS,key);evt.register(evt.MOUSEDOWN,down);evt.register(evt.MOUSEMOVE,move);evt.register(evt.MOUSEUP,up);evt.register(evt.AFTERSIM,aftersim)
function T.shutdown() evt.unregister(evt.TICK,tick);evt.unregister(evt.TICK,draw);evt.unregister(evt.KEYPRESS,key);evt.unregister(evt.MOUSEDOWN,down);evt.unregister(evt.MOUSEMOVE,move);evt.unregister(evt.MOUSEUP,up);evt.unregister(evt.AFTERSIM,aftersim);close() end
tick()
print('Templates library ready: '..#T.projects..' local community projects. F8 opens the browser.')
