#!/bin/zsh
cd -- "${0:A:h}"
exec /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 launch.py
