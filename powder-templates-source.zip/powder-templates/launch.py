#!/usr/bin/env python3
"""Start the existing Steam game in its original userdata directory with its OpenGL fix."""
from pathlib import Path
import json,os,subprocess
ROOT=Path(__file__).resolve().parent
cfg=json.loads((ROOT/'config.json').read_text());binary=Path(cfg['game_app'])/'Contents/MacOS/powder'
running=subprocess.run(['pgrep','-f',str(binary)],capture_output=True,text=True).returncode==0
if not running:
 env=os.environ.copy();env.setdefault('SDL_RENDER_DRIVER','opengl')
 with (ROOT/'game.log').open('ab') as log:
  subprocess.Popen([str(binary),'ddir',cfg['game_data'],'kiosk=false'],cwd=cfg['game_data'],env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
print('Templates is ready inside The Powder Toy. Click Templates or press F8.')
