#!/usr/bin/env python3
"""Download credited public saves through The Powder Toy's official read-only API."""
from pathlib import Path
import bz2,concurrent.futures,hashlib,json,re,struct,subprocess,time,urllib.parse

ROOT=Path(__file__).resolve().parent
CATEGORIES={
 'Human body & biology':['human body','organism','heart','biology'],
 'Computers & processors':['computer','processor','cpu','turing'],
 'Electronic circuits':['circuit','logic','calculator','electronics'],
 'Trains & transport':['train','railway','locomotive','transport'],
 'Chemical reactions':['reaction','chemistry','chemical','electrolysis'],
 'Worlds & planets':['world','planet','earth','ecosystem'],
 'Cities & architecture':['city','town','building','skyscraper'],
 'Bombs & explosions':['bomb','nuke','explosion','explosive'],
 'Nuclear & power plants':['reactor','nuclear plant','power plant','fusion'],
 'Factories & automation':['factory','automatic','refinery','production'],
 'Engines & machinery':['engine','machine','motor','turbine'],
 'Vehicles & aircraft':['car','airplane','spaceship','ship'],
 'Volcanoes & disasters':['volcano','disaster','earthquake','tsunami'],
 'Waterworks & boilers':['water','boiler','dam','fountain'],
 'Space & science':['space','solar system','physics','particle accelerator'],
 'Games & displays':['game','display','screen','tetris'],
 'Robots & complex machines':['robot','printer','mechanical','subframe']
}
FEATURED={1477357:'Human body & biology',3422457:'Human body & biology',1281282:'Human body & biology',1932845:'Computers & processors',2303519:'Computers & processors',1761441:'Computers & processors',2148569:'Computers & processors',1559619:'Computers & processors',1045867:'Computers & processors',3235632:'Computers & processors'}

def fetch(url,path):
 if path.exists() and path.stat().st_size>20:return path.read_bytes()
 result=subprocess.run(['curl','-fsSL','--retry','2','--retry-delay','1','--max-time','25',url,'-o',str(path)+'.tmp'],capture_output=True)
 if result.returncode:raise RuntimeError(result.stderr.decode(errors='replace')[:200])
 Path(str(path)+'.tmp').replace(path);return path.read_bytes()

def bson(data,pos=0):
 end=pos+struct.unpack_from('<i',data,pos)[0];pos+=4;out={}
 if end>len(data) or end-pos<1:raise ValueError('Invalid BSON length')
 while pos<end-1:
  typ=data[pos];pos+=1;z=data.index(0,pos);key=data[pos:z].decode('utf8',errors='replace');pos=z+1
  if typ==1:value=struct.unpack_from('<d',data,pos)[0];pos+=8
  elif typ==2:
   n=struct.unpack_from('<i',data,pos)[0];pos+=4;value=data[pos:pos+n-1].decode('utf8',errors='replace');pos+=n
  elif typ in (3,4):value,pos=bson(data,pos)
  elif typ==5:
   n=struct.unpack_from('<i',data,pos)[0];pos+=5;value=data[pos:pos+n];pos+=n
  elif typ==8:value=bool(data[pos]);pos+=1
  elif typ==10:value=None
  elif typ==16:value=struct.unpack_from('<i',data,pos)[0];pos+=4
  elif typ in (17,18):value=struct.unpack_from('<q',data,pos)[0];pos+=8
  else:raise ValueError('Unsupported BSON field '+str(typ))
  out[key]=value
 if data[end-1]!=0:raise ValueError('Invalid BSON terminator')
 return out,end

def inspect_save(data):
 if len(data)<20:raise ValueError('Save is too small')
 signature=data[:3];version=data[4];width=data[6]*data[5];height=data[7]*data[5]
 if signature==b'OPS':
  raw=bz2.decompress(data[12:]);expected=struct.unpack_from('<I',data,8)[0]
  if len(raw)!=expected or len(raw)>40000000:raise ValueError('Invalid decompressed size')
  doc,end=bson(raw)
  positions=doc.get('partsPos',b'');particles=sum(int.from_bytes(positions[i:i+3],'big') for i in range(0,len(positions),3))
  settings={k:doc.get(k,default) for k,default in {'legacyEnable':False,'gravityEnable':False,'aheat_enable':False,'waterEEnabled':False,'paused':False,'gravityMode':0,'airMode':0,'edgeMode':0,'ambientAirTemp':295.15,'customGravityX':0.0,'customGravityY':0.0,'edgePressure':0.0,'edgeVelocityX':0.0,'edgeVelocityY':0.0,'vorticityCoeff':0.0,'convectionMode':1}.items()}
  minimum=doc.get('minimumVersion',{});signs=doc.get('signs',{})
  sign_texts=[str(v.get('text','')) for v in signs.values() if isinstance(v,dict)]
  if minimum.get('major',0)>100 or (minimum.get('major',0)==100 and minimum.get('minor',0)>1):raise ValueError('Requires a newer game version')
  return {'format':'OPS','width':width,'height':height,'particles':particles,'settings':settings,'minimum_version':minimum,'signs':sign_texts,'origin':doc.get('origin',{})}
 if signature in (b'PSv',b'fuC'):
  bz2.decompress(data[12:]);flags=data[3]
  return {'format':'legacy','width':width,'height':height,'particles':None,'settings':{'legacyEnable':bool(flags&1),'paused':bool((flags>>1)&1),'gravityMode':(flags>>2)&3,'airMode':(flags>>4)&7,'gravityEnable':bool((flags>>7)&1),'aheat_enable':False,'waterEEnabled':False,'edgeMode':0,'ambientAirTemp':295.15,'customGravityX':0.,'customGravityY':0.,'edgePressure':0.,'edgeVelocityX':0.,'edgeVelocityY':0.,'vorticityCoeff':0.,'convectionMode':0},'signs':[]}
 raise ValueError('Not a Powder Toy save')

def search(category,query):
 key=hashlib.sha256(query.encode()).hexdigest()[:12];url='https://powdertoy.co.uk/Browse.json?'+urllib.parse.urlencode({'Start':0,'Count':35,'Search_Query':query})
 data=json.loads(fetch(url,ROOT/'metadata'/('search-'+key+'.json')))
 return category,query,[s for s in data.get('Saves',[]) if s.get('Published') and s.get('ScoreUp',0)>=8]

def download(item):
 try:
  sid=item['id'];url=f'https://static.powdertoy.co.uk/{sid}.cps';path=ROOT/'saves'/f'{sid}.cps';data=fetch(url,path);parsed=inspect_save(data)
  if parsed.get('particles') is not None and parsed['particles']<150:raise ValueError('Too few particles for this collection')
  info=json.loads(fetch(f'https://powdertoy.co.uk/Browse/View.json?ID={sid}',ROOT/'metadata'/f'{sid}.json'))
  if not info.get('Published'):raise ValueError('Project is not public')
  item.update(title=info['Name'],author=info['Username'],description=info.get('Description',''),tags=info.get('Tags',[]),votes=info.get('ScoreUp',0),downvotes=info.get('ScoreDown',0),views=info.get('Views',0),updated=info.get('Date'),source=f'https://powdertoy.co.uk/Browse/View.html?ID={sid}',download_url=url,file=f'saves/{sid}.cps',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),**parsed)
  return item,None
 except Exception as e:return None,{'id':item['id'],'error':str(e)}

def field(value):return re.sub(r'[\x00-\x1f\x7f]',' ',str(value)).replace('\t',' ').strip()
def write_catalog(projects,failures):
 projects.sort(key=lambda x:(list(CATEGORIES).index(x['category']),-x['votes'],x['title'].lower()))
 catalog={'name':'Powder Templates','source':'Official Powder Toy community save library','created':'2026-10-13','categories':[k for k in CATEGORIES if any(p['category']==k for p in projects)],'count':len(projects),'projects':projects,'download_failures':failures}
 (ROOT/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2))
 lines=[]
 keys=['gravityMode','airMode','edgeMode','legacyEnable','gravityEnable','aheat_enable','waterEEnabled','paused','ambientAirTemp','customGravityX','customGravityY','edgePressure','edgeVelocityX','edgeVelocityY','vorticityCoeff','convectionMode']
 for p in projects:
  s=p['settings'];values=[p['id'],p['category'],p['title'],p['author'],p['votes'],p.get('particles') or 0,p['description'][:1200],p['source']]
  values += [int(s[k]) if isinstance(s[k],bool) else s[k] for k in keys]
  lines.append('\t'.join(field(v) for v in values))
 (ROOT/'catalog.tsv').write_text('\n'.join(lines)+'\n')
 return catalog

def main():
 for sub in ('saves','metadata','verification','backups'):(ROOT/sub).mkdir(exist_ok=True)
 pools={c:{} for c in CATEGORIES};tasks=[(c,q) for c,qs in CATEGORIES.items() for q in qs]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
  futures={ex.submit(search,c,q):(c,q) for c,q in tasks}
  for f in concurrent.futures.as_completed(futures):
   try:
    category,query,saves=f.result()
    for s in saves:pools[category][s['ID']]=s
    print('Search:',category,query,len(saves),flush=True)
   except Exception as e:print('Search failed:',futures[f],str(e),flush=True)
 selected={sid:{'id':sid,'category':cat,'featured':True} for sid,cat in FEATURED.items()}
 # Reserve 22 distinct highly rated projects per category, then take alternates.
 for category,pool in pools.items():
  added=sum(v['category']==category for v in selected.values())
  for sid,s in sorted(pool.items(),key=lambda v:v[1]['ScoreUp']-v[1].get('ScoreDown',0),reverse=True):
   if sid in selected:continue
   selected[sid]={'id':sid,'category':category,'featured':False};added+=1
   if added>=22:break
 projects=[];failures=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
  for item,error in ex.map(download,selected.values()):
   if item:projects.append(item)
   else:failures.append(error)
   if (len(projects)+len(failures))%20==0:print('Downloaded',len(projects),'projects;',len(failures),'skipped',flush=True)
 catalog=write_catalog(projects,failures);print('CATALOG READY:',catalog['count'],'projects',flush=True)
 if len(projects)<201:raise SystemExit('Not enough validated projects; expand queries before delivery')
if __name__=='__main__':main()
