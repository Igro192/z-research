// swift-tools-version: 6.2

import PackageDescription

let package = Package(
    name: "SystemLoadLab",
    platforms: [
        .macOS(.v13)
    ],
    products: [
        .executable(name: "SystemLoadLab", targets: ["SystemLoadLab"]),
        .executable(name: "SafetyPolicyCheck", targets: ["SafetyPolicyCheck"])
    ],
    targets: [
        .target(name: "LoadSafetyCore"),
        .executableTarget(
            name: "SystemLoadLab",
            dependencies: ["LoadSafetyCore"]
        ),
        .executableTarget(
            name: "SafetyPolicyCheck",
            dependencies: ["LoadSafetyCore"]
        )
    ],
    swiftLanguageModes: [.v5]
)
