#!/bin/zsh
set -euo pipefail

script_dir="${0:A:h}"
cd "$script_dir"

swift build -c release --product SystemLoadLab

app_dir="$script_dir/dist/System Load Lab.app"
contents_dir="$app_dir/Contents"
macos_dir="$contents_dir/MacOS"

mkdir -p "$macos_dir"
cp "$script_dir/.build/release/SystemLoadLab" "$macos_dir/SystemLoadLab"

apply_plist="$contents_dir/Info.plist"
/usr/libexec/PlistBuddy -c "Clear dict" "$apply_plist" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Add :CFBundleDevelopmentRegion string en" "$apply_plist"
/usr/libexec/PlistBuddy -c "Add :CFBundleDisplayName string System Load Lab" "$apply_plist"
/usr/libexec/PlistBuddy -c "Add :CFBundleExecutable string SystemLoadLab" "$apply_plist"
/usr/libexec/PlistBuddy -c "Add :CFBundleIdentifier string local.system-load-lab" "$apply_plist"
/usr/libexec/PlistBuddy -c "Add :CFBundleInfoDictionaryVersion string 6.0" "$apply_plist"
/usr/libexec/PlistBuddy -c "Add :CFBundleName string System Load Lab" "$apply_plist"
/usr/libexec/PlistBuddy -c "Add :CFBundlePackageType string APPL" "$apply_plist"
/usr/libexec/PlistBuddy -c "Add :CFBundleShortVersionString string 1.0.0" "$apply_plist"
/usr/libexec/PlistBuddy -c "Add :CFBundleVersion string 1" "$apply_plist"
/usr/libexec/PlistBuddy -c "Add :LSMinimumSystemVersion string 13.0" "$apply_plist"
/usr/libexec/PlistBuddy -c "Add :NSHighResolutionCapable bool true" "$apply_plist"

xattr -cr "$app_dir"
codesign --force --sign - "$app_dir"

echo "$app_dir"
