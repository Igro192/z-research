import Foundation

public struct LoadConfiguration: Equatable, Sendable {
    public var workers: Int
    public var dutyCycle: Double
    public var memoryMB: Int
    public var durationSeconds: Int

    public init(workers: Int, dutyCycle: Double, memoryMB: Int, durationSeconds: Int) {
        self.workers = workers
        self.dutyCycle = dutyCycle
        self.memoryMB = memoryMB
        self.durationSeconds = durationSeconds
    }
}

public struct SafetyLimits: Equatable, Sendable {
    public let maxWorkers: Int
    public let maxDutyCycle: Double
    public let maxMemoryMB: Int
    public let minDurationSeconds: Int
    public let maxDurationSeconds: Int

    public init(
        maxWorkers: Int,
        maxDutyCycle: Double,
        maxMemoryMB: Int,
        minDurationSeconds: Int,
        maxDurationSeconds: Int
    ) {
        self.maxWorkers = maxWorkers
        self.maxDutyCycle = maxDutyCycle
        self.maxMemoryMB = maxMemoryMB
        self.minDurationSeconds = minDurationSeconds
        self.maxDurationSeconds = maxDurationSeconds
    }
}

public enum SafetyPolicy {
    public static let hardMaximumMemoryMB = 1_024
    public static let hardMaximumWorkers = 8
    public static let hardMaximumDutyCycle = 0.75
    public static let minimumDurationSeconds = 5
    public static let hardMaximumDurationSeconds = 60

    public static func limits(
        logicalProcessorCount: Int,
        physicalMemoryBytes: UInt64,
        availableMemoryBytes: UInt64
    ) -> SafetyLimits {
        // Keep at least one logical processor available for macOS and the Stop button.
        let processorLimit = max(1, logicalProcessorCount - 1)
        let maxWorkers = min(hardMaximumWorkers, processorLimit)

        let bytesPerMB = UInt64(1_048_576)
        let physicalMB = physicalMemoryBytes / bytesPerMB
        let availableMB = availableMemoryBytes / bytesPerMB

        // Never reserve more than 10% of physical RAM. Also keep 512 MB of the
        // currently available memory untouched, then use at most 25% of the rest.
        let physicalCap = physicalMB / 10
        let availableHeadroom = availableMB > 512 ? availableMB - 512 : 0
        let availableCap = availableHeadroom / 4
        let calculatedMemoryCap = min(
            UInt64(hardMaximumMemoryMB),
            min(physicalCap, availableCap)
        )

        return SafetyLimits(
            maxWorkers: maxWorkers,
            maxDutyCycle: hardMaximumDutyCycle,
            maxMemoryMB: Int(calculatedMemoryCap),
            minDurationSeconds: minimumDurationSeconds,
            maxDurationSeconds: hardMaximumDurationSeconds
        )
    }

    public static func clamp(_ configuration: LoadConfiguration, to limits: SafetyLimits) -> LoadConfiguration {
        LoadConfiguration(
            workers: min(max(configuration.workers, 1), limits.maxWorkers),
            dutyCycle: min(max(configuration.dutyCycle, 0.10), limits.maxDutyCycle),
            memoryMB: min(max(configuration.memoryMB, 0), limits.maxMemoryMB),
            durationSeconds: min(
                max(configuration.durationSeconds, limits.minDurationSeconds),
                limits.maxDurationSeconds
            )
        )
    }
}
