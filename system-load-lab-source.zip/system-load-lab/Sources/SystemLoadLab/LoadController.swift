import Combine
import Darwin
import Dispatch
import Foundation
import LoadSafetyCore

@MainActor
final class LoadController: ObservableObject {
    @Published var workerCount: Int
    @Published var dutyCycle: Double
    @Published var memoryMB: Double
    @Published var durationSeconds: Double

    @Published private(set) var isRunning = false
    @Published private(set) var elapsedSeconds = 0.0
    @Published private(set) var allocatedMemoryMB = 0
    @Published private(set) var status = "Ready. Configure a bounded test, then press Start."
    @Published private(set) var thermalStateText = "Nominal"

    let limits: SafetyLimits

    private var cpuTasks: [Task<Void, Never>] = []
    private var memoryAllocationTask: Task<MemoryReservation?, Never>?
    private var memoryInstallTask: Task<Void, Never>?
    private var monitorTask: Task<Void, Never>?
    private var memoryReservation: MemoryReservation?
    private var memoryPressureSource: DispatchSourceMemoryPressure?
    private var startedAt: Date?
    private var activeDurationSeconds = 0

    init() {
        let processInfo = ProcessInfo.processInfo
        limits = SafetyPolicy.limits(
            logicalProcessorCount: processInfo.activeProcessorCount,
            physicalMemoryBytes: processInfo.physicalMemory,
            availableMemoryBytes: Self.availableMemoryBytes()
        )

        workerCount = min(2, limits.maxWorkers)
        dutyCycle = 0.50
        memoryMB = Double(min(256, limits.maxMemoryMB))
        durationSeconds = 20
        thermalStateText = Self.describe(processInfo.thermalState)

        configureMemoryPressureMonitor()
    }

    var progress: Double {
        guard activeDurationSeconds > 0 else { return 0 }
        return min(1, elapsedSeconds / Double(activeDurationSeconds))
    }

    var configuredCPUPercentText: String {
        let approximateCores = Double(workerCount) * dutyCycle
        return String(format: "%.2f core-equivalents", approximateCores)
    }

    func start() {
        guard !isRunning else { return }

        let thermalState = ProcessInfo.processInfo.thermalState
        thermalStateText = Self.describe(thermalState)
        guard thermalState == .nominal || thermalState == .fair else {
            status = "Start refused because macOS reports elevated thermal pressure."
            return
        }

        let requested = LoadConfiguration(
            workers: workerCount,
            dutyCycle: dutyCycle,
            memoryMB: Int(memoryMB.rounded()),
            durationSeconds: Int(durationSeconds.rounded())
        )
        let configuration = SafetyPolicy.clamp(requested, to: limits)

        workerCount = configuration.workers
        dutyCycle = configuration.dutyCycle
        memoryMB = Double(configuration.memoryMB)
        durationSeconds = Double(configuration.durationSeconds)
        activeDurationSeconds = configuration.durationSeconds
        elapsedSeconds = 0
        allocatedMemoryMB = 0
        startedAt = Date()
        isRunning = true
        status = "Running within the enforced safety limits."

        let sink = WorkSink()
        cpuTasks = (0..<configuration.workers).map { workerIndex in
            CPUWorker.start(
                index: workerIndex,
                dutyCycle: configuration.dutyCycle,
                sink: sink
            )
        }

        if configuration.memoryMB > 0 {
            let allocationTask = Task.detached(priority: .utility) {
                MemoryReservation.allocate(megabytes: configuration.memoryMB)
            }
            memoryAllocationTask = allocationTask
            memoryInstallTask = Task { [weak self] in
                let reservation = await allocationTask.value
                guard !Task.isCancelled, let reservation, let self, self.isRunning else { return }
                self.memoryReservation = reservation
                self.allocatedMemoryMB = reservation.allocatedMegabytes
            }
        }

        monitorTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 250_000_000)
                guard !Task.isCancelled, let self else { return }
                self.updateRunState()
            }
        }
    }

    func stopByUser() {
        stop(reason: "Stopped by user. All reserved memory was released.")
    }

    func stopForWindowClose() {
        stop(reason: "Stopped because the window closed.")
    }

    private func updateRunState() {
        guard isRunning, let startedAt else { return }

        elapsedSeconds = Date().timeIntervalSince(startedAt)
        let thermalState = ProcessInfo.processInfo.thermalState
        thermalStateText = Self.describe(thermalState)

        if thermalState == .serious || thermalState == .critical {
            stop(reason: "Automatically stopped: macOS reported serious thermal pressure.")
            return
        }

        if elapsedSeconds >= Double(activeDurationSeconds) {
            elapsedSeconds = Double(activeDurationSeconds)
            stop(reason: "Completed safely at the hard time limit. Memory was released.")
        }
    }

    private func stop(reason: String) {
        guard isRunning else { return }

        cpuTasks.forEach { $0.cancel() }
        cpuTasks.removeAll()
        memoryAllocationTask?.cancel()
        memoryAllocationTask = nil
        memoryInstallTask?.cancel()
        memoryInstallTask = nil
        monitorTask?.cancel()
        monitorTask = nil
        memoryReservation = nil
        allocatedMemoryMB = 0
        startedAt = nil
        isRunning = false
        status = reason
    }

    private func configureMemoryPressureMonitor() {
        let source = DispatchSource.makeMemoryPressureSource(
            eventMask: [.warning, .critical],
            queue: .main
        )
        source.setEventHandler { [weak self] in
            guard let self, self.isRunning else { return }
            self.stop(reason: "Automatically stopped: macOS reported memory pressure.")
        }
        source.resume()
        memoryPressureSource = source
    }

    private static func describe(_ state: ProcessInfo.ThermalState) -> String {
        switch state {
        case .nominal: return "Nominal"
        case .fair: return "Fair"
        case .serious: return "Serious"
        case .critical: return "Critical"
        @unknown default: return "Unknown"
        }
    }

    private static func availableMemoryBytes() -> UInt64 {
        var pageSize: vm_size_t = 0
        guard host_page_size(mach_host_self(), &pageSize) == KERN_SUCCESS else {
            return ProcessInfo.processInfo.physicalMemory / 2
        }

        var statistics = vm_statistics64()
        var count = mach_msg_type_number_t(
            MemoryLayout<vm_statistics64_data_t>.size / MemoryLayout<integer_t>.size
        )
        let result = withUnsafeMutablePointer(to: &statistics) { pointer in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { reboundPointer in
                host_statistics64(
                    mach_host_self(),
                    HOST_VM_INFO64,
                    reboundPointer,
                    &count
                )
            }
        }

        guard result == KERN_SUCCESS else {
            return ProcessInfo.processInfo.physicalMemory / 2
        }

        let availablePages = UInt64(statistics.free_count)
            + UInt64(statistics.inactive_count)
            + UInt64(statistics.speculative_count)
        return availablePages * UInt64(pageSize)
    }
}

private enum CPUWorker {
    static func start(index: Int, dutyCycle: Double, sink: WorkSink) -> Task<Void, Never> {
        Task.detached(priority: .userInitiated) {
            let quantumNanoseconds = UInt64(100_000_000)
            let busyNanoseconds = UInt64(Double(quantumNanoseconds) * dutyCycle)
            let restNanoseconds = quantumNanoseconds - busyNanoseconds
            var value = UInt64(index + 1) &* 0x9E3779B97F4A7C15

            while !Task.isCancelled {
                let busyUntil = DispatchTime.now().uptimeNanoseconds &+ busyNanoseconds
                var cancellationCounter = 0

                while DispatchTime.now().uptimeNanoseconds < busyUntil {
                    value ^= value >> 12
                    value ^= value << 25
                    value ^= value >> 27
                    value = value &* 0x2545F4914F6CDD1D

                    cancellationCounter &+= 1
                    if cancellationCounter & 0x3FFF == 0, Task.isCancelled {
                        return
                    }
                }

                sink.consume(value)

                if restNanoseconds > 0 {
                    do {
                        try await Task.sleep(nanoseconds: restNanoseconds)
                    } catch {
                        return
                    }
                }
            }
        }
    }
}

private final class WorkSink: @unchecked Sendable {
    private let lock = NSLock()
    private var value: UInt64 = 0

    func consume(_ newValue: UInt64) {
        lock.lock()
        value ^= newValue
        lock.unlock()
    }
}

private final class MemoryReservation: @unchecked Sendable {
    private let blocks: [Data]
    let allocatedMegabytes: Int

    private init(blocks: [Data], allocatedMegabytes: Int) {
        self.blocks = blocks
        self.allocatedMegabytes = allocatedMegabytes
    }

    static func allocate(megabytes: Int) -> MemoryReservation? {
        guard megabytes > 0 else { return MemoryReservation(blocks: [], allocatedMegabytes: 0) }

        let chunkSizeMB = 8
        var blocks: [Data] = []
        var allocatedMB = 0
        blocks.reserveCapacity((megabytes + chunkSizeMB - 1) / chunkSizeMB)

        while allocatedMB < megabytes {
            if Task.isCancelled { return nil }

            let nextChunkMB = min(chunkSizeMB, megabytes - allocatedMB)
            blocks.append(Data(repeating: 0xA5, count: nextChunkMB * 1_048_576))
            allocatedMB += nextChunkMB
        }

        return MemoryReservation(blocks: blocks, allocatedMegabytes: allocatedMB)
    }
}
