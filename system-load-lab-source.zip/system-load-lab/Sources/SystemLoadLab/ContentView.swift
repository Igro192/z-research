import SwiftUI

struct ContentView: View {
    @StateObject private var controller = LoadController()

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            header
            controls
            runStatus
            safetyNotes
        }
        .padding(24)
        .onDisappear {
            controller.stopForWindowClose()
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("System Load Lab")
                .font(.largeTitle.weight(.semibold))
            Text("A short, bounded load generator for reproducing UI slowdowns without trying to crash or overheat your Mac.")
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var controls: some View {
        GroupBox("Test configuration") {
            Grid(alignment: .leading, horizontalSpacing: 14, verticalSpacing: 14) {
                GridRow {
                    Text("CPU workers")
                    Stepper(
                        value: $controller.workerCount,
                        in: 1...controller.limits.maxWorkers
                    ) {
                        Text("\(controller.workerCount) of \(controller.limits.maxWorkers) max")
                            .monospacedDigit()
                    }
                    .disabled(controller.isRunning)
                }

                GridRow {
                    Text("Worker duty")
                    HStack {
                        Slider(
                            value: $controller.dutyCycle,
                            in: 0.10...controller.limits.maxDutyCycle,
                            step: 0.05
                        )
                        Text("\(Int(controller.dutyCycle * 100))%")
                            .monospacedDigit()
                            .frame(width: 44, alignment: .trailing)
                    }
                    .disabled(controller.isRunning)
                }

                GridRow {
                    Text("Memory")
                    memoryControl
                }

                GridRow {
                    Text("Duration")
                    HStack {
                        Slider(
                            value: $controller.durationSeconds,
                            in: Double(controller.limits.minDurationSeconds)...Double(controller.limits.maxDurationSeconds),
                            step: 5
                        )
                        Text("\(Int(controller.durationSeconds)) s")
                            .monospacedDigit()
                            .frame(width: 48, alignment: .trailing)
                    }
                    .disabled(controller.isRunning)
                }
            }
            .padding(.top, 8)

            HStack {
                Text("Configured load: \(controller.configuredCPUPercentText)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Text("Thermal state: \(controller.thermalStateText)")
                    .font(.caption.weight(.medium))
            }
            .padding(.top, 10)
        }
    }

    @ViewBuilder
    private var memoryControl: some View {
        if controller.limits.maxMemoryMB > 0 {
            HStack {
                Slider(
                    value: $controller.memoryMB,
                    in: 0...Double(controller.limits.maxMemoryMB),
                    step: 16
                )
                Text("\(Int(controller.memoryMB)) MB")
                    .monospacedDigit()
                    .frame(width: 72, alignment: .trailing)
            }
            .disabled(controller.isRunning)
        } else {
            Text("Disabled because available memory is low")
                .foregroundStyle(.secondary)
        }
    }

    private var runStatus: some View {
        GroupBox("Run") {
            VStack(alignment: .leading, spacing: 12) {
                ProgressView(value: controller.progress)

                HStack {
                    Text(controller.status)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text("\(controller.elapsedSeconds, specifier: "%.1f") s")
                        .monospacedDigit()
                }

                HStack {
                    Button("Start bounded test") {
                        controller.start()
                    }
                    .keyboardShortcut(.defaultAction)
                    .disabled(controller.isRunning)

                    Button("Stop now", role: .destructive) {
                        controller.stopByUser()
                    }
                    .keyboardShortcut(.cancelAction)
                    .disabled(!controller.isRunning)

                    Spacer()

                    if controller.isRunning {
                        Text("Reserved: \(controller.allocatedMemoryMB) MB")
                            .font(.caption)
                            .monospacedDigit()
                    }
                }
            }
            .padding(.top, 8)
        }
    }

    private var safetyNotes: some View {
        VStack(alignment: .leading, spacing: 6) {
            Label("Hard stops", systemImage: "shield.checkered")
                .font(.headline)
            Text("The test automatically stops after 60 seconds, on serious thermal pressure, or when macOS reports memory pressure. It keeps one logical CPU available and releases all memory when stopped.")
                .font(.callout)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}
