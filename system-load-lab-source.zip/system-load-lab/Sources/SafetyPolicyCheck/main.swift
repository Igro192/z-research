import Darwin
import LoadSafetyCore

private var failures: [String] = []

private func check(_ condition: @autoclosure () -> Bool, _ message: String) {
    if !condition() {
        failures.append(message)
    }
}

let laptop = SafetyPolicy.limits(
    logicalProcessorCount: 10,
    physicalMemoryBytes: 16 * 1_073_741_824,
    availableMemoryBytes: 8 * 1_073_741_824
)
check(laptop.maxWorkers == 8, "The hard worker cap was not enforced")

let smallMachine = SafetyPolicy.limits(
    logicalProcessorCount: 4,
    physicalMemoryBytes: 8 * 1_073_741_824,
    availableMemoryBytes: 4 * 1_073_741_824
)
check(smallMachine.maxWorkers == 3, "A logical processor was not kept free")

let physicalMemoryLimited = SafetyPolicy.limits(
    logicalProcessorCount: 8,
    physicalMemoryBytes: 8 * 1_073_741_824,
    availableMemoryBytes: 16 * 1_073_741_824
)
check(physicalMemoryLimited.maxMemoryMB == 819, "The physical-memory cap was not enforced")

let availableMemoryLimited = SafetyPolicy.limits(
    logicalProcessorCount: 8,
    physicalMemoryBytes: 64 * 1_073_741_824,
    availableMemoryBytes: 1_073_741_824
)
check(availableMemoryLimited.maxMemoryMB == 128, "The available-memory cap was not enforced")

let lowMemory = SafetyPolicy.limits(
    logicalProcessorCount: 8,
    physicalMemoryBytes: 16 * 1_073_741_824,
    availableMemoryBytes: 400 * 1_048_576
)
check(lowMemory.maxMemoryMB == 0, "Memory reservation was not disabled under low headroom")

let limits = SafetyLimits(
    maxWorkers: 5,
    maxDutyCycle: 0.75,
    maxMemoryMB: 512,
    minDurationSeconds: 5,
    maxDurationSeconds: 60
)
let unsafe = LoadConfiguration(
    workers: 100,
    dutyCycle: 1.0,
    memoryMB: 50_000,
    durationSeconds: 3_600
)
check(
    SafetyPolicy.clamp(unsafe, to: limits)
        == LoadConfiguration(workers: 5, dutyCycle: 0.75, memoryMB: 512, durationSeconds: 60),
    "An unsafe configuration escaped clamping"
)

if failures.isEmpty {
    print("Safety policy checks passed")
} else {
    for failure in failures {
        fputs("FAIL: \(failure)\n", stderr)
    }
    exit(EXIT_FAILURE)
}
