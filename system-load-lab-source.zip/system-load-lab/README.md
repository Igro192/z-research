# System Load Lab

Original Swift macOS performance utility source. Compiled binaries and local diagnostics are excluded.

## Run

swift build

This is a source snapshot from Z. Research. No license is granted for third-party content or trademarks.
