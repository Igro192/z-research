# SceneAtlas — original application source snapshot

Local public-scene geolocation research application. The source separates coarse geographic estimates, public landmark pins and geographically aligned camera poses.

## Scope
Original Python application modules and tests, recovered 26 October 2026. This is a source snapshot, not an installable binary. Vendored libraries, model weights, photos, user history and private diagnostics are excluded. Full inference requires separately licensed Qwen, GeoCLIP, AnyLoc, DINOv2 and hloc components; this snapshot alone does not provide those engines. Qwen research-license conditions apply to its weights.

## Validation
The original local environment passed 74 unittest checks. Many provider/integration checks use declared fixtures: this is not an accuracy benchmark or evidence of worldwide camera localization.

Architecture and requirements are included. A reproducible source-only subset can be run with Pillow installed: `python -m unittest discover -s tests -p test_support.py`. See the portfolio for the full validation scope.
