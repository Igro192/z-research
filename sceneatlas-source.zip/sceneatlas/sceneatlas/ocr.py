"""Bounded Tesseract region reading. OCR is evidence, never place identity."""
from pathlib import Path
import logging,sys,time

def run_ocr(image_path,models_dir):
    started=time.perf_counter()
    result={'status':'unavailable','text':'','regions':[],'passes':[],
        'interpretation':'Unverified transcription; physical signs must be separated from overlays before place ranking.'}
    try:
        import cv2,numpy as np,pytesseract
        from PIL import Image,ImageOps
        executable=Path(getattr(sys,'_MEIPASS',''))/'ocr/tesseract' if getattr(sys,'frozen',False) else Path('/opt/homebrew/bin/tesseract')
        if not executable.exists():raise FileNotFoundError('Tesseract executable unavailable.')
        pytesseract.pytesseract.tesseract_cmd=str(executable)
        tessdata=Path(models_dir)/'tessdata'
        languages=['eng']+(['rus'] if (tessdata/'rus.traineddata').exists() else [])
        with Image.open(image_path) as source:rgb=ImageOps.exif_transpose(source).convert('RGB');rgb.thumbnail((1600,1600));array=np.array(rgb)
        gray=cv2.cvtColor(array,cv2.COLOR_RGB2GRAY);height,width=gray.shape
        # Overlapping regions recover smaller signs without an image-specific box.
        views=[('full',(0.,0.,1.,1.),'eng',11,False)]
        for row in range(2):
            for col in range(2):views.append((f'region-{row}-{col}',(col*.4,row*.4,min(1.,col*.4+.6),min(1.,row*.4+.6)),'eng',11,True))
        if 'rus' in languages:views.append(('cyrillic',(0.,0.,1.,1.),'rus+eng',11,True))
        seen=set()
        for name,box,language,psm,contrast in views:
            if time.perf_counter()-started>18:result['passes'].append({'name':name,'status':'skipped','reason':'18-second OCR budget'});continue
            x0,y0,x1,y1=box;crop=gray[int(y0*height):int(y1*height),int(x0*width):int(x1*width)]
            scale=min(2.5,2000/max(crop.shape));crop=cv2.resize(crop,None,fx=scale,fy=scale,interpolation=cv2.INTER_CUBIC)
            if contrast:crop=cv2.createCLAHE(clipLimit=2,tileGridSize=(8,8)).apply(crop)
            t=time.perf_counter()
            try:
                data=pytesseract.image_to_data(crop,lang=language,config=f'--tessdata-dir "{tessdata}" --psm {psm}',output_type=pytesseract.Output.DICT,timeout=5)
                groups={}
                for i,word in enumerate(data['text']):
                    if not word.strip() or float(data['conf'][i])<40:continue
                    key=tuple(data[k][i] for k in ('block_num','par_num','line_num'))
                    groups.setdefault(key,[]).append(i)
                for indices in groups.values():
                    text=' '.join(data['text'][i].strip() for i in indices)
                    if not any(c.isalpha() for c in text) or text.casefold() in seen:continue
                    left=min(data['left'][i] for i in indices)/scale/width+x0;top=min(data['top'][i] for i in indices)/scale/height+y0
                    right=max(data['left'][i]+data['width'][i] for i in indices)/scale/width+x0;bottom=max(data['top'][i]+data['height'][i] for i in indices)/scale/height+y0
                    seen.add(text.casefold());result['regions'].append({'text':text[:240],'bbox':[left,top,right,bottom],
                        'mean_ocr_confidence':round(sum(float(data['conf'][i]) for i in indices)/len(indices),2),'pass':name,'kind':'unclassified'})
                result['passes'].append({'name':name,'status':'executed','language':language,'seconds':round(time.perf_counter()-t,3)})
            except Exception as exc:result['passes'].append({'name':name,'status':'error','error':str(exc),'seconds':round(time.perf_counter()-t,3)})
        result.update(status='processed',text=' | '.join(r['text'] for r in result['regions'])[:3000],language='+'.join(languages),
            preprocessing=['EXIF orientation','bounded enlargement','overlapping image regions','CLAHE local contrast','separate Latin and Cyrillic passes'])
    except Exception as exc:
        logging.exception('OCR failed');result.update(status='failed',error=str(exc))
    result['duration_seconds']=round(time.perf_counter()-started,3)
    return result
