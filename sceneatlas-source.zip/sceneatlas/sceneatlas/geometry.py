"""Actual official hloc RootSIFT/NN correspondences and COLMAP robust geometry.

An image match does not determine the query camera's geographic position. WGS84
output requires a COLMAP absolute pose plus a separately validated GPS alignment.
No model weights or network requests are used by this CPU geometry stage.
"""
from __future__ import annotations
import hashlib
import json
import logging
from pathlib import Path
import threading
import time

HLOC_COMMIT='c13273bd0ecc2917a35910fd843712a1c6243193'
FEATURE_CONF={'output':'feats-sceneatlas-rootsift-v1','model':{'name':'dog','descriptor':'rootsift',
    'options':{'first_octave':0,'peak_threshold':0.006,'max_num_features':4096}},
    'preprocessing':{'grayscale':True,'resize_max':1600}}
MATCH_CONF={'output':'matches-sceneatlas-nn-ratio','model':{'name':'nearest_neighbor',
    'do_mutual_check':True,'ratio_threshold':0.8}}
THRESHOLDS={'min_matches':30,'min_inliers':25,'min_inlier_ratio':0.25,
    'ransac_max_error_pixels':4.0,'min_query_grid_cells_of_16':4,'min_query_bbox_fraction':0.06,
    'pose_min_inliers':30,'pose_min_inlier_ratio':0.15,'pose_max_reprojection_error_pixels':4.0}
_LOCK=threading.Lock()

def sha256(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def _extract(image_path,cache):
    import numpy as np
    import torch
    from PIL import Image,ImageOps
    from hloc.extractors.dog import DoG
    cache.mkdir(parents=True,exist_ok=True)
    signature=hashlib.sha256((sha256(image_path)+json.dumps(FEATURE_CONF,sort_keys=True)).encode()).hexdigest()
    path=cache/(signature+'.npz')
    if path.is_file():
        with np.load(path,allow_pickle=False) as data:return {k:data[k] for k in data.files}
    with Image.open(image_path) as source:
        im=ImageOps.exif_transpose(source).convert('L');original=np.array(im.size,dtype=np.int32)
        im.thumbnail((1600,1600),Image.Resampling.LANCZOS)
        array=np.asarray(im,dtype=np.float32)/255.0
    torch.set_num_threads(4)
    model=DoG(FEATURE_CONF['model']).eval().to('cpu')
    with torch.inference_mode():pred=model({'image':torch.from_numpy(array)[None,None]})
    data={k:v[0].cpu().numpy() for k,v in pred.items()}
    scales=original/np.array([array.shape[1],array.shape[0]])
    data['keypoints']=(data['keypoints']+.5)*scales[None]-.5
    data['image_size']=original
    np.savez_compressed(path,**data)
    return data

def _match(features0,features1):
    import numpy as np
    import torch
    from hloc.matchers.nearest_neighbor import NearestNeighbor
    model=NearestNeighbor(MATCH_CONF['model']).eval().to('cpu')
    data={f'descriptors{i}':torch.from_numpy(f['descriptors'].astype(np.float32))[None] for i,f in enumerate((features0,features1))}
    with torch.inference_mode():out=model(data)
    matches0=out['matches0'][0].numpy().astype(np.int32)
    scores0=out['matching_scores0'][0].numpy()
    indexes=np.flatnonzero(matches0>=0)
    return np.column_stack((indexes,matches0[indexes])).astype(np.uint32),matches0,scores0

def _camera(size):
    import pycolmap
    width,height=map(int,size)
    return pycolmap.Camera(model='SIMPLE_RADIAL',width=width,height=height,
        params=[1.2*max(width,height),width/2,height/2,0.0])

def _coverage(points,size):
    import numpy as np
    if len(points)==0:return 0,0.0
    width,height=map(float,size)
    cells=np.clip((points/np.array([width,height])*4).astype(int),0,3)
    occupied=len(set(map(tuple,cells.tolist())))
    span=np.ptp(points,axis=0)
    return occupied,float(span[0]*span[1]/(width*height))

def _two_view(q,r,matches,reference_id):
    import numpy as np
    import pycolmap
    count=len(matches)
    row={'reference_id':reference_id,'num_matches':count,'inliers':0,'inlier_ratio':0.0,
        'verified':False,'model':'fundamental','thresholds':dict(THRESHOLDS)}
    if count<THRESHOLDS['min_matches']:return row
    options=pycolmap.TwoViewGeometryOptions({'min_num_inliers':15,
        'ransac':{'max_error':THRESHOLDS['ransac_max_error_pixels'],'random_seed':42,'max_num_trials':10000}})
    geometry=pycolmap.estimate_two_view_geometry(_camera(q['image_size']),q['keypoints']+.5,
        _camera(r['image_size']),r['keypoints']+.5,matches,options)
    inlier_matches=np.asarray(geometry.inlier_matches,dtype=np.uint32).reshape(-1,2)
    config=pycolmap.TwoViewGeometryConfiguration(geometry.config).name
    if config in ('PLANAR','PANORAMIC','PLANAR_OR_PANORAMIC'):row['model']='homography'
    inliers=len(inlier_matches);ratio=inliers/max(1,count)
    cells,area=_coverage(q['keypoints'][inlier_matches[:,0]] if inliers else [],q['image_size'])
    row.update(inliers=inliers,inlier_ratio=ratio,colmap_configuration=config,
        query_grid_cells_of_16=cells,query_bbox_fraction=area)
    row['verified']=bool(config not in ('UNDEFINED','DEGENERATE','WATERMARK') and
        inliers>=THRESHOLDS['min_inliers'] and ratio>=THRESHOLDS['min_inlier_ratio'] and
        cells>=THRESHOLDS['min_query_grid_cells_of_16'] and area>=THRESHOLDS['min_query_bbox_fraction'])
    return row

def _load_models(paths):
    models=[]
    for manifest_path in sorted((Path(paths.models)/'geometry'/'registered').glob('*/manifest.json')):
        try:
            manifest=json.loads(manifest_path.read_text());manifest['_root']=str(manifest_path.parent)
            manifest['_manifest_path']=str(manifest_path);models.append(manifest)
        except Exception:logging.exception('Invalid geometry reference manifest: %s',manifest_path)
    return models

def _alignment(model,reconstruction):
    """Recompute fit/validation errors rather than trust a manifest success flag."""
    import numpy as np
    import pycolmap
    evidence={'validated':False,'crs':'EPSG:4978','reason':'No independently validated reference-camera GPS alignment.'}
    alignment=model.get('geographic_alignment',{})
    controls=alignment.get('controls',[])
    if alignment.get('crs')!='EPSG:4978' or alignment.get('control_kind')!='reference_camera_gps':return evidence
    matrix=np.asarray(alignment.get('ecef_from_model',[]),dtype=float)
    if matrix.shape!=(3,4) or not np.isfinite(matrix).all():return evidence
    scale=float(np.linalg.norm(matrix[:,:3],axis=0).mean());rotation=matrix[:,:3]/scale if scale else matrix[:,:3]
    if scale<=0 or not np.allclose(rotation.T@rotation,np.eye(3),atol=1e-4) or np.linalg.det(rotation)<.99:return evidence
    image_map={image.name:image for image in reconstruction.images.values()}
    source=[];destination=[];roles=[];names=[]
    for control in controls:
        name=control.get('image_name');gps=control.get('latitude_longitude_altitude')
        if name not in image_map or not isinstance(gps,list) or len(gps)!=3:continue
        if name in names or not (-90<=gps[0]<=90 and -180<=gps[1]<=180):continue
        names.append(name);source.append(image_map[name].projection_center());destination.append(gps);roles.append(control.get('role'))
    fit=np.array([r=='fit' for r in roles]);validation=np.array([r=='validation' for r in roles])
    if sum(fit)<6 or sum(validation)<3:return {**evidence,'reason':'At least six fit and three held-out reference-camera GPS controls are required.'}
    source=np.asarray(source);destination=np.asarray(destination)
    rank=np.linalg.svd(source[fit]-source[fit].mean(axis=0),compute_uv=False)
    if rank[1]<1e-3:return {**evidence,'reason':'Reference camera GPS controls are collinear.'}
    ecef=pycolmap.GPSTransform().ellipsoid_to_ecef(destination)
    prediction=source@matrix[:,:3].T+matrix[:,3]
    errors=np.linalg.norm(prediction-ecef,axis=1)
    fit_rmse=float(np.sqrt(np.mean(errors[fit]**2)));validation_rmse=float(np.sqrt(np.mean(errors[validation]**2)))
    valid=fit_rmse<=10 and validation_rmse<=15
    return {'validated':bool(valid),'crs':'EPSG:4978','control_kind':'reference_camera_gps',
        'fit_control_count':int(sum(fit)),'validation_control_count':int(sum(validation)),
        'fit_rmse_m':fit_rmse,'held_out_reference_rmse_m':validation_rmse,
        'threshold_fit_rmse_m':10,'threshold_validation_rmse_m':15,
        'ecef_from_model':matrix.tolist(),'scale_m_per_model_unit':scale,
        'source':alignment.get('source'),'accuracy_note':alignment.get('accuracy_note','Consumer GPS controls have uncalibrated uncertainty.'),
        'query_used_for_alignment':False,'reason':'Reference-only GPS fit and held-out reference controls checked.' if valid else 'Reference GPS alignment exceeds residual thresholds.'}

def _registered_reference(reference,models):
    ident=reference.get('reference_id')
    for model in models:
        for record in model.get('images',[]):
            if record.get('reference_id')==ident:
                path=Path(reference.get('reference_image_path') or reference.get('reference_path') or '')
                if path.is_file() and sha256(path)==record.get('sha256'):return model,record
    return None,None

def _reference_features(model,record):
    import h5py
    import numpy as np
    path=Path(model['_root'])/model['features_path']
    if sha256(path)!=model.get('features_sha256'):raise ValueError('Reference feature file changed since registration.')
    with h5py.File(path,'r') as f:return {k:np.array(v) for k,v in f[record['image_name']].items()}

def _pose(q,matched,model,cache):
    import h5py
    import numpy as np
    import pycolmap
    from hloc.localize_sfm import QueryLocalizer,pose_from_cluster
    from hloc.utils.parsers import names_to_pair
    root=Path(model['_root']);sfm=root/model['model_path']
    for name,digest in model.get('model_sha256',{}).items():
        if sha256(sfm/name)!=digest:raise ValueError('Registered 3D reconstruction changed.')
    reconstruction=pycolmap.Reconstruction(sfm)
    query_name='query.jpg';features=cache/'query_features.h5';matches=cache/'pose_matches.h5'
    image_ids={image.name:i for i,image in reconstruction.images.items()}
    db_ids=[]
    with h5py.File(features,'w') as f:
        group=f.create_group(query_name)
        for k,v in q.items():group.create_dataset(k,data=v)
    with h5py.File(matches,'w') as f:
        for item in matched:
            record=item['record'];name=record['image_name']
            if name not in image_ids:continue
            image=reconstruction.images[image_ids[name]]
            if len(image.points2D)!=len(item['ref_features']['keypoints']):raise ValueError('Reference features do not match COLMAP point indices.')
            group=f.create_group(names_to_pair(query_name,name))
            group.create_dataset('matches0',data=item['matches0']);group.create_dataset('matching_scores0',data=item['scores0'])
            db_ids.append(image_ids[name])
    if not db_ids:return None
    camera=_camera(q['image_size'])
    localizer=QueryLocalizer(reconstruction,{'estimation':{'estimate_focal_length':True,
        'ransac':{'max_error':THRESHOLDS['pose_max_reprojection_error_pixels'],'random_seed':42}},
        'refinement':{'refine_focal_length':True,'refine_extra_params':True}})
    ret,log=pose_from_cluster(localizer,query_name,camera,db_ids,features,matches)
    if ret is None:return None
    inliers=int(ret['num_inliers']);total=len(log['points3D_ids']);ratio=inliers/max(1,total)
    mask=np.asarray(ret['inlier_mask'],dtype=bool)
    cells,area=_coverage(log['keypoints_query'][mask],q['image_size'])
    if inliers<THRESHOLDS['pose_min_inliers'] or ratio<THRESHOLDS['pose_min_inlier_ratio'] or cells<4 or area<.06:return None
    pose=ret['cam_from_world'];center=pose.inverse().translation
    xyz=np.array([reconstruction.points3D[i].xyz for i in log['points3D_ids']])
    projected=camera.img_from_cam(pose*xyz)
    reprojection=np.linalg.norm(projected-log['keypoints_query'],axis=1)
    median_error=float(np.median(reprojection[mask]))
    if median_error>4:return None
    output={'camera_pose':{'frame':'COLMAP local model; arbitrary units before GPS alignment',
        'cam_from_world':pose.matrix().tolist(),'camera_center_local':center.tolist(),
        'camera_model':camera.model.name,'camera_parameters':camera.params.tolist(),
        'intrinsics_source':'Unknown focal initialized geometrically, estimated and refined by COLMAP PnP',
        'num_inliers':inliers,'num_2d_3d_correspondences':total,'inlier_ratio':ratio,
        'median_reprojection_error_pixels':median_error,'reference_image_count':len(db_ids)},
        'reconstruction_id':model['model_id'],'geographic_alignment':_alignment(model,reconstruction)}
    alignment=output['geographic_alignment']
    if alignment['validated']:
        transform=np.array(alignment['ecef_from_model']);ecef=transform[:,:3]@center+transform[:,3]
        latitude,longitude,altitude=pycolmap.GPSTransform().ecef_to_ellipsoid(ecef[None])[0]
        output.update(latitude=float(latitude),longitude=float(longitude),altitude_m=float(altitude),
            camera_center_ecef_m=ecef.tolist(),radius_m=max(15.0,3*alignment['held_out_reference_rmse_m']),
            radius_note='GPS alignment residual-based display radius; not a calibrated camera confidence interval.')
    return output

def verify_geometry(query_path,retrieval_matches,paths):
    """Run genuine hloc local matching; camera GPS requires valid aligned 3D."""
    started=time.perf_counter()
    result={'status':'no_usable_3d_reference','pairs':[],'geographic_alignment':{'validated':False},
        'engine':{'hloc_commit':HLOC_COMMIT,'features':'official hloc RootSIFT / COLMAP SIFT CPU',
            'matcher':'official hloc nearest-neighbor mutual ratio0.8','geometry':'COLMAP LO-RANSAC + hloc QueryLocalizer PnP'},
        'thresholds':dict(THRESHOLDS),'warnings':[]}
    query_path=Path(query_path)
    if not query_path.is_file():return {**result,'error':'Query image is unavailable.'}
    references=[r for r in retrieval_matches if isinstance(r,dict) and
        Path(r.get('reference_image_path') or r.get('reference_path') or '').is_file()][:12]
    if not references:return {**result,'reason':'No local reference photographs were supplied.','duration_seconds':time.perf_counter()-started}
    with _LOCK:
        try:
            import tempfile
            models=_load_models(paths);cache=Path(paths.cache)/'geometry';cache.mkdir(parents=True,exist_ok=True)
            q=_extract(query_path,cache/'features');query_digest=sha256(query_path);groups={}
            for reference in references:
                path=Path(reference.get('reference_image_path') or reference['reference_path']);ident=reference.get('reference_id',path.name)
                if sha256(path)==query_digest:
                    result['pairs'].append({'reference_id':ident,'verified':False,'num_matches':0,'inliers':0,'model':'fundamental','reason':'Identical input/reference bytes are not independent geometric evidence.'});continue
                try:
                    model,record=_registered_reference(reference,models)
                    r=_reference_features(model,record) if model else _extract(path,cache/'features')
                    matches,matches0,scores0=_match(q,r)
                    pair=_two_view(q,r,matches,ident);result['pairs'].append(pair)
                    if model and pair['verified']:
                        groups.setdefault(model['model_id'],{'model':model,'matched':[]})['matched'].append(
                            {'record':record,'ref_features':r,'matches0':matches0,'scores0':scores0})
                except Exception as exc:
                    logging.exception('Geometry pair failed');result['pairs'].append({'reference_id':ident,'verified':False,'num_matches':0,'inliers':0,'model':'fundamental','error':str(exc)})
            verified=any(p['verified'] for p in result['pairs'])
            result['status']='geometric_match_without_georeferenced_pose' if verified else 'insufficient_matching_evidence'
            for group in groups.values():
                with tempfile.TemporaryDirectory(prefix='pose-',dir=cache) as temporary:
                    pose=_pose(q,group['matched'],group['model'],Path(temporary))
                if pose:
                    result.update(pose)
                    if pose['geographic_alignment']['validated']:
                        result['status']='pose_verified';break
            if result['status']=='geometric_match_without_georeferenced_pose':
                result['warnings'].append('The image correspondence is geometrically supported. No geographically aligned query-camera pose was established; reference/landmark coordinates must not be substituted.')
        except Exception as exc:
            logging.exception('Geometric verification unavailable');result['error']=str(exc)
    result['duration_seconds']=time.perf_counter()-started
    return result
