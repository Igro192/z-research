"""Image-driven public POI lookup, ambiguity checks and traceable name matching.

No query-specific names or coordinates. Photon tolerates imperfect sign OCR;
Nominatim is the bounded fallback. Both use OSM, not independent imagery.
"""
from pathlib import Path
from difflib import SequenceMatcher
import hashlib,json,re,time,unicodedata
from urllib.parse import urlencode
from .support import (LandmarkVerifier,SettingsStore,_read_json,_atomic_write,
    _locked_file,_validate_endpoint,result_json,REFERENCE_ATTRIBUTION)
from .geographic import distance_km

def normalized(text):
    text=unicodedata.normalize('NFKD',str(text)).casefold()
    return ' '.join(''.join(c if c.isalnum() else ' ' for c in text if not unicodedata.combining(c)).split()).removeprefix('the ')

def name_match(query,names):
    q=normalized(query);a=q.replace(' ','')
    best=('none',0.)
    for name in names:
        n=normalized(name);b=n.replace(' ','')
        if not a or not b:continue
        if a==b:return 'exact',1.
        # A mapped name may have a script suffix or an operator suffix.
        if len(a)>=7 and n.startswith(q+' '):return 'name_prefix',1.
        ratio=SequenceMatcher(None,a,b).ratio()
        # Compare the same number of words so an unrelated long result cannot
        # gain credit merely for a generic category such as "mall".
        if len(n.split())>len(q.split())>=2:
            ratio=max(ratio,SequenceMatcher(None,a,''.join(n.split()[:len(q.split())])).ratio())
        if ratio>best[1]:best=('approximate' if ratio>=.84 and min(len(a),len(b))>=7 else 'none',ratio)
    return best

def proposed_queries(visual,ocr):
    queries=[];rejected=[];seen=set()
    excluded_text=[normalized(s.get('text','')) for s in visual.get('visible_text',[]) if s.get('kind') in ('overlay','uncertain')]
    def excluded_name(key):
        return any(len(text)>=4 and (key==text or (' '+key+' ') in (' '+text+' ') or (' '+text+' ') in (' '+key+' ')) for text in excluded_text)
    def add(name,basis,context='',place_type='other',support=''):
        name=' '.join(str(name).split()).strip(' .,:;"')[:140]
        key=normalized(name)
        if key in seen or len(key)<4:return
        if basis=='visual_landmark' and excluded_name(key):
            rejected.append({'query':name,'reason':'Name also appears in overlay/uncertain text; caption-derived recognition is quarantined unless reference geometry supports the scene.'});return
        if re.search(r'https?://|@|\b(?:private|residence|address of|home of)\b|^\d+\s',name,re.I):return
        if not any(c.isalpha() for c in name):return
        # A bare brand or an ordinary street name cannot establish a branch.
        words=key.split()
        if basis=='physical_sign' and (place_type=='road' or (len(words)==1 and not re.search(r'mall|museum|station|hotel|centre|center',key))):
            rejected.append({'query':name,'reason':'Unqualified shop brand or road sign; no unique public place identity.'});return
        if basis=='visual_landmark' and len(words)==1 and re.search(r'\b(store|shop|brand)\b',support,re.I):
            rejected.append({'query':name,'reason':'Visual model named a shop brand without a branch.'});return
        seen.add(key);queries.append({'name':name,'basis':basis,'context':context,'place_type':place_type,'visual_support':support})
    for sign in visual.get('visible_text',[]):
        if sign.get('kind')=='physical_sign' and sign.get('context'):
            add(sign['text'],'physical_sign',sign.get('context',''),sign.get('place_type','other'))
        elif sign.get('text'):rejected.append({'query':sign['text'],'reason':'Overlay or uncertain text; excluded from place lookup.'})
    evidence={normalized(x['name']):x for x in visual.get('landmark_evidence',[]) if isinstance(x,dict) and x.get('name')}
    for name in visual.get('landmark_hypotheses',[]):
        if isinstance(name,dict):name=name.get('name','')
        item=evidence.get(normalized(name),{})
        add(name,'visual_landmark',support=item.get('visual_support',''))
    # OCR may suggest a lookup, but cannot promote a result on its own.
    overlays=[normalized(s.get('text','')) for s in visual.get('visible_text',[]) if s.get('kind') in ('overlay','uncertain')]
    for region in ocr.get('regions',[]):
        text=region['text'];key=normalized(text)
        if any(x and (x in key or key in x) for x in overlays):continue
        if re.search(r'\b(mall|museum|station|hotel|centre|center|theatre|palace|молл|музей|вокзал|центр)\b',key) and 2<=len(key.split())<=7:
            add(text,'ocr_only')
    return queries[:3],rejected

class PublicPlaceSearch:
    def __init__(self,paths):self.paths=paths;self.trace=[];self.settings=SettingsStore(paths).load()
    def photon(self,query,allow_network=True):
        endpoint=_validate_endpoint(self.settings.get('photon_endpoint','https://photon.komoot.io'))
        key=hashlib.sha256(f'photon-v1|{endpoint}|{query.casefold()}'.encode()).hexdigest()
        cache=self.paths.cache/'References'/f'{key}.json';cached=_read_json(cache,{})
        if isinstance(cached,dict) and time.time()-cached.get('retrieved_at',0)<30*86400 and 'results' in cached:
            return cached['results'],'cache'
        if not allow_network:return [],'offline_no_cache'
        with _locked_file(self.paths.cache/'.reference-rate.lock'):
            rate_path=self.paths.cache/'.reference-rate.json';previous=_read_json(rate_path,{}).get('started_at',0)
            time.sleep(max(0.,1.1-(time.time()-min(time.time(),float(previous)))))
            _atomic_write(rate_path,result_json({'started_at':time.time()}).encode())
            raw=LandmarkVerifier(self.paths)._fetch_json(endpoint+'/api/?'+urlencode({'q':query,'limit':10,'lang':'en'}))
        rows=[]
        for feature in raw.get('features',[]):
            p=feature.get('properties',{});coords=feature.get('geometry',{}).get('coordinates',[])
            if len(coords)!=2:continue
            osm_type={'N':'node','W':'way','R':'relation'}.get(p.get('osm_type'))
            # Retain original OSM classification, not Photon's generic "house"
            # address-layer classification, which also describes public malls.
            row=LandmarkVerifier._public_reference({'name':p.get('name'),
                'display_name':', '.join(str(p[k]) for k in ('name','city','state','country') if p.get(k)),
                'lat':coords[1],'lon':coords[0],'category':p.get('osm_key'),'type':p.get('osm_value'),
                'osm_type':osm_type,'osm_id':p.get('osm_id'),'namedetails':{'name':p.get('name','')}},query)
            if row:row.update(source='OpenStreetMap / Photon',area=', '.join(str(p[k]) for k in ('city','state','country') if p.get(k)),provider_properties=p);rows.append(row)
        _atomic_write(cache,result_json({'retrieved_at':time.time(),'results':rows}).encode())
        return rows,'online'

    def search(self,visual,ocr,online=True,coarse=None):
        queries,rejected=proposed_queries(visual,ocr);references=[]
        for query in queries:
            t=time.perf_counter();trace={'query':query,'executed':False,'errors':[],'providers':[]}
            found=[]
            # Name-only resolution uses generic live/cached geographic services.
            # Reference-image metadata never acts as a place-name answer table.
            if not found:
                try:
                    found,status=self.photon(query['name'],allow_network=online);trace['providers'].append({'provider':'Photon','status':status});trace['executed']=True
                except Exception as exc:trace['errors'].append(f'Photon: {exc}')
                if not found and online:
                    try:
                        verifier=LandmarkVerifier(self.paths);found=verifier.search(query['name'],5);trace['providers'].append({'provider':'Nominatim','status':verifier.last_status});trace['executed']=True
                    except Exception as exc:trace['errors'].append(f'Nominatim: {exc}')
            trace['skip_reason']=None if (found or online) else 'Online lookup disabled and no cached public-place result.'
            accepted=[]
            for row in found:
                aliases=[row.get('name','')]+list((row.get('names') or {}).values())
                match,similarity=name_match(query['name'],aliases)
                if match=='none':continue
                # Physical type consistency prevents a named bus stop from
                # being reported as the photographed shopping centre.
                kind=query.get('place_type');typ=row.get('type')
                type_consistent=kind not in ('mall','museum','station','hotel') or typ in {'mall':('mall','department_store','retail'),'museum':('museum',),'station':('station','train_station','halt'),'hotel':('hotel',)}[kind]
                item=dict(row,query=query['name'],query_evidence=query,name_match=match,name_similarity=round(similarity,4),type_consistent=type_consistent)
                if type_consistent:accepted.append(item)
            # Cluster duplicate objects for the same mapped place. Several
            # distant branches remain ambiguous, irrespective of provider order.
            clusters=[]
            for row in accepted:
                point=[row['latitude'],row['longitude']]
                if not any(distance_km(point,[r['latitude'],r['longitude']])<.5 for r in clusters):clusters.append(row)
            for row in accepted:
                row['ambiguous_name']=len(clusters)>1
                row['regional_agreement']=any(distance_km([row['latitude'],row['longitude']],[c['latitude'],c['longitude']])<150 for c in (coarse or []))
                supported_sign=query['basis']=='physical_sign' and len(normalized(query['name']).replace(' ',''))>=7
                # Regional agreement cannot verify a building's identity: many
                # unrelated public places share the same city/region. A visual
                # name remains a hypothesis until the separate image-geometry
                # stage verifies it. Grounded physical signage can establish a
                # mapped public-place identity, never the query camera position.
                row['identity_supported']=not row['ambiguous_name'] and supported_sign
                row['identity_basis']='physical sign + compatible mapped public place' if supported_sign else 'unconfirmed visual/text hypothesis; regional agreement and place existence do not verify photo identity'
                if not any(r.get('source_url')==row.get('source_url') for r in references):references.append(row)
            trace.update(seconds=round(time.perf_counter()-t,3),output=accepted,returned_public_places=len(found));self.trace.append(trace)
        return references,{'queries':self.trace,'rejected_text':rejected,'candidate_queries':queries,'online_enabled':online,
            'policy':'At most 3 image-derived names; one worker, at least 1.1s between requests, 30-day cache; no photos sent.',
            'status':'executed' if self.trace else 'skipped','skip_reason':None if self.trace else 'No credible public-place name or physical sign detected.'}
