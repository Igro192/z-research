"""Evidence tiers, never an average of incompatible model scores."""
from copy import deepcopy
import math
from .presentation import valid_coordinates
from .geographic import distance_km

def _coordinates(row):
 if not isinstance(row,dict):return None
 for key in ['landmark_coordinates','camera_coordinates','coordinates']:
  value=row.get(key)
  if isinstance(value,dict):
   lat=value.get('latitude',value.get('lat'));lon=value.get('longitude',value.get('lon'))
   if lat is not None and lon is not None:return float(lat),float(lon)
  elif isinstance(value,(list,tuple)) and len(value)>=2:return float(value[0]),float(value[1])
 try:return float(row['latitude']),float(row['longitude'])
 except (KeyError,TypeError,ValueError):return None

def combine_candidates(coarse,visual,public_references,retrieval,geometry):
 candidates=[];coarse=deepcopy(coarse)
 for candidate in coarse:
  candidate.update(result_type='broad_geographic_prediction',coordinate_kind='model_gallery_estimate',evidence_tier=1)
  candidate['precision']='Broad estimate; the camera position is not verified.'
  candidate['map_zoom']=5
 # PnP only becomes geographic camera evidence after measured geographic alignment.
 alignment=geometry.get('geographic_alignment') or geometry.get('alignment') or {}
 if geometry.get('status')=='pose_verified' and alignment.get('validated') is True:
  point=_coordinates(geometry)
  if point:
   candidate={'id':'camera-pose','label':geometry.get('place_name','Geometrically localized camera'),
    'latitude':point[0],'longitude':point[1],'result_type':'verified_camera_location',
    'coordinate_kind':'georeferenced_query_camera','source':'hloc + geographically aligned 3D reconstruction',
    'precision':geometry.get('accuracy_description','Verified pose in a geographically aligned model; accuracy depends on reconstruction and reference GPS.'),
    'evidence_tier':5,'evidence':['Camera pose estimated from 2D–3D correspondences.',
      'The reconstruction has a validated geographic alignment.'], 'uncertainty':geometry.get('uncertainty','Reference GPS and reconstruction errors limit absolute accuracy.'),
    'map_zoom':17,'radius_km':float(geometry['radius_m'])/1000 if geometry.get('radius_m') else None,'radius_note':geometry.get('radius_note'),'pose_evidence':geometry}
   if valid_coordinates(candidate):candidates.append(candidate)
 # Geometric image matches can recognize a public landmark. They cannot create a camera GPS pose.
 matched={}
 for pair in geometry.get('pairs',[]):
  if pair.get('verified') or pair.get('status') in ['geometric_match','verified']:
   matched[str(pair.get('reference_id',''))]=pair
 for index,match in enumerate(retrieval.get('matches',[])):
  identifier=str(match.get('reference_id',match.get('id','')))
  pair=matched.get(identifier)
  if not pair:continue
  point=_coordinates(match)
  if not point:continue
  is_landmark=match.get('coordinate_kind')=='landmark' or bool(match.get('landmark_coordinates'))
  candidate={'id':'retrieval-'+identifier,'label':match.get('place_name',match.get('label','Matched public reference')),
    'latitude':point[0],'longitude':point[1],'source':'AnyLoc retrieval + hloc geometric image matching',
    'result_type':'recognized_landmark_location' if is_landmark else 'reference_image_location',
    'coordinate_kind':'landmark' if is_landmark else 'reference_image_camera',
    'precision':'Public landmark coordinates; query viewpoint unknown.' if is_landmark else 'Coordinates of the reference photo; query camera position is not verified.',
    'evidence_tier':4,'map_zoom':15 if is_landmark else 13,'radius_km':None,
    'reference_id':identifier,'reference_path':match.get('reference_path') or match.get('reference_image_path'),
    'reference_url':match.get('source_url'),'reference_attribution':match.get('attribution',match.get('license','')),
    'evidence':['A real public reference photo was retrieved by AnyLoc.',
      f"hloc found a geometrically consistent match ({pair.get('inliers',pair.get('num_inliers','unknown'))} inliers)."],
    'uncertainty':'A geometric image match does not establish the photographer’s position without a geographically aligned 3D pose.',
    'retrieval_evidence':match,'geometry_evidence':pair}
  if valid_coordinates(candidate):candidates.append(candidate)
 supported=[r for r in public_references if r.get('identity_supported')]
 for index,reference in enumerate(public_references):
  point=_coordinates(reference)
  if not point:continue
  label=reference.get('name',reference.get('query','Public landmark'))
  nearby=any(distance_km(point,[c['latitude'],c['longitude']])<150 for c in coarse)
  supported_identity=reference.get('identity_supported',False)
  basis=reference.get('query_evidence',{}).get('basis')
  conflicting_places=[r for r in supported if r is not reference and r.get('query_evidence',{}).get('basis')==basis and distance_km(point,_coordinates(r))>150]
  if conflicting_places:supported_identity=False
  conflicts=[]
  if not nearby:conflicts.append('The broad GeoCLIP prediction disagrees with this mapped place. The place evidence and model prior are shown separately.')
  if reference.get('ambiguous_name'):conflicts.append('The name matches multiple distant public places; no branch is verified.')
  if conflicting_places:conflicts.append('Other similarly supported named places conflict geographically; identity needs more evidence.')
  candidate={'id':'reference-'+str(index+1),'label':label,'latitude':point[0],'longitude':point[1],
   'result_type':'recognized_landmark_location' if supported_identity else 'public_place_hypothesis','coordinate_kind':'landmark','evidence_tier':(3.5 if basis=='physical_sign' else 3) if supported_identity else .5,
   'source':'Image evidence + public geographic place lookup','precision':'Mapped landmark location; camera position unknown.' if supported_identity else 'Unconfirmed mapped public place; camera position unknown.',
   'map_zoom':15,'radius_km':None,'regional_agreement':nearby,'reference':reference,
   'reference_url':reference.get('source_url') or reference.get('osm_url'),'area':reference.get('area') or reference.get('display_name',''),'identity_supported':supported_identity,'conflicts':conflicts,
   'evidence':[f"Image evidence: {reference.get('query',label)} ({reference.get('identity_basis','unconfirmed visual name')}).",
    f"{reference.get('source','Public geographic data')} maps this named public place; name match: {reference.get('name_match','catalog')}.",
    'GeoCLIP has a candidate in the same region.' if nearby else 'GeoCLIP does not independently agree within 150 km; it cannot veto stronger place evidence.'],
   'uncertainty':'Mapped public-place coordinates; photographer position unknown. '+('The photo does not establish this place identity; it remains an alternative hypothesis.' if not supported_identity else ('The name was read approximately; inspect the sign and geographic source.' if reference.get('name_match')=='approximate' else 'Image identity is supported by the recorded evidence, not a surveyed camera pose.'))}
  if valid_coordinates(candidate) and not any(c['label'].casefold()==str(label).casefold() and c.get('evidence_tier',0)>=4 for c in candidates):candidates.append(candidate)
 # Retrieval-only suggestions stay in Advanced Details until independently supported.
 candidates.extend(coarse)
 scene=str(visual.get('scene_type','unclear')).lower()
 if scene in ('indoor','interior') and not any(c['evidence_tier']>=4 for c in candidates):return []
 return sorted(candidates,key=lambda c:-c.get('evidence_tier',0))
