"""One disposable model worker; asynchronous progress and deterministic shutdown."""
from pathlib import Path
import asyncio,json,logging,sys,time,uuid

class AnalysisRunner:
 def __init__(self,paths):self.paths=paths;self.process=None;self._jobs=set()
 async def run(self,image_path,settings,source_name='',metadata=None,on_progress=lambda text:None):
  if self.process and self.process.returncode is None:raise RuntimeError('An analysis is already running.')
  job=uuid.uuid4().hex;request=self.paths.imports/(job+'.request.json');output=self.paths.imports/(job+'.result.json');progress=self.paths.imports/(job+'.progress.json')
  files=[request,output,progress];self._jobs.update(files)
  request.write_text(json.dumps({'image_path':str(image_path),'settings':settings,'source_name':source_name,
    'metadata':metadata or {},'output':str(output),'progress':str(progress)}))
  if getattr(sys,'frozen',False):command=[sys.executable,'--worker',str(request)]
  else:command=[sys.executable,str(Path(__file__).resolve().parents[1]/'main.py'),'--worker',str(request)]
  try:
   with (self.paths.logs/'worker-console.log').open('ab') as log:
    self.process=await asyncio.create_subprocess_exec(*command,stdout=log,stderr=log)
   last=None;started=time.monotonic()
   while self.process.returncode is None:
    if progress.exists():
     try:
      message=json.loads(progress.read_text()).get('message','Analyzing…')
      if message!=last:on_progress(message);last=message
     except (OSError,ValueError):pass
    if time.monotonic()-started>600:
     await self.cancel();raise TimeoutError('Analysis exceeded ten minutes. Models were stopped; see the local log for the failed stage.')
    try:await asyncio.wait_for(self.process.wait(),timeout=.4)
    except asyncio.TimeoutError:pass
   if not output.exists():raise RuntimeError(f'Model worker exited ({self.process.returncode}) before writing a result. See Settings → Open Logs.')
   result=json.loads(output.read_text())
   if result.get('status')=='error':raise RuntimeError(result.get('error','The model worker failed.'))
   return result
  finally:
   if self.process and self.process.returncode is None:await self.cancel()
   self.process=None
   for file in files:file.unlink(missing_ok=True);self._jobs.discard(file)
 async def cancel(self):
  if self.process and self.process.returncode is None:
   self.process.terminate()
   try:await asyncio.wait_for(self.process.wait(),timeout=5)
   except asyncio.TimeoutError:self.process.kill();await self.process.wait()
 async def shutdown(self):
  await self.cancel()
  for p in list(self._jobs):p.unlink(missing_ok=True)
  self._jobs.clear()
