"""Import an explicitly supplied, licensed public-image reference archive."""
from pathlib import Path
import hashlib,io,json,shutil,tempfile,zipfile
from .references import reference_directory,load_references
from .support import _atomic_write,result_json

MAX_ARCHIVE_BYTES=256*1024*1024
MAX_EXPANDED_BYTES=512*1024*1024

def import_collection_archive(content,paths):
    if len(content)>MAX_ARCHIVE_BYTES:raise ValueError('Reference archive exceeds256MB.')
    archive=zipfile.ZipFile(io.BytesIO(content))
    members=archive.infolist()
    if len(members)>4000 or sum(m.file_size for m in members)>MAX_EXPANDED_BYTES:raise ValueError('Reference archive is too large.')
    for member in members:
        name=Path(member.filename)
        if name.is_absolute() or '..' in name.parts or (member.external_attr>>16)&0o170000==0o120000:raise ValueError('Unsafe archive path or symbolic link.')
    manifests=[m for m in members if Path(m.filename).name=='manifest.json']
    if len(manifests)!=1:raise ValueError('The archive must contain exactly one manifest.json.')
    with tempfile.TemporaryDirectory(prefix='reference-import-',dir=paths.cache) as temporary:
        root=Path(temporary);archive.extractall(root)
        manifest_path=root/manifests[0].filename;payload=json.loads(manifest_path.read_text())
        rows=payload.get('references',[]) if isinstance(payload,dict) else []
        if not rows or len(rows)>1000:raise ValueError('Provide1–1000 licensed public reference images.')
        from PIL import Image
        prepared=[]
        for row in rows:
            if not isinstance(row,dict) or not row.get('reference_id') or not row.get('place_name') or not row.get('license') or not row.get('source_url'):raise ValueError('Each image needs an ID, public place, license and source URL.')
            if row.get('public_place') is False:raise ValueError('Only public-place reference photographs are supported.')
            kind=row.get('coordinate_kind')
            coordinate=row.get('camera_coordinates' if kind=='reference_camera' else 'landmark_coordinates')
            try:
                latitude,longitude=float(coordinate['latitude']),float(coordinate['longitude'])
                if kind not in ('reference_camera','landmark') or not(-90<=latitude<=90 and -180<=longitude<=180):raise ValueError()
            except (KeyError,TypeError,ValueError):raise ValueError('Each reference needs valid coordinates and their explicit kind.')
            image=(manifest_path.parent/row.get('image','')).resolve()
            if not image.is_relative_to(manifest_path.parent.resolve()) or not image.is_file() or image.stat().st_size>30*1024*1024:raise ValueError('Reference image is missing or outside the archive.')
            with Image.open(image) as source:
                if source.format not in ['JPEG','PNG','WEBP'] or source.width*source.height>50_000_000:raise ValueError('Unsupported or oversized reference image.')
                source.verify()
            digest=hashlib.sha256(image.read_bytes()).hexdigest()
            if row.get('image_sha256') and row['image_sha256']!=digest:raise ValueError('Reference checksum does not match its manifest.')
            identifier=str(row['reference_id'])
            if len(identifier)>100 or any(c in identifier for c in '/\\\0'):raise ValueError('Unsafe reference ID.')
            prepared.append((row,image,digest))
        current=load_references(paths);by_id={r['reference_id']:r for r in current}
        for row,image,digest in prepared:
            if row['reference_id'] in by_id and by_id[row['reference_id']].get('image_sha256')!=digest:raise ValueError('A different image already uses reference ID '+row['reference_id'])
        target=paths.root/'References';old_root=reference_directory(paths)
        if not (target/'manifest.json').is_file() and current:
            # Preserve the bundled starter references when expanding the collection.
            shutil.copytree(old_root,target,dirs_exist_ok=True)
        images=target/'images';images.mkdir(parents=True,exist_ok=True)
        for row,image,digest in prepared:
            destination=images/(digest+image.suffix.lower())
            if not destination.exists():shutil.copy2(image,destination)
            by_id[row['reference_id']]={**row,'image':str(destination.relative_to(target)),'image_sha256':digest}
        records=[]
        for row in by_id.values():records.append({k:v for k,v in row.items() if k not in ['reference_path','reference_image_path','latitude','longitude']})
        _atomic_write(target/'manifest.json',result_json({'version':1,'references':records}).encode())
        return {'ok':True,'imported':len(prepared),'reference_count':len(records),'index_rebuild_required':True}
