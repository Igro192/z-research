"""Offline public-domain country boundaries; country names describe candidates."""
from functools import lru_cache
from pathlib import Path
import json

@lru_cache(maxsize=1)
def _countries():
    from shapely.geometry import shape
    source=Path(__file__).parent/'data/countries.geojson'
    with source.open() as f:data=json.load(f)
    return [(shape(row['geometry']),row['properties']) for row in data['features']]

@lru_cache(maxsize=2000)
def country_at(latitude,longitude):
    from shapely.geometry import Point
    point=Point(float(longitude),float(latitude))
    for geometry,properties in _countries():
        if geometry.covers(point):
            return {'name':properties.get('NAME_EN',properties.get('ADMIN','Unknown')),
                    'code':properties.get('ISO_A2_EH',properties.get('ISO_A2','')),
                    'source':'Natural Earth 1:50m country boundaries (public domain)'}
    return {'name':'Offshore / border area','code':'','source':'Natural Earth 1:50m; coastlines and borders are approximate'}

def label_candidates(candidates):
    for i,candidate in enumerate(candidates,1):
        if candidate.get('source')=='GeoCLIP':
            try:
                country=country_at(candidate['latitude'],candidate['longitude']);candidate['candidate_country']=country
                candidate['label']=country['name']+' · regional hypothesis'
            except Exception:pass
    return candidates
