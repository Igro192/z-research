"""Build/import genuine COLMAP maps with reference-camera GPS alignment.

Inputs are an explicitly authorized public reference collection. Query images
and their location labels must be absent from the reference control records.
"""
from __future__ import annotations
import json
from pathlib import Path
import re
import shutil
import time
from .geometry import FEATURE_CONF,MATCH_CONF,HLOC_COMMIT,sha256

def _inside(root,relative):
    path=(root/relative).resolve()
    if not path.is_relative_to(root.resolve()):raise ValueError('Reference manifest path escapes its bundle.')
    return path

def register_reference_model(manifest_path,paths,overwrite=False):
    import h5py
    import pycolmap
    from .geometry import _alignment
    manifest_path=Path(manifest_path).expanduser().resolve();root=manifest_path.parent
    data=json.loads(manifest_path.read_text());ident=data.get('model_id','')
    if not re.fullmatch(r'[a-z0-9][a-z0-9_-]{1,63}',ident):raise ValueError('Use a simple reference model ID.')
    if data.get('feature_configuration')!=FEATURE_CONF:raise ValueError('This adapter requires its documented official hloc RootSIFT configuration.')
    sfm=_inside(root,data['model_path']);features=_inside(root,data['features_path'])
    if sha256(features)!=data['features_sha256']:raise ValueError('Feature file digest mismatch.')
    for name,digest in data['model_sha256'].items():
        if sha256(_inside(sfm,name))!=digest:raise ValueError('COLMAP model digest mismatch.')
    model=pycolmap.Reconstruction(sfm)
    if model.num_reg_images()<3 or model.num_points3D()<100:raise ValueError('A genuine multi-view 3D reference with >=3 cameras and >=100 points is required.')
    names={image.name:image for image in model.images.values()}
    with h5py.File(features,'r') as f:
        for record in data['images']:
            image=_inside(root,record['image_path']);name=record['image_name']
            if sha256(image)!=record['sha256']:raise ValueError('Reference image digest mismatch.')
            if name not in names or name not in f or len(f[name]['keypoints'])!=len(names[name].points2D):
                raise ValueError('Reference features and COLMAP 2D-point indices differ.')
    alignment=_alignment(data,model)
    data['alignment_validation_at_import']=alignment
    target=Path(paths.models)/'geometry'/'registered'/ident
    if target.exists():
        current=target/'manifest.json'
        if not overwrite:
            if current.exists() and json.loads(current.read_text()).get('features_sha256')==data['features_sha256']:
                return {'status':'already_registered','model_id':ident,'path':str(target),'geographic_alignment':alignment}
            raise FileExistsError('Reference model already exists; explicit overwrite is required.')
        shutil.rmtree(target)
    target.mkdir(parents=True)
    for relative in (data['features_path'],*[str(Path(data['model_path'])/name) for name in data['model_sha256']],
                     *[r['image_path'] for r in data['images']],*data.get('license_files',[])):
        source=_inside(root,relative);destination=target/relative;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,destination)
    (target/'manifest.json').write_text(json.dumps(data,indent=2,allow_nan=False))
    return {'status':'registered','model_id':ident,'path':str(target),'geographic_alignment':alignment}

def build_reference_model(image_dir,controls,output_dir,model_id,source_url,license_file=None):
    """Official hloc SfM; fit GPS to reference cameras with held-out controls.

    `controls` contains only training reference images and EXIF GPS. At least
    three entries must have role='validation'; those GPS values are not fit.
    Build images should already be EXIF stripped, with location labels separate.
    """
    import copy
    import itertools
    import numpy as np
    import pycolmap
    import torch
    from hloc import extract_features,match_features,reconstruction
    started=time.perf_counter();image_dir=Path(image_dir).resolve();output=Path(output_dir).resolve();output.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(4)
    names=[r['image_name'] for r in controls]
    if len(set(names))!=len(names) or len(names)<9:raise ValueError('At least nine unique reference images/controls required.')
    if sum(r.get('role')=='fit' for r in controls)<6 or sum(r.get('role')=='validation' for r in controls)<3:
        raise ValueError('Reserve >=6 fit and >=3 held-out GPS controls.')
    images=output/'images';images.mkdir(exist_ok=True)
    for name in names:shutil.copy2(_inside(image_dir,name),images/name)
    features=extract_features.main(copy.deepcopy(FEATURE_CONF),images,output,as_half=False,image_list=names)
    pairs=output/'pairs-reference.txt';pairs.write_text(''.join(f'{a} {b}\n' for a,b in itertools.combinations(names,2)))
    matches=match_features.main(copy.deepcopy(MATCH_CONF),pairs,features,matches=output/'matches-reference.h5')
    sfm=output/'sfm'
    reused=(sfm/'cameras.bin').is_file() and (sfm/'images.bin').is_file() and (sfm/'points3D.bin').is_file()
    if reused:model=pycolmap.Reconstruction(sfm)
    else:
        model=reconstruction.main(sfm,images,pairs,features,matches,camera_mode=pycolmap.CameraMode.SINGLE,
            image_list=names,image_options={'camera_model':'SIMPLE_RADIAL'},
            mapper_options={'num_threads':4,'ba_refine_focal_length':True,'ba_refine_extra_params':True,'random_seed':42})
    if model is None:raise RuntimeError('COLMAP did not reconstruct a reference model.')
    name_to_image={im.name:im for im in model.images.values()}
    controls=[r for r in controls if r['image_name'] in name_to_image]
    fit=[r for r in controls if r['role']=='fit']
    source=np.array([name_to_image[r['image_name']].projection_center() for r in fit])
    target=pycolmap.GPSTransform().ellipsoid_to_ecef(np.array([r['latitude_longitude_altitude'] for r in fit]))
    alignment_ret=pycolmap.estimate_sim3d_robust(source,target,pycolmap.RANSACOptions({'max_error':10.0,'random_seed':42}))
    if alignment_ret is None:raise RuntimeError('Reference-camera GPS alignment estimation failed.')
    transform=alignment_ret['tgt_from_src'] if isinstance(alignment_ret,dict) else alignment_ret
    model_files={p.name:sha256(p) for p in sfm.glob('*.bin')}
    if not model_files:raise RuntimeError('No actual COLMAP binary model was written.')
    manifest={'format':'sceneatlas-hloc-reference-v1','model_id':model_id,'source_url':source_url,
        'model_path':'sfm','model_sha256':model_files,'features_path':features.name,'features_sha256':sha256(features),
        'feature_configuration':FEATURE_CONF,'matching_configuration':MATCH_CONF,'hloc_commit':HLOC_COMMIT,
        'images':[{'reference_id':f'{model_id}:{name}','image_name':name,'image_path':f'images/{name}',
            'sha256':sha256(images/name)} for name in names if name in name_to_image],
        'geographic_alignment':{'crs':'EPSG:4978','control_kind':'reference_camera_gps',
            'ecef_from_model':transform.matrix().tolist(),'controls':controls,'source':source_url,
            'accuracy_note':'Consumer drone EXIF GPS and altitude; no RTK/GCP survey or calibrated uncertainty. Query GPS is excluded from fit and reference validation.'},
        'license_files':[],'construction':{'registered_images':model.num_reg_images(),'points3D':model.num_points3D(),
            'duration_seconds_this_build_call':time.perf_counter()-started,'existing_reconstruction_reused':reused,'query_included_in_map':False}}
    if license_file:
        shutil.copy2(license_file,output/'DATA_LICENSE.txt');manifest['license_files']=['DATA_LICENSE.txt']
    from .geometry import _alignment
    manifest['alignment_validation_at_build']=_alignment(manifest,model)
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2,allow_nan=False))
    return manifest
