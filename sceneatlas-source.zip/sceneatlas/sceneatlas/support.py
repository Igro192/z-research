"""Image preparation, opt-in history, exports, and public-place references.

No models, GUI, or network requests run when this module is imported. Geographic
reference lookup establishes that a public place exists; it never establishes
that an uploaded photograph shows that place.
"""
from __future__ import annotations

import dataclasses
import hashlib
import html
import io
import json
import math
import os
import re
import shutil
import ssl
import tempfile
import threading
import time
import uuid
import warnings
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, BinaryIO, Mapping
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen

from PIL import ExifTags, Image, ImageOps, UnidentifiedImageError

MAX_IMAGE_BYTES = 30 * 1024 * 1024
MAX_IMAGE_PIXELS = 50_000_000
MAX_IMAGE_SIDE = 1600
ALLOWED_IMAGE_FORMATS = frozenset({'JPEG', 'MPO', 'PNG', 'WEBP'})
REFERENCE_POLICY_URL = 'https://operations.osmfoundation.org/policies/nominatim/'
REFERENCE_ATTRIBUTION = '© OpenStreetMap contributors; ODbL'
DEFAULT_SETTINGS = {
    'history_enabled': False,
    'online_references': True,
    'use_vision': True,
    'ocr': True,
    'device': 'auto',
    'nominatim_endpoint': 'https://nominatim.openstreetmap.org',
    'photon_endpoint': 'https://photon.komoot.io',
    'use_retrieval': True,
    'use_geometry': True,
}
_FILE_LOCK = threading.RLock()
_REFERENCE_LOCK = threading.Lock()
_HISTORY_ID = re.compile(r'^[0-9a-f]{32}$')


class ImageValidationError(ValueError):
    """The input cannot safely be processed as a supported scene image."""


class ReferenceLookupError(RuntimeError):
    """An optional geographic reference provider could not be reached."""


@dataclasses.dataclass(frozen=True)
class AppPaths:
    root: Path
    models: Path
    history: Path
    cache: Path
    logs: Path
    imports: Path
    exports: Path

    @property
    def settings(self) -> Path:
        return self.root / 'settings.json'


def app_paths(root: str | Path | None = None) -> AppPaths:
    """Create only SceneAtlas's data directories and return their absolute paths.

    Pass ``root`` for isolated tests. Normal application storage is always
    ``~/Library/Application Support/SceneAtlas``; model files use ``Models``.
    """
    base = Path(root).expanduser().resolve() if root else (
        Path.home() / 'Library' / 'Application Support' / 'SceneAtlas'
    )
    paths = AppPaths(base, *(base / name for name in (
        'Models', 'History', 'Cache', 'Logs', 'Imports', 'Exports'
    )))
    for directory in dataclasses.astuple(paths):
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    return paths


def _json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (datetime,)):
        return value.isoformat()
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return dataclasses.asdict(value)
    if hasattr(value, 'tolist'):
        return value.tolist()
    if hasattr(value, 'item'):
        return value.item()
    raise TypeError(f'Cannot export {type(value).__name__} as JSON')


def result_json(result: Mapping[str, Any]) -> str:
    """Serialize the complete result without discarding provenance or diagnostics."""
    return json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False,
                      default=_json_default) + '\n'


def _atomic_write(path: Path, data: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor, temporary = tempfile.mkstemp(prefix=f'.{path.name}.', dir=path.parent)
    temporary_path = Path(temporary)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_path, path)
    finally:
        temporary_path.unlink(missing_ok=True)


def _read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return default


@contextmanager
def _locked_file(path: Path):
    """Protect settings/rate state across this app's threads and processes."""
    import fcntl
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with _FILE_LOCK:
        with path.open('a+b') as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


class SettingsStore:
    """Atomic user preferences; saving images/history is disabled by default."""

    def __init__(self, paths: AppPaths | None = None):
        self.paths = paths or app_paths()

    def load(self) -> dict[str, Any]:
        stored = _read_json(self.paths.settings, {})
        settings = dict(DEFAULT_SETTINGS)
        if isinstance(stored, dict):
            settings.update(stored)
        for flag in ('history_enabled', 'online_references', 'use_vision', 'ocr', 'use_retrieval', 'use_geometry'):
            if not isinstance(settings[flag], bool):
                settings[flag] = DEFAULT_SETTINGS[flag]
        return settings

    def update(self, **values: Any) -> dict[str, Any]:
        for flag in ('history_enabled', 'online_references', 'use_vision', 'ocr', 'use_retrieval', 'use_geometry'):
            if flag in values and not isinstance(values[flag], bool):
                raise ValueError(f'{flag} must be true or false')
        for endpoint in ('nominatim_endpoint','photon_endpoint'):
            if endpoint in values:_validate_endpoint(values[endpoint])
        with _locked_file(self.paths.root / '.settings.lock'):
            settings = self.load()
            settings.update(values)
            _atomic_write(self.paths.settings, result_json(settings).encode('utf-8'))
        return settings


@dataclasses.dataclass(frozen=True)
class PreparedImage:
    path: Path
    thumbnail_path: Path
    source_name: str
    original_size: tuple[int, int]
    size: tuple[int, int]
    metadata: dict[str, Any]


def _read_image_bytes(source: str | Path | bytes | bytearray | BinaryIO) -> tuple[bytes, str]:
    if isinstance(source, (str, Path)):
        path = Path(source).expanduser()
        if not path.is_file():
            raise ImageValidationError('Choose an existing image file.')
        if path.stat().st_size > MAX_IMAGE_BYTES:
            raise ImageValidationError('The image exceeds the 30 MB limit.')
        with path.open('rb') as stream:
            data = stream.read(MAX_IMAGE_BYTES + 1)
        name = path.name
    elif isinstance(source, (bytes, bytearray)):
        data, name = bytes(source), 'Uploaded image'
    elif hasattr(source, 'read'):
        data, name = source.read(MAX_IMAGE_BYTES + 1), Path(
            str(getattr(source, 'name', 'Uploaded image'))
        ).name
    else:
        raise ImageValidationError('Provide JPEG, PNG, or WebP image data.')
    if not isinstance(data, bytes) or not data:
        raise ImageValidationError('The image file is empty or unreadable.')
    if len(data) > MAX_IMAGE_BYTES:
        raise ImageValidationError('The image exceeds the 30 MB limit.')
    return data, name


def _metadata(image: Image.Image) -> dict[str, Any]:
    result: dict[str, Any] = {
        'format': image.format,
        'metadata_is_optional_evidence': True,
        'metadata_is_not_visual_inference': True,
    }
    try:
        exif = image.getexif()
        allowed = {'Make', 'Model', 'DateTime', 'DateTimeOriginal', 'LensModel', 'Orientation'}
        result['exif'] = {ExifTags.TAGS.get(key, str(key)): str(value)
                          for key, value in exif.items()
                          if ExifTags.TAGS.get(key) in allowed}
        gps = exif.get_ifd(34853) if 34853 in exif else {}
        if gps:
            result['gps_exif_present'] = True
            result['gps_exif'] = {ExifTags.GPSTAGS.get(key, str(key)): str(value)
                                  for key, value in gps.items()}
    except (AttributeError, OSError, TypeError, ValueError):
        result['metadata_warning'] = 'Some source metadata could not be decoded.'
    return result


def _open_image(source, include_metadata: bool) -> tuple[Image.Image, str, tuple[int, int], dict]:
    data, name = _read_image_bytes(source)
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(data)) as probe:
                if probe.format not in ALLOWED_IMAGE_FORMATS:
                    raise ImageValidationError('Choose a JPEG, PNG, or WebP image.')
                original_size = probe.size
                if probe.width * probe.height > MAX_IMAGE_PIXELS:
                    raise ImageValidationError('The image exceeds the 50 megapixel limit.')
                probe.verify()
            with Image.open(io.BytesIO(data)) as decoded:
                metadata = _metadata(decoded) if include_metadata else {}
                oriented = ImageOps.exif_transpose(decoded)
                oriented.load()
                # White avoids transparent screenshots becoming black on conversion.
                if 'A' in oriented.getbands() or 'transparency' in oriented.info:
                    rgba = oriented.convert('RGBA')
                    rgb = Image.new('RGB', rgba.size, 'white')
                    rgb.paste(rgba, mask=rgba.getchannel('A'))
                else:
                    rgb = oriented.convert('RGB')
        return rgb, name, original_size, metadata
    except ImageValidationError:
        raise
    except (UnidentifiedImageError, OSError, SyntaxError, ValueError,
            Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
        raise ImageValidationError('The image is corrupt or cannot be decoded safely.') from exc


def _save_prepared(image: Image.Image, source_name: str, original_size: tuple[int, int],
                   metadata: dict[str, Any], dest: str | Path | None,
                   paths: AppPaths | None, max_side: int) -> PreparedImage:
    if not isinstance(max_side, int) or not 1 <= max_side <= MAX_IMAGE_SIDE:
        raise ValueError('max_side must be between 1 and 1600 pixels')
    image.thumbnail((max_side, max_side), Image.Resampling.LANCZOS)
    destination = Path(dest).expanduser().resolve() if dest else (
        (paths or app_paths()).imports / f'{uuid.uuid4().hex}.jpg'
    )
    if destination.suffix.lower() not in {'.jpg', '.jpeg'}:
        raise ValueError('Normalized image destination must use .jpg or .jpeg')
    full = io.BytesIO()
    image.save(full, format='JPEG', quality=92, optimize=True)
    thumb = image.copy()
    thumb.thumbnail((360, 240), Image.Resampling.LANCZOS)
    thumbnail = io.BytesIO()
    thumb.save(thumbnail, format='JPEG', quality=82, optimize=True)
    thumb_path = destination.with_name(destination.stem + '-thumb.jpg')
    _atomic_write(destination, full.getvalue())
    try:
        _atomic_write(thumb_path, thumbnail.getvalue())
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    return PreparedImage(destination, thumb_path, source_name, original_size, image.size, metadata)


def normalize_image(source, dest: str | Path | None = None, *, paths: AppPaths | None = None,
                    max_side: int = MAX_IMAGE_SIDE, source_name: str | None = None,
                    include_metadata: bool = True) -> PreparedImage:
    """Validate JPEG/PNG/WebP, correct EXIF orientation, strip metadata, save RGB JPEG.

    ``source`` accepts a path, bytes, or binary stream. Limits are 30 MiB, 50 MP,
    and a 1600-pixel long edge. Metadata is returned separately, never copied to
    the model-compatible JPEG. Call ``cleanup_prepared`` when a session ends.
    """
    image, name, original_size, metadata = _open_image(source, include_metadata)
    return _save_prepared(image, source_name or name, original_size, metadata,
                          dest, paths, max_side)


def crop_image(source, x: float, y: float, w: float, h: float,
               dest: str | Path | None = None, *, paths: AppPaths | None = None,
               source_name: str | None = None) -> PreparedImage:
    """Crop the oriented image using fractions of its width/height.

    Top-left must be inside the image; positive width/height are clipped to the
    right/bottom image boundary. Invalid, empty, non-finite selections fail.
    The returned JPEG obeys the same limits as ``normalize_image``.
    """
    try:
        x, y, w, h = map(float, (x, y, w, h))
    except (TypeError, ValueError) as exc:
        raise ImageValidationError('Choose a valid background crop.') from exc
    if not all(math.isfinite(value) for value in (x, y, w, h)) or not (
        0 <= x < 1 and 0 <= y < 1 and w > 0 and h > 0
    ):
        raise ImageValidationError('The background crop must lie inside the image.')
    image, name, original_size, metadata = _open_image(source, True)
    left, top = int(x * image.width), int(y * image.height)
    right = math.ceil(min(1.0, x + w) * image.width)
    bottom = math.ceil(min(1.0, y + h) * image.height)
    if right <= left or bottom <= top:
        raise ImageValidationError('The background crop is empty.')
    metadata['crop_fraction'] = {'x': x, 'y': y, 'w': min(w, 1 - x), 'h': min(h, 1 - y)}
    metadata['crop_source'] = 'User-selected environmental background'
    return _save_prepared(image.crop((left, top, right, bottom)), source_name or name,
                          original_size, metadata, dest, paths, MAX_IMAGE_SIDE)


def cleanup_prepared(prepared: PreparedImage, paths: AppPaths | None = None) -> None:
    """Delete temporary prepared files only if they belong to SceneAtlas Imports."""
    imports = (paths or app_paths()).imports.resolve()
    for path in (prepared.path, prepared.thumbnail_path):
        if path.resolve().parent == imports:
            path.unlink(missing_ok=True)


class HistoryStore:
    """Atomic local records with copied images; callers must explicitly enable history.

    ``save`` checks the setting itself and returns ``None`` when disabled. Records
    are published by atomic directory rename, so readers cannot see partial saves.
    Deletion is limited to validated UUID entries inside this application's root.
    """

    def __init__(self, paths: AppPaths | None = None):
        self.paths = paths or app_paths()

    def save(self, result: Mapping[str, Any], image_path: str | Path,
             source_name: str = '') -> dict[str, Any] | None:
        if not SettingsStore(self.paths).load()['history_enabled']:
            return None
        serialized = result_json(result)
        identifier = uuid.uuid4().hex
        staging = self.paths.history / f'.pending-{identifier}'
        staging.mkdir(mode=0o700)
        try:
            prepared = normalize_image(image_path, staging / 'image.jpg',
                                       source_name=source_name or Path(image_path).name)
            created = datetime.now(timezone.utc).isoformat()
            summary = result.get('summary') or result.get('best_estimate') or result.get('status') or 'Scene analysis'
            record = {
                'id': identifier, 'created_at': created,
                'source_name': prepared.source_name,
                'summary': summary if isinstance(summary, str) else json.dumps(summary, default=_json_default),
            }
            _atomic_write(staging / 'result.json', serialized.encode('utf-8'))
            _atomic_write(staging / 'record.json', result_json(record).encode('utf-8'))
            os.replace(staging, self.paths.history / identifier)
        except Exception:
            shutil.rmtree(staging, ignore_errors=True)
            raise
        return self.get(identifier)

    def _entry_dir(self, identifier: str) -> Path:
        if not isinstance(identifier, str) or not _HISTORY_ID.fullmatch(identifier):
            raise ValueError('Invalid saved analysis identifier')
        directory = self.paths.history / identifier
        if directory.is_symlink():
            raise ValueError('Saved analysis directory cannot be a symbolic link')
        return directory

    def get(self, identifier: str) -> dict[str, Any] | None:
        directory = self._entry_dir(identifier)
        record = _read_json(directory / 'record.json')
        result = _read_json(directory / 'result.json')
        if not isinstance(record, dict) or not isinstance(result, dict):
            return None
        return {**record, 'id': identifier, 'result': result,
                'image_path': str(directory / 'image.jpg'),
                'thumbnail_path': str(directory / 'image-thumb.jpg')}

    def list(self) -> list[dict[str, Any]]:
        records = []
        for directory in self.paths.history.iterdir():
            if _HISTORY_ID.fullmatch(directory.name) and directory.is_dir() and not directory.is_symlink():
                record = self.get(directory.name)
                if record:
                    records.append(record)
        return sorted(records, key=lambda item: item.get('created_at', ''), reverse=True)

    def delete(self, identifier: str) -> bool:
        directory = self._entry_dir(identifier)
        if not directory.exists():
            return False
        # Removal completes before the UI receives success; a failed unlink raises.
        shutil.rmtree(directory)
        return True

    def clear(self) -> int:
        deleted = 0
        for directory in self.paths.history.iterdir():
            if _HISTORY_ID.fullmatch(directory.name) and directory.is_dir() and not directory.is_symlink():
                deleted += int(self.delete(directory.name))
        return deleted


def _markdown_value(value: Any) -> str:
    if isinstance(value, str):
        return html.escape(value, quote=False)
    return html.escape(json.dumps(value, ensure_ascii=False, default=_json_default), quote=False)


def result_markdown(result: Mapping[str, Any]) -> str:
    """Render evidence, uncertainty, sources, and complete JSON without confidence fiction."""
    lines = ['# SceneAtlas analysis', '']
    sections = (
        ('summary', 'Best supported estimate'), ('best_estimate', 'Geographic estimate'),
        ('best', 'Selected candidate'), ('status', 'Status'),
        ('candidates', 'Geographic candidates'), ('evidence', 'Supporting evidence'),
        ('observations', 'Visible scene observations'),
        ('visual', 'Visual observations'), ('reasoning', 'Visual reasoning'),
        ('ocr', 'Supplementary visible text'), ('references', 'Public geographic references'),
        ('uncertainty', 'Uncertainty'), ('limitations', 'Limitations'),
        ('warnings', 'Warnings and limitations'),
        ('diagnostics', 'Model diagnostics'),
    )
    for key, title in sections:
        value = result.get(key)
        if value is None or value == '' or value == [] or value == {}:
            continue
        lines.extend([f'## {title}', ''])
        if isinstance(value, list):
            lines.extend(f'- {_markdown_value(item)}' for item in value)
        elif isinstance(value, dict):
            lines.extend(f'- **{_markdown_value(name)}:** {_markdown_value(item)}'
                         for name, item in value.items())
        else:
            lines.append(_markdown_value(value))
        lines.append('')
    lines.extend([
        '## Interpretation', '',
        'GeoCLIP scores are model ranking scores, not calibrated confidence percentages. '
        'Candidate coordinates are approximate hypotheses unless evidence explicitly supports greater precision. '
        'A public-place reference verifies existence and coordinates only; it does not establish an image match. '
        'EXIF and OCR are optional supplementary evidence.', '',
        '## Complete source result', '',
    ])
    serialized = result_json(result).rstrip()
    fence = '`' * max(3, max((len(match.group()) for match in re.finditer(r'`+', serialized)), default=0) + 1)
    lines.extend([f'{fence}json', serialized, fence, ''])
    return '\n'.join(lines)


def export_result(result: Mapping[str, Any], dest: str | Path, format: str | None = None) -> Path:
    """Atomically export JSON or Markdown; extension determines format by default."""
    path = Path(dest).expanduser().resolve()
    selected = (format or path.suffix.lstrip('.')).lower()
    if selected == 'json':
        rendered = result_json(result)
    elif selected in {'md', 'markdown'}:
        rendered = result_markdown(result)
    else:
        raise ValueError('Choose JSON or Markdown export')
    _atomic_write(path, rendered.encode('utf-8'))
    return path


def directory_bytes(directory: str | Path) -> int:
    """Count regular files without following symlinks outside an app directory."""
    total = 0
    for item in Path(directory).rglob('*'):
        if item.is_file() and not item.is_symlink():
            try:
                total += item.stat().st_size
            except OSError:
                pass
    return total


_PUBLIC_TYPES = {
    'historic': {'monument', 'memorial', 'castle', 'fort', 'archaeological_site', 'ruins', 'city_gate', 'battlefield', 'ship'},
    'amenity': {'arts_centre', 'theatre', 'library', 'townhall', 'university', 'fountain', 'place_of_worship'},
    'shop': {'mall', 'department_store', 'supermarket', 'books', 'clothes', 'retail'},
    'building': {'retail', 'commercial', 'train_station', 'museum', 'hotel'},
    'railway': {'station', 'halt'},
    'man_made': {'bridge', 'tower'},
    'tourism': {'attraction', 'viewpoint', 'museum', 'gallery', 'artwork', 'zoo', 'theme_park', 'aquarium', 'hotel'},
}
_PRIVATE_TYPES = {'house', 'detached', 'semidetached_house', 'residential', 'apartments', 'bungalow', 'cabin', 'dormitory'}


def _validate_endpoint(endpoint: str) -> str:
    parsed = urlparse(str(endpoint))
    if parsed.scheme != 'https' or not parsed.netloc or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError('The geographic provider endpoint must be an HTTPS URL')
    return str(endpoint).rstrip('/')


class LandmarkVerifier:
    """Optional cached existence lookup for named public landmarks only.

    Photos never leave the Mac. Only a proposed public landmark name is sent.
    The public Nominatim service is limited to one request per second across
    threads/processes, cached for 30 days, and never used for autocomplete or
    background/bulk search. Endpoint can be changed in Settings without updating
    the app. Provider policy: ``REFERENCE_POLICY_URL``. Check ``last_status`` for
    ``disabled``, ``cache``, ``online``, or ``rejected_query``. No imagery is fetched.
    """

    def __init__(self, paths: AppPaths | None = None, *, endpoint: str | None = None):
        self.paths = paths or app_paths()
        self.endpoint = endpoint
        self.last_status = 'idle'

    def search(self, query: str, limit: int = 3) -> list[dict[str, Any]]:
        settings = SettingsStore(self.paths).load()
        if not settings['online_references']:
            self.last_status = 'disabled'
            return []
        query = ' '.join(str(query).split())
        if not 3 <= len(query) <= 180 or re.search(
            r'(?i)(?:https?://|@|\b(?:private|residence|apartment|home\s+of|address\s+of)\b|^\d+\s)', query
        ):
            self.last_status = 'rejected_query'
            return []
        limit = max(1, min(int(limit), 5))
        endpoint = _validate_endpoint(self.endpoint or settings['nominatim_endpoint'])
        key = hashlib.sha256(f'public-v2|{endpoint}|{query.casefold()}'.encode()).hexdigest()
        cache = self.paths.cache / 'References' / f'{key}.json'
        with _REFERENCE_LOCK:
            cached = _read_json(cache)
            retrieved = cached.get('retrieved_at', 0) if isinstance(cached, dict) else 0
            if (isinstance(cached, dict) and isinstance(cached.get('results'), list)
                    and isinstance(retrieved, (int, float))
                    and 0 <= time.time() - retrieved < 30 * 86400):
                self.last_status = 'cache'
                return cached['results'][:limit]
            url = endpoint + '/search?' + urlencode({
                'q': query, 'format': 'jsonv2', 'limit': 10,
                'addressdetails': 0, 'extratags': 1, 'namedetails': 1,
            })
            with _locked_file(self.paths.cache / '.reference-rate.lock'):
                # A timestamp on disk covers separate app processes as well.
                rate_path = self.paths.cache / '.reference-rate.json'
                rate = _read_json(rate_path, {})
                previous = rate.get('started_at', 0) if isinstance(rate, dict) else 0
                if not isinstance(previous, (int, float)) or not math.isfinite(previous):
                    previous = 0
                previous = min(previous, time.time())
                delay = max(0.0, 1.1 - (time.time() - previous))
                if delay:
                    time.sleep(delay)
                _atomic_write(rate_path, result_json({'started_at': time.time()}).encode())
                raw_results = self._fetch_json(url)
            results = []
            if not isinstance(raw_results, list):
                raise ReferenceLookupError('The geographic provider returned an unexpected response.')
            for raw in raw_results:
                reference = self._public_reference(raw, query)
                if reference:
                    results.append(reference)
            _atomic_write(cache, result_json({'retrieved_at': time.time(), 'results': results}).encode())
            self.last_status = 'online'
            return results[:limit]

    def _fetch_json(self, url: str) -> Any:
        try:
            import certifi
            context = ssl.create_default_context(cafile=certifi.where())
            request = Request(url, headers={
                'User-Agent': 'SceneAtlas/1.0 (local macOS public-landmark verification)',
                'Accept': 'application/json', 'Accept-Language': 'en',
            })
            with urlopen(request, timeout=15, context=context) as response:
                payload = response.read(2_000_001)
            if len(payload) > 2_000_000:
                raise ReferenceLookupError('The geographic provider response was too large.')
            return json.loads(payload)
        except ReferenceLookupError:
            raise
        except Exception as exc:
            self.last_status = 'unavailable'
            raise ReferenceLookupError(f'Online public-place verification is unavailable: {exc}') from exc

    @staticmethod
    def _public_reference(raw: Any, query: str) -> dict[str, Any] | None:
        if not isinstance(raw, dict):
            return None
        category = str(raw.get('category', raw.get('class', ''))).lower()
        place_type = str(raw.get('type', '')).lower()
        extras = raw.get('extratags') or {}
        if not isinstance(extras, dict):
            extras = {}
        if place_type in _PRIVATE_TYPES or extras.get('building') in _PRIVATE_TYPES or extras.get('access') == 'private':
            return None
        if place_type not in _PUBLIC_TYPES.get(category, set()):
            matched = next(((key, value) for key, value in extras.items()
                            if isinstance(value, str) and value in _PUBLIC_TYPES.get(key, set())), None)
            if not matched:
                return None
            category, place_type = matched
        try:
            latitude, longitude = float(raw['lat']), float(raw['lon'])
        except (ValueError, TypeError, KeyError):
            return None
        if not math.isfinite(latitude) or not math.isfinite(longitude) or not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
            return None
        osm_type = str(raw.get('osm_type', ''))
        osm_id = str(raw.get('osm_id', ''))
        if osm_type not in {'node', 'way', 'relation'} or not osm_id.isdigit():
            return None
        source_url = f'https://www.openstreetmap.org/{osm_type}/{osm_id}'
        return {
            'name': raw.get('name') or raw.get('display_name') or query,
            'display_name': raw.get('display_name') or raw.get('name') or query,
            'latitude': latitude, 'longitude': longitude, 'lat': latitude, 'lon': longitude,
            'category': category, 'type': place_type,
            'source': 'OpenStreetMap / Nominatim', 'source_url': source_url, 'osm_url': source_url,
            'attribution': REFERENCE_ATTRIBUTION, 'query': query,
            'verification': 'public_place_exists', 'image_match': False,
            'names': raw.get('namedetails') or {}, 'tags': extras,
            'explanation': 'Public place existence and mapped coordinates only. No reference-image comparison was performed.',
        }
