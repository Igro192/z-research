"""SceneAtlas: local visual geographic hypotheses, with explicit uncertainty."""
__version__='0.3.0'
