"""One sequential geolocation workflow with a complete per-engine audit trail."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,logging,time,uuid
from .geographic import GeographicEngine,distinct_candidates
from .ocr import run_ocr


def analyze(image_path,settings,paths,progress=lambda text:None):
    started=time.perf_counter();warnings=[];engines={}
    def record(name,output,t,executed=True,reason=None,error=None):
        errors=[str(v) for k,v in output.items() if (k=='error' or k.endswith('_error')) and v]
        if error:errors.append(str(error))
        for row in output.get('queries',[]):errors.extend(row.get('errors',[]))
        for row in output.get('passes',[]):
            if row.get('error'):errors.append(row['error'])
        engines[name]={'executed':executed,'skip_reason':reason,'seconds':round(time.perf_counter()-t,3),
            'status':output.get('status','ok'),'output':output,'errors':errors,
            'affected_final_result':False}
    t=time.perf_counter();progress('Reading text regions with local OCR…')
    ocr=run_ocr(image_path,paths.models) if settings.get('ocr',True) else {'status':'disabled','text':'','regions':[]}
    record('ocr',ocr,t,settings.get('ocr',True),None if settings.get('ocr',True) else 'OCR disabled in settings.')
    t=time.perf_counter();progress('Examining the scene, landmarks and physical signs…')
    if settings.get('use_vision',True):
        from .vision import analyze_visual
        visual=analyze_visual(str(image_path),str(paths.models/'qwen'),ocr=ocr)
    else:visual={'status':'disabled','observations':[],'landmark_hypotheses':[],'visible_text':[]}
    record('vision',visual,t,settings.get('use_vision',True),None if settings.get('use_vision',True) else 'Vision disabled in settings.')
    if visual.get('error'):warnings.append('Scene reasoning: '+visual['error'])
    t=time.perf_counter();progress('Computing worldwide GeoCLIP hypotheses…');coarse=[]
    engine=GeographicEngine(paths.models,paths.cache)
    try:
        try:geo=engine.predict(image_path,device=settings.get('device','auto'))
        except Exception as exc:
            if engine.device!='mps':raise
            engine.unload();warnings.append(f'GeoCLIP MPS failed; CPU fallback: {exc}');geo=engine.predict(image_path,device='cpu')
        coarse=distinct_candidates(geo['coordinates'],geo['scores'])
        from .geography_data import label_candidates
        label_candidates(coarse)
    except Exception as exc:
        logging.exception('GeoCLIP failed');geo={'status':'failed','error':str(exc)};warnings.append('Worldwide prediction unavailable: '+str(exc))
    finally:engine.unload()
    record('geoclip',geo,t)
    t=time.perf_counter();progress('Verifying image-derived public place names…')
    from .place_search import PublicPlaceSearch
    try:references,lookup=PublicPlaceSearch(paths).search(visual,ocr,settings.get('online_references',True),coarse)
    except Exception as exc:
        logging.exception('Place lookup failed');references=[];lookup={'status':'error','error':str(exc),'queries':[]}
    record('public_place_lookup',lookup,t,bool(lookup.get('queries')),lookup.get('skip_reason'))
    t=time.perf_counter();progress('Retrieving real photos from the available AnyLoc index…')
    retrieval={'status':'disabled','matches':[]}
    if settings.get('use_retrieval',True):
        try:
            from .retrieval import retrieve
            retrieval=retrieve(image_path,paths,top_k=5)
        except Exception as exc:logging.exception('AnyLoc failed');retrieval={'status':'error','error':str(exc),'matches':[]}
    record('anyloc',retrieval,t,settings.get('use_retrieval',True),None if settings.get('use_retrieval',True) else 'Retrieval disabled in settings.')
    t=time.perf_counter();progress('Checking hloc matches and geographically aligned 3D poses…')
    geometry={'status':'disabled','pairs':[]}
    if settings.get('use_geometry',True):
        try:
            from .geometry import verify_geometry
            geometry=verify_geometry(image_path,retrieval.get('matches',[]),paths)
        except Exception as exc:logging.exception('hloc failed');geometry={'status':'error','error':str(exc),'pairs':[]}
    geometry_ran=settings.get('use_geometry',True) and bool(retrieval.get('matches'))
    record('hloc',geometry,t,geometry_ran,None if geometry_ran else ('Geometry disabled in settings.' if not settings.get('use_geometry',True) else 'No usable retrieved reference images.'))
    from .fusion import combine_candidates
    candidates=combine_candidates(coarse,visual,references,retrieval,geometry);primary=candidates[0] if candidates else None
    kind=primary.get('result_type') if primary else None
    if kind=='verified_camera_location':summary='Camera pose localized in a geographically aligned 3D reference reconstruction.';status='verified'
    elif kind=='recognized_landmark_location':summary='The supported public place is mapped. This is the landmark position; the photographer’s position is unknown.';status='landmark_supported'
    elif kind=='reference_image_location':summary='A geometrically matching reference photograph was found. Its coordinates do not establish the query-camera position.';status='reference_matched'
    elif primary:summary='Only a broad geographic prediction is available. The scene location is unverified.';status='uncertain'
    else:summary='The visible scene does not establish a public geographic location.';status='uncertain'
    if primary:
        tier=primary.get('evidence_tier',0)
        engines['geoclip']['affected_final_result']=primary.get('source')=='GeoCLIP'
        engines['hloc']['affected_final_result']=tier>=4
        engines['anyloc']['affected_final_result']=primary.get('id','').startswith('retrieval-') or (kind=='verified_camera_location')
        engines['public_place_lookup']['affected_final_result']=primary.get('id','').startswith('reference-')
        engines['vision']['affected_final_result']=engines['public_place_lookup']['affected_final_result']
        query=primary.get('reference',{}).get('query_evidence',{})
        engines['ocr']['affected_final_result']=query.get('basis')=='ocr_only' or bool(primary.get('reference',{}).get('ocr_agreement'))
    elif str(visual.get('scene_type','')).lower() in ('indoor','interior'):
        engines['vision']['affected_final_result']=True
    if geometry.get('status')!='pose_verified':warnings.append('Geometric localization could not establish a geographically aligned query-camera pose.')
    if primary and primary.get('conflicts'):warnings.extend(primary['conflicts'])
    for name in ('anyloc','hloc','public_place_lookup'):
        if engines[name]['errors']:warnings.append(name+': '+'; '.join(engines[name]['errors']))
    warnings+=['GeoCLIP gallery coordinates and AnyLoc similarities are uncalibrated model outputs.',
        'Decimal places are display precision, not measured location accuracy.',
        'Public-place pins and reference-photo coordinates are not camera positions.',
        'Online lookup verifies mapped place existence; photo identity depends on the recorded visual/sign/geometric evidence.',
        'No private residence or individual identity is inferred.']
    result={'id':uuid.uuid4().hex,'created_at':datetime.now(timezone.utc).isoformat(),'status':status,'summary':summary,
        'application_version':__import__('sceneatlas').__version__,'image_sha256':hashlib.sha256(Path(image_path).read_bytes()).hexdigest(),
        'result_type':kind,'selected_candidate_id':primary['id'] if primary else None,'candidates':candidates,
        'recognized_landmarks':list(dict.fromkeys(c['label'] for c in candidates if c.get('result_type')=='recognized_landmark_location')),
        'observations':visual.get('observations',[]),'visual':visual,'ocr':ocr,'references':references,'retrieval':retrieval,'geometry':geometry,
        'warnings':warnings,'diagnostics':{'engines':engines,'geo':geo,'policy':'Aligned 3D camera pose > geometric reference match > grounded physical sign + compatible public POI lookup > broad geographic prediction. Visual names and regional agreement alone remain unconfirmed. Conflicts and ambiguous branches remain explicit; raw scores are not averaged.'},
        'duration_seconds':round(time.perf_counter()-started,3)}
    # One current diagnostic, no retained photo or growing hidden image history.
    from .support import _atomic_write,result_json
    _atomic_write(paths.logs/'latest-analysis.json',result_json(result).encode())
    return result
