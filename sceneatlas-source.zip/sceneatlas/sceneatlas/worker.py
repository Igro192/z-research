from pathlib import Path
import json,logging,os,sys,threading,time,traceback

def main(request_file):
    request_path=Path(request_file);request=json.loads(request_path.read_text())
    output=Path(request['output']);status=Path(request['progress'])
    parent=os.getppid()
    def watch_parent():
        while True:
            time.sleep(2)
            if os.getppid()!=parent:os._exit(2)
    threading.Thread(target=watch_parent,daemon=True).start()
    def progress(text):
        tmp=status.with_suffix('.tmp');tmp.write_text(json.dumps({'message':text,'time':time.time()}));tmp.replace(status)
    try:
        from .support import app_paths
        from .pipeline import analyze
        result=analyze(request['image_path'],request.get('settings',{}),app_paths(),progress)
        result['source_name']=request.get('source_name','Image')
        # Metadata remains labeled supplementary evidence. It is never passed
        # to either visual model or used to generate the geographic candidates.
        if isinstance(request.get('metadata'),dict):result['metadata']=request['metadata']
    except Exception as exc:
        logging.exception('Analysis worker failed');result={'status':'error','error':str(exc),'traceback':traceback.format_exc()}
    tmp=output.with_suffix('.tmp');tmp.write_text(json.dumps(result,indent=2));tmp.replace(output)
    progress('Analysis complete' if result.get('status')!='error' else 'Analysis failed')
