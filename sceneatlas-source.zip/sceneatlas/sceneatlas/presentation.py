"""Coordinate semantics shared by results, maps, and exports; no model guesses."""
import math
from urllib.parse import urlencode

RESULT_LABELS={
 'verified_camera_location':'Verified Camera Location',
 'estimated_camera_location':'Estimated Camera Location',
 'recognized_landmark_location':'Verified Public Landmark Position',
 'broad_geographic_prediction':'Broad Geographic Prediction',
 'public_place_hypothesis':'Unconfirmed Public Place',
 'reference_image_location':'Reference Image Location',
}

def valid_coordinates(candidate):
 try:
  lat,lon=float(candidate['latitude']),float(candidate['longitude'])
  return math.isfinite(lat) and math.isfinite(lon) and -90<=lat<=90 and -180<=lon<=180
 except (TypeError,ValueError,KeyError):return False

def result_type(candidate):
 value=candidate.get('result_type')
 if value in RESULT_LABELS:return value
 if candidate.get('id','').startswith('reference-'):return 'recognized_landmark_location'
 return 'broad_geographic_prediction'

def coordinate_text(candidate):
 if not valid_coordinates(candidate):raise ValueError('This candidate has no valid geographic coordinates.')
 return f"{float(candidate['latitude']):.6f}, {float(candidate['longitude']):.6f}"

def map_zoom(candidate):
 if candidate.get('map_zoom') is not None:return max(1,min(19,int(candidate['map_zoom'])))
 kind=result_type(candidate)
 if kind=='verified_camera_location':return 17
 if kind=='recognized_landmark_location':return 15
 if kind=='reference_image_location':return 13
 return 5 if candidate.get('source')=='GeoCLIP' else 12

def maps_url(candidate):
 if not valid_coordinates(candidate):raise ValueError('No coordinates to open.')
 return 'https://maps.apple.com/?'+urlencode({'ll':coordinate_text(candidate),'q':candidate.get('label','SceneAtlas location')})

def candidate_warning(candidate):
 kind=result_type(candidate)
 if kind=='verified_camera_location':return 'Camera pose checked against a geographically aligned 3D reference model. See evidence for measured accuracy.'
 if kind=='public_place_hypothesis':return 'This public place exists, but its identity in the photo is unconfirmed.'
 if kind=='recognized_landmark_location':return 'This pin marks the landmark. The photographer’s position has not been established.'
 if kind=='reference_image_location':return 'These coordinates belong to a matching reference image, not a verified query-camera pose.'
 return 'Estimated point, not a verified camera position. Decimal places do not indicate geographic accuracy.'
