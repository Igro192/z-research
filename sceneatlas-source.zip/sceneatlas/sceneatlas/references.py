"""Licensed local reference photographs with explicit coordinate provenance.

A reference-camera geotag and a depicted landmark coordinate are different
facts. Neither establishes the query camera position. Reference photos are used
for visual retrieval and optional geometry, never selected from query labels.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


def reference_directory(paths=None) -> Path:
    """Prefer an installed collection; otherwise use the bundled starter set."""
    if paths is not None:
        installed = paths.root / 'References'
        if (installed / 'manifest.json').is_file():
            return installed
    return Path(__file__).resolve().parent / 'data' / 'reference_collection'


def load_references(paths=None) -> list[dict[str, Any]]:
    """Load existing image records only, resolving paths inside the collection."""
    root = reference_directory(paths)
    try:
        data = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        data = []
    records = data.get('references', []) if isinstance(data, dict) else data
    if not isinstance(records, list):
        return []
    result = []
    for row in records:
        if not isinstance(row, dict) or not row.get('reference_id') or not row.get('license'):
            continue
        relative = row.get('image', '')
        image = (root / relative).resolve()
        if not image.is_relative_to(root.resolve()) or not image.is_file():
            continue
        coordinate_kind = row.get('coordinate_kind')
        if coordinate_kind not in {'reference_camera', 'landmark'}:
            continue
        coordinate = row.get('camera_coordinates' if coordinate_kind == 'reference_camera' else 'landmark_coordinates')
        try:
            latitude, longitude = float(coordinate['latitude']), float(coordinate['longitude'])
            if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
                continue
        except (TypeError, KeyError, ValueError):
            continue
        result.append({**row, 'reference_path': str(image), 'reference_image_path': str(image),
                       'latitude': latitude, 'longitude': longitude})
    if paths is not None:
        result.extend(_registered_references(paths))
    return result


def _registered_references(paths) -> list[dict]:
    """Use original registered images and their manifest camera GPS controls.

    Never resize/copy these paths: hloc's stored feature indices and 3D model
    refer to these exact prepared reference files. Only manifest-listed images
    participate; held-out query photos cannot enter through directory scanning.
    """
    registered = paths.models / 'geometry' / 'registered'
    records = []
    if not registered.is_dir():
        return records
    for manifest_path in sorted(registered.glob('*/manifest.json')):
        try:
            manifest = json.loads(manifest_path.read_text())
            if manifest.get('format') != 'sceneatlas-hloc-reference-v1':
                continue
            controls = {row['image_name']: row for row in manifest['geographic_alignment']['controls']}
            model_id = manifest['model_id']
            root = manifest_path.parent.resolve()
            for row in manifest['images']:
                name = row['image_name']
                control = controls.get(name)
                if not control or control.get('role') == 'query':
                    continue
                image = (root / row['image_path']).resolve()
                if not image.is_relative_to(root) or not image.is_file():
                    continue
                latitude, longitude, altitude = map(float, control['latitude_longitude_altitude'])
                if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
                    continue
                records.append({
                    'reference_id': row['reference_id'], 'reference_path': str(image),
                    'reference_image_path': str(image), 'image_sha256': row['sha256'],
                    'place_name': manifest.get('place_name', model_id.replace('_', ' ')),
                    'latitude': latitude, 'longitude': longitude,
                    'coordinate_kind': 'reference_camera',
                    'camera_coordinates': {'latitude': latitude, 'longitude': longitude, 'altitude': altitude,
                        'source': 'Source image EXIF GPS retained in registered reference manifest',
                        'accuracy': 'Consumer GPS; reference-camera metadata, not query-camera proof.'},
                    'landmark_coordinates': None,
                    'source_url': control.get('source_url', manifest['source_url']),
                    'license': control['license'], 'creator': control.get('author'),
                    'reconstruction_id': model_id, 'image_name_in_model': name,
                    'registered_reference': True,
                })
        except (OSError, ValueError, KeyError, TypeError):
            continue
    return records


def collection_fingerprint(records: list[dict]) -> str:
    """Bind a descriptor index to exact reference identities and image hashes."""
    encoded = json.dumps([(row['reference_id'], row.get('image_sha256')) for row in records],
                         sort_keys=True, separators=(',', ':')).encode()
    return hashlib.sha256(encoded).hexdigest()


def reference_status(paths=None) -> dict:
    records = load_references(paths)
    return {'status': 'available' if records else 'missing', 'count': len(records),
            'collection_fingerprint': collection_fingerprint(records),
            'directory': str(reference_directory(paths)),
            'coordinate_kinds': sorted({row['coordinate_kind'] for row in records}),
            'limitations': 'A small curated starter collection cannot cover the world. Reference-camera geotags are community-supplied, not surveyed query camera positions.'}
