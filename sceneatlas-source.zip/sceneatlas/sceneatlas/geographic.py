"""Official GeoCLIP inference, with lossless gallery-embedding caching."""
from pathlib import Path
import gc, importlib.metadata, json, logging, math, time

def distance_km(a,b):
    p1,p2=map(math.radians,[float(a[0]),float(b[0])]); dp=p2-p1; dl=math.radians(float(b[1])-float(a[1]))
    h=math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 6371.0088*2*math.asin(min(1,math.sqrt(h)))

def distinct_candidates(coordinates,scores,min_distance_km=120,limit=5):
    out=[]
    for rank,(point,score) in enumerate(zip(coordinates,scores),1):
        point=list(map(float,point))
        if len(point)!=2 or not all(math.isfinite(v) for v in point) or not (-90<=point[0]<=90 and -180<=point[1]<=180) or not math.isfinite(float(score)):continue
        if any(distance_km(point,[p['latitude'],p['longitude']])<min_distance_km for p in out):continue
        out.append({'id':f'geo-{rank}','label':f'Geographic hypothesis {len(out)+1}',
          'latitude':point[0],'longitude':point[1],'raw_score':float(score),
          'model_rank':rank,'source':'GeoCLIP','precision':'broad regional estimate','result_type':'estimated_camera_location','coordinate_kind':'model_gallery_estimate',
          'radius_km':150,'radius_note':'Display radius only; not a calibrated error bound.',
          'evidence':['Visual similarity in the pretrained GeoCLIP geographic embedding.'],
          'uncertainty':'Uncalibrated model ranking; coordinate is a gallery sample, not proof of the photograph location.'})
        if len(out)==limit:break
    return out

class GeographicEngine:
    def __init__(self,models_dir,cache_dir=None):
        self.models_dir=Path(models_dir);self.cache_dir=Path(cache_dir or self.models_dir/'cache')
        self.cache_dir.mkdir(parents=True,exist_ok=True)
        self.model=None;self.device=None;self.features=None;self.load_seconds=None
    def load(self,device='auto'):
        if self.model is not None:return
        import torch
        from geoclip import GeoCLIP
        t=time.perf_counter();torch.set_num_threads(4)
        if not (self.models_dir/'clip/model.safetensors').is_file():raise FileNotFoundError('CLIP weights are not installed. Open Settings → Download models.')
        self.device=('mps' if torch.backends.mps.is_available() else 'cpu') if device=='auto' else device
        self.model=GeoCLIP(clip_path=str(self.models_dir/'clip')).eval().to(self.device)
        self.load_seconds=time.perf_counter()-t
    def unload(self):
        self.model=None;self.features=None;gc.collect()
        # Cleanup must not import a broken/missing framework again and replace
        # the actual inference error. Use it only if prediction imported it.
        import sys
        torch=sys.modules.get('torch')
        if torch is not None:
            try:
                if torch.backends.mps.is_available():torch.mps.empty_cache()
            except Exception:
                logging.warning('Could not release the PyTorch MPS cache',exc_info=True)
    def predict_upstream(self,image_path,top_k=30,device='auto'):
        """Exact public upstream API for compatibility/acceptance verification."""
        self.load(device); t=time.perf_counter()
        coords,scores=self.model.predict(str(image_path),top_k=top_k)
        if self.device=='mps':
            import torch
            torch.mps.synchronize()
        return {'coordinates':coords.tolist(),'scores':scores.tolist(),'inference_seconds':time.perf_counter()-t,'load_seconds':self.load_seconds,'device':self.device,'api':'GeoCLIP.predict','version':importlib.metadata.version('geoclip')}
    def predict(self,image_path,top_k=50,device='auto'):
        """Same official encoders/softmax as predict; cache fixed gallery features.

        Batching changes floating point roundoff only; no new model or coordinates.
        """
        import torch
        import torch.nn.functional as F
        from PIL import Image
        self.load(device);t=time.perf_counter();cache_status='memory'
        with torch.inference_mode():
            if self.features is None:
                # Include installed pretrained weights hash in cache identity.
                import hashlib, geoclip
                weight=Path(geoclip.__file__).parent/'model/weights/location_encoder_weights.pth'
                fingerprint=hashlib.sha256(weight.read_bytes()).hexdigest()[:16]
                cache=self.cache_dir/f'gallery-{importlib.metadata.version("geoclip")}-{fingerprint}.pt'
                if cache.exists():
                    features=torch.load(cache,map_location='cpu',weights_only=True)
                    if features.shape != (len(self.model.gps_gallery),512):raise ValueError('Invalid cached gallery shape')
                    self.features=features.to(self.device);cache_status='disk'
                else:
                    batches=[]
                    for points in self.model.gps_gallery.split(2048):
                        batches.append(F.normalize(self.model.location_encoder(points),dim=1).cpu())
                    features=torch.cat(batches);tmp=cache.with_suffix('.tmp');torch.save(features,tmp);tmp.replace(cache)
                    self.features=features.to(self.device);cache_status='computed'
            with Image.open(image_path) as image:
                x=self.model.image_encoder.preprocess_image(image.convert('RGB')).to(self.device)
            visual=F.normalize(self.model.image_encoder(x),dim=1)
            logits=self.model.logit_scale.exp()*(visual@self.features.T)
            scores,indices=logits.softmax(dim=-1).topk(min(top_k,len(self.model.gps_gallery)),dim=1)
            coords=self.model.gps_gallery.index_select(0,indices[0]).cpu().tolist();scores=scores[0].cpu().tolist()
            if self.device=='mps':torch.mps.synchronize()
        return {'coordinates':coords,'scores':scores,'inference_seconds':time.perf_counter()-t,'load_seconds':self.load_seconds,'device':self.device,'gallery_cache':cache_status,'api':'GeoCLIP official encoders with cached gallery embeddings','version':importlib.metadata.version('geoclip')}
