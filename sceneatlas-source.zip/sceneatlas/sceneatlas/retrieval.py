"""Real AnyLoc DINOv2 + VLAD retrieval over a small licensed local collection.

Descriptor similarity is an image-retrieval ranking, never calibrated confidence
or a query-camera coordinate. Matching geometry is a separate pipeline stage.
All heavy imports are lazy; models are released before subsequent MLX work.
"""
from __future__ import annotations

import gc
import hashlib
import json
import os
from pathlib import Path
import sys
import threading
import time
from typing import Callable

from .references import collection_fingerprint, load_references
from .support import _atomic_write, app_paths, result_json

ANYLOC_COMMIT = 'a9fda68c55083f765b019df148a1b67614f90ee2'
DINOV2_COMMIT = '7764ea0f912e53c92e82eb78a2a1631e92725fc8'
MODEL_NAME = 'dinov2_vits14'
LAYER = 11
FACET = 'value'
CLUSTERS = 32
DESC_DIM = 384
MAX_EDGE = 504
WEIGHTS_FILENAME = 'dinov2_vits14_pretrain.pth'
WEIGHTS_BYTES = 88283115
WEIGHTS_SHA256 = 'b938bf1bc15cd2ec0feacfe3a1bb553fe8ea9ca46a7e1d8d00217f29aef60cd9'
_LOCK = threading.Lock()


def retrieval_status(paths=None) -> dict:
    paths = paths or app_paths()
    directory = paths.models / 'AnyLoc'
    references = load_references(paths)
    metadata = {}
    try:
        metadata = json.loads((directory / 'index.json').read_text())
    except (OSError, ValueError):
        pass
    weights = directory / WEIGHTS_FILENAME
    ready = (weights.is_file() and (directory / 'descriptors.npz').is_file()
             and (directory / 'vocabulary/c_centers.pt').is_file()
             and metadata.get('collection_fingerprint') == collection_fingerprint(references)
             and metadata.get('descriptor_config') == descriptor_config())
    return {'status': 'available' if ready else 'missing_or_stale', 'ready': ready,
            'reference_count': len(references), 'model': MODEL_NAME, 'loaded': None,
            'anyloc_commit': ANYLOC_COMMIT, 'index': metadata}


def descriptor_config() -> dict:
    return {'model': MODEL_NAME, 'layer': LAYER, 'facet': FACET, 'clusters': CLUSTERS,
            'dimension': DESC_DIM, 'max_edge': MAX_EDGE, 'anyloc_commit': ANYLOC_COMMIT,
            'dinov2_commit': DINOV2_COMMIT}


def _extractor(paths, device='auto'):
    import torch
    from .vendor.anyloc.utilities import DinoV2ExtractFeatures
    weights = paths.models / 'AnyLoc' / WEIGHTS_FILENAME
    if not weights.is_file():
        raise FileNotFoundError('AnyLoc DINOv2 weights are missing. Install or repair the retrieval model.')
    if weights.stat().st_size != WEIGHTS_BYTES:
        raise ValueError('The local AnyLoc DINOv2 checkpoint has an incorrect size')
    with weights.open('rb') as weight_file:
        if hashlib.file_digest(weight_file, 'sha256').hexdigest() != WEIGHTS_SHA256:
            raise ValueError('The local AnyLoc DINOv2 checkpoint failed its pinned SHA256 check')
    os.environ.setdefault('XFORMERS_DISABLED', '1')
    # Official DINOv2 imports its own top-level package internally. Bind that
    # name to our pinned, packaged source rather than Torch Hub or a global pip.
    from .vendor.dinov2 import dinov2 as dino_package
    sys.modules.setdefault('dinov2', dino_package)
    from .vendor.dinov2.dinov2.hub.backbones import dinov2_vits14

    def local_loader(repository, model_name):
        if model_name != MODEL_NAME:
            raise ValueError('Unexpected AnyLoc backbone request')
        model = dinov2_vits14(pretrained=False)
        state = torch.load(weights, map_location='cpu', weights_only=True)
        model.load_state_dict(state, strict=True)
        return model

    if device == 'auto':
        device = 'mps' if torch.backends.mps.is_available() else 'cpu'
    torch.set_num_threads(4)
    return DinoV2ExtractFeatures(MODEL_NAME, LAYER, FACET, device=device,
                                model_loader=local_loader), device


def _patch_descriptors(image_path, extractor):
    """The same ImageNet normalization, resize and 14-patch crop as AnyLoc demo."""
    import torch
    from PIL import Image, ImageOps
    from torchvision import transforms as tvf
    from torchvision.transforms import functional as transform
    with Image.open(image_path) as source:
        image = ImageOps.exif_transpose(source).convert('RGB')
    tensor = tvf.Compose([tvf.ToTensor(), tvf.Normalize(
        mean=[.485, .456, .406], std=[.229, .224, .225])])(image)
    height, width = tensor.shape[-2:]
    if max(height, width) > MAX_EDGE:
        factor = MAX_EDGE / max(height, width)
        tensor = transform.resize(tensor, [max(14, int(height * factor)), max(14, int(width * factor))],
                                  interpolation=transform.InterpolationMode.BICUBIC)
    height, width = tensor.shape[-2:]
    if min(height, width) < 14:
        raise ValueError('The scene image is too small for DINOv2 patches')
    tensor = tvf.CenterCrop(((height // 14) * 14, (width // 14) * 14))(tensor)[None]
    with torch.inference_mode():
        return extractor(tensor.to(extractor.device)).cpu().squeeze(0)


def _release(extractor):
    if extractor is not None:
        # Remove the forward hook before clearing its model reference.
        extractor.fh_handle.remove()
        extractor.dino_model = None
    gc.collect()
    torch = sys.modules.get('torch')
    if torch is not None:
        try:
            if torch.backends.mps.is_available():
                torch.mps.empty_cache()
        except Exception:
            pass


def build_index(paths=None, progress: Callable[[str], None] | None = None,
                device='auto') -> dict:
    """Fit upstream VLAD vocabulary on references only, then persist descriptors.

    No evaluation/query image participates in fitting. This is unsupervised
    descriptor aggregation, not foundation-model training. Rebuilding requires
    the local official DINOv2 checkpoint and local reference photographs.
    """
    paths = paths or app_paths()
    emit = progress or (lambda text: None)
    references = load_references(paths)
    if len(references) < CLUSTERS // 2:
        raise ValueError('At least sixteen licensed reference photographs are required to fit this starter vocabulary.')
    directory = paths.models / 'AnyLoc'
    directory.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter();extractor = None
    with _LOCK:
        try:
            import numpy as np
            import torch
            from .vendor.anyloc.utilities import VLAD
            torch.manual_seed(0);np.random.seed(0)
            extractor, actual_device = _extractor(paths, device)
            patches = []
            for index, reference in enumerate(references, 1):
                emit(f'AnyLoc reference features {index}/{len(references)}')
                with Path(reference['reference_path']).open('rb') as source_file:
                    actual_hash = hashlib.file_digest(source_file, 'sha256').hexdigest()
                if actual_hash != reference.get('image_sha256'):
                    raise ValueError(f'Reference image integrity mismatch: {reference["reference_id"]}')
                patches.append(_patch_descriptors(reference['reference_path'], extractor))
            _release(extractor);extractor = None
            vocabulary = directory / 'vocabulary'
            vocabulary.mkdir(exist_ok=True)
            # Use a separate vocabulary per exact collection/config so a stale
            # upstream cache cannot silently suppress the requested fit.
            fingerprint = collection_fingerprint(references)
            config_hash = hashlib.sha256(result_json(descriptor_config()).encode()).hexdigest()
            fit_key = hashlib.sha256((fingerprint + config_hash).encode()).hexdigest()
            centers = vocabulary / 'c_centers.pt'
            fit_metadata = vocabulary / 'fit.json'
            prior = json.loads(fit_metadata.read_text()) if fit_metadata.is_file() else {}
            if centers.exists() and prior.get('fit_key') != fit_key:
                centers.replace(vocabulary / f'c_centers.previous-{time.time_ns()}.pt')
            vlad = VLAD(CLUSTERS, desc_dim=DESC_DIM, cache_dir=str(vocabulary))
            # Bound fitting memory while sampling every reference evenly.
            training = torch.cat([value[::max(1, len(value) // 384)][:384] for value in patches])
            emit(f'Fitting reference-only AnyLoc VLAD vocabulary ({len(training)} patches)…')
            vlad.fit(training)
            _atomic_write(fit_metadata, result_json({'fit_key': fit_key,
                'reference_collection_fingerprint': fingerprint,
                'reference_ids': [row['reference_id'] for row in references],
                'patch_count': len(training), 'descriptor_config': descriptor_config(),
                'implementation': 'AnyLoc upstream VLAD.fit; fast-pytorch-kmeans0.2.2',
                'evaluation_or_query_images_used': False}).encode())
            descriptors = []
            for index, values in enumerate(patches, 1):
                emit(f'Aggregating AnyLoc VLAD reference {index}/{len(patches)}')
                descriptors.append(vlad.generate(values).numpy())
            matrix = np.stack(descriptors).astype(np.float32)
            temporary = directory / 'descriptors.partial.npz'
            np.savez_compressed(temporary, descriptors=matrix,
                                reference_ids=np.array([row['reference_id'] for row in references]))
            temporary.replace(directory / 'descriptors.npz')
            with (directory / WEIGHTS_FILENAME).open('rb') as weight_file:
                weight_sha256 = hashlib.file_digest(weight_file, 'sha256').hexdigest()
            metadata = {'status': 'ready', 'created_at': time.time(),
                'collection_fingerprint': fingerprint, 'reference_count': len(references),
                'descriptor_config': descriptor_config(), 'device': actual_device,
                'build_seconds': time.perf_counter() - started, 'fit_key': fit_key,
                'weight_sha256': weight_sha256,
                'score_interpretation': 'Cosine similarity of normalized AnyLoc VLAD descriptors; not a probability.',
                'geographic_scope': 'Only the explicitly indexed starter reference places; no worldwide coverage claim.'}
            _atomic_write(directory / 'index.json', result_json(metadata).encode())
            return metadata
        finally:
            _release(extractor)


def retrieve(image_path, paths=None, top_k=5) -> dict:
    """Return genuine AnyLoc-ranked reference photos with coordinate provenance.

    Missing/stale references or models produce an explicit unavailable result.
    Same-file SHA matches are excluded rather than being counted as retrieval
    success. Every model object is released before returning to the pipeline.
    """
    paths = paths or app_paths()
    started = time.perf_counter();extractor = None
    result = {'status': 'unavailable', 'matches': [], 'model': MODEL_NAME,
              'method': 'AnyLoc DINOv2 value facets + upstream VLAD',
              'model_version': descriptor_config(), 'inference_seconds': 0,
              'score_interpretation': 'Raw cosine descriptor similarity, not calibrated confidence.',
              'limitations': ['Retrieval identifies visually similar reference images; it does not establish query-camera pose.',
                              'The starter reference collection covers only its listed public places.']}
    status = retrieval_status(paths)
    if not status['ready']:
        result['error'] = 'Local AnyLoc model, reference collection, or descriptor index is missing/stale.'
        return result
    with _LOCK:
        try:
            import numpy as np
            from .vendor.anyloc.utilities import VLAD
            references = load_references(paths)
            directory = paths.models / 'AnyLoc'
            query_hash = hashlib.sha256(Path(image_path).read_bytes()).hexdigest()
            load_started = time.perf_counter()
            extractor, device = _extractor(paths)
            result['load_seconds'] = time.perf_counter() - load_started
            descriptor = _patch_descriptors(image_path, extractor)
            _release(extractor);extractor = None
            vlad = VLAD(CLUSTERS, desc_dim=DESC_DIM, cache_dir=str(directory / 'vocabulary'))
            vlad.fit(None)
            query = vlad.generate(descriptor).numpy().astype(np.float32)
            with np.load(directory / 'descriptors.npz', allow_pickle=False) as stored:
                matrix = stored['descriptors'];ids = stored['reference_ids'].tolist()
            if matrix.shape != (len(references), CLUSTERS * DESC_DIM):
                raise ValueError('Reference descriptor shape is inconsistent with the local collection')
            lookup = {row['reference_id']: row for row in references}
            if not np.isfinite(matrix).all() or not np.isfinite(query).all():
                raise ValueError('Non-finite reference/query descriptor')
            # Same cosine dot products, avoiding Accelerate BLAS exception-state
            # warnings after sequential Metal inference in this process.
            scores = np.einsum('ij,j->i', matrix, query, optimize=False)
            if not np.isfinite(scores).all():
                raise ValueError('AnyLoc returned non-finite descriptor similarities')
            matches = []
            for index in np.argsort(-scores):
                row = lookup.get(ids[int(index)])
                if not row or row.get('image_sha256') == query_hash:
                    continue
                matches.append({**row, 'score': float(scores[index]),
                                'retrieval_rank': len(matches) + 1,
                                'image_match_status': 'retrieval_candidate_requires_geometry'})
                if len(matches) >= max(1, min(int(top_k), 20)):
                    break
            result.update(status='ok', matches=matches, device=device,
                          reference_count=len(references), query_descriptor_dimension=len(query),
                          reference_collection_fingerprint=status['index']['collection_fingerprint'])
        except Exception as exc:
            result.update(status='error', error=f'{type(exc).__name__}: {exc}', matches=[])
        finally:
            _release(extractor)
            result['inference_seconds'] = time.perf_counter() - started
    return result
