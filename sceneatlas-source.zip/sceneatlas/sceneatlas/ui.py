"""Native NiceGUI workspace. Model work always runs outside the UI process."""
from __future__ import annotations
import asyncio,html,importlib.metadata,json,logging,os,secrets,socket,subprocess,time,weakref
from pathlib import Path
from nicegui import app,ui
from nicegui.elements.leaflet import Leaflet
from .presentation import RESULT_LABELS,result_type,valid_coordinates,coordinate_text,map_zoom,maps_url,candidate_warning
from .support import (SettingsStore,HistoryStore,normalize_image,crop_image,cleanup_prepared,
                      result_json,result_markdown,export_result,directory_bytes)
from .model_management import model_status,verify_models,download_models,clear_inference_cache,clear_models
from .runner import AnalysisRunner

CSS='''
:root {--bg:#121619;--panel:#1b2227;--line:#303b42;--muted:#9caeb7;--accent:#8cddbf}
body,.q-page {background:var(--bg);color:#e9f0f2;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
.nicegui-content {padding:0;gap:0} .shell {max-width:1500px;margin:0 auto;width:100%}
.topbar {height:82px;border-bottom:1px solid var(--line);padding:0 34px;align-items:center}
.wordmark {font-size:23px;font-weight:650;letter-spacing:-.8px}.tagline {color:var(--muted);font-size:12px;letter-spacing:1.3px;text-transform:uppercase}
.nav {border-bottom:1px solid var(--line);padding:10px 28px;gap:8px}.nav .q-btn {color:var(--muted);text-transform:none;letter-spacing:0}
.nav .selected {color:var(--accent);background:#223b34}.workspace {width:100%;padding:30px 36px 40px;min-height:640px}
.hero {font-size:40px;line-height:1.15;font-weight:620;letter-spacing:-1.5px;max-width:680px}.muted {color:var(--muted)}
.panel {background:var(--panel);border:1px solid var(--line);border-radius:16px;box-shadow:none;padding:24px}
.dropzone {border:1.5px dashed #53686e;border-radius:18px;min-height:260px;padding:34px;align-items:center;justify-content:center;background:#192126}
.q-uploader {background:transparent;box-shadow:none;width:100%;max-width:580px;border:1px solid #42564f;border-radius:12px}
.q-uploader__header {background:#315b4c;color:#eefbf5}.q-uploader__list {min-height:80px}
.primary {background:var(--accent)!important;color:#11271e!important;border-radius:10px;text-transform:none;font-weight:600}
.secondary {border:1px solid var(--line);border-radius:10px;text-transform:none}.eyebrow {color:var(--accent);font-size:11px;letter-spacing:1.5px;text-transform:uppercase}
.candidate {padding:16px;background:#202b31;border:1px solid #3b4c55;border-radius:12px;width:100%;align-items:flex-start}
.candidate .q-btn {text-transform:none;text-align:left;justify-content:flex-start;padding:0;color:#b6ead8;font-size:17px}
.result-grid {display:grid;grid-template-columns:minmax(320px,40fr) minmax(460px,60fr);gap:24px;align-items:start;width:100%}
.map-panel {position:sticky;top:20px;overflow:hidden;padding:0}.map-panel .nicegui-leaflet {height:calc(100vh - 295px);min-height:490px;width:100%}.leaflet-container {background:#26363e!important;color:#15232b}
.q-expansion-item {width:100%;border-top:1px solid var(--line)}.q-toggle__label {font-size:14px}.q-field {max-width:100%}
.result-photo{height:210px;object-fit:contain;background:#1b2227;border-radius:12px}.location-name{font-size:26px;font-weight:600;line-height:1.15;letter-spacing:-.6px}.gps-display{background:#202f33;border:1px solid #3e6559;border-radius:12px;padding:18px}.gps-caption{font-size:10px;letter-spacing:1.5px;color:#8cddbf}.gps-axis{font-size:10px;letter-spacing:1px;width:83px;color:#a8bbb9}.gps-number{font-family:ui-monospace,Menlo,monospace;font-size:23px;letter-spacing:-.8px}.precision-note{font-size:12px;color:#c8d9d5;border-left:2px solid #8cddbf;padding-left:10px}.source-link{font-size:12px;color:#8cddbf}.candidate-choice{border:1px solid #35484d;border-radius:8px;text-align:left;color:#bfe7d8}.map-expanded{position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;z-index:99999!important;border-radius:0!important}.map-expanded .nicegui-leaflet{height:calc(100vh - 95px)!important}.map-toolbar{background:#1b252b}
@media(max-width:1000px){.result-grid{grid-template-columns:1fr}.map-panel{position:relative;top:0}.workspace{padding:22px}.hero{font-size:32px}}
'''

class Workspace:
 def __init__(self,paths,runner):
  self.client=ui.context.client;self.selected_candidate_id=None;self.candidate_markers={};self.map_expanded=False;self.paths=paths;self.runner=runner;self.settings=SettingsStore(paths);self.history=HistoryStore(paths)
  self.view='Analyze';self.image_path=None;self.prepared=None;self.original=None;self.source_name='';self.result=None
  self.temporary=[];self.busy=False;self.progress='Ready when you are.';self.status_label=None;self.map=None
  self.crop_start=None;self.crop_rect=None;self.crop_widget=None;self.history_id=None;self.maintenance=False
  ui.add_css(CSS)
  with ui.column().classes('shell gap-0'):
   with ui.row().classes('topbar w-full no-wrap'):
    ui.icon('travel_explore',size='32px').style('color:#8cddbf')
    with ui.column().classes('gap-0'):
     ui.label('SceneAtlas').classes('wordmark');ui.label('A place to investigate places').classes('tagline')
    ui.space();ui.label('LOCAL AI · PUBLIC SCENES').classes('tagline')
   with ui.row().classes('nav w-full'):
    self.nav={name:ui.button(name,icon=icon,on_click=lambda n=name:self.show(n)).props('flat').classes('selected' if name=='Analyze' else '') for name,icon in [('Analyze','add_photo_alternate'),('Results','explore'),('History','history'),('Settings','tune')]}
   self.content=ui.column().classes('workspace')
  self.show('Analyze')
 def cleanup(self):
  for prepared in self.temporary:cleanup_prepared(prepared,self.paths)
  self.temporary.clear()
 def show(self,view):
  self.view=view
  for name,button in self.nav.items():button.classes(add='selected' if name==view else '',remove='selected' if name!=view else '')
  self.content.clear();self.status_label=None;self.map=None
  with self.content:
   {'Analyze':self.analyze_view,'Results':self.results_view,'History':self.history_view,'Settings':self.settings_view}[view]()
 def is_busy(self):return self.busy or self.maintenance or (self.runner.process is not None and self.runner.process.returncode is None)
 def status(self,message):
  self.progress=message
  if self.status_label is not None:self.status_label.set_text(message)
 def import_image(self,source,name=None):
  if self.is_busy():self.notify('Wait for the current operation to finish.',type='warning');return
  try:
   prepared=normalize_image(source,paths=self.paths,source_name=name)
   self.cleanup();self.temporary.append(prepared);self.prepared=self.original=prepared
   self.image_path=prepared.path;self.source_name=prepared.source_name;self.result=None;self.history_id=None
   self.crop_rect=None;self.progress='Image ready. Select the environmental background if needed.';self.show('Analyze')
  except Exception as exc:self.notify(str(exc),type='negative')
 async def uploaded(self,event):
  try:self.import_image(await event.file.read(),event.file.name)
  except Exception as exc:self.notify('Could not read this image: '+str(exc),type='negative')
 async def paste(self):
  try:
   from PIL import ImageGrab,Image
   image=await asyncio.to_thread(ImageGrab.grabclipboard)
   if isinstance(image,Image.Image):
    import io
    stream=io.BytesIO();image.save(stream,format='PNG');self.import_image(stream.getvalue(),'Pasted screenshot.png')
   elif isinstance(image,list) and image:self.import_image(image[0])
   else:self.notify('Copy an image or screenshot, then choose Paste Screenshot.',type='info')
  except Exception as exc:self.notify('Clipboard image could not be read: '+str(exc),type='negative')
 def crop_mouse(self,event):
  if self.is_busy() or self.prepared is None:return
  if event.type=='mousedown':self.crop_start=(event.image_x,event.image_y)
  elif event.type in ('mousemove','mouseup') and self.crop_start and (event.buttons or event.type=='mouseup'):
   x1,y1=self.crop_start;x2,y2=event.image_x,event.image_y
   width,height=self.prepared.size
   x=max(0,min(x1,x2,width-1));y=max(0,min(y1,y2,height-1));w=min(width-x,abs(x2-x1));h=min(height-y,abs(y2-y1))
   if w>=8 and h>=8:
    self.crop_rect=(x/width,y/height,w/width,h/height)
    self.crop_widget.content=f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#8cddbf" fill-opacity=".15" stroke="#8cddbf" stroke-width="4"/>'
   if event.type=='mouseup':self.crop_start=None
 def apply_crop(self):
  if self.is_busy():return
  if not self.crop_rect:self.notify('Drag a rectangle over the background first.',type='info');return
  try:
   prepared=crop_image(self.image_path,*self.crop_rect,paths=self.paths,source_name=self.source_name)
   self.temporary.append(prepared);self.prepared=prepared;self.image_path=prepared.path;self.crop_rect=None
   self.progress='Background crop applied. Models will analyze this crop.';self.show('Analyze')
  except Exception as exc:self.notify(str(exc),type='negative')
 def reset_crop(self):
  if self.original and not self.is_busy():self.prepared=self.original;self.image_path=self.original.path;self.crop_rect=None;self.show('Analyze')
 def analyze_view(self):
  ui.label('Follow the clues.').classes('eyebrow')
  ui.label('Where could this scene be?').classes('hero mt-1')
  ui.label('Explore a public landmark, street, or landscape with local visual models.').classes('muted mb-4')
  if self.image_path:
   with ui.row().classes('w-full items-start gap-6 no-wrap'):
    with ui.column().classes('panel').style('width:65%'):
     if self.prepared:
      self.crop_widget=ui.interactive_image(str(self.image_path),on_mouse=self.crop_mouse,events=['mousedown','mousemove','mouseup']).classes('w-full rounded-lg').style('max-height:420px;object-fit:contain;user-select:none')
     else:ui.image(str(self.image_path)).classes('w-full rounded-lg').style('max-height:420px;object-fit:contain')
     ui.label(self.source_name).classes('muted text-sm')
     ui.label('Background selection: drag a rectangle over the environment, then apply.').classes('muted text-sm')
     with ui.row():
      ui.button('Apply background crop',icon='crop',on_click=self.apply_crop).props('flat dense').classes('secondary')
      ui.button('Reset crop',on_click=self.reset_crop).props('flat dense').classes('secondary')
    with ui.column().classes('panel gap-4').style('width:35%'):
     ui.label('A careful estimate').classes('text-lg font-medium')
     ui.label('Local scene analysis finds possible places. Reference-photo matching and geometry check the available evidence.').classes('muted')
     ui.label('A model guess is not an exact address. Weak scenes may produce uncertainty.').classes('muted text-sm')
     self.analyze_button=ui.button('Analyze scene',icon='travel_explore',on_click=self.run_analysis).classes('primary w-full').props('size=lg')
     if self.is_busy():self.analyze_button.disable();ui.spinner(size='24px',color='teal-3')
     self.status_label=ui.label(self.progress).classes('muted text-sm')
     if self.busy:ui.button('Cancel analysis',on_click=self.cancel_analysis).props('flat').classes('secondary')
  with ui.column().classes('dropzone w-full mt-4'):
   if not self.image_path:
    ui.icon('image_search',size='44px').style('color:#8cddbf')
    ui.label('Drop a public-location photo here').classes('text-xl mt-2')
    ui.label('JPEG, PNG or WebP · up to 30 MB · screenshots welcome').classes('muted text-sm')
   uploader=ui.upload(label='Choose Image',on_upload=self.uploaded,auto_upload=True,max_files=1,max_file_size=30*1024*1024,on_rejected=lambda:self.notify('Choose a JPEG, PNG or WebP under 30 MB.',type='warning')).props('accept=".jpg,.jpeg,.png,.webp"').classes('mt-3')
   if self.is_busy():uploader.disable()
   ui.button('Paste Screenshot',icon='content_paste',on_click=self.paste).props('flat').classes('secondary')
  ui.label('Photos stay on this Mac. Optional reference lookups send landmark names; map tiles reveal the viewed region. History is off by default.').classes('muted text-xs mt-4')
 async def run_analysis(self):
  if not self.image_path or self.is_busy():return
  self.busy=True;self.status('Starting local model worker…');self.show('Analyze')
  try:
   result=await self.runner.run(self.image_path,self.settings.load(),self.source_name,self.prepared.metadata if self.prepared else {},self.status)
   self.result=result;self.history_id=None
   entry=self.history.save(result,self.image_path,self.source_name)
   if entry:self.history_id=entry['id']
   self.status('Analysis complete.');self.busy=False;self.show('Results')
   logging.info('Analysis completed status=%s duration=%s',result.get('status'),result.get('duration_seconds'))
  except asyncio.CancelledError:self.status('Analysis cancelled.');raise
  except Exception as exc:
   logging.exception('Analysis failed');self.status('Analysis failed: '+str(exc));self.notify(str(exc),type='negative',timeout=10000)
  finally:
   self.busy=False
   if self.view=='Analyze':self.show('Analyze')
 async def cancel_analysis(self):
  await self.runner.cancel();self.status('Analysis cancelled.');self.busy=False
 def select_candidate(self,candidate):
  from .presentation import valid_coordinates
  if not valid_coordinates(candidate):return
  self.selected_candidate_id=candidate['id']
  self.selected_details.refresh()
  for identifier,marker in self.candidate_markers.items():
   selected=identifier==candidate['id']
   marker.run_method('setStyle',{'color':'#87e9c3' if selected else '#d8a355','fillColor':'#1e6f55' if selected else '#a7772e','weight':4 if selected else 2,'radius':11 if selected else 7,'fillOpacity':.95})
   if selected:marker.run_method('openPopup')
  if self.map:
   self.map.set_center((candidate['latitude'],candidate['longitude']));self.map.set_zoom(map_zoom(candidate))
   self.map.run_map_method('invalidateSize')
 def selected_candidate(self):
  candidates=[c for c in (self.result or {}).get('candidates',[]) if valid_coordinates(c)]
  return next((c for c in candidates if c.get('id')==self.selected_candidate_id),candidates[0] if candidates else None)
 def notify(self,message,**kwargs):
  with self.client:ui.notify(message,**kwargs)
 def copy_coordinates(self):
  candidate=self.selected_candidate()
  if candidate is None:return
  try:
   # Native pasteboard has no browser clipboard-permission dependency.
   from AppKit import NSPasteboard,NSPasteboardTypeString
   pasteboard=NSPasteboard.generalPasteboard();pasteboard.clearContents()
   if not pasteboard.setString_forType_(coordinate_text(candidate),NSPasteboardTypeString):raise RuntimeError('macOS did not accept the clipboard text.')
   self.notify('Coordinates copied.',type='positive')
  except Exception as exc:self.notify('Could not copy coordinates: '+str(exc),type='negative')
 def open_maps(self):
  candidate=self.selected_candidate()
  if candidate:subprocess.Popen(['/usr/bin/open',maps_url(candidate)])
 def toggle_map_fullscreen(self):
  self.map_expanded=not self.map_expanded
  self.map_panel.classes(add='map-expanded' if self.map_expanded else '',remove='map-expanded' if not self.map_expanded else '')
  self.fullscreen_button.set_text('Exit full-screen map' if self.map_expanded else 'Full-screen map')
  ui.timer(.15,lambda:self.map.run_map_method('invalidateSize') if self.map else None,once=True)
 @ui.refreshable
 def selected_details(self):
  candidate=self.selected_candidate()
  if candidate is None:
   ui.label('No supported location').classes('text-2xl font-medium')
   ui.label((self.result or {}).get('summary','The image does not establish a location.')).classes('muted');return
  kind=result_type(candidate)
  ui.label(RESULT_LABELS[kind]).classes('eyebrow')
  ui.label(candidate.get('label','Geographic candidate')).classes('location-name')
  if candidate.get('area'):ui.label(candidate['area']).classes('muted text-sm')
  with ui.column().classes('gps-display w-full gap-2'):
   ui.label('LOCATION RESULT').classes('gps-caption')
   with ui.row().classes('w-full no-wrap items-baseline'):
    ui.label('LATITUDE').classes('gps-axis');ui.label(f"{float(candidate['latitude']):.6f}").classes('gps-number').props('data-testid=latitude')
   with ui.row().classes('w-full no-wrap items-baseline'):
    ui.label('LONGITUDE').classes('gps-axis');ui.label(f"{float(candidate['longitude']):.6f}").classes('gps-number').props('data-testid=longitude')
   with ui.row().classes('mt-2 gap-2'):
    ui.button('Copy Coordinates',icon='content_copy',on_click=self.copy_coordinates).classes('primary').props('no-caps dense')
    ui.button('Open in Maps',icon='open_in_new',on_click=self.open_maps).classes('secondary').props('flat no-caps dense')
  ui.label(candidate_warning(candidate)).classes('precision-note')
  ui.label(candidate.get('precision','Geographic accuracy has not been measured for this image.')).classes('muted text-sm')
  for evidence in candidate.get('evidence',[])[:3]:ui.label('• '+str(evidence)).classes('text-sm')
  if candidate.get('uncertainty'):ui.label(candidate['uncertainty']).classes('muted text-xs')
  if candidate.get('reference_url'):ui.link('Geographic source ↗',candidate['reference_url'],new_tab=True).classes('source-link')
  reference_image=candidate.get('reference_path') or candidate.get('reference_image_path')
  if reference_image and Path(reference_image).is_file():
   with ui.expansion('Matching public reference photo',icon='compare'):
    ui.image(str(reference_image)).classes('w-full rounded-lg').style('max-height:200px;object-fit:contain')
    ui.label(candidate.get('reference_attribution') or candidate.get('license') or 'See Advanced Details for source attribution.').classes('muted text-xs')
 def results_view(self):
  if not self.result:
   ui.label('Your location result appears here.').classes('text-2xl font-medium');ui.label('Choose a public scene in Analyze to begin.').classes('muted');return
  result=self.result
  failures=[name for name,e in result.get('diagnostics',{}).get('engines',{}).items() if e.get('errors')]
  if failures:ui.label('Some analysis stages were unavailable: '+', '.join(failures)+'. See Advanced Details.').classes('precision-note w-full mb-3')
  candidates=[c for c in result.get('candidates',[]) if valid_coordinates(c)]
  if not any(c.get('id')==self.selected_candidate_id for c in candidates):self.selected_candidate_id=candidates[0]['id'] if candidates else None
  selected=self.selected_candidate();self.candidate_markers={};self.map_expanded=False
  with ui.row().classes('w-full items-center mb-2 gap-2'):
   ui.label('Location result').classes('text-xl font-medium');ui.space()
   ui.button('JSON',icon='data_object',on_click=lambda:self.export('json')).props('flat dense no-caps').classes('secondary')
   ui.button('Report',icon='description',on_click=lambda:self.export('md')).props('flat dense no-caps').classes('secondary')
  with ui.element('div').classes('result-grid'):
   with ui.column().classes('result-sidebar w-full gap-4'):
    if self.image_path:ui.image(str(self.image_path)).classes('result-photo w-full')
    self.selected_details()
    landmarks=result.get('recognized_landmarks',[])
    if landmarks:
     ui.label('Recognized public landmarks').classes('eyebrow')
     with ui.row().classes('gap-2'):
      for landmark in landmarks:ui.badge(landmark if isinstance(landmark,str) else landmark.get('name','Public landmark'),color='teal-9').props('outline')
    if len(candidates)>1:
     ui.label('Candidate locations').classes('eyebrow mt-2')
     for candidate in candidates:
      button=ui.button(candidate.get('label','Candidate'),on_click=lambda c=candidate:self.select_candidate(c)).props('flat no-caps align=left').classes('candidate-choice w-full')
      ui.label(coordinate_text(candidate)).classes('muted text-xs -mt-2')
    with ui.expansion('Advanced Details',icon='tune').classes('mt-3'):
     ui.label(result.get('summary','')).classes('text-sm')
     for name,engine in result.get('diagnostics',{}).get('engines',{}).items():
      ui.label(f"{name}: {'executed' if engine.get('executed') else 'skipped'} · {engine.get('seconds',0):.2f}s · {'selected evidence' if engine.get('affected_final_result') else engine.get('skip_reason') or engine.get('status','')}").classes('muted text-xs')
     for item in result.get('observations',[]):ui.label('• '+str(item)).classes('muted text-sm')
     for warning in result.get('warnings',[]):ui.label('• '+str(warning)).classes('muted text-xs')
     ui.code(json.dumps({k:result[k] for k in ['diagnostics','retrieval','geometry','visual','references','ocr'] if k in result},indent=2,ensure_ascii=False),language='json').classes('w-full').style('max-height:460px;overflow:auto;font-size:11px')
   with ui.column().classes('panel map-panel w-full') as self.map_panel:
    with ui.row().classes('w-full px-4 py-3 items-center map-toolbar'):
     ui.label('Selected location').classes('font-medium');ui.space()
     self.fullscreen_button=ui.button('Full-screen map',icon='fullscreen',on_click=self.toggle_map_fullscreen).props('flat dense no-caps').classes('secondary')
    center=(float(selected['latitude']),float(selected['longitude'])) if selected else (20.,0.)
    self.map=Leaflet(center=center,zoom=map_zoom(selected) if selected else 2,options={'zoomControl':True,'scrollWheelZoom':True}).classes('w-full result-map')
    self.map.on('candidate-selected',lambda e:self.select_candidate(next(c for c in candidates if c['id']==e.args['id'])))
    marker_bindings=[]
    for candidate in candidates:
     active=candidate['id']==self.selected_candidate_id
     marker=self.map.generic_layer(name='circleMarker',args=[[float(candidate['latitude']),float(candidate['longitude'])],{'radius':11 if active else 7,'color':'#87e9c3' if active else '#d8a355','fillColor':'#1e6f55' if active else '#a7772e','weight':4 if active else 2,'fillOpacity':.95}])
     self.candidate_markers[candidate['id']]=marker
     popup='<strong>'+html.escape(candidate.get('label','Location'))+'</strong><br>'+html.escape(coordinate_text(candidate))+'<br><small>'+html.escape(RESULT_LABELS[result_type(candidate)])+'</small>'
     marker_bindings.append((marker,popup,candidate['id']))
     radius=candidate.get('radius_km')
     if radius and radius>0:
      self.map.generic_layer(name='circle',args=[[float(candidate['latitude']),float(candidate['longitude'])],{'radius':float(radius)*1000,'color':'#6f9c90','weight':1,'dashArray':'6,6','fillOpacity':.05,'interactive':False}])
    leaflet=self.map
    def bind_markers():
     # NiceGUI discards layer method calls before its Leaflet init event.
     # Register popup/click behaviour after the initial layers have been sent.
     for marker,popup,identifier in marker_bindings:
      marker.run_method('bindPopup',popup)
      marker.run_method(':on',json.dumps('click'),f"(e)=>getElement({leaflet.id}).$emit('candidate-selected',{{id:{json.dumps(identifier)}}})")
    leaflet.on('init',bind_markers)
    ui.label('Estimated regions are not measured accuracy bounds. Landmark pins are not photographer positions.').classes('muted text-xs px-4 py-2')
    self.map.on('map-moveend',lambda e:logging.debug('Map moved center=%s',e.args.get('center')))
    ui.timer(.4,lambda:self.map.run_map_method('invalidateSize') if self.map else None,once=True)
 def export(self,format):
  if not self.result:return
  try:
   destination=self.paths.exports/f"SceneAtlas-{self.result.get('id','analysis')}.{format}"
   export_result(self.result,destination,format)
   subprocess.Popen(['/usr/bin/open','-R',str(destination)])
   self.notify('Export saved; shown in Finder.',type='positive')
  except Exception as exc:self.notify('Export failed: '+str(exc),type='negative')
 def open_history(self,identifier):
  entry=self.history.get(identifier)
  if not entry:self.notify('This analysis no longer exists.',type='warning');self.show('History');return
  self.result=entry['result'];self.image_path=Path(entry['image_path']);self.source_name=entry['source_name'];self.history_id=identifier
  self.prepared=None;self.show('Results')
 def delete_history(self,identifier):
  self.history.delete(identifier)
  if self.history_id==identifier:self.result=None;self.image_path=None;self.history_id=None
  self.show('History')
 def history_view(self):
  ui.label('Your local history').classes('text-2xl font-medium')
  enabled=self.settings.load()['history_enabled']
  ui.label('History is '+('enabled.' if enabled else 'off. Enable it in Settings to retain future analyses.')).classes('muted')
  records=self.history.list()
  if not records:ui.label('No saved investigations.').classes('muted mt-8');return
  for entry in records:
   with ui.row().classes('panel w-full no-wrap items-center'):
    ui.image(entry['thumbnail_path']).style('width:110px;height:80px;object-fit:cover;border-radius:8px')
    with ui.column().classes('gap-1 grow'):
     ui.label(entry['source_name']).classes('font-medium');ui.label(entry['summary']).classes('muted text-sm')
     ui.label(entry['created_at']).classes('muted text-xs')
    ui.button('Open',on_click=lambda i=entry['id']:self.open_history(i)).props('flat').classes('secondary')
    ui.button(icon='delete_outline',on_click=lambda i=entry['id']:self.delete_history(i)).props('flat color=grey').tooltip('Delete stored image and record')
 def change_setting(self,name,value):self.settings.update(**{name:value})
 async def maintenance_action(self,action):
  if self.is_busy():self.notify('Wait for analysis or maintenance to finish.',type='warning');return
  self.maintenance=True;self.status('Working…')
  try:
   result=await asyncio.to_thread(action)
   self.notify('Operation completed.' if not isinstance(result,dict) or result.get('ok',True) else 'Some model files failed verification.',type='positive' if not isinstance(result,dict) or result.get('ok',True) else 'warning')
  except Exception as exc:logging.exception('Maintenance failed');self.notify(str(exc),type='negative',timeout=10000)
  finally:self.maintenance=False;self.show(self.view)
 def confirm(self,title,message,action):
  with ui.dialog() as dialog,ui.card().classes('panel').style('max-width:480px'):
   ui.label(title).classes('text-xl');ui.label(message).classes('muted')
   with ui.row().classes('justify-end w-full'):
    ui.button('Cancel',on_click=dialog.close).props('flat')
    async def accepted():dialog.close();await self.maintenance_action(action)
    ui.button('Confirm',on_click=accepted).classes('primary')
  dialog.open()
 async def import_reference_archive(self,event):
  try:
   from .datasets import import_collection_archive
   content=await event.file.read()
   await self.maintenance_action(lambda:import_collection_archive(content,self.paths))
  except Exception as exc:self.notify('Reference import failed: '+str(exc),type='negative')
 def settings_view(self):
  values=self.settings.load();ui.label('Settings').classes('text-2xl font-medium')
  ui.label('Local models, explicit evidence, and control over your data.').classes('muted mb-3')
  with ui.row().classes('w-full items-start gap-5 no-wrap'):
   with ui.column().classes('panel').style('width:58%'):
    ui.label('Models on this Mac').classes('text-lg font-medium')
    for model in model_status(self.paths):
     with ui.column().classes('w-full gap-1 mb-3'):
      ui.label(model.get('name',model['id'])).classes('font-medium')
      ui.label(f"{model.get('status')} · {model.get('bytes',0)/1024**3:.2f} GiB · {model.get('verification','not verified')}").classes('muted text-sm')
      ui.label('Models are loaded only in the inference worker; disk readiness is separate from model loading.').classes('muted text-xs')
    with ui.row():
     ui.button('Verify model files',on_click=lambda:self.maintenance_action(lambda:verify_models(self.paths))).props('flat').classes('secondary')
     ui.button('Download / repair models',on_click=lambda:self.maintenance_action(lambda:download_models(self.paths))).props('flat').classes('secondary')
    ui.select({'auto':'Automatic · MPS with CPU fallback','mps':'PyTorch MPS','cpu':'PyTorch CPU'},value=values.get('device','auto'),label='GeoCLIP device',on_change=lambda e:self.change_setting('device',e.value)).classes('w-full')
    ui.label('Vision uses MLX / Apple Metal. Models run sequentially and are released after each analysis.').classes('muted text-sm')
    ui.label(f"Model storage: {directory_bytes(self.paths.models)/1024**3:.2f} GiB · inference cache: {directory_bytes(self.paths.cache)/1024**2:.0f} MiB").classes('muted text-sm')
    ui.button('Clear inference cache',on_click=lambda:self.maintenance_action(lambda:clear_inference_cache(self.paths))).props('flat').classes('secondary')
    ui.button('Clear downloaded model cache…',on_click=lambda:self.confirm('Remove downloaded models?','This removes only SceneAtlas model files. Download / repair models will be required before inference can work again.',lambda:clear_models(self.paths))).props('flat color=orange-3')
    with ui.expansion('Public reference collection',icon='collections'):
     from .references import reference_status
     from .retrieval import retrieval_status,build_index
     references=reference_status(self.paths);retrieval=retrieval_status(self.paths)
     ui.label(f"{references['count']} licensed public reference photos · retrieval index {retrieval['status']}").classes('muted text-sm')
     ui.label('Coverage is limited to the indexed places. Add an authorized collection to expand it.').classes('muted text-sm')
     ui.upload(label='Import Reference Collection ZIP',on_upload=self.import_reference_archive,auto_upload=True,max_files=1,max_file_size=256*1024*1024).props('accept=.zip').classes('w-full')
     ui.button('Build / refresh visual index',on_click=lambda:self.maintenance_action(lambda:build_index(self.paths))).props('flat no-caps').classes('secondary')
     ui.label('A collection ZIP contains manifest.json, images, coordinates, licenses and source attribution. Importing requires rebuilding its visual index.').classes('muted text-xs')
   with ui.column().classes('panel').style('width:42%'):
    ui.label('Privacy and evidence').classes('text-lg font-medium')
    ui.switch('Save future analyses in local history',value=values['history_enabled'],on_change=lambda e:self.change_setting('history_enabled',e.value))
    ui.switch('Use Qwen visual reasoning',value=values.get('use_vision',True),on_change=lambda e:self.change_setting('use_vision',e.value))
    ui.switch('Read supplementary text with OCR',value=values.get('ocr',True),on_change=lambda e:self.change_setting('ocr',e.value))
    ui.switch('Look up public landmarks online',value=values['online_references'],on_change=lambda e:self.change_setting('online_references',e.value))
    ui.label('Only suggested public landmark names are sent to the reference provider. Photos and faces are never uploaded. Map tiles request the visible map region.').classes('muted text-sm')
    ui.input('Photon endpoint',value=values['photon_endpoint'],on_change=lambda e:self.change_setting('photon_endpoint',e.value)).classes('w-full')
    ui.link('Photon provider policy ↗','https://github.com/komoot/photon#demo-server',new_tab=True)
    ui.label('Lookups are limited to three image-derived names, serialized at ≤1 request per second and cached for 30 days.').classes('muted text-xs')
    ui.input('Nominatim endpoint',value=values['nominatim_endpoint'],on_change=lambda e:self.change_setting('nominatim_endpoint',e.value)).classes('w-full')
    ui.link('OpenStreetMap provider policy ↗','https://operations.osmfoundation.org/policies/nominatim/',new_tab=True)
    ui.label('The latest diagnostic report is kept in local logs; images are retained only when history is enabled.').classes('muted text-sm')
    ui.button('Clear all history…',on_click=lambda:self.confirm('Delete saved investigations?','All images and records stored in SceneAtlas History will be deleted.',self.history.clear)).props('flat color=orange-3')
    ui.button('Open local logs',icon='folder_open',on_click=lambda:subprocess.Popen(['/usr/bin/open',str(self.paths.logs)])).props('flat').classes('secondary')
    with ui.expansion('Component versions',icon='code'):
     for name in ['geoclip','torch','transformers','mlx','mlx-vlm','nicegui','pywebview','opencv-python']:
      try:ui.label(name+' '+importlib.metadata.version(name)).classes('muted text-xs')
      except importlib.metadata.PackageNotFoundError:ui.label(name+' · metadata unavailable').classes('muted text-xs')
  if self.maintenance:ui.spinner();self.status_label=ui.label(self.progress)

def launch(paths):
 runner=AnalysisRunner(paths);workspaces=[]
 # Remove only abandoned temporary imports from earlier runs. Single-instance
 # locking in main.py prevents erasing another SceneAtlas session's files.
 for path in paths.imports.iterdir():
  if path.is_file() and time.time()-path.stat().st_mtime>86400:path.unlink(missing_ok=True)
 @ui.page('/')
 def index():
  workspace=Workspace(paths,runner);workspaces.append(workspace)
  logging.info('Native UI page built')
 async def shutdown():
  await runner.shutdown()
  for workspace in workspaces:workspace.cleanup()
  (paths.root/'runtime.json').unlink(missing_ok=True)
 app.on_shutdown(shutdown)
 app.native.window_args.update({'min_size':(980,700),'background_color':'#121619','resizable':True})
 app.native.settings['ALLOW_DOWNLOADS']=True
 app.native.start_args['debug']=False
 with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 (paths.root/'runtime.json').write_text(json.dumps({'pid':os.getpid(),'port':port,'host':'127.0.0.1','started':time.time()}))
 logging.info('Starting native UI on loopback port %s',port)
 ui.run(native=True,host='127.0.0.1',port=port,reload=False,title='SceneAtlas',window_size=(1280,880),dark=True,show=False,storage_secret=secrets.token_hex(32),show_welcome_message=False)
