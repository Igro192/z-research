"""SceneAtlas-owned model storage, resumable downloads, and real integrity checks."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import ssl
import threading
import time
from pathlib import Path
from typing import Callable
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from .support import AppPaths, _atomic_write, _locked_file, _read_json, app_paths, directory_bytes, result_json

MODEL_SPECS = {
    'clip': {
        'name': 'OpenAI CLIP ViT-L/14 — GeoCLIP visual encoder',
        'repo': 'openai/clip-vit-large-patch14',
        'revision': '32bd64288804d66eefd0ccbe215aa642df71cc41',
        'weight_bytes': 1710540580,
        'weight_sha256': 'a2bf730a0c7debf160f7a6b50b3aaf3703e7e88ac73de7a314903141db026dcb',
        'files': ['config.json', 'preprocessor_config.json', 'tokenizer_config.json',
                  'special_tokens_map.json', 'tokenizer.json', 'vocab.json', 'merges.txt',
                  'model.safetensors', 'README.md'],
    },
    'qwen': {
        'name': 'Qwen2.5-VL 3B Instruct — MLX 4-bit',
        'repo': 'mlx-community/Qwen2.5-VL-3B-Instruct-4bit',
        'revision': '46d4cf06a06ffc1a766c214174f9cbed2f45bcab',
        'weight_bytes': 3073720461,
        'weight_sha256': '636982419c940321ac0f7793dc9dc3575a4ee4843a6b167b2e8c3d3cd25dacf4',
        'files': ['config.json', 'preprocessor_config.json', 'tokenizer_config.json',
                  'special_tokens_map.json', 'tokenizer.json', 'vocab.json', 'merges.txt',
                  'added_tokens.json', 'chat_template.json', 'model.safetensors',
                  'model.safetensors.index.json', 'README.md'],
    },
    'anyloc': {
        'name': 'AnyLoc / DINOv2 ViT-S/14 visual retrieval',
        'repo': 'facebookresearch/dinov2',
        'revision': '7764ea0f912e53c92e82eb78a2a1631e92725fc8',
        'directory': 'AnyLoc', 'weight_filename': 'dinov2_vits14_pretrain.pth',
        'weight_bytes': 88283115,
        'weight_sha256': 'b938bf1bc15cd2ec0feacfe3a1bb553fe8ea9ca46a7e1d8d00217f29aef60cd9',
        'files': ['dinov2_vits14_pretrain.pth'],
        'urls': {'dinov2_vits14_pretrain.pth': 'https://dl.fbaipublicfiles.com/dinov2/dinov2_vits14/dinov2_vits14_pretrain.pth'},
        'optional_until_installed': True,
    },
}
_DOWNLOAD_LOCK = threading.Lock()


def _file_signature(path: Path) -> dict:
    stat = path.stat()
    return {'bytes': stat.st_size, 'mtime_ns': stat.st_mtime_ns}


def _required_files(spec: dict) -> list[str]:
    return [name for name in spec['files'] if name != 'README.md']


def _model_directory(paths: AppPaths, key: str, spec: dict) -> Path:
    return paths.models / spec.get('directory', key)


def _weight_path(paths: AppPaths, key: str, spec: dict) -> Path:
    return _model_directory(paths, key, spec) / spec.get('weight_filename', 'model.safetensors')


def _verified_weight(paths: AppPaths, key: str, spec: dict, receipt: dict) -> bool:
    weight = _weight_path(paths, key, spec)
    try:
        saved = receipt.get('models', {}).get(key, {})
        return (saved.get('ok') is True and saved.get('sha256') == spec['weight_sha256']
                and saved.get('signature') == _file_signature(weight))
    except (OSError, AttributeError):
        return False


def model_status(paths: AppPaths | None = None) -> list[dict]:
    """Inspect required files and sizes without importing/loading an ML framework.

    ``ready`` means the required local files have plausible sizes. ``verification``
    separately reports whether their current weight file has a successful pinned
    SHA256 receipt. Runtime model residency cannot be inferred from disk state;
    ``loaded`` is therefore None, never a fabricated green loaded indicator.
    """
    paths = paths or app_paths()
    receipt = _read_json(paths.models / 'verification.json', {})
    if not isinstance(receipt, dict):
        receipt = {}
    statuses = []
    for key, spec in MODEL_SPECS.items():
        folder = _model_directory(paths, key, spec)
        missing = [name for name in _required_files(spec)
                   if not (folder / name).is_file() or (folder / name).stat().st_size == 0]
        weight = _weight_path(paths, key, spec)
        actual = weight.stat().st_size if weight.is_file() else 0
        size_ok = actual == spec['weight_bytes']
        verified = _verified_weight(paths, key, spec, receipt)
        partial = weight.with_name(weight.name + '.partial')
        statuses.append({
            'id': key, 'name': spec['name'], 'repo': spec['repo'], 'revision': spec['revision'],
            'ready': not missing and size_ok, 'loaded': None,
            'status': 'available' if not missing and size_ok else ('partial' if partial.exists() else 'missing_or_incomplete'),
            'verification': 'sha256_verified' if verified else 'not_verified',
            'bytes': directory_bytes(folder) if folder.is_dir() else 0,
            'weight_bytes': actual, 'weight_bytes_expected': spec['weight_bytes'],
            'partial_bytes': partial.stat().st_size if partial.is_file() else 0,
            'missing_files': missing, 'path': str(folder),
        })
    tessdata = paths.models / 'tessdata'
    languages = [lang for lang in ('eng', 'rus') if (tessdata / f'{lang}.traineddata').is_file()]
    statuses.append({'id': 'ocr', 'name': 'Tesseract OCR language data', 'ready': 'eng' in languages,
                     'loaded': None, 'status': 'available' if 'eng' in languages else 'optional_unavailable',
                     'verification': 'not_applicable', 'languages': languages,
                     'bytes': directory_bytes(tessdata) if tessdata.is_dir() else 0,
                     'missing_files': [] if 'eng' in languages else ['eng.traineddata'], 'path': str(tessdata)})
    return statuses


def verify_models(paths: AppPaths | None = None, progress: Callable[[str], None] | None = None) -> dict:
    """Read installed weights and compare their exact pinned SHA256.

    This may read roughly 4.8 GB and belongs in a background worker. Required JSON
    is parsed; missing/empty assets fail. A receipt is written only after actual
    hashing, and includes size/mtime so fast status checks detect later changes.
    """
    paths = paths or app_paths()
    emit = progress or (lambda text: None)
    report = {'ok': True, 'checked_at': time.time(), 'models': {}}
    for key, spec in MODEL_SPECS.items():
        if spec.get('optional_until_installed') and not _weight_path(paths, key, spec).is_file():
            continue
        emit(f'Checking {key} model files and SHA256…')
        folder = _model_directory(paths, key, spec)
        errors = []
        for name in _required_files(spec):
            file = folder / name
            if not file.is_file() or file.stat().st_size == 0:
                errors.append(f'Missing or empty: {name}')
            elif name.endswith('.json'):
                try:
                    json.loads(file.read_text(encoding='utf-8'))
                except (ValueError, OSError) as exc:
                    errors.append(f'Invalid {name}: {exc}')
        weight = _weight_path(paths, key, spec)
        digest = signature = None
        if weight.is_file():
            signature = _file_signature(weight)
            if signature['bytes'] != spec['weight_bytes']:
                errors.append(f'Weight size {signature["bytes"]} differs from expected {spec["weight_bytes"]}')
            else:
                with weight.open('rb') as stream:
                    digest = hashlib.file_digest(stream, 'sha256').hexdigest()
                if digest != spec['weight_sha256']:
                    errors.append('Weight SHA256 differs from the pinned upstream file')
        checked = {'ok': not errors, 'repo': spec['repo'], 'revision': spec['revision'],
                   'sha256': digest, 'expected_sha256': spec['weight_sha256'],
                   'signature': signature, 'errors': errors}
        report['models'][key] = checked
        report['ok'] = report['ok'] and checked['ok']
    _atomic_write(paths.models / 'verification.json', result_json(report).encode())
    return report


def _download_file(url: str, destination: Path, emit: Callable[[str], None],
                   expected_bytes: int | None = None, expected_sha256: str | None = None) -> None:
    """Resume owned .partial files; verified replacement retains a corrupt original."""
    import certifi
    destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    context = ssl.create_default_context(cafile=certifi.where())
    partial = destination.with_name(destination.name + '.partial')

    def publish() -> None:
        if destination.exists():
            backup = destination.parent / '.previous' / f'{destination.name}.{time.time_ns()}'
            backup.parent.mkdir(mode=0o700, exist_ok=True)
            os.replace(destination, backup)
        os.replace(partial, destination)

    # A previous transfer may have finished before the process was interrupted.
    # Validate locally instead of issuing an unsatisfiable Range request (416).
    if partial.is_file() and expected_bytes and partial.stat().st_size >= expected_bytes:
        complete = partial.stat().st_size == expected_bytes
        if complete and expected_sha256:
            emit(f'Checking completed partial {destination.parent.name} SHA256…')
            with partial.open('rb') as stream:
                complete = hashlib.file_digest(stream, 'sha256').hexdigest() == expected_sha256
        if complete:
            publish()
            return
        # Retain corrupt/oversized downloaded bytes, then begin a clean transfer.
        retained = partial.with_name(partial.name + f'.invalid-{time.time_ns()}')
        os.replace(partial, retained)
    last_error = None
    for attempt in range(4):
        start = partial.stat().st_size if partial.exists() else 0
        headers = {'User-Agent': 'SceneAtlas/1.0 local-model-installer', 'Accept-Encoding': 'identity'}
        if start:
            headers['Range'] = f'bytes={start}-'
        try:
            request = Request(url, headers=headers)
            with urlopen(request, timeout=60, context=context) as response:
                status = response.status
                content_range = response.headers.get('Content-Range', '')
                if start and status == 206 and not content_range.startswith(f'bytes {start}-'):
                    raise RuntimeError('The download server returned an inconsistent resume offset')
                # A server may ignore Range; truncating only our partial file is safe.
                mode = 'ab' if start and status == 206 else 'wb'
                total = start if mode == 'ab' else 0
                last_update = 0.0
                with partial.open(mode) as output:
                    while chunk := response.read(4 * 1024 * 1024):
                        output.write(chunk)
                        total += len(chunk)
                        if expected_bytes and total > expected_bytes:
                            raise RuntimeError('Downloaded weight exceeds its pinned size')
                        if time.monotonic() - last_update > 1:
                            emit(f'Downloading {destination.parent.name}/{destination.name}: {total / 1e6:.0f} MB'
                                 + (f' / {expected_bytes / 1e6:.0f} MB' if expected_bytes else ''))
                            last_update = time.monotonic()
                    output.flush()
                    os.fsync(output.fileno())
            if expected_bytes is not None and partial.stat().st_size != expected_bytes:
                raise RuntimeError('The download ended before the expected file size')
            if partial.stat().st_size == 0:
                raise RuntimeError('The downloaded file is empty')
            if expected_sha256:
                emit(f'Verifying downloaded {destination.parent.name} SHA256…')
                with partial.open('rb') as source:
                    digest = hashlib.file_digest(source, 'sha256').hexdigest()
                if digest != expected_sha256:
                    raise RuntimeError('Downloaded weight SHA256 does not match the pinned upstream file')
            elif destination.suffix == '.json':
                json.loads(partial.read_text(encoding='utf-8'))
            publish()
            return
        except HTTPError as exc:
            last_error = exc
            # Unknown-length assets retain partial bytes for diagnosis on 416.
            if exc.code in {401, 403, 404, 416}:
                break
        except Exception as exc:
            last_error = exc
        if attempt < 3:
            emit(f'Download interrupted; retrying {destination.name} ({attempt + 1}/3)…')
            time.sleep(2 ** attempt)
    raise RuntimeError(f'Could not download {destination.name}; partial data retained for resume: {last_error}')


def download_models(paths: AppPaths | None = None,
                    progress: Callable[[str], None] | None = None) -> dict:
    """Download pinned model assets using HTTPS, resume, then verify both weights.

    Existing valid files are reused. Corrupt replaced files are retained in the
    model directory's ``.previous`` folder. This function never invokes Homebrew,
    Python, curl, or an external model manager, so it also runs inside the .app.
    OCR language files remain optional and are managed separately by installation.
    """
    paths = paths or app_paths()
    emit = progress or (lambda text: None)
    with _DOWNLOAD_LOCK, _locked_file(paths.models / '.download.lock'):
        receipt = _read_json(paths.models / 'verification.json', {})
        if not isinstance(receipt, dict):
            receipt = {}
        for key, spec in MODEL_SPECS.items():
            folder = _model_directory(paths, key, spec)
            weight_filename = spec.get('weight_filename', 'model.safetensors')
            if folder.is_symlink():
                raise RuntimeError(f'Refusing to download into a symbolic-link model directory: {key}')
            for name in spec['files']:
                destination = folder / name
                existing_ok = destination.is_file() and destination.stat().st_size > 0
                if name == weight_filename and existing_ok:
                    existing_ok = destination.stat().st_size == spec['weight_bytes']
                    if existing_ok and not _verified_weight(paths, key, spec, receipt):
                        emit(f'Checking existing {key} weight SHA256…')
                        with destination.open('rb') as stream:
                            existing_ok = hashlib.file_digest(stream, 'sha256').hexdigest() == spec['weight_sha256']
                elif name.endswith('.json') and existing_ok:
                    try:
                        json.loads(destination.read_text(encoding='utf-8'))
                    except (ValueError, OSError):
                        existing_ok = False
                if existing_ok:
                    continue
                emit(f'Preparing {key}/{name}…')
                url = spec.get('urls', {}).get(name) or f'https://huggingface.co/{spec["repo"]}/resolve/{spec["revision"]}/{name}'
                _download_file(url, destination, emit,
                               spec['weight_bytes'] if name == weight_filename else None,
                               spec['weight_sha256'] if name == weight_filename else None)
        report = verify_models(paths, emit)
        if not report['ok']:
            raise RuntimeError('Downloaded model verification failed: ' + result_json(report['models']))
        manifest = {key: {'repo': spec['repo'], 'revision': spec['revision'],
                          'weight_sha256': spec['weight_sha256']}
                    for key, spec in MODEL_SPECS.items()}
        _atomic_write(paths.models / 'manifest.json', result_json(manifest).encode())
        if 'anyloc' in MODEL_SPECS:
            from .references import load_references
            from .retrieval import build_index, retrieval_status
            if load_references(paths) and not retrieval_status(paths)['ready']:
                emit('Building the local AnyLoc reference descriptor index…')
                report['retrieval_index'] = build_index(paths, emit)
        emit('Pinned model weights verified and ready for local inference.')
        return report


def clear_inference_cache(paths: AppPaths | None = None) -> dict:
    """Clear SceneAtlas's cache only; models, settings, and history are untouched."""
    paths = paths or app_paths()
    removed = 0
    total = directory_bytes(paths.cache)
    for entry in paths.cache.iterdir():
        if entry.is_symlink() or entry.is_file():
            entry.unlink()
        elif entry.is_dir():
            shutil.rmtree(entry)
        removed += 1
    return {'files': removed, 'bytes': total}


def clear_models(paths: AppPaths | None = None) -> dict:
    """Remove only known SceneAtlas models after the UI obtains confirmation.

    The caller must stop inference/download activity first. Model redownload is
    available through ``download_models``; this function never touches any other
    application's cache or model directory, nor unknown files in Models.
    """
    paths = paths or app_paths()
    removed = []
    total = 0
    with _DOWNLOAD_LOCK, _locked_file(paths.models / '.download.lock'):
        for name in ('clip', 'qwen', 'tessdata', 'AnyLoc'):
            entry = paths.models / name
            if entry.is_symlink():
                entry.unlink()
                removed.append(name)
            elif entry.is_dir():
                total += directory_bytes(entry)
                shutil.rmtree(entry)
                removed.append(name)
        for name in ('manifest.json', 'verification.json'):
            entry = paths.models / name
            if entry.is_file() or entry.is_symlink():
                total += entry.lstat().st_size
                entry.unlink()
                removed.append(name)
    return {'removed': removed, 'bytes': total}
