"""Reference provenance tests; these are not model retrieval accuracy tests."""
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from PIL import Image

from sceneatlas.references import load_references, collection_fingerprint
from sceneatlas.retrieval import retrieve, descriptor_config
from sceneatlas.support import app_paths


class ReferenceProvenanceTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.paths = app_paths(self.temporary.name)
        self.root = self.paths.root / 'References'
        (self.root / 'images').mkdir(parents=True)
        image = self.root / 'images/test.jpg'
        Image.new('RGB', (32, 32), 'red').save(image)
        self.row = {
            'reference_id': 'unit-reference', 'place_name': 'Unit public scene',
            'image': 'images/test.jpg', 'image_sha256': hashlib.sha256(image.read_bytes()).hexdigest(),
            'license': 'CC0', 'source_url': 'https://example.test/unit-public-source',
            'coordinate_kind': 'reference_camera',
            'camera_coordinates': {'latitude': 10, 'longitude': 20},
            'landmark_coordinates': {'latitude': 11, 'longitude': 21},
        }

    def tearDown(self):
        self.temporary.cleanup()

    def write(self, rows):
        (self.root / 'manifest.json').write_text(json.dumps({'references': rows}))

    def test_camera_and_landmark_coordinates_remain_distinct(self):
        self.write([self.row])
        reference = load_references(self.paths)[0]
        self.assertEqual(reference['latitude'], 10)
        self.assertEqual(reference['landmark_coordinates']['latitude'], 11)
        self.assertEqual(reference['reference_path'], reference['reference_image_path'])
        self.assertTrue(Path(reference['reference_path']).is_file())

    def test_landmark_only_reference_does_not_acquire_fabricated_camera_gps(self):
        row = {**self.row, 'coordinate_kind': 'landmark', 'camera_coordinates': None}
        self.write([row])
        reference = load_references(self.paths)[0]
        self.assertEqual(reference['latitude'], 11)
        self.assertIsNone(reference['camera_coordinates'])

    def test_unsafe_paths_unlicensed_and_invalid_coordinates_are_ignored(self):
        unsafe = {**self.row, 'image': '../../outside.jpg'}
        unlicensed = {**self.row, 'license': ''}
        invalid = {**self.row, 'camera_coordinates': {'latitude': 200, 'longitude': 20}}
        self.write([unsafe, unlicensed, invalid])
        self.assertEqual(load_references(self.paths), [])

    def test_missing_index_returns_unavailable_without_importing_models(self):
        self.write([self.row])
        result = retrieve(self.root / self.row['image'], self.paths)
        self.assertEqual(result['status'], 'unavailable')
        self.assertEqual(result['matches'], [])
        self.assertNotIn('confidence', result)

    def test_collection_identity_changes_with_image_content_identity(self):
        self.assertNotEqual(collection_fingerprint([self.row]),
                            collection_fingerprint([{**self.row, 'image_sha256': 'changed'}]))
        self.assertEqual(descriptor_config()['clusters'] * descriptor_config()['dimension'], 12288)

    def test_registered_manifest_uses_only_listed_reference_images(self):
        self.write([])
        root = self.paths.models / 'geometry/registered/unit-model'
        (root / 'images').mkdir(parents=True)
        Image.new('RGB', (50, 50)).save(root / 'images/ref.jpg')
        Image.new('RGB', (50, 50)).save(root / 'images/query.jpg')
        manifest = {'format': 'sceneatlas-hloc-reference-v1', 'model_id': 'unit-model',
                    'source_url': 'https://example.test/unit-model',
                    'images': [{'reference_id': 'unit-model:ref.jpg', 'image_name': 'ref.jpg',
                                'image_path': 'images/ref.jpg', 'sha256': 'test-hash'}],
                    'geographic_alignment': {'controls': [
                        {'image_name': 'ref.jpg', 'latitude_longitude_altitude': [1, 2, 3],
                         'role': 'fit', 'license': 'BSD-2-Clause'}]}}
        (root / 'manifest.json').write_text(json.dumps(manifest))
        records = load_references(self.paths)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]['image_name_in_model'], 'ref.jpg')
        self.assertEqual(records[0]['reconstruction_id'], 'unit-model')
        self.assertFalse(any('query.jpg' in row['reference_path'] for row in records))


if __name__ == '__main__':
    unittest.main()
