"""Safety/persistence tests; provider mocks do not assert live-service availability."""
from __future__ import annotations

import io
import json
import math
import struct
import tempfile
import unittest
import zlib
from pathlib import Path
from unittest.mock import patch

from PIL import Image

from sceneatlas.support import (
    HistoryStore, ImageValidationError, LandmarkVerifier, ReferenceLookupError,
    SettingsStore, app_paths, cleanup_prepared, crop_image, directory_bytes,
    export_result, normalize_image, result_json, result_markdown,
)


def image_bytes(size=(200, 100), mode='RGB', color='red', format='PNG', **kwargs):
    stream = io.BytesIO()
    Image.new(mode, size, color).save(stream, format=format, **kwargs)
    return stream.getvalue()


def oversized_png():
    """A valid PNG header can be rejected before allocating its 50 MP pixels."""
    def chunk(kind, payload):
        return struct.pack('>I', len(payload)) + kind + payload + struct.pack(
            '>I', zlib.crc32(kind + payload) & 0xffffffff
        )
    return (b'\x89PNG\r\n\x1a\n'
            + chunk(b'IHDR', struct.pack('>IIBBBBB', 10000, 5001, 8, 2, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(b'')) + chunk(b'IEND', b''))


PUBLIC_RESULT = {
    'name': 'Test Public Museum', 'display_name': 'Test Public Museum, Example City',
    'lat': '48.1', 'lon': '2.2', 'category': 'tourism', 'type': 'museum',
    'osm_type': 'way', 'osm_id': 123456,
}


class SupportTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.paths = app_paths(Path(self.temporary.name) / 'SceneAtlas')

    def tearDown(self):
        self.temporary.cleanup()

    def test_settings_default_private_history_and_atomic_update(self):
        settings = SettingsStore(self.paths)
        self.assertFalse(settings.load()['history_enabled'])
        self.assertTrue(settings.load()['online_references'])
        self.assertTrue(settings.load()['use_vision'])
        settings.update(history_enabled=True, online_references=False)
        self.assertTrue(SettingsStore(self.paths).load()['history_enabled'])
        self.assertFalse(SettingsStore(self.paths).load()['online_references'])
        self.assertEqual(list(self.paths.root.glob('.settings.json.*')), [])
        with self.assertRaises(ValueError):
            settings.update(history_enabled='yes')
        with self.assertRaises(ValueError):
            settings.update(nominatim_endpoint='http://insecure.example')

    def test_corrupt_preferences_recover_to_defaults(self):
        self.paths.settings.write_text('{incomplete', encoding='utf-8')
        self.assertFalse(SettingsStore(self.paths).load()['history_enabled'])

    def test_orientation_rgb_limits_and_exif_stripping(self):
        exif = Image.Exif()
        exif[274] = 6
        exif[271] = 'Test camera'
        prepared = normalize_image(image_bytes((200, 100), format='JPEG', exif=exif), paths=self.paths)
        self.assertEqual(prepared.original_size, (200, 100))
        self.assertEqual(prepared.size, (100, 200))
        self.assertEqual(prepared.metadata['exif']['Make'], 'Test camera')
        with Image.open(prepared.path) as image:
            self.assertEqual(image.mode, 'RGB')
            self.assertEqual(dict(image.getexif()), {})
        with Image.open(prepared.thumbnail_path) as thumb:
            self.assertLessEqual(thumb.width, 360)
            self.assertLessEqual(thumb.height, 240)
        larger = normalize_image(image_bytes((2400, 1200)), paths=self.paths)
        self.assertEqual(larger.size, (1600, 800))

    def test_transparent_screenshot_has_white_background(self):
        prepared = normalize_image(image_bytes(mode='RGBA', color=(0, 0, 0, 0)), paths=self.paths)
        with Image.open(prepared.path) as image:
            self.assertGreater(min(image.getpixel((50, 50))), 245)

    def test_corrupt_unsupported_oversize_inputs_rejected(self):
        for value in (b'', b'not an image', image_bytes(format='GIF'), oversized_png()):
            with self.subTest(value=value[:20]):
                with self.assertRaises(ImageValidationError):
                    normalize_image(value, paths=self.paths)
        large = Path(self.temporary.name) / 'oversized.jpg'
        with large.open('wb') as stream:
            stream.truncate(30 * 1024 * 1024 + 1)
        with self.assertRaisesRegex(ImageValidationError, '30 MB'):
            normalize_image(large, paths=self.paths)
        self.assertEqual(list(self.paths.imports.iterdir()), [])

    def test_fractional_crop_clamps_edges_and_rejects_invalid(self):
        image = Image.new('RGB', (200, 100), 'red')
        image.paste('blue', (100, 0, 200, 100))
        stream = io.BytesIO()
        image.save(stream, format='PNG')
        cropped = crop_image(stream.getvalue(), .5, 0, .8, 1, paths=self.paths)
        self.assertEqual(cropped.size, (100, 100))
        self.assertEqual(cropped.metadata['crop_fraction']['w'], .5)
        with Image.open(cropped.path) as result:
            self.assertGreater(result.getpixel((50, 50))[2], 240)
        for crop in ((-1, 0, 1, 1), (1, 0, 1, 1), (0, 0, 0, 1), (0, 0, math.nan, 1)):
            with self.subTest(crop=crop):
                with self.assertRaises(ImageValidationError):
                    crop_image(stream.getvalue(), *crop, paths=self.paths)

    def test_cleanup_only_deletes_application_imports(self):
        imported = normalize_image(image_bytes(), paths=self.paths)
        cleanup_prepared(imported, self.paths)
        self.assertFalse(imported.path.exists())
        self.assertFalse(imported.thumbnail_path.exists())
        external = normalize_image(image_bytes(), Path(self.temporary.name) / 'external.jpg')
        cleanup_prepared(external, self.paths)
        self.assertTrue(external.path.exists())

    def test_history_opt_in_saved_image_is_independent_delete_removes_all(self):
        prepared = normalize_image(image_bytes(), paths=self.paths)
        history = HistoryStore(self.paths)
        result = {'summary': 'Broad estimate', 'candidates': [], 'warnings': ['Uncertain']}
        self.assertIsNone(history.save(result, prepared.path))
        self.assertEqual(history.list(), [])
        SettingsStore(self.paths).update(history_enabled=True)
        entry = history.save(result, prepared.path, source_name='travel.png')
        cleanup_prepared(prepared, self.paths)
        self.assertTrue(Path(entry['image_path']).is_file())
        self.assertTrue(Path(entry['thumbnail_path']).is_file())
        self.assertEqual(history.get(entry['id'])['result'], result)
        self.assertEqual(history.list()[0]['source_name'], 'travel.png')
        self.assertTrue(history.delete(entry['id']))
        self.assertFalse(Path(entry['image_path']).parent.exists())
        self.assertFalse(history.delete(entry['id']))
        self.assertEqual(history.list(), [])
        with self.assertRaises(ValueError):
            history.delete('../Models')
        self.assertTrue(self.paths.models.is_dir())

    def test_history_clear_preserves_unrelated_model_and_history_files(self):
        prepared = normalize_image(image_bytes(), paths=self.paths)
        SettingsStore(self.paths).update(history_enabled=True)
        history = HistoryStore(self.paths)
        history.save({'summary': 'One'}, prepared.path)
        history.save({'summary': 'Two'}, prepared.path)
        unrelated = self.paths.history / 'keep.txt'
        unrelated.write_text('unrelated')
        model = self.paths.models / 'weight.bin'
        model.write_bytes(b'weights')
        self.assertEqual(history.clear(), 2)
        self.assertEqual(history.list(), [])
        self.assertTrue(unrelated.is_file())
        self.assertEqual(model.read_bytes(), b'weights')

    def test_exports_preserve_sources_scores_and_uncertainty(self):
        result = {
            'summary': 'Approximate scene estimate',
            'candidates': [{'label': 'Example', 'source': 'GeoCLIP', 'score': 0.3,
                            'precision': 'broad_region'}],
            'observations': ['Mixed architecture'], 'warnings': ['No image comparison'],
            'diagnostics': {'version': 'test', 'literal': '```example```'},
        }
        json_path = export_result(result, self.paths.exports / 'report.json')
        markdown_path = export_result(result, self.paths.exports / 'report.md')
        self.assertEqual(json.loads(json_path.read_text()), result)
        markdown = markdown_path.read_text()
        self.assertIn('not calibrated confidence percentages', markdown)
        self.assertIn('No image comparison', markdown)
        self.assertIn('Mixed architecture', markdown)
        self.assertIn('````json', markdown)
        self.assertIn('GeoCLIP', result_markdown(result))
        with self.assertRaises(ValueError):
            result_json({'score': float('nan')})
        with self.assertRaises(ValueError):
            export_result(result, self.paths.exports / 'report.html')

    def test_public_lookup_filters_houses_and_never_claims_image_match(self):
        verifier = LandmarkVerifier(self.paths)
        house = {**PUBLIC_RESULT, 'category': 'building', 'type': 'house'}
        residential_museum = {**PUBLIC_RESULT, 'extratags': {'building': 'house'}}
        invalid = {**PUBLIC_RESULT, 'lat': 'nan'}
        tower_tag = {**PUBLIC_RESULT, 'category': 'man_made', 'type': 'tower',
                     'extratags': {'tourism': 'attraction'}}
        with patch.object(verifier, '_fetch_json', return_value=[house, residential_museum, invalid, PUBLIC_RESULT, tower_tag]) as fetch:
            results = verifier.search('Test Public Museum')
            self.assertEqual(len(results), 2)
            self.assertEqual(results[0]['verification'], 'public_place_exists')
            self.assertFalse(results[0]['image_match'])
            self.assertIn('openstreetmap.org/way/', results[0]['source_url'])
            self.assertIn('No reference-image comparison', results[0]['explanation'])
            self.assertIn('OpenStreetMap contributors', results[0]['attribution'])
            self.assertEqual(verifier.last_status, 'online')
            self.assertEqual(verifier.search('  test PUBLIC museum  '), results)
            self.assertEqual(verifier.last_status, 'cache')
            self.assertEqual(fetch.call_count, 1)

    def test_disabled_or_private_reference_query_never_requests_network(self):
        verifier = LandmarkVerifier(self.paths)
        with patch.object(verifier, '_fetch_json') as fetch:
            for query in ('Home of Jane Smith', '123 Example Road', 'private residence', 'a'):
                self.assertEqual(verifier.search(query), [])
            SettingsStore(self.paths).update(online_references=False)
            self.assertEqual(verifier.search('Test Public Museum'), [])
            self.assertEqual(verifier.last_status, 'disabled')
            fetch.assert_not_called()

    def test_reference_throttle_and_failures_are_not_success_results(self):
        verifier = LandmarkVerifier(self.paths)
        with patch('sceneatlas.support.time.time', return_value=1000), patch(
            'sceneatlas.support.time.sleep'
        ) as sleep, patch.object(verifier, '_fetch_json', return_value=[PUBLIC_RESULT]):
            verifier.search('First Public Museum')
            verifier.search('Second Public Museum')
            sleep.assert_called_once()
            self.assertGreaterEqual(sleep.call_args.args[0], 1.0)
        with patch.object(verifier, '_fetch_json', side_effect=ReferenceLookupError('offline')):
            with self.assertRaises(ReferenceLookupError):
                verifier.search('Uncached Public Museum')

    def test_disk_usage_ignores_outside_file_symlinks(self):
        (self.paths.models / 'weights').write_bytes(b'1234')
        target = Path(self.temporary.name) / 'outside'
        target.write_bytes(b'123456789')
        (self.paths.models / 'alias').symlink_to(target)
        self.assertEqual(directory_bytes(self.paths.models), 4)


if __name__ == '__main__':
    unittest.main()
