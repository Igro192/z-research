import unittest
from urllib.parse import parse_qs,urlparse
from sceneatlas.presentation import coordinate_text,maps_url,result_type,candidate_warning,map_zoom,valid_coordinates
class CoordinateSemantics(unittest.TestCase):
 def test_actual_coordinates_are_not_truncated_to_one_decimal(self):
  c={'latitude':51.5007291,'longitude':-.1246254,'label':'Public location'}
  self.assertEqual(coordinate_text(c),'51.500729, -0.124625')
  self.assertEqual(parse_qs(urlparse(maps_url(c)).query)['ll'],['51.500729, -0.124625'])
 def test_a_landmark_is_not_a_verified_camera(self):
  c={'result_type':'recognized_landmark_location'}
  self.assertIn('photographer',candidate_warning(c));self.assertEqual(map_zoom(c),15)
 def test_invalid_model_points_never_reach_the_map(self):
  for latitude,longitude in [(float('nan'),0),(0,float('inf')),(91,0),(0,181)]:
   self.assertFalse(valid_coordinates({'latitude':latitude,'longitude':longitude}))
 def test_legacy_geographic_candidates_are_estimates(self):
  self.assertEqual(result_type({'source':'GeoCLIP'}),'broad_geographic_prediction')
  self.assertIn('not a verified',candidate_warning({'source':'GeoCLIP'}))
if __name__=='__main__':unittest.main()
