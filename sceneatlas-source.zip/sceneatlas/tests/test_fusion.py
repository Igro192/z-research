import unittest
from sceneatlas.fusion import combine_candidates
class EvidenceSemantics(unittest.TestCase):
 def test_a_pose_without_geographic_alignment_is_not_gps(self):
  geometry={'status':'pose_verified','latitude':51.,'longitude':0.,'geographic_alignment':{'validated':False}}
  self.assertEqual(combine_candidates([],{},[],{},geometry),[])
 def test_landmark_recognition_does_not_become_camera_location(self):
  references=[{'name':'Fixture Public Monument','latitude':51.,'longitude':.12}]
  result=combine_candidates([],{},references,{},{});self.assertEqual(result[0]['result_type'],'public_place_hypothesis')
  self.assertEqual(result[0]['coordinate_kind'],'landmark')
 def test_retrieval_similarity_alone_cannot_override_global_estimate(self):
  coarse=[{'id':'geo-1','latitude':40.,'longitude':-73.,'label':'Estimate','source':'GeoCLIP'}]
  retrieval={'matches':[{'reference_id':'b','place_name':'Other','latitude':0.,'longitude':0.,'score':.99}]}
  result=combine_candidates(coarse,{},[],retrieval,{});self.assertEqual(result[0]['id'],'geo-1')
 def test_2d_match_never_claims_camera_pose(self):
  retrieval={'matches':[{'reference_id':'b','place_name':'Public Monument','latitude':48.,'longitude':2.,'coordinate_kind':'landmark'}]}
  geometry={'status':'geometric_match_without_georeferenced_pose','pairs':[{'reference_id':'b','verified':True,'inliers':30}]}
  result=combine_candidates([],{},[],retrieval,geometry)
  self.assertEqual(result[0]['result_type'],'recognized_landmark_location');self.assertNotEqual(result[0]['result_type'],'verified_camera_location')
if __name__=='__main__':unittest.main()
