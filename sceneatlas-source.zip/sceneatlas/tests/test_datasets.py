import io,json,tempfile,unittest,zipfile
from PIL import Image
from sceneatlas.support import app_paths
from sceneatlas.datasets import import_collection_archive
from sceneatlas.references import load_references
class ReferenceImportSafety(unittest.TestCase):
 def test_import_retains_license_coordinate_kind_and_pixels(self):
  pixels=io.BytesIO();Image.new('RGB',(32,32),'green').save(pixels,format='JPEG')
  record={'reference_id':'custom-fixture','place_name':'Test Public Park','license':'CC0','source_url':'https://example.test/photo','coordinate_kind':'landmark','landmark_coordinates':{'latitude':1.,'longitude':2.},'image':'image.jpg'}
  archive=io.BytesIO()
  with zipfile.ZipFile(archive,'w') as z:z.writestr('manifest.json',json.dumps({'references':[record]}));z.writestr('image.jpg',pixels.getvalue())
  with tempfile.TemporaryDirectory() as root:
   paths=app_paths(root)
   # Explicit empty installed collection keeps this fixture independent of bundled data.
   target=paths.root/'References';target.mkdir();(target/'manifest.json').write_text('{"references":[]}')
   outcome=import_collection_archive(archive.getvalue(),paths)
   loaded=load_references(paths)
   self.assertTrue(outcome['index_rebuild_required']);self.assertEqual(len(loaded),1)
   self.assertEqual(loaded[0]['coordinate_kind'],'landmark');self.assertEqual(loaded[0]['license'],'CC0')
 def test_zip_cannot_write_outside_its_import_directory(self):
  archive=io.BytesIO()
  with zipfile.ZipFile(archive,'w') as z:z.writestr('../escape.jpg',b'not used')
  with tempfile.TemporaryDirectory() as root:
   with self.assertRaises(ValueError):import_collection_archive(archive.getvalue(),app_paths(root))
if __name__=='__main__':unittest.main()
