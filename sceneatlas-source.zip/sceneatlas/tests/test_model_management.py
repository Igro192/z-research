"""Model integrity and owned-storage deletion tests with small local fixtures."""
import hashlib
import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from sceneatlas import model_management as management
from sceneatlas.support import app_paths


class Response(io.BytesIO):
    status = 206

    def __init__(self, data, start=0, status=206):
        super().__init__(data)
        self.status = status
        self.headers = {'Content-Range': f'bytes {start}-{start + len(data) - 1}/{start + len(data)}'}


class ModelManagementTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.paths = app_paths(Path(self.temporary.name) / 'SceneAtlas')
        self.weight = b'real local fixture weight'
        self.spec = {'clip': {
            'name': 'Small fixture', 'repo': 'test/fixture', 'revision': 'pinned-fixture',
            'weight_bytes': len(self.weight),
            'weight_sha256': hashlib.sha256(self.weight).hexdigest(),
            'files': ['config.json', 'model.safetensors'],
        }}
        self.patcher = patch.object(management, 'MODEL_SPECS', self.spec)
        self.patcher.start()

    def tearDown(self):
        self.patcher.stop()
        self.temporary.cleanup()

    def install_fixture(self):
        folder = self.paths.models / 'clip'
        folder.mkdir()
        (folder / 'config.json').write_text('{}')
        (folder / 'model.safetensors').write_bytes(self.weight)
        return folder

    def test_status_does_not_confuse_files_with_loaded_or_verified_models(self):
        self.assertFalse(management.model_status(self.paths)[0]['ready'])
        self.install_fixture()
        status = management.model_status(self.paths)[0]
        self.assertTrue(status['ready'])
        self.assertIsNone(status['loaded'])
        self.assertEqual(status['verification'], 'not_verified')
        checked = management.verify_models(self.paths)
        self.assertTrue(checked['ok'])
        self.assertEqual(management.model_status(self.paths)[0]['verification'], 'sha256_verified')

    def test_corrupt_same_size_weight_fails_pinned_checksum(self):
        folder = self.install_fixture()
        management.verify_models(self.paths)
        (folder / 'model.safetensors').write_bytes(b'x' * len(self.weight))
        self.assertEqual(management.model_status(self.paths)[0]['verification'], 'not_verified')
        checked = management.verify_models(self.paths)
        self.assertFalse(checked['ok'])
        self.assertIn('SHA256', checked['models']['clip']['errors'][0])

    def test_invalid_json_fails_verification(self):
        folder = self.install_fixture()
        (folder / 'config.json').write_text('{corrupt')
        checked = management.verify_models(self.paths)
        self.assertFalse(checked['ok'])
        self.assertIn('Invalid config.json', checked['models']['clip']['errors'][0])

    def test_complete_partial_is_verified_and_promoted_without_network(self):
        destination = self.paths.models / 'clip' / 'model.safetensors'
        destination.parent.mkdir()
        destination.with_name(destination.name + '.partial').write_bytes(self.weight)
        with patch.object(management, 'urlopen') as request:
            management._download_file('https://example.test/file', destination, lambda _: None,
                                      len(self.weight), hashlib.sha256(self.weight).hexdigest())
            request.assert_not_called()
        self.assertEqual(destination.read_bytes(), self.weight)

    def test_resume_uses_http_range_and_preserves_replaced_corrupt_original(self):
        destination = self.paths.models / 'clip' / 'model.safetensors'
        destination.parent.mkdir()
        destination.write_bytes(b'old corrupt bytes')
        destination.with_name(destination.name + '.partial').write_bytes(self.weight[:6])
        with patch.object(management, 'urlopen', return_value=Response(self.weight[6:], 6)) as request:
            management._download_file('https://example.test/file', destination, lambda _: None,
                                      len(self.weight), hashlib.sha256(self.weight).hexdigest())
            self.assertEqual(request.call_args.args[0].get_header('Range'), 'bytes=6-')
        self.assertEqual(destination.read_bytes(), self.weight)
        backups = list((destination.parent / '.previous').iterdir())
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_bytes(), b'old corrupt bytes')

    def test_downloader_reuses_verified_local_assets_without_network(self):
        self.install_fixture()
        with patch.object(management, '_download_file') as download:
            result = management.download_models(self.paths)
            download.assert_not_called()
        self.assertTrue(result['ok'])

    def test_clear_models_is_scoped_and_symlink_does_not_delete_target(self):
        self.install_fixture()
        unknown = self.paths.models / 'unrelated'
        unknown.mkdir()
        (unknown / 'keep').write_text('keep')
        outside = Path(self.temporary.name) / 'other-app-models'
        outside.mkdir()
        (outside / 'keep').write_text('other app')
        (self.paths.models / 'qwen').symlink_to(outside, target_is_directory=True)
        (self.paths.history / 'keep').write_text('saved photo')
        result = management.clear_models(self.paths)
        self.assertIn('clip', result['removed'])
        self.assertTrue((outside / 'keep').is_file())
        self.assertTrue((unknown / 'keep').is_file())
        self.assertTrue((self.paths.history / 'keep').is_file())

    def test_clear_cache_does_not_clear_models_or_history(self):
        folder = self.install_fixture()
        (self.paths.cache / 'gallery.pt').write_bytes(b'12345')
        (self.paths.history / 'keep').write_text('saved photo')
        result = management.clear_inference_cache(self.paths)
        self.assertEqual(result['bytes'], 5)
        self.assertTrue((folder / 'model.safetensors').is_file())
        self.assertTrue((self.paths.history / 'keep').is_file())

    def test_optional_anyloc_custom_weight_receipt_is_only_written_when_installed(self):
        self.install_fixture()
        optional = {**self.spec['clip'], 'name': 'AnyLoc tiny fixture',
                    'directory': 'AnyLoc', 'weight_filename': 'tiny.pth',
                    'files': ['tiny.pth'], 'optional_until_installed': True}
        with patch.object(management, 'MODEL_SPECS', {**self.spec, 'anyloc': optional}):
            checked = management.verify_models(self.paths)
            self.assertTrue(checked['ok'])
            self.assertNotIn('anyloc', checked['models'])
            folder = self.paths.models / 'AnyLoc'
            folder.mkdir();(folder / 'tiny.pth').write_bytes(self.weight)
            checked = management.verify_models(self.paths)
            self.assertTrue(checked['models']['anyloc']['ok'])
            status = next(row for row in management.model_status(self.paths) if row['id'] == 'anyloc')
            self.assertEqual(status['verification'], 'sha256_verified')

    def test_clear_anyloc_cache_preserves_registered_geometry_and_user_references(self):
        anyloc = self.paths.models / 'AnyLoc'
        anyloc.mkdir();(anyloc / 'vocabulary.pt').write_bytes(b'derived vocabulary')
        geometry = self.paths.models / 'geometry/registered/user-scene'
        geometry.mkdir(parents=True);(geometry / 'model.bin').write_bytes(b'user 3D model')
        references = self.paths.root / 'References'
        references.mkdir();(references / 'manifest.json').write_text('{}')
        management.clear_models(self.paths)
        self.assertFalse(anyloc.exists())
        self.assertEqual((geometry / 'model.bin').read_bytes(), b'user 3D model')
        self.assertTrue((references / 'manifest.json').is_file())


if __name__ == '__main__':
    unittest.main()
