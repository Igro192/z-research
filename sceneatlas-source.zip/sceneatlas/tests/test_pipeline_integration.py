"""Integration-rule tests with explicit fixtures, never model-accuracy evidence."""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from sceneatlas import pipeline, worker
from sceneatlas.geographic import GeographicEngine
from sceneatlas.support import app_paths


class FixtureEngine:
    device = 'cpu'

    def __init__(self, *args):
        pass

    def predict(self, *args, **kwargs):
        return {'coordinates': [[0.0, 0.0]], 'scores': [0.01]}

    def unload(self):
        pass


class PipelineIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.paths = app_paths(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def test_indoor_abstention_credits_the_vision_decision(self):
        with patch.object(pipeline, 'GeographicEngine', FixtureEngine), patch(
            'sceneatlas.vision.analyze_visual', return_value={'status':'ok','scene_type':'indoor'}
        ), patch('sceneatlas.place_search.PublicPlaceSearch.search', return_value=([],{'queries':[]})):
            fixture=self.paths.imports/'fixture.jpg';fixture.write_bytes(b'fixture input, no model inference')
            result=pipeline.analyze(fixture,{'ocr':False,'use_retrieval':False,'use_geometry':False},self.paths)
        self.assertEqual(result['candidates'],[])
        self.assertTrue(result['diagnostics']['engines']['vision']['affected_final_result'])
        self.assertFalse(result['diagnostics']['engines']['geoclip']['affected_final_result'])

    def test_reference_cannot_corroborate_another_reference_as_geoclip(self):
        visual = {'status': 'ok', 'scene_type': 'outdoor', 'observations': ['Visible public structure'],
                  'landmark_hypotheses': ['Fixture Museum A', 'Fixture Museum B']}
        references = [
            [{'name': 'Fixture Museum A', 'latitude': 40, 'longitude': 20,
              'source_url': 'https://example.test/a'}],
            [{'name': 'Fixture Museum B', 'latitude': 40.01, 'longitude': 20.01,
              'source_url': 'https://example.test/b'}],
        ]
        with patch.object(pipeline, 'GeographicEngine', FixtureEngine), patch(
            'sceneatlas.vision.analyze_visual', return_value=visual
        ), patch('sceneatlas.place_search.PublicPlaceSearch.search', return_value=([r[0] for r in references],{'queries':[]})):
            fixture=self.paths.imports/'fixture.jpg';fixture.write_bytes(b'fixture input hash, no model inference')
            result = pipeline.analyze(fixture, {'ocr': False,'use_retrieval':False,'use_geometry':False}, self.paths)
        reference_candidates = [item for item in result['candidates'] if item['id'].startswith('reference')]
        self.assertEqual(len(reference_candidates), 2)
        self.assertTrue(all(item['regional_agreement'] is False for item in reference_candidates))
        self.assertTrue(all('does not independently agree' in item['evidence'][2]
                            for item in reference_candidates))
        self.assertEqual(result['candidates'][0]['source'],'GeoCLIP')
        self.assertEqual(result['result_type'],'broad_geographic_prediction')
        self.assertTrue(result['diagnostics']['engines']['geoclip']['affected_final_result'])

    def test_framework_cleanup_does_not_import_missing_torch(self):
        engine = GeographicEngine(self.paths.models, self.paths.cache)
        with patch.dict(sys.modules, {'torch': None}):
            engine.unload()
        self.assertIsNone(engine.model)
        self.assertIsNone(engine.features)

    def test_mps_cleanup_failure_does_not_replace_inference_failure(self):
        def failed_cleanup():
            raise RuntimeError('Fixture device release failure')
        torch = SimpleNamespace(backends=SimpleNamespace(mps=SimpleNamespace(is_available=lambda: True)),
                                mps=SimpleNamespace(empty_cache=failed_cleanup))
        engine = GeographicEngine(self.paths.models, self.paths.cache)
        with patch.dict(sys.modules, {'torch': torch}), self.assertLogs(level='WARNING'):
            engine.unload()

    def test_worker_preserves_source_metadata_without_passing_it_to_inference(self):
        request = {
            'image_path': 'fixture.jpg', 'source_name': 'Source travel photo.png',
            'output': str(self.paths.cache / 'result.json'),
            'progress': str(self.paths.cache / 'progress.json'),
            'metadata': {'metadata_is_not_visual_inference': True, 'exif': {'Make': 'Fixture'}},
        }
        request_path = self.paths.cache / 'request.json'
        request_path.write_text(json.dumps(request))
        with patch.object(pipeline, 'analyze', return_value={'status': 'uncertain'}) as analyze, patch(
            'sceneatlas.support.app_paths', return_value=self.paths
        ), patch.object(worker.threading, 'Thread'):
            worker.main(request_path)
        result = json.loads(Path(request['output']).read_text())
        self.assertEqual(result['metadata'], request['metadata'])
        self.assertEqual(result['source_name'], request['source_name'])
        self.assertEqual(analyze.call_args.args[1], {})
        self.assertNotIn('metadata', analyze.call_args.kwargs)


if __name__ == '__main__':
    unittest.main()
