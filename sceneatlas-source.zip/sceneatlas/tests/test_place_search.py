import tempfile,unittest
from unittest.mock import patch
from sceneatlas.support import app_paths,LandmarkVerifier
from sceneatlas.place_search import proposed_queries,name_match,PublicPlaceSearch
from sceneatlas.fusion import combine_candidates
class PlaceRules(unittest.TestCase):
 def test_overlay_and_unqualified_brand_are_not_location_queries(self):
  visual={'visible_text':[{'text':'Example watermark','kind':'overlay','context':'printed over photo'}, {'text':'RetailBrand','kind':'physical_sign','context':'store facade','place_type':'shop'}]}
  queries,rejected=proposed_queries(visual,{});self.assertEqual(queries,[]);self.assertEqual(len(rejected),2)
 def test_unfamiliar_signed_mall_triggers_lookup(self):
  q,_=proposed_queries({'visible_text':[{'text':'Example Valley Mall','kind':'physical_sign','context':'attached to building','place_type':'mall'}]}, {})
  self.assertEqual(q[0]['basis'],'physical_sign')
 def test_typo_tolerance_does_not_match_unrelated_malls(self):
  self.assertEqual(name_match('Example Vallcy Mall',['Example Valley Mall'])[0],'approximate')
  self.assertEqual(name_match('Example Valley Mall',['Other Shopping Mall'])[0],'none')
 def test_mall_is_public_but_private_house_is_rejected(self):
  r={'category':'shop','type':'mall','name':'Fixture Centre','lat':'3','lon':'4','osm_type':'way','osm_id':123}
  self.assertIsNotNone(LandmarkVerifier._public_reference(r,'Fixture Centre'))
  self.assertIsNone(LandmarkVerifier._public_reference(dict(r,category='building',type='house'),'Fixture House'))
 def test_sign_and_geographic_match_can_override_distant_global_prior(self):
  coarse=[{'id':'geo','source':'GeoCLIP','latitude':0.,'longitude':0.,'label':'Broad prior'}]
  r={'name':'Example Valley Mall','latitude':40.,'longitude':70.,'identity_supported':True,'query_evidence':{'basis':'physical_sign'},'name_match':'exact'}
  rows=combine_candidates(coarse,{},[r],{},{});self.assertEqual(rows[0]['label'],r['name']);self.assertEqual(rows[0]['result_type'],'recognized_landmark_location');self.assertFalse(rows[0]['regional_agreement'])
 def test_multiple_distant_branches_remain_ambiguous(self):
  visual={'visible_text':[{'text':'Example Valley Mall','kind':'physical_sign','context':'building','place_type':'mall'}]}
  refs=[{'name':'Example Valley Mall','type':'mall','latitude':1.,'longitude':2.,'source_url':'https://example.test/a'}, {'name':'Example Valley Mall','type':'mall','latitude':30.,'longitude':40.,'source_url':'https://example.test/b'}]
  with tempfile.TemporaryDirectory() as d,patch.object(PublicPlaceSearch,'photon',return_value=(refs,'online')):
   rows,trace=PublicPlaceSearch(app_paths(d)).search(visual,{},True,[])
   self.assertTrue(all(r['ambiguous_name'] for r in rows));self.assertTrue(all(not r['identity_supported'] for r in rows))
if __name__=='__main__':unittest.main()

class ProviderFallbackRules(unittest.TestCase):
 def test_cached_public_place_is_available_without_network(self):
  import hashlib,json,time
  from sceneatlas.support import _atomic_write,result_json
  with tempfile.TemporaryDirectory() as d:
   paths=app_paths(d);query='Fixture Public Museum';endpoint='https://photon.komoot.io'
   key=hashlib.sha256(f'photon-v1|{endpoint}|{query.casefold()}'.encode()).hexdigest()
   row={'name':query,'latitude':1.,'longitude':2.}
   _atomic_write(paths.cache/'References'/f'{key}.json',result_json({'retrieved_at':time.time(),'results':[row]}).encode())
   with patch.object(LandmarkVerifier,'_fetch_json',side_effect=AssertionError('Must not contact provider')):
    rows,status=PublicPlaceSearch(paths).photon(query,allow_network=False)
   self.assertEqual(status,'cache');self.assertEqual(rows,[row])
 def test_provider_failure_preserves_errors_without_inventing_place(self):
  visual={'visible_text':[{'text':'Fixture Public Museum','kind':'physical_sign','context':'building facade','place_type':'museum'}]}
  with tempfile.TemporaryDirectory() as d,patch.object(PublicPlaceSearch,'photon',side_effect=OSError('simulated outage')),patch.object(LandmarkVerifier,'search',side_effect=OSError('simulated outage')):
   rows,trace=PublicPlaceSearch(app_paths(d)).search(visual,{},online=True)
   self.assertEqual(rows,[]);self.assertEqual(len(trace['queries'][0]['errors']),2)

class VisualIdentityRules(unittest.TestCase):
 def test_even_same_region_does_not_verify_visual_building_identity(self):
  visual={'landmark_hypotheses':['Fixture Public Tower'],'landmark_evidence':[{'name':'Fixture Public Tower','visual_support':'A tall glass building with a pointed roof'}]}
  ref={'name':'Fixture Public Tower','type':'tower','latitude':40.,'longitude':70.,'source_url':'https://example.test/tower'}
  coarse=[{'id':'geo','source':'GeoCLIP','latitude':40.01,'longitude':70.01,'label':'Broad prior'}]
  with tempfile.TemporaryDirectory() as d,patch.object(PublicPlaceSearch,'photon',return_value=([ref],'online')):
   refs,_=PublicPlaceSearch(app_paths(d)).search(visual,{},True,coarse)
   self.assertTrue(refs[0]['regional_agreement']);self.assertFalse(refs[0]['identity_supported'])
   self.assertEqual(combine_candidates(coarse,visual,refs,{},{} )[0]['id'],'geo')
 def test_place_existence_cannot_promote_an_uncorroborated_visual_guess(self):
  visual={'landmark_hypotheses':['Fixture Public Tower'],'landmark_evidence':[{'name':'Fixture Public Tower','visual_support':'A tall glass building with a pointed roof'}]}
  ref={'name':'Fixture Public Tower','type':'tower','latitude':40.,'longitude':70.,'source_url':'https://example.test/tower'}
  coarse=[{'id':'geo','source':'GeoCLIP','latitude':0.,'longitude':0.,'label':'Broad prior'}]
  with tempfile.TemporaryDirectory() as d,patch.object(PublicPlaceSearch,'photon',return_value=([ref],'online')):
   refs,trace=PublicPlaceSearch(app_paths(d)).search(visual,{},True,coarse)
   self.assertFalse(refs[0]['identity_supported']);self.assertEqual(combine_candidates(coarse,visual,refs,{},{} )[0]['id'],'geo')

class OverlayCrossPathRules(unittest.TestCase):
 def test_overlay_entity_cannot_reenter_through_visual_landmark_names(self):
  visual={'visible_text':[{'text':'Fixture Famous Wheel','kind':'overlay','context':'video caption','place_type':'other'}], 'landmark_hypotheses':['Fixture Famous Wheel'], 'landmark_evidence':[{'name':'Fixture Famous Wheel','visual_support':'A named structure described by caption text'}]}
  queries,rejected=proposed_queries(visual,{})
  self.assertEqual(queries,[]);self.assertTrue(any('quarantined' in r['reason'] for r in rejected))
