import unittest
from sceneatlas.geographic import distinct_candidates,distance_km
class GeographicRules(unittest.TestCase):
 def test_known_great_circle(self):
  self.assertAlmostEqual(distance_km([0,0],[0,1]),111.195,places=2)
  self.assertEqual(distance_km([40,30],[40,30]),0)
 def test_dateline(self):self.assertLess(distance_km([0,179.9],[0,-179.9]),23)
 def test_candidates_preserve_ranking_and_scores(self):
  r=distinct_candidates([[48.858,2.29],[48.86,2.3],[40.7,-74]], [.012,.010,.007])
  self.assertEqual(len(r),2);self.assertEqual(r[1]['model_rank'],3);self.assertEqual(r[0]['raw_score'],.012)
  self.assertNotIn('confidence',r[0]);self.assertEqual(r[0]['result_type'],'estimated_camera_location')
  self.assertIn('not proof',r[0]['uncertainty'])
 def test_no_candidates(self):self.assertEqual(distinct_candidates([],[]),[])
if __name__=='__main__':unittest.main()
