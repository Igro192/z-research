"""Scene-output validation and lazy imports; no model is mocked as inference."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from sceneatlas import vision as VISION

ROOT = Path(__file__).resolve().parents[1]


class VisionParserTests(unittest.TestCase):
    def test_fenced_json_preserves_only_actual_evidence(self):
        scene = {
            "scene_type": "outdoor", "observations": ["Stone tower", "Stone tower"],
            "geographic_clues": ["A tower might resemble European architecture"],
            "landmark_hypotheses": ["A park or public park", "A", "B", "C"], "ambiguity": ["No readable signs"],
        }
        result = VISION.parse_scene_output("Here is the JSON:\n```json\n" + json.dumps(scene) + "\n```")
        self.assertEqual(result["observations"], ["Stone tower"])
        self.assertEqual(result["landmark_hypotheses"], ["A", "B"])
        self.assertNotIn("coordinates", result)

    def test_quoted_braces_and_schema_echo_do_not_replace_actual_response(self):
        actual = {
            "scene_type": "outdoor", "observations": ['A sign reads "{city}"'],
            "geographic_clues": [], "landmark_hypotheses": [], "ambiguity": [],
            "extra": {"anything": True},
        }
        # A model can repeat the example schema before its actual response.
        example = {
            "scene_type": "unclear", "observations": ["visible fact"],
            "geographic_clues": [], "landmark_hypotheses": [], "ambiguity": [],
        }
        raw = json.dumps(example) + "\nActual response:\n" + json.dumps(actual)
        self.assertEqual(VISION.parse_scene_output(raw)["observations"], ['A sign reads "{city}"'])

    def test_invalid_scene_kind_and_non_string_evidence_are_conservative(self):
        raw = '{"scene_type":"Paris","observations":[42,null,{"fake":"fact"}],"landmark_hypotheses":["Eiffel Tower"]}'
        result = VISION.parse_scene_output(raw)
        self.assertEqual(result["scene_type"], "unclear")
        self.assertEqual(result["observations"], [])
        self.assertEqual(result["landmark_hypotheses"], [])

    def test_truncated_output_is_not_repaired_into_evidence(self):
        for raw in ('{"observations":["a tower"', 'The scene is probably Paris.', '', '{"unrelated": true}'):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                VISION.parse_scene_output(raw)

    def test_empty_valid_schema_does_not_invent_evidence(self):
        result = VISION.parse_scene_output('{"scene_type":"unclear","observations":[],"ambiguity":[]}')
        self.assertEqual(result["observations"], [])
        self.assertEqual(result["geographic_clues"], [])

    def test_missing_model_has_no_evidence_and_import_remains_light(self):
        with tempfile.TemporaryDirectory() as directory:
            result = VISION.analyze_visual(__file__, Path(directory) / "missing-qwen")
        self.assertEqual(result["status"], "error")
        self.assertEqual(result["observations"], [])
        self.assertIsNotNone(result["error"])
        # Check in a fresh interpreter, independent of other tests' imports.
        subprocess.run(
            [sys.executable, "-c", "import sceneatlas.vision, sys; assert 'mlx.core' not in sys.modules; assert 'torch' not in sys.modules"],
            cwd=ROOT, check=True, capture_output=True, text=True,
        )

    def test_named_landmark_objects_keep_support_and_legacy_name_list(self):
        raw = json.dumps({
            "scene_type": "outdoor", "observations": ["A wheel with enclosed pods"],
            "landmark_hypotheses": [{"name": "London Eye", "visual_support": "A large cantilevered wheel with enclosed oval pods"}],
        })
        result = VISION.parse_scene_output(raw)
        self.assertEqual(result["landmark_hypotheses"], ["London Eye"])
        self.assertEqual(result["landmark_evidence"][0]["name"], "London Eye")
        self.assertIn("oval pods", result["landmark_evidence"][0]["visual_support"])
        self.assertEqual(result["landmark_evidence"][0]["status"], "unverified_visual_hypothesis")

    def test_generic_filter_keeps_real_names_with_articles_and_structure_words(self):
        names = ["A park or public park", "A Famosa", "Tower Bridge"]
        result = VISION.parse_scene_output(json.dumps({
            "observations": ["Visible stone fort"], "landmark_hypotheses": names,
        }))
        self.assertEqual(result["landmark_hypotheses"], ["A Famosa", "Tower Bridge"])

    def test_sentences_are_not_sent_as_landmark_search_queries(self):
        result = VISION.parse_scene_output(json.dumps({
            "observations": ["Visible tower"],
            "landmark_hypotheses": ["The tallest building is the Burj Khalifa.", "The city is likely Dubai.", "Burj Khalifa"],
        }))
        self.assertEqual(result["landmark_hypotheses"], ["Burj Khalifa"])

    def test_dedicated_landmark_pass_preserves_names_and_corresponding_features(self):
        result = VISION.parse_landmark_output(json.dumps({
            "names": ["London Eye", "Big Ben"],
            "visual_support": ["A large wheel with oval enclosed capsules", "A pointed Gothic clock tower"],
            "limitations": ["The clock tower is distant"],
        }))
        self.assertEqual(result["landmark_hypotheses"], ["London Eye", "Big Ben"])
        self.assertIn("Gothic", result["landmark_evidence"][1]["visual_support"])
        self.assertEqual(result["landmark_limitations"], ["The clock tower is distant"])

    def test_dedicated_pass_abstains_and_rejects_truncation(self):
        result = VISION.parse_landmark_output('{"names":[],"visual_support":[],"limitations":["Generic city scene"]}')
        self.assertEqual(result["landmark_hypotheses"], [])
        for raw in ('{"names":["London Eye"', 'Probably London', None):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                VISION.parse_landmark_output(raw)

    def test_real_model_array_shape_keeps_both_landmark_objects(self):
        result = VISION.parse_landmark_output(json.dumps([
            {"names": ["London Eye"], "visual_support": ["Large wheel with enclosed pods"]},
            {"names": ["Big Ben"], "visual_support": [["Clock face", "Gothic pointed tower"]]},
        ]))
        self.assertEqual(result["landmark_hypotheses"], ["London Eye", "Big Ben"])
        self.assertIn("Gothic", result["landmark_evidence"][1]["visual_support"])

    def test_extra_unagreed_and_explicitly_contradicted_names_are_suppressed(self):
        recognition = VISION.parse_landmark_output(json.dumps({
            "names": ["London Eye", "The Shard"],
            "visual_support": ["Large wheel", "Distant pointed skyscraper"],
            "limitations": [],
        }))
        final = VISION._consistent_landmarks({}, recognition, 'Possible landmark: London Eye')
        self.assertEqual(final["landmark_hypotheses"], ["London Eye"])
        self.assertEqual(final["suppressed_landmark_hypotheses"][0]["name"], "The Shard")
        recognition["landmark_limitations"] = ["The Shard is not visible in the image"]
        final = VISION._consistent_landmarks({}, recognition, 'London Eye and The Shard')
        self.assertEqual(final["landmark_hypotheses"], ["London Eye"])

    def test_generic_field_self_contradiction_and_interiors_abstain(self):
        recognition = VISION.parse_landmark_output(json.dumps({
            "names": ["Wicken Fen Nature Reserve"], "visual_support": ["A dirt path through a field"],
            "limitations": ["The image does not clearly show any distinct landmarks or structures that can be named with certainty."],
        }))
        final = VISION._consistent_landmarks({"scene_type": "outdoor"}, recognition, 'A generic field')
        self.assertEqual(final["landmark_hypotheses"], [])
        self.assertTrue(final["landmark_abstention_reason"])
        recognition["landmark_limitations"] = []
        final = VISION._consistent_landmarks({"scene_type": "indoor"}, recognition, 'Interior decoration')
        self.assertEqual(final["landmark_hypotheses"], [])


if __name__ == "__main__":
    unittest.main()
