# Kis Experience

Owner-created concept prototype for KIS Almaty; not an official school website. Original HTML/CSS/JavaScript and a licensed Three.js vendor copy are included. School imagery and crest are excluded because they belong to their owners.

## Run

Serve dist/ with a local static server. Image placeholders will be empty until appropriately licensed assets are supplied.

This is a source snapshot from Z. Research. No license is granted for third-party content or trademarks.
