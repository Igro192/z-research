# HumanoidBench Control Center — original wrapper

Original controller/UI code around the official `carlosferrazza/humanoid-bench` project at commit cb1189039151c8aadaaa987b442da54383c87fab. Physics, robot definitions and PPO are upstream work. The upstream repository, assets, policies and runtime are excluded.

The local installation uses MuJoCo 3.1.6 and Stable-Baselines3 2.3.2, with an isolated Python 3.11 environment. `control/common.py` documents the expected vendor/runtime layout. Install upstream separately under vendor/humanoid-bench and provide runtime/python311 before launch. Run `python -m control.launch` only in a trusted local setup.

Saved historical short policy tests report 0% skill success. The project demonstrates scheduling, checkpoint handling and diagnostics, not mastered walking. No training is necessary to inspect source.
