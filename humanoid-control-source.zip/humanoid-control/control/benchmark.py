"""Bounded comparison of official PPO with 1, 2, 4 and 8 subprocess environments."""
import argparse
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import time

import psutil

from .common import ROOT, REPO, PYTHON, REPORTS, now, read_json, write_json, commit

STEPS = 32768
COUNTS = (1, 2, 4, 8)

class BenchmarkSuite:
    def __init__(self, run):
        self.run = Path(run)
        self.child = None
        self.interrupted = False
        self.results = []
        self.started_at = now()
        self.swap_start=psutil.swap_memory().sout
        signal.signal(signal.SIGINT,self.stop)
        signal.signal(signal.SIGTERM,self.stop)

    def stop(self,*unused):
        self.interrupted = True
        if self.child and self.child.poll() is None:
            self.child.send_signal(signal.SIGTERM)

    def measure(self,count):
        run=self.run/f'env-{count}'
        run.mkdir(exist_ok=False)
        config=dict(env_id='g1-walk-v0',operation='new',checkpoint=None,run_dir=str(run),
                    steps=STEPS,num_envs=count,seed=7,checkpoint_every=8192,
                    vectorization='subproc',purpose='parallel-benchmark-only',created_at=now())
        write_json(run/'config.json',config)
        env=os.environ.copy()
        env.update(PYTHONPATH=str(ROOT),JAX_PLATFORMS='cpu',WANDB_MODE='disabled',
                   OMP_NUM_THREADS='4',PYTHONUNBUFFERED='1')
        env.pop('MUJOCO_GL',None)
        start=time.monotonic()
        peak_tree=0
        cpu_seconds={}
        machine_cpu=[]
        psutil.cpu_percent()
        with (run/'training.log').open('w') as stream:
            self.child=subprocess.Popen([str(PYTHON),'-m','control.train','--config',str(run/'config.json')],
                                        cwd=REPO,env=env,stdout=stream,stderr=subprocess.STDOUT)
            write_json(self.run/'child.json',dict(pid=self.child.pid,create_time=psutil.Process(self.child.pid).create_time(),num_envs=count))
            while self.child.poll() is None:
                try:
                    p=psutil.Process(self.child.pid)
                    rss=0
                    for proc in [p,*p.children(recursive=True)]:
                        try:
                            rss+=proc.memory_info().rss
                            cpu=proc.cpu_times()
                            key=(proc.pid,proc.create_time())
                            cpu_seconds[key]=max(cpu_seconds.get(key,0),cpu.user+cpu.system)
                        except psutil.Error: pass
                    peak_tree=max(peak_tree,rss)
                except psutil.Error: pass
                machine_cpu.append(psutil.cpu_percent(interval=.1))
                status=read_json(run/'status.json',{'state':'starting','training_steps':0})
                write_json(self.run/'status.json',dict(**status,benchmark_count=count,
                           benchmark_completed_counts=len(self.results),benchmark_total_counts=len(COUNTS)))
                if psutil.virtual_memory().available<4*1024**3 or psutil.swap_memory().sout-self.swap_start>128*1024**2:
                    self.stop()
        wall=time.monotonic()-start
        status=read_json(run/'status.json',{})
        passed=(self.child.returncode==0 and status.get('state')=='completed'
                and status.get('training_steps')==STEPS and not self.interrupted)
        result=dict(passed=passed,state='completed' if passed else ('cancelled' if self.interrupted else 'failed'),
                    task='g1-walk-v0',robot='Unitree G1',git_commit=commit(),
                    algorithm='Official HumanoidBench SB3 PPO 2.3.2',fixed_steps=STEPS,
                    completed_steps=status.get('training_steps',0),num_parallel_environments=count,
                    vectorization='SubprocVecEnv (spawn), identical for all counts',rendering=False,
                    device='cpu',torch_threads=4,hardware=platform.machine(),wall_clock_seconds=wall,
                    training_wall_seconds=status.get('training_wall_seconds'),
                    process_cpu_percent=status.get('process_cpu_percent'),
                    process_tree_cpu_percent=100*sum(cpu_seconds.values())/wall,
                    cpu_definition='Sampled total user+system CPU seconds across trainer and workers / full trainer wall time; 100% = one logical CPU. Includes startup.',
                    machine_cpu_percent_mean=sum(machine_cpu)/len(machine_cpu) if machine_cpu else None,
                    peak_ram_bytes=max(peak_tree,status.get('peak_rss_bytes',0)),
                    ram_definition='Peak aggregate resident RSS of trainer + subprocess tree, sampled at 0.1 s; shared mapped pages can be counted in multiple processes.',
                    ppo_update_seconds_total=status.get('ppo_update_seconds_total'),
                    ppo_rollout_seconds_total=status.get('ppo_rollout_seconds_total'),
                    ppo_update_seconds_mean=status.get('ppo_update_seconds_mean'),
                    ppo_train_calls=status.get('ppo_train_calls'),
                    ppo_update_definition='Wall time inside the unchanged Stable-Baselines3 PPO.train() method; a call includes all 10 epochs.',
                    run_dir=str(run),checkpoint=status.get('checkpoint'),exit_code=self.child.returncode,
                    measured_at=now(),checkpoint_reload_verified=False)
        if passed:
            try:
                from stable_baselines3 import PPO
                import torch
                from .common import sha256,state_digest
                cp=Path(status['checkpoint']);meta=read_json(cp.parent/'metadata.json')
                model=PPO.load(cp,device='cpu')
                assert sha256(cp)==meta['sha256']
                assert state_digest(model.policy.state_dict())==meta['policy_sha256']
                assert state_digest(model.policy.optimizer.state_dict())==meta['optimizer_sha256']
                assert all(torch.isfinite(v).all() for v in model.policy.state_dict().values())
                assert model.num_timesteps==STEPS and model._n_updates==(STEPS//(model.n_steps*count))*model.n_epochs
                result['checkpoint_reload_verified']=True
                result['hyperparameters']=meta['hyperparameters']
                result['environment_steps_per_second']=STEPS/status['training_wall_seconds']
                result['startup_and_shutdown_seconds']=max(0,wall-status['training_wall_seconds'])
                del model
            except Exception as e:
                result.update(passed=False,state='failed',error=f'Checkpoint verification failed: {e}')
        if not result['passed'] and 'error' not in result:
            result['error']=(run/'training.log').read_text(errors='replace')[-3500:]
        write_json(run/'result.json',result)
        print(json.dumps(result,indent=2),flush=True)
        return result

    def publish(self,complete=False):
        report=dict(passed=complete and any(r['passed'] for r in self.results),
                    all_configurations_passed=complete and len(self.results)==4 and all(r['passed'] for r in self.results),
                    state='cancelled' if self.interrupted else ('completed' if complete else 'running'),
                    fixed_steps_per_test=STEPS,environment_counts=list(COUNTS),results=self.results,
                    rendering=False,started_at=self.started_at,updated_at=now(),git_commit=commit(),
                    selection_rule='Highest measured PPO-loop environment steps/s among configurations that finish all steps with finite observations/rewards/weights and verified model+optimizer reload.',
                    measurement_note='PPO n_steps stays 2048 per environment, batch_size 512 and n_epochs 10 stay fixed. Increasing num_envs therefore increases rollout batch size and decreases update-call count at the same total steps.')
        if complete and not self.interrupted:
            stable=[r for r in self.results if r['passed']]
            if stable:
                winner=max(stable,key=lambda r:r['environment_steps_per_second'])
                report['fastest_num_envs']=winner['num_parallel_environments']
                rate=winner['environment_steps_per_second']
                winner=dict(winner,estimated_training_seconds={str(n):n/rate for n in [100_000,1_000_000,5_000_000,20_000_000]},
                            estimate_definition='Linear projection from measured PPO-loop throughput of fastest stable parallel configuration; startup excluded, long-run performance and skill quality unmeasured.')
                write_json(REPORTS/'training-benchmark.json',winner)
                previous=read_json(ROOT/'state/training-defaults.json',{})
                selected=dict(num_envs=winner['num_parallel_environments'],
                            vectorization='subproc',torch_threads=4,selected_at=now(),source=str(REPORTS/'parallel-benchmark.json'),
                            environment_steps_per_second=rate,git_commit=commit())
                if previous.get('num_envs')==selected['num_envs']:
                    selected.update({k:previous[k] for k in ('max_jobs','aggregate_steps_per_second','concurrency_source') if k in previous})
                write_json(ROOT/'state/training-defaults.json',selected)
                report['default_updated']=True
        write_json(self.run/'result.json',report)
        if complete and not self.interrupted:write_json(REPORTS/'parallel-benchmark.json',report)
        return report

    def main(self):
        self.publish()
        for count in COUNTS:
            if self.interrupted: break
            self.results.append(self.measure(count))
            self.publish()
        report=self.publish(complete=not self.interrupted and len(self.results)==len(COUNTS))
        write_json(self.run/'status.json',dict(state=report['state'],training_steps=sum(r['completed_steps'] for r in self.results),
                   benchmark_completed_counts=len(self.results),benchmark_total_counts=len(COUNTS),fastest_num_envs=report.get('fastest_num_envs')))
        print('PARALLEL BENCHMARK '+json.dumps(report),flush=True)
        if not report['passed']: raise SystemExit(1)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run-dir',required=True)
    BenchmarkSuite(p.parse_args().run_dir).main()
