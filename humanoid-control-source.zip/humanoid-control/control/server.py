import argparse
import csv
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import secrets
import signal
import subprocess
import sys
import threading
import time
import uuid
import webbrowser

import psutil

from .common import ROOT, REPO, PYTHON, MJPYTHON, SKILLS, REPORTS, PRIMARY, now, write_json, read_json, checkpoint_entries, checked_checkpoint, skill_for

PORT = 8765
TOKEN = secrets.token_urlsafe(32)
JOB_LOCK = threading.Lock()
CHILDREN = {}

def processes():
    data = read_json(ROOT / 'state' / 'jobs.json', [])
    for job in data:
        try:
            proc = psutil.Process(job['pid'])
            alive = abs(proc.create_time()-job['create_time']) < .1 and proc.is_running() and proc.status() != psutil.STATUS_ZOMBIE
            job['active'] = alive
            job['ram_mb'] = proc.memory_info().rss/1024**2 if alive else 0
        except psutil.Error:
            job['active'] = False
        if job['kind']=='autopilot':
            job['status']=read_json(Path(job['run_dir'])/'session.json',{})
        elif job['kind'] in ('train','benchmark'):
            job['status'] = read_json(Path(job['run_dir']) / 'status.json', {'state':'starting'})
        child = CHILDREN.get(job['pid'])
        if child and child.poll() is not None:
            job['exit_code'] = child.returncode
            job['active'] = False
        log = Path(job['log'])
        if log.is_file():
            with log.open('rb') as f:
                f.seek(max(0,log.stat().st_size-12000))
                job['log_tail']=f.read().decode(errors='replace')[-6000:]
    return data

def spawn(kind, command, log, **extra):
    log.parent.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.update(PYTHONPATH=str(ROOT), PYTHONUNBUFFERED='1', JAX_PLATFORMS='cpu', WANDB_MODE='disabled', OMP_NUM_THREADS='4')
    env.pop('MUJOCO_GL', None)
    with log.open('w') as stream:
        proc = subprocess.Popen(command, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    CHILDREN[proc.pid] = proc
    job = dict(kind=kind, pid=proc.pid, create_time=psutil.Process(proc.pid).create_time(),
               created_at=now(), log=str(log), **extra)
    jobs = read_json(ROOT / 'state' / 'jobs.json', [])
    jobs.append(job)
    write_json(ROOT / 'state' / 'jobs.json', jobs[-100:])
    return job

def start_training(payload):
    with JOB_LOCK:
        if any(j['active'] and j['kind'] in ('train','benchmark','autopilot') for j in processes()):
            raise ValueError('A training run is already active. Stop it safely before starting another.')
        env_id = valid_task(payload.get('env_id','g1-walk-v0'))
        operation = payload.get('operation','new')
        if operation not in ('new','resume','transfer'): raise ValueError('Unknown model operation.')
        steps = int(payload.get('steps',32768))
        if not 2048 <= steps <= 20_000_000: raise ValueError('Training steps must be between 2048 and 20,000,000.')
        checkpoint = payload.get('checkpoint')
        num_envs = int(read_json(ROOT/'state/training-defaults.json',{}).get('num_envs',1))
        seed = int(payload.get('seed',0))
        if operation != 'new':
            cp, meta = checked_checkpoint(checkpoint or '')
            checkpoint = str(cp)
            if operation == 'resume':
                if meta['task'] != env_id: raise ValueError('Resume requires the exact checkpoint task.')
                num_envs, seed = meta['num_envs'], meta['seed']
        else:
            checkpoint = None
        rollout_steps=2048*num_envs
        if steps % rollout_steps:
            raise ValueError(f'Use a multiple of {rollout_steps} steps for {num_envs} environments so PPO completes whole rollouts.')
        run = SKILLS / skill_for(env_id) / 'runs' / (time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8])
        run.mkdir(parents=True, exist_ok=False)
        cfg = dict(env_id=env_id, operation=operation, checkpoint=checkpoint, run_dir=str(run), steps=steps,
                   seed=seed, num_envs=num_envs, checkpoint_every=8192, created_at=now(),
                   purpose=payload.get('purpose','research'))
        cfg['vectorization']='subproc'
        write_json(run / 'config.json', cfg)
        return spawn('train', [str(PYTHON),'-m','control.train','--config',str(run/'config.json')],
                     run/'training.log', run_dir=str(run), task=env_id)

def valid_task(env_id):
    tasks = read_json(REPORTS/'tasks.json', [])
    if not any(t['env_id']==env_id and t['status']=='passes' for t in tasks):
        raise ValueError('This official task has not passed the local environment probe.')
    return env_id

def stop_training(env_id=None):
    with JOB_LOCK:
        active = [j for j in processes() if j['kind'] in ('train','benchmark') and j['active'] and (env_id is None or j['task']==env_id)]
        if not active: return {'message':'No active training run.'}
        for j in active:
            proc = psutil.Process(j['pid'])
            identity=str(Path(j['run_dir'])/'config.json') if j['kind']=='train' else j['run_dir']
            if identity not in proc.cmdline():
                raise ValueError('Process identity changed; refusing to signal it.')
            proc.send_signal(signal.SIGTERM)
        return {'message':'Stop requested. The current PPO update will finish and save before exit.'}

def start_benchmark(payload):
    with JOB_LOCK:
        active=processes()
        if any(j['active'] and j['kind'] in ('train','benchmark','autopilot') for j in active):
            raise ValueError('Stop current training safely before benchmarking.')
        if any(j['active'] and j['kind'] in ('viewer','evaluation') for j in active):
            raise ValueError('Close the native viewer and wait for evaluation before the headless benchmark.')
        valid_task('g1-walk-v0')
        run=ROOT/'benchmarks'/'runs'/(time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8])
        run.mkdir(parents=True,exist_ok=False)
        return spawn('benchmark',[str(PYTHON),'-m','control.benchmarks','--run-dir',str(run)],
                     run/'benchmark.log',run_dir=str(run),task='g1-walk-v0')

def start_viewer(payload):
    with JOB_LOCK:
        if any(j['active'] and j['kind']=='benchmark' for j in processes()):
            raise ValueError('The headless benchmark is running. Open the viewer after it finishes.')
        if any(j['active'] and j['kind']=='viewer' for j in processes()):
            raise ValueError('A native viewer is already open. Close it before opening another.')
        env_id = valid_task(payload.get('env_id','g1-walk-v0'))
        args = [str(MJPYTHON),'-m','control.play','--env',env_id]
        cp = payload.get('checkpoint')
        if cp:
            path, meta = checked_checkpoint(cp)
            if meta['task']!=env_id: raise ValueError('Play requires the checkpoint task.')
            args += ['--checkpoint',str(path)]
        if payload.get('running'): args += ['--running']
        if payload.get('random'): args += ['--random']
        job_id = uuid.uuid4().hex[:8]
        report=ROOT/'state'/f'viewer-{job_id}.json'
        args += ['--report',str(report)]
        return spawn('viewer',args, ROOT/'state'/f'viewer-{job_id}.log', task=env_id, report=str(report))

def start_evaluation(payload):
    with JOB_LOCK:
        if any(j['active'] and j['kind']=='benchmark' for j in processes()):
            raise ValueError('The headless benchmark is running. Evaluate after it finishes.')
        if any(j['active'] and j['kind']=='evaluation' for j in processes()): raise ValueError('Evaluation is already running.')
        env_id = valid_task(payload.get('env_id','g1-walk-v0'))
        path, meta = checked_checkpoint(payload.get('checkpoint',''))
        if meta['task']!=env_id: raise ValueError('Evaluate the checkpoint on its original task.')
        report = path.parent / ('evaluation-'+uuid.uuid4().hex[:8]+'.json')
        return spawn('evaluation',[str(PYTHON),'-m','control.evaluate','--env',env_id,'--checkpoint',str(path),'--report',str(report)],
                     report.with_suffix('.log'),task=env_id, report=str(report))


def start_autopilot(payload):
    from .autopilot import create
    with JOB_LOCK:
        if any(j['active'] and j['kind'] in ('train','benchmark','autopilot') for j in processes()):
            raise ValueError('Stop active training/benchmark/session before starting another session.')
        path=create(payload)
        return spawn('autopilot',[str(PYTHON),'-m','control.autopilot','--session',str(path)],path.parent/'supervisor.log',run_dir=str(path.parent),task='G1 independent skill scheduler')

def resume_autopilot(payload):
    from .autopilot import snapshot,command
    with JOB_LOCK:
        s=snapshot()
        if not s:raise ValueError('No saved Train All session.')
        if s['active']:
            if payload.get('skill'):return command('resume',payload['skill'])
            return {'message':'Train All is already active.'}
        if any(j['active'] and j['kind'] in ('train','benchmark') for j in processes()):raise ValueError('Wait for current training/benchmark first.')
        path=Path(s['path']);saved=read_json(path)
        if payload.get('skill'):
            name=payload['skill']
            if name not in saved['skills']:raise ValueError('Unknown skill.')
            saved['resume_only']=[name]
            if saved['skills'][name]['status']=='Failed':saved['skills'][name].update(status='Paused',retries=0,error=None)
        else:saved.pop('resume_only',None)
        write_json(path,saved)
        return spawn('autopilot',[str(PYTHON),'-m','control.autopilot','--session',str(path)],path.parent/('supervisor-'+uuid.uuid4().hex[:6]+'.log'),run_dir=str(path.parent),task='G1 independent skill scheduler')

def autopilot_command(payload):
    from .autopilot import command
    return command(payload.get('action','stop'),payload.get('skill'))

def state():
    from .autopilot import snapshot
    jobs = processes()
    session=snapshot()
    diagnostics = read_json(REPORTS/'diagnostics.json', {})
    diagnostics.update(cpu_usage_percent=psutil.cpu_percent(),
                       ram_used_gb=psutil.virtual_memory().used/1024**3,
                       ram_available_gb=psutil.virtual_memory().available/1024**3,
                       ram_total_gb=psutil.virtual_memory().total/1024**3)
    latest = next((j for j in reversed(jobs) if j['kind']=='train'), None)
    if session.get('active_jobs'):
        active=next((j for j in session['active_jobs'] if j['stage']=='train'),None)
        if active:
            skill=session['skills'][active['skill']]
            latest=dict(task=skill['env_id'],run_dir=skill['last_run'],status=read_json(Path(skill['last_run'])/'status.json',{}),active=True)
    curves = []
    if latest:
        p = Path(latest['run_dir'])/'metrics'/'progress.csv'
        if p.exists():
            try:
                curves=list(csv.DictReader(p.open()))[-300:]
            except (OSError, csv.Error): pass
    return dict(autopilot=session,progress_job=latest,concurrency_benchmark=read_json(REPORTS/'concurrency-benchmark.json',{}),workspace=str(ROOT),server_pid=os.getpid(),diagnostics=diagnostics, tasks=read_json(REPORTS/'tasks.json', []),
                checkpoints=checkpoint_entries(), official_pretrained=read_json(REPORTS/'official-pretrained.json', []),
                jobs=jobs, curves=curves, smoke=read_json(REPORTS/'smoke-test.json', {}),
                benchmark=read_json(REPORTS/'training-benchmark.json', {}),
                parallel_benchmark=read_json(REPORTS/'parallel-benchmark.json', {}),
                training_defaults=read_json(ROOT/'state/training-defaults.json',{'num_envs':1,'vectorization':'subproc'}))

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def reply(self, value, code=200):
        data=json.dumps(value,allow_nan=False).encode()
        self.send_response(code)
        self.send_header('Content-Type','application/json')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    def do_GET(self):
        if self.path=='/api/state':
            return self.reply(state())
        if self.path=='/':
            body=(ROOT/'control'/'index.html').read_text().replace('__TOKEN__',TOKEN).encode()
            self.send_response(200)
            self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Cache-Control','no-store')
            self.send_header('Content-Length',str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else: self.reply({'error':'Not found'},404)
    def do_POST(self):
        if self.headers.get('X-Control-Token') != TOKEN:
            return self.reply({'error':'Open the local Control Center to perform actions.'},403)
        if self.headers.get('Origin') not in (None,f'http://127.0.0.1:{PORT}',f'http://localhost:{PORT}'):
            return self.reply({'error':'Origin rejected'},403)
        try:
            length = int(self.headers.get('Content-Length','0'))
            if length>65536: raise ValueError('Request too large.')
            payload=json.loads(self.rfile.read(length) or '{}')
            routes={'/api/autopilot/start':start_autopilot,'/api/autopilot/resume':resume_autopilot,'/api/autopilot/command':autopilot_command,'/api/train':start_training,'/api/viewer':start_viewer,'/api/evaluate':start_evaluation,'/api/benchmark':start_benchmark}
            if self.path=='/api/stop': result=stop_training(payload.get('env_id'))
            elif self.path in routes: result=routes[self.path](payload)
            else: return self.reply({'error':'Not found'},404)
            self.reply(result)
        except Exception as e: self.reply({'error':str(e)},400)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--open',action='store_true')
    a=p.parse_args()
    ROOT.joinpath('state').mkdir(exist_ok=True)
    try:
        server=ThreadingHTTPServer(('127.0.0.1',PORT),Handler)
    except OSError:
        import urllib.request
        try:
            with urllib.request.urlopen(f'http://127.0.0.1:{PORT}/api/state',timeout=2) as response:
                existing=json.load(response)
            if 'official_pretrained' not in existing: raise RuntimeError('Port 8765 belongs to another app.')
            webbrowser.open(f'http://127.0.0.1:{PORT}/')
            sys.exit(0)
        except Exception:
            print('Port 8765 is busy with another app. Close that app and reopen this launcher.')
            sys.exit(1)
    print(f'HumanoidBench Control Center: http://127.0.0.1:{PORT}/',flush=True)
    if a.open: webbrowser.open(f'http://127.0.0.1:{PORT}/')
    try: server.serve_forever()
    except KeyboardInterrupt: server.server_close()
