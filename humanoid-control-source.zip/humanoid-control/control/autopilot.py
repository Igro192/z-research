"""Persistent scheduler for independent official PPO skills. No environment/task logic."""
import argparse
import fcntl
import math
import os
from pathlib import Path
import signal
import subprocess
import time
import uuid
import psutil
from .common import ROOT,REPO,PYTHON,SKILLS,REPORTS,PRIMARY,now,read_json,write_json,checkpoint_entries,checked_checkpoint
from .models import register,retain

SESSIONS=ROOT/'state/sessions'
POINTER=ROOT/'state/autopilot-latest.json'
PRESETS={'quick':250000,'medium':1000000,'serious':5000000}

def alive(pid,created):
    try:
        p=psutil.Process(pid)
        return abs(p.create_time()-created)<.1 and p.is_running() and p.status()!=psutil.STATUS_ZOMBIE
    except (psutil.Error,ValueError):return False

def snapshot():
    pointer=read_json(POINTER,{})
    if not pointer:return {}
    s=read_json(pointer['session'],{})
    if not s:return {}
    s['active']=alive(s.get('supervisor_pid',-1),s.get('supervisor_created',0))
    if not s['active']:
        s['sleep_prevention']='Inactive'
        if s['state'] in ('Running','Stopping safely'):
            s['state']='Paused'
            s['recovery_note']='Supervisor ended; resume restores each latest valid checkpoint in fresh environments.'
            for skill in s['skills'].values():
                if skill['status']=='Training':skill['status']='Paused'
                run=skill.get('last_run')
                cp=read_json(Path(run)/'status.json',{}).get('checkpoint') if run else skill.get('latest_checkpoint')
                if cp:
                    try:
                        _,meta=checked_checkpoint(cp);skill.update(latest_checkpoint=cp,current_steps=meta['training_steps'])
                    except (ValueError,OSError):pass
    return s

def create(payload):
    defaults=read_json(ROOT/'state/training-defaults.json',{})
    if not defaults.get('max_jobs'):raise ValueError('Run the strategy benchmark before Train All.')
    smoke=payload.get('purpose')=='autopilot-smoke'
    preset=payload.get('preset','quick');budget=PRESETS.get(preset,int(payload.get('steps_per_skill',250000)))
    if not 2048<=budget<=20000000:raise ValueError('Use 2048 to 20,000,000 environment steps per skill.')
    strategy=payload.get('strategy','balanced')
    if strategy not in ('balanced','sequential'):raise ValueError('Unknown scheduler strategy.')
    chunk=int(payload.get('chunk_steps',250000));evaluation=int(payload.get('evaluate_every',250000))
    if min(chunk,evaluation)<2048:raise ValueError('Chunks/evaluation intervals must be at least 2048 steps.')
    selected=payload.get('skills',list(PRIMARY)) if smoke else list(PRIMARY)
    if not selected or any(n not in PRIMARY for n in selected):raise ValueError('Choose official primary G1 skills.')
    num_envs=int(payload.get('num_envs',defaults['num_envs'])) if smoke else defaults['num_envs']
    max_jobs=int(payload.get('max_jobs',defaults['max_jobs'])) if smoke else defaults['max_jobs']
    assert num_envs in (1,2,4,8) and max_jobs in (1,2)
    sid=time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]
    path=SESSIONS/sid/'session.json';path.parent.mkdir(parents=True,exist_ok=False)
    entries=checkpoint_entries();skills={}
    for name,task in PRIMARY.items():
        env_id=f'g1-{task}-v0';cp=None;initial=0;wall=0
        if name in selected and payload.get('continue_latest',True):
            for e in entries:
                if e['task']==env_id:
                    try:cp,meta=checked_checkpoint(e['checkpoint']);initial=meta['training_steps'];wall=meta.get('wall_clock_training_seconds',0);break
                    except (ValueError,OSError):continue
        target=math.ceil(budget/(2048*num_envs))*(2048*num_envs) if name in selected else 0
        skills[name]=dict(name=name,env_id=env_id,status=('Finished budget' if initial>=target and target else 'Not started'),
                    current_steps=initial,initial_steps=initial,requested_steps=budget if name in selected else 0,target_steps=target,
                    latest_checkpoint=str(cp) if cp else None,best_checkpoint=None,training_reward=None,evaluation_reward=None,
                    episode_length=None,success=None,elapsed_training_seconds=wall,retries=0,error=None,error_history=[],last_run=None)
    order=[n for n in (['Walk','Stand','Run','Crawl','Hurdle','Stair','Balance'] if strategy=='balanced' else list(PRIMARY)) if n in selected]
    s=dict(id=sid,path=str(path),state='Ready',preset=preset,purpose='autopilot-smoke' if smoke else 'autopilot',created_at=now(),
           selected_skills=selected,skills=skills,queue=order,strategy=strategy,chunk_steps=chunk,evaluate_every=evaluation,
           num_envs=num_envs,max_jobs=max_jobs,retry_limit=1,elapsed_seconds=0,active_jobs=[],sleep_prevention='Inactive',
           supervisor_pid=-1,supervisor_created=0,fail_before_training=payload.get('fail_before_training',[]) if smoke else [],
           estimated_rate=defaults['aggregate_steps_per_second'],events=[])
    write_json(path,s);write_json(POINTER,dict(session=str(path)));return path

def command(action,skill=None):
    s=snapshot()
    if not s:raise ValueError('No Train All session yet.')
    path=Path(s['path'])
    if action not in ('stop','pause','resume'):raise ValueError('Unknown session action.')
    if skill and skill not in s['skills']:raise ValueError('Unknown skill.')
    if not s['active']:return dict(message='Session is stopped. Use Resume All to restart its backend.')
    write_json(path.parent/'commands'/f'{time.time_ns()}-{uuid.uuid4().hex[:6]}.json',dict(action=action,skill=skill))
    return dict(message='Safe stop requested; current updates will finish and save.' if action in ('stop','pause') else 'Resume queued.')

class Supervisor:
    def __init__(self,path):
        self.path=Path(path);self.s=read_json(path);self.active={};self.stop_all=False;self.caffeinate=None
        self.started=time.monotonic();self.previous_elapsed=self.s.get('elapsed_seconds',0)
        self.swap_start=psutil.swap_memory().sout;self.last_save=0
        self.env=os.environ.copy();self.env.update(PYTHONPATH=str(ROOT),JAX_PLATFORMS='cpu',WANDB_MODE='disabled',OMP_NUM_THREADS='4',PYTHONUNBUFFERED='1');self.env.pop('MUJOCO_GL',None)
        signal.signal(signal.SIGINT,lambda *a:self.request_stop())
        signal.signal(signal.SIGTERM,lambda *a:self.request_stop())

    def request_stop(self):
        self.stop_all=True;self.s['state']='Stopping safely'
        for job in self.active.values():job['stop_pending']=True

    def recover(self):
        for name,k in self.s['skills'].items():
            run=k.get('last_run')
            if run:
                status=read_json(Path(run)/'status.json',{})
                pid=k.get('worker_pid');created=k.get('worker_created',0)
                if pid and alive(pid,created):
                    raise RuntimeError('A prior worker is still active. Stop it safely before resuming this session.')
                candidates=sorted(Path(run).glob('checkpoints/*/policy.zip'),key=lambda p:p.parent.name,reverse=True)
                for cp in candidates:
                    try:
                        _,m=checked_checkpoint(cp)
                        k.update(latest_checkpoint=str(cp),current_steps=m['training_steps'],elapsed_training_seconds=m.get('wall_clock_training_seconds',0));break
                    except (ValueError,OSError):pass
            if k.get('latest_checkpoint'):
                try:
                    _,m=checked_checkpoint(k['latest_checkpoint']);k['current_steps']=m['training_steps']
                except (ValueError,OSError):k['error']='Latest checkpoint missing or checksum invalid.';k['status']='Failed';continue
            if k['status'] not in ('Failed','Finished budget'):
                k['status']='Finished budget' if k['target_steps'] and k['current_steps']>=k['target_steps'] else ('Paused' if self.s.get('resume_only') and name not in self.s['resume_only'] else 'Not started')
        self.s['queue']=[n for n in self.s.get('resume_only',self.s['selected_skills']) if self.s['skills'][n]['status']=='Not started']
        if self.s['strategy']=='balanced':
            order=['Walk','Stand','Run','Crawl','Hurdle','Stair','Balance']
            self.s['queue'].sort(key=lambda n:(self.s['skills'][n]['current_steps']-self.s['skills'][n]['initial_steps'],order.index(n)))

    def launch(self,name):
        k=self.s['skills'][name];remaining=k['target_steps']-k['current_steps']
        quantum=2048*self.s['num_envs'];limit=min(self.s['chunk_steps'] if self.s['strategy']=='balanced' else self.s['evaluate_every'],self.s['evaluate_every'])
        steps=min(remaining,math.ceil(limit/quantum)*quantum)
        run=SKILLS/name/'runs'/(time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:8]);run.mkdir(parents=True,exist_ok=False)
        cfg=dict(env_id=k['env_id'],operation='resume' if k['latest_checkpoint'] else 'new',checkpoint=k['latest_checkpoint'],
                 run_dir=str(run),steps=steps,num_envs=self.s['num_envs'],allow_env_resize=True,seed=7,checkpoint_every=100000,
                 vectorization='subproc',purpose='autopilot',session_id=self.s['id'],parent_wall_seconds=k['elapsed_training_seconds'],created_at=now())
        write_json(run/'config.json',cfg)
        cmd=[str(PYTHON),'-m','control.train','--config',str(run/'config.json')]
        if name in self.s.get('fail_before_training',[]):cmd=[str(PYTHON),'-c',"raise RuntimeError('Intentional wrapper-only failure-handling smoke test')"]
        with (run/'training.log').open('w') as f:p=subprocess.Popen(cmd,cwd=REPO,env=self.env,stdout=f,stderr=subprocess.STDOUT)
        k.update(status='Training',last_run=str(run),worker_pid=p.pid,worker_created=psutil.Process(p.pid).create_time())
        self.active[name]=dict(process=p,run=run,stage='train',start=time.monotonic(),stop_pending=False,stop_sent=False,start_steps=k['current_steps'])
        self.s['events'].append(dict(event='train_started',skill=name,requested_chunk=steps,time=now()))

    def finish_train(self,name,job):
        k=self.s['skills'][name];status=read_json(job['run']/'status.json',{})
        cp=status.get('checkpoint')
        if cp:
            try:
                _,m=checked_checkpoint(cp);register(cp)
                k.update(latest_checkpoint=cp,current_steps=m['training_steps'],elapsed_training_seconds=m.get('wall_clock_training_seconds',k['elapsed_training_seconds']),training_reward=m['metrics']['average_reward'],episode_length=m['metrics']['average_episode_length'],success=m['metrics']['success'])
            except (ValueError,OSError) as e:k['error']=str(e)
        if job['process'].returncode or status.get('state') not in ('completed','stopped safely'):
            if k.get('latest_checkpoint'):
                _,previous=checked_checkpoint(k['latest_checkpoint']);k['current_steps']=previous['training_steps']
            else:k['current_steps']=0
            error=(job['run']/'training.log').read_text(errors='replace')
            k['error']=error;k['error_history'].append(dict(error=error,log=str(job['run']/'training.log'),time=now()))
            k['retries']+=1;k['status']='Not started' if k['retries']<=self.s['retry_limit'] and not self.stop_all else 'Failed'
            if k['status']=='Not started':self.s['queue'].append(name)
            self.s['events'].append(dict(event='training_failed',skill=name,retries=k['retries'],time=now()))
            del self.active[name];return
        if self.stop_all or job['stop_pending']:
            k['status']='Finished budget' if k['current_steps']>=k['target_steps'] else 'Paused'
            del self.active[name];return
        # Finite chunks close training workers before deterministic official evaluation.
        report=Path(k['latest_checkpoint']).parent/('evaluation-'+uuid.uuid4().hex[:8]+'.json')
        with report.with_suffix('.log').open('w') as f:p=subprocess.Popen([str(PYTHON),'-m','control.evaluate','--env',k['env_id'],'--checkpoint',k['latest_checkpoint'],'--report',str(report)],cwd=REPO,env=self.env,stdout=f,stderr=subprocess.STDOUT)
        self.active[name]=dict(process=p,run=job['run'],stage='evaluate',report=report,start=time.monotonic(),stop_pending=False)
        k['worker_pid']=p.pid;k['worker_created']=psutil.Process(p.pid).create_time()

    def finish_evaluation(self,name,job):
        k=self.s['skills'][name];result=read_json(job['report'])
        if job['process'].returncode or not result:
            error=job['report'].with_suffix('.log').read_text(errors='replace');k['error']=error
            k['error_history'].append(dict(error=error,log=str(job['report'].with_suffix('.log')),time=now()))
            k['status']='Failed';self.s['events'].append(dict(event='evaluation_failed',skill=name,time=now()))
        else:
            index=read_json(ROOT/'state/model-index.json',{'tasks':{}})['tasks'].get(k['env_id'],{})
            k.update(evaluation_reward=result['average_reward'],episode_length=result['average_episode_length'],success=result['success'],best_checkpoint=index.get('best'),last_evaluation=result,evaluation_wall_seconds=time.monotonic()-job['start'])
            retain(k['env_id'])
            k['status']='Finished budget' if k['current_steps']>=k['target_steps'] else ('Paused' if self.stop_all or job['stop_pending'] else 'Not started')
            if k['status']=='Not started':
                if self.s['strategy']=='sequential':self.s['queue'].insert(0,name)
                else:self.s['queue'].append(name)
            self.s['events'].append(dict(event='evaluation_completed',skill=name,time=now()))
        del self.active[name]

    def commands(self):
        for path in sorted(self.path.parent.glob('commands/*.json')):
            c=read_json(path,{})
            if c.get('action')=='stop':self.request_stop()
            elif c.get('skill'):
                name=c['skill'];k=self.s['skills'][name]
                if c['action']=='pause':
                    if name in self.active:self.active[name]['stop_pending']=True
                    else:k['status']='Paused'
                    self.s['queue']=[n for n in self.s['queue'] if n!=name]
                elif c['action']=='resume' and name not in self.active and k['current_steps']<k['target_steps']:
                    k.update(status='Not started',retries=0,error=None)
                    if name not in self.s['queue']:self.s['queue'].append(name)
            path.unlink()

    def save(self):
        elapsed=self.previous_elapsed+time.monotonic()-self.started
        self.s.update(elapsed_seconds=elapsed,updated_at=now(),active_jobs=[dict(skill=n,stage=j['stage'],pid=j['process'].pid) for n,j in self.active.items()],
                      sleep_prevention='Active' if self.caffeinate and self.caffeinate.poll() is None else 'Inactive',
                      completed_steps=sum(min(k['current_steps'],k['target_steps']) for k in self.s['skills'].values()),
                      requested_total_steps=sum(k['requested_steps'] for k in self.s['skills'].values()),
                      allocated_total_steps=sum(k['target_steps'] for k in self.s['skills'].values()),
                      aggregate_throughput=sum(max(0,k['current_steps']-k['initial_steps']) for k in self.s['skills'].values())/max(elapsed,.01))
        remain=sum(max(0,k['target_steps']-k['current_steps']) for k in self.s['skills'].values() if k['status']!='Failed')
        self.s['estimated_remaining_seconds']=remain/max(1,self.s['estimated_rate'])
        write_json(self.path,self.s)

    def main(self):
        with self.path.with_suffix('.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            self.recover();self.s.update(state='Running',supervisor_pid=os.getpid(),supervisor_created=psutil.Process().create_time())
            self.caffeinate=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            self.s['caffeinate_pid']=self.caffeinate.pid
            self.save()
            try:
                while True:
                    self.commands()
                    for name,job in list(self.active.items()):
                        if job['stage']=='train':
                            status=read_json(job['run']/'status.json',{})
                            k=self.s['skills'][name]
                            if 'training_steps' in status:k.update(current_steps=status['training_steps'],training_reward=status.get('average_reward'),episode_length=status.get('average_episode_length'),success=status.get('success'))
                            if job['stop_pending'] and not job['stop_sent'] and status.get('state') in ('training','stopping: completing current PPO update'):
                                job['process'].send_signal(signal.SIGTERM);job['stop_sent']=True
                        if job['process'].poll() is not None:
                            if job['stage']=='train':self.finish_train(name,job)
                            else:self.finish_evaluation(name,job)
                    if psutil.virtual_memory().available<4*1024**3 or psutil.swap_memory().sout-self.swap_start>128*1024**2:
                        if not self.stop_all:
                            self.s['pause_reason']='Memory reserve/swap guard requested a safe stop. Free memory before resuming.';self.request_stop()
                    if not self.stop_all:
                        while len(self.active)<self.s['max_jobs'] and self.s['queue']:
                            name=self.s['queue'].pop(0);k=self.s['skills'][name]
                            if name not in self.active and k['status']=='Not started' and k['current_steps']<k['target_steps']:self.launch(name)
                    if not self.active and (self.stop_all or not self.s['queue']):
                        if self.stop_all:
                            self.s['state']='Paused'
                            for k in self.s['skills'].values():
                                if k['status']=='Not started' and k['target_steps']:k['status']='Paused'
                        else:self.s['state']='Completed with failures' if any(k['status']=='Failed' for k in self.s['skills'].values()) else ('Paused' if any(k['status']=='Paused' for k in self.s['skills'].values()) else 'Finished budget')
                        break
                    if time.monotonic()-self.last_save>1:self.save();self.last_save=time.monotonic()
                    time.sleep(.25)
            except BaseException:
                import traceback
                self.s['supervisor_error']=traceback.format_exc()
                self.request_stop()
                # Reap owned workers before releasing the sleep assertion or session lock.
                # Training signals are deferred until its safe-boundary handler is installed.
                for name,job in list(self.active.items()):
                    if job['stage']=='train':
                        while job['process'].poll() is None:
                            status=read_json(job['run']/'status.json',{})
                            if not job['stop_sent'] and status.get('state') in ('training','stopping: completing current PPO update'):
                                job['process'].send_signal(signal.SIGTERM);job['stop_sent']=True
                            time.sleep(.25)
                        self.finish_train(name,job)
                    else:
                        if job['process'].poll() is None:job['process'].terminate()
                        job['process'].wait();self.s['skills'][name]['status']='Paused';del self.active[name]
                self.s['state']='Paused'
                raise
            finally:
                if self.caffeinate:
                    self.caffeinate.terminate()
                    try:self.caffeinate.wait(3)
                    except subprocess.TimeoutExpired:self.caffeinate.kill();self.caffeinate.wait()
                self.save();self.s['sleep_prevention']='Inactive';write_json(self.path,self.s)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--session',required=True);Supervisor(p.parse_args().session).main()
