import argparse
from dataclasses import dataclass, asdict
import json
from pathlib import Path
import time
import threading
import sys

import mujoco
import mujoco.viewer
import numpy as np
from stable_baselines3 import PPO

from .common import make_official_env, checked_checkpoint, require_compatible, write_json, now

@dataclass
class HighLevelRequest:
    forward: float = 0.0
    turn: float = 0.0
    faster: bool = False
    enabled: bool = False  # Future command-conditioned policy adapter; baseline is fixed-task.

def run(env_id, checkpoint=None, seconds=0, report=None, paused=True, random_actions=False):
    env = make_official_env(env_id)
    obs, _ = env.reset(seed=0)
    raw = env.unwrapped
    policy = None
    if checkpoint:
        checkpoint, meta = checked_checkpoint(checkpoint)
        require_compatible(meta, env, 'resume')
        policy = PPO.load(checkpoint, device='cpu')
    state = {'paused': paused, 'reset': False, 'follow': True, 'contacts': False, 'com': False}
    request = HighLevelRequest()
    lock = threading.Lock()
    key_events = []
    def key_callback(key):
        with lock:
            key_events.append(key)
            if key in (32, 80): state['paused'] = not state['paused']
            elif key in (82, 259): state['reset'] = True
            elif key == 70: state['follow'] = not state['follow']
            elif key == 67: state['contacts'] = not state['contacts']
            elif key == 66: state['com'] = not state['com']
            elif key == 87: request.forward = 1.0
            elif key == 83: request.forward = -0.5
            elif key == 65: request.turn = -1.0
            elif key == 68: request.turn = 1.0
            elif key in (340, 344): request.faster = True
            elif key == 88: request.forward = request.turn = 0; request.faster = False
        # Requests are never mapped to joint positions or actuator controls.

    steps = 0
    applied = {'follow': True, 'contacts': None, 'com': None}
    start = time.monotonic()
    try:
        with mujoco.viewer.launch_passive(raw.model, raw.data, key_callback=key_callback,
                                         show_left_ui=True, show_right_ui=True) as viewer:
            with viewer.lock():
                viewer.cam.type = mujoco.mjtCamera.mjCAMERA_TRACKING
                viewer.cam.trackbodyid = raw.model.body('pelvis').id
                viewer.cam.distance = 3.2
                viewer.cam.elevation = -15
                viewer.cam.azimuth = 135
            print(f'NATIVE VIEWER: {env_id}; Space/P pause, R reset, F follow, C contacts, B center of mass.', flush=True)
            print('W/S/A/D command requests are preview only; fixed-task PPO does not consume commands.', flush=True)
            while viewer.is_running() and (not seconds or time.monotonic()-start < seconds):
                tick = time.monotonic()
                with lock:
                    flags = dict(state)
                    state['reset'] = False
                with viewer.lock():
                    if flags['reset']:
                        obs, _ = env.reset()
                    if not flags['paused']:
                        if policy is not None:
                            action, _ = policy.predict(obs, deterministic=True)
                        elif random_actions:
                            action = env.action_space.sample()
                        else:
                            action = np.zeros(env.action_space.shape, dtype=env.action_space.dtype)
                        obs, reward, terminated, truncated, info = env.step(action)
                        steps += 1
                        if not np.isfinite(obs).all():
                            raise RuntimeError('Official environment returned nonfinite observation.')
                        if terminated or truncated:
                            obs, _ = env.reset()
                    # Apply callback changes once so native panel controls also remain usable.
                    if flags['follow'] != applied['follow']:
                        viewer.cam.type = mujoco.mjtCamera.mjCAMERA_TRACKING if flags['follow'] else mujoco.mjtCamera.mjCAMERA_FREE
                    if flags['contacts'] != applied['contacts']:
                        viewer.opt.flags[mujoco.mjtVisFlag.mjVIS_CONTACTPOINT] = flags['contacts']
                        viewer.opt.flags[mujoco.mjtVisFlag.mjVIS_CONTACTFORCE] = flags['contacts']
                    if flags['com'] != applied['com']:
                        viewer.opt.flags[mujoco.mjtVisFlag.mjVIS_COM] = flags['com']
                    applied = {k: flags[k] for k in applied}
                viewer.sync()
                time.sleep(max(0, (raw.dt if not flags['paused'] else .02) - (time.monotonic()-tick)))
    finally:
        if report:
            error=sys.exc_info()[1]
            write_json(report, dict(task=env_id, robot=type(raw.robot).__name__, native_passive_viewer=True,
                       policy_reloaded=policy is not None, checkpoint=str(checkpoint) if checkpoint else None,
                       steps=steps, finite_state=bool(np.isfinite(raw.data.qpos).all()), key_events=key_events,
                       high_level_request=asdict(request), completed_at=now(),
                       error=str(error) if error and not isinstance(error,KeyboardInterrupt) else None))
        env.close()

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--env', default='g1-walk-v0')
    p.add_argument('--checkpoint')
    p.add_argument('--seconds', type=float, default=0)
    p.add_argument('--report')
    p.add_argument('--running', action='store_true')
    p.add_argument('--random', action='store_true')
    a = p.parse_args()
    run(a.env, a.checkpoint, a.seconds, a.report, not a.running, a.random)
