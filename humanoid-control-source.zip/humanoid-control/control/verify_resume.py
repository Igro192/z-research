"""Empirically verify only what SB3 actually saves/restores."""
import argparse
import numpy as np
from stable_baselines3 import PPO
from .common import make_official_env, checked_checkpoint, require_compatible, write_json, state_digest, now

def verify(checkpoint, report):
    path,meta=checked_checkpoint(checkpoint)
    env=make_official_env(meta['task'])
    try:
        require_compatible(meta,env,'resume')
        model=PPO.load(path,env=env,device='cpu',force_reset=True)
        reference=np.load(path.parent/'reload-reference.npz')
        action=model.predict(reference['observation'],deterministic=True)[0]
        assert np.array_equal(action,reference['action'])
        assert model.num_timesteps==meta['training_steps']
        assert model._n_updates==meta['updates']
        assert model.policy.optimizer.state_dict()['state']
        assert state_digest(model.policy.optimizer.state_dict())==meta['optimizer_sha256']
        assert state_digest(model.policy.state_dict())==meta['policy_sha256']
        result=dict(passed=True,checkpoint=str(path),policy_weights_verified=True,
                    identical_action_for_saved_observation=True,optimizer_values_verified=True,
                    timestep_counter=model.num_timesteps,ppo_update_counter=model._n_updates,
                    simulator_state_restored=False,subprocess_rng_restored=False,
                    bit_for_bit_continuation_claimed=False,
                    resume_semantics='SB3 model/optimizer/training state and counters restored; a fresh official environment is reset.',
                    verified_at=now())
        write_json(report,result)
        print(result,flush=True)
    finally: env.close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--checkpoint',required=True);p.add_argument('--report',required=True)
    a=p.parse_args();verify(a.checkpoint,a.report)
