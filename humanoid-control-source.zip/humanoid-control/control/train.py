"""External lifecycle wrapper around the pristine official SB3 PPO baseline.

Evaluates its actual PPO constructor and reuses its EpisodeLogCallback.
No policy optimizer, reward, task, actuator, or physics code is implemented here.
Resume restores SB3 training state and resets the environment; it is not bitwise replay.
"""
from collections import deque
import os
from pathlib import Path
import signal
import resource
import sys
import time
import uuid

import numpy as np
import torch
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.vec_env import DummyVecEnv, SubprocVecEnv

from .common import REPO, commit, now, read_json, write_json, checked_checkpoint, require_compatible, signature, sha256, state_digest

class StopAtBoundary(Exception):
    pass

def require_finite_state(model):
    for tensor in model.policy.state_dict().values():
        if not torch.isfinite(tensor).all():raise RuntimeError('PPO policy contains nonfinite parameters; preserving earlier valid checkpoints.')
    for state in model.policy.optimizer.state.values():
        for value in state.values():
            if isinstance(value,torch.Tensor) and not torch.isfinite(value).all():
                raise RuntimeError('PPO optimizer contains nonfinite state; preserving earlier valid checkpoints.')

class LocalLifecycle(BaseCallback):
    def __init__(self, run, config, env, parent, task_signature, success_bar):
        super().__init__()
        self.run, self.config, self.env, self.parent = run, config, env, parent
        self.stopping = False
        self.last_saved = -1
        self.last_checkpoint = None
        self.last_status = 0
        self.started = time.monotonic()
        self.start_steps = 0
        self.started_cpu = time.process_time()
        self.task_signature, self.success_bar = task_signature, success_bar
        self.update_times = []
        self.rollout_times = []
        self.episode_returns = deque(maxlen=100)
        self.episode_lengths = deque(maxlen=100)
        self.successes = deque(maxlen=100)

    def request_stop(self, *unused):
        self.stopping = True
        self.status('stopping: completing current PPO update')

    def metrics(self):
        return dict(average_reward=float(np.mean(self.episode_returns)) if self.episode_returns else None,
                    average_episode_length=float(np.mean(self.episode_lengths)) if self.episode_lengths else None,
                    success=float(np.mean(self.successes)) if self.successes else None)

    def status(self, state='training'):
        import psutil
        proc = psutil.Process()
        elapsed = max(time.monotonic()-self.started, .01)
        cpu_seconds = time.process_time()-self.started_cpu
        peak_rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        if sys.platform != 'darwin': peak_rss *= 1024
        write_json(self.run / 'status.json', dict(state=state, task=self.config['env_id'], algorithm='Official SB3 PPO',
                    pid=os.getpid(), training_steps=int(self.model.num_timesteps),
                    checkpoint=self.last_checkpoint, updated_at=now(),
                    fps=(self.model.num_timesteps-self.start_steps)/elapsed,
                    training_wall_seconds=elapsed, training_cpu_seconds=cpu_seconds,
                    process_cpu_percent=100*cpu_seconds/elapsed, peak_rss_bytes=peak_rss,
                    ppo_update_seconds_total=sum(self.update_times),
                    ppo_update_seconds_mean=float(np.mean(self.update_times)) if self.update_times else None,
                    ppo_update_seconds_samples=self.update_times, ppo_train_calls=len(self.update_times),
                    ppo_rollout_seconds_total=sum(self.rollout_times),
                    ram_mb=proc.memory_info().rss/1024**2, **self.metrics()))

    def save(self, reason):
        if self.last_saved == self.model.num_timesteps:
            return self.last_checkpoint
        require_finite_state(self.model)
        folder = self.run / 'checkpoints' / f'step-{self.model.num_timesteps:012d}-{uuid.uuid4().hex[:8]}'
        folder.mkdir(parents=True, exist_ok=False)
        self.model.save(folder / 'policy.zip')
        observation = self.model._last_obs.copy()
        action = self.model.predict(observation, deterministic=True)[0]
        np.savez(folder / 'reload-reference.npz', observation=observation, action=action)
        meta = dict(complete=True, task=self.config['env_id'], robot='Unitree G1',
                    algorithm='stable-baselines3 PPO 2.3.2 (official HumanoidBench baseline)',
                    training_steps=int(self.model.num_timesteps), updates=int(self.model._n_updates),
                    reward=self.metrics()['average_reward'], created_at=now(),
                    git_commit=commit(), signature=self.task_signature,
                    parent_checkpoint=self.parent, operation=self.config['operation'],
                    seed=self.config['seed'], num_envs=self.config['num_envs'],
                    vectorization=self.config.get('vectorization','subproc'),
                    reason=reason, purpose=self.config.get('purpose','research'),
                    skill=__import__('control.common',fromlist=['skill_for']).skill_for(self.config['env_id']),
                    environment=self.config['env_id'], session_id=self.config.get('session_id'),
                    wall_clock_training_seconds=self.config.get('parent_wall_seconds',0)+time.monotonic()-self.started,
                    milestones=[m for m in (100000,250000,500000,1000000,2000000,5000000,10000000,20000000)
                                if self.last_saved < m <= self.model.num_timesteps],
                    sha256=sha256(folder / 'policy.zip'), optimizer_sha256=state_digest(self.model.policy.optimizer.state_dict()),
                    policy_sha256=state_digest(self.model.policy.state_dict()),
                    resume_semantics='SB3 model, policy optimizer, PPO update count and timestep counter; environment resets on resume',
                    hyperparameters=dict(learning_rate=self.model.learning_rate, n_steps=self.model.n_steps,
                                         batch_size=self.model.batch_size, n_epochs=self.model.n_epochs,
                                         gamma=self.model.gamma, gae_lambda=self.model.gae_lambda,
                                         clip_range=0.2, ent_coef=self.model.ent_coef, vf_coef=self.model.vf_coef),
                    metrics=self.metrics())
        write_json(folder / 'metadata.json', meta)  # completion marker is committed last
        from .common import SKILLS
        if folder.is_relative_to(SKILLS):
            from .models import register
            register(folder/'policy.zip')
        self.last_saved = self.model.num_timesteps
        self.last_checkpoint = str(folder / 'policy.zip')
        print('CHECKPOINT ' + self.last_checkpoint, flush=True)
        return self.last_checkpoint

    def _on_training_start(self):
        self.started = time.monotonic()
        self.started_cpu = time.process_time()
        self.start_steps = self.model.num_timesteps
        self.last_saved = self.start_steps
        for ep in self.model.ep_info_buffer or []:
            self.episode_returns.append(ep['r'])
            self.episode_lengths.append(ep['l'])
        self.status()

    def _on_step(self):
        if not np.isfinite(self.locals['new_obs']).all() or not np.isfinite(self.locals['rewards']).all():
            raise RuntimeError('Official environment produced nonfinite observations/rewards.')
        for info in self.locals['infos']:
            if 'episode' in info:
                ep = info['episode']
                self.episode_returns.append(ep['r'])
                self.episode_lengths.append(ep['l'])
                if 'success' in info:
                    self.successes.append(float(info['success']))
                elif self.success_bar is not None:
                    self.successes.append(float(ep['r'] >= self.success_bar))
        if time.monotonic()-self.last_status > 2:
            self.status('stopping: completing current PPO update' if self.stopping else 'training')
            self.last_status = time.monotonic()
        return True

    def _on_rollout_start(self):
        # SB3 calls this after optimizing the preceding rollout.
        if self.model._n_updates and (self.stopping or self.model.num_timesteps-self.last_saved >= self.config['checkpoint_every']):
            self.save('safe stop' if self.stopping else 'automatic')
        if self.stopping:
            if self.model._n_updates:
                self.save('safe stop')
            raise StopAtBoundary()

    def _on_training_end(self):
        self.save('safe stop' if self.stopping else 'completed')
        self.status('stopped safely' if self.stopping else 'completed')

def run_local(args, official_episode_callback):
    config = read_json(args.control_config)
    run = Path(config['run_dir'])
    torch.set_num_threads(4)
    # Reproduce the official Monitor/1000-step TimeLimit factory using the public headless option.
    from .common import make_official_env
    from gymnasium.wrappers import TimeLimit
    from stable_baselines3.common.monitor import Monitor
    def make_env(rank):
        return lambda: Monitor(TimeLimit(make_official_env(args.env_name,args.seed+rank),1000))
    parent = config.get('checkpoint')
    operation = config['operation']
    # Inspect an official instance locally; MuJoCo model/data objects are not pickled across workers.
    reference = make_env(0)()
    try:
        task_signature = signature(reference)
        success_bar = getattr(reference.unwrapped.task,'success_bar',None)
        if parent:
            checkpoint, meta = checked_checkpoint(parent)
            require_compatible(meta, reference, operation)
    finally:
        reference.close()
    factories=[make_env(i) for i in range(args.num_envs)]
    env = DummyVecEnv(factories) if config.get('vectorization')=='dummy' else SubprocVecEnv(factories,start_method='spawn')
    original_train = PPO.train
    original_rollout = PPO.collect_rollouts
    try:
        if parent:
            model = PPO.load(checkpoint, env=env, device='cpu', force_reset=True)
            if operation == 'resume':
                if args.num_envs != meta['num_envs'] and not config.get('allow_env_resize'):
                    raise ValueError('Resume requires the original environment count.')
                if model.num_timesteps != meta['training_steps'] or model._n_updates != meta['updates']:
                    raise ValueError('SB3 did not restore timestep/update counters.')
                if state_digest(model.policy.optimizer.state_dict()) != meta['optimizer_sha256']:
                    raise ValueError('SB3 optimizer state differs from the saved state.')
                if state_digest(model.policy.state_dict()) != meta['policy_sha256']:
                    raise ValueError('SB3 policy state differs from the saved state.')
                write_json(run / 'resume-restored.json', dict(training_steps=model.num_timesteps,
                    updates=model._n_updates, optimizer_verified=True, policy_verified=True,
                    simulator_state_restored=False, subprocess_rng_restored=False,
                    bit_for_bit_continuation_claimed=False))
            else:
                # Initialise only compatible learned weights; retain an independent new optimizer.
                source = model
                model = official_model(args, env, run)
                if source.policy.net_arch != model.policy.net_arch or source.policy.activation_fn != model.policy.activation_fn:
                    raise ValueError('Policy architecture differs.')
                model.policy.load_state_dict(source.policy.state_dict())
                del source
        else:
            # Identical official constructor/defaults; CPU, deterministic seed and local logs added.
            model = official_model(args, env, run)
        model.set_logger(__import__('stable_baselines3.common.logger', fromlist=['configure']).configure(str(run / 'metrics'), ['stdout', 'csv', 'tensorboard']))
        lifecycle = LocalLifecycle(run, config, env, parent, task_signature, success_bar)
        lifecycle.model = model
        if globals().get('_early_stop',False):lifecycle.stopping=True
        # Time the unchanged SB3 update call. No optimizer or PPO hyperparameter is replaced.
        def timed_train(ppo):
            started=time.perf_counter()
            try:
                result=original_train(ppo)
                require_finite_state(ppo)
                return result
            finally:
                lifecycle.update_times.append(time.perf_counter()-started)
        PPO.train = timed_train
        def timed_rollout(ppo,*a,**kw):
            started=time.perf_counter()
            try:return original_rollout(ppo,*a,**kw)
            finally:lifecycle.rollout_times.append(time.perf_counter()-started)
        PPO.collect_rollouts=timed_rollout
        signal.signal(signal.SIGINT, lifecycle.request_stop)
        signal.signal(signal.SIGTERM, lifecycle.request_stop)
        try:
            model.learn(total_timesteps=args.max_steps, reset_num_timesteps=operation != 'resume',
                        log_interval=1, callback=[official_episode_callback(), lifecycle])
        except StopAtBoundary:
            lifecycle.status('stopped safely')
        except BaseException:
            # Preserve completed immutable checkpoints; never mark a partial update as successful.
            lifecycle.status('failed; use latest completed checkpoint')
            raise
    finally:
        PPO.train = original_train
        PPO.collect_rollouts = original_rollout
        env.close()


def official_model(args, env, run):
    """Execute the upstream PPO constructor without running its W&B/video lifecycle."""
    import ast
    from types import SimpleNamespace
    tree = ast.parse((REPO / 'ppo' / 'run_sb3_ppo.py').read_text())
    main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name=='main')
    call = next(n.value for n in main.body if isinstance(n, ast.Assign)
                and isinstance(n.value, ast.Call) and getattr(n.value.func,'id',None)=='PPO')
    # Only local output path, CPU selection and reproducible initialization differ.
    for keyword in call.keywords:
        if keyword.arg=='tensorboard_log': keyword.value=ast.Constant(str(run/'tensorboard'))
    call.keywords += [ast.keyword(arg='device',value=ast.Constant('cpu')),
                      ast.keyword(arg='seed',value=ast.Constant(args.seed))]
    expression=ast.fix_missing_locations(ast.Expression(call))
    return eval(compile(expression,str(REPO/'ppo'/'run_sb3_ppo.py'),'eval'),
                {'PPO':PPO,'env':env,'ARGS':args,'run':SimpleNamespace(id=run.name)})

if __name__=='__main__':
    import argparse
    import runpy
    import sys
    p=argparse.ArgumentParser()
    p.add_argument('--config',required=True)
    cli=p.parse_args()
    cfg=read_json(cli.config)
    def early_stop(*unused):
        globals()['_early_stop']=True
    signal.signal(signal.SIGINT,early_stop)
    signal.signal(signal.SIGTERM,early_stop)
    upstream=REPO/'ppo'/'run_sb3_ppo.py'
    sys.argv=[str(upstream),'--env_name',cfg['env_id'],'--seed',str(cfg['seed']),
              '--num_envs',str(cfg['num_envs']),'--max_steps',str(cfg['steps'])]
    official=runpy.run_path(str(upstream),run_name='humanoidbench_official_baseline')
    args=official['ARGS']
    args.control_config=cli.config  # Local wrapper object only; no patch or dependency in upstream code.
    run_local(args,official['EpisodeLogCallback'])
