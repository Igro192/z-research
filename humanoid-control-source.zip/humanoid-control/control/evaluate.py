import argparse
from pathlib import Path
import numpy as np
from stable_baselines3 import PPO
from .common import checked_checkpoint, require_compatible, make_official_env, write_json, now

def evaluate(env_id, checkpoint, episodes=3, report=None):
    path, meta = checked_checkpoint(checkpoint)
    env = make_official_env(env_id)
    try:
        require_compatible(meta, env, 'resume')
        model = PPO.load(path, env=env, device='cpu')
        results = []
        for i in range(episodes):
            obs, _ = env.reset(seed=100+i)
            total, length = 0., 0
            while True:
                action, _ = model.predict(obs, deterministic=True)
                obs, reward, terminated, truncated, info = env.step(action)
                if not np.isfinite(obs).all(): raise ValueError('Nonfinite observation.')
                total += float(reward)
                length += 1
                if terminated or truncated: break
            success = info.get('success')
            bar = getattr(env.unwrapped.task, 'success_bar', None)
            if success is None and bar is not None: success = float(total >= bar)
            results.append(dict(reward=total, length=length, success=success))
        valid = [r['success'] for r in results if r['success'] is not None]
        output = dict(task=env_id, checkpoint=str(path), training_steps=meta['training_steps'],
                      average_reward=float(np.mean([r['reward'] for r in results])),
                      average_episode_length=float(np.mean([r['length'] for r in results])),
                      success=float(np.mean(valid)) if valid else None,
                      success_definition='terminal info.success when available, otherwise official task.success_bar episode return',
                      episodes=results, evaluated_at=now())
        from .models import record_evaluation
        record_evaluation(path,output)
        if report: write_json(report, output)
        print(output, flush=True)
        return output
    finally:
        env.close()

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--env', required=True)
    p.add_argument('--checkpoint', required=True)
    p.add_argument('--episodes', type=int, default=3)
    p.add_argument('--report', required=True)
    a = p.parse_args()
    evaluate(a.env, a.checkpoint, a.episodes, a.report)
