"""Executed environment/asset probes; failures stay visible and disabled."""
import importlib.metadata
import sys
import traceback
from pathlib import Path
import numpy as np
import gymnasium as gym
import humanoid_bench
import mujoco
from .common import ROOT, REPO, SKILLS, REPORTS, PRIMARY, MJPYTHON, commit, signature, make_official_env, now, write_json

def main(env_ids=None):
    for name in (*PRIMARY, 'Other'):
        (SKILLS/name/'runs').mkdir(parents=True, exist_ok=True)
    tasks=[]
    for env_id in sorted(k for k in gym.registry if k.startswith('g1-')):
        if env_ids and env_id not in env_ids: continue
        env=None
        item={'env_id':env_id,'status':'failed','tested_at':now()}
        try:
            env=make_official_env(env_id,17)
            obs, _=env.reset(seed=17)
            item.update(robot=type(env.unwrapped.robot).__name__,
                        observation_dimensions=int(np.prod(env.observation_space.shape)),
                        action_dimensions=int(np.prod(env.action_space.shape)),
                        model_file=env.unwrapped.fullpath, signature=signature(env))
            initial_time=float(env.unwrapped.data.time)
            count=0
            for _ in range(100):
                obs,reward,terminated,truncated,info=env.step(env.action_space.sample())
                assert np.isfinite(obs).all() and np.isfinite(reward)
                count+=1
                if terminated or truncated: obs,_=env.reset()
            item.update(status='passes', random_action_steps=count,
                        success_bar=getattr(env.unwrapped.task,'success_bar',None))
        except Exception as e:
            item.update(error=str(e), traceback=traceback.format_exc())
        finally:
            if env is not None: env.close()
        tasks.append(item)
        write_json(REPORTS/'tasks.json',tasks)
        print(env_id,item['status'],item.get('error',''),flush=True)
    write_json(REPORTS/'diagnostics.json',dict(python_version=sys.version.split()[0],
               python_executable=sys.executable,python_base_prefix=sys.base_prefix,
               python_provider='Homebrew Python 3.11 framework; standard venv (not uv)',
               mujoco_version=mujoco.__version__,mjpython_path=str(MJPYTHON),
               passive_viewer_passes=__import__('json').loads((REPORTS/'native-preflight.json').read_text())['passive_viewer'],
               humanoidbench_commit=commit(),ppo_version=importlib.metadata.version('stable-baselines3'),
               algorithm='Official HumanoidBench Stable-Baselines3 PPO',diagnosed_at=now()))
    policies=[]
    for folder,obs,task in [('reach_one_hand',55,'one-hand reaching'),('reach_two_hands',61,'two-hand reaching')]:
        base=REPO/'data'/folder
        mean=np.load(base/'mean.npy')
        var=np.load(base/'var.npy')
        import torch
        weights=torch.load(base/'torch_model.pt',map_location='cpu',weights_only=True)
        policies.append(dict(name='Official H1/H1-hand '+folder,task=task,algorithm='MJX PPO low-level reaching (PyTorch export)',
                        policy_path=str(base/'torch_model.pt'),mean_path=str(base/'mean.npy'),var_path=str(base/'var.npy'),
                        observation_dimensions=obs,action_dimensions=19,mean_shape=list(mean.shape),var_shape=list(var.shape),
                        state_dict_keys=list(weights.keys()),compatible_with_g1=False,
                        compatibility='H1 low-level reaching policy. Official hierarchical wrappers require H1/H1Hand/H1Touch; incompatible with the G1 robot/actuator layout; 87/37 are G1 Walk dimensions. Not an SB3 locomotion checkpoint.',
                        source='official repository data directory',training_steps=None,reward=None,created_at=None))
    write_json(REPORTS/'official-pretrained.json',policies)

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--env',action='append')
    main(parser.parse_args().env)
