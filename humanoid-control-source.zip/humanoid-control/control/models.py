"""Checkpoint annotations/evaluation history; policy files stay immutable."""
from contextlib import contextmanager
import fcntl
import math
from pathlib import Path
import shutil
from .common import ROOT,SKILLS,read_json,write_json,checked_checkpoint,now

INDEX=ROOT/'state/model-index.json'
@contextmanager
def locked():
    INDEX.parent.mkdir(exist_ok=True)
    with INDEX.with_suffix('.lock').open('a') as f:
        fcntl.flock(f,fcntl.LOCK_EX)
        index=read_json(INDEX,{'tasks':{},'evaluations':[]})
        yield index
        write_json(INDEX,index)

def register(path):
    cp,meta=checked_checkpoint(path)
    with locked() as index:
        entry=index['tasks'].setdefault(meta['task'],{'best_history':[]})
        entry['latest']=str(cp)

def record_evaluation(path,result):
    cp,meta=checked_checkpoint(path)
    assert math.isfinite(result['average_reward'])
    success=result.get('success')
    score=[float(success) if success is not None else -1.,float(result['average_reward'])]
    with locked() as index:
        task=index['tasks'].setdefault(meta['task'],{'best_history':[]})
        item=dict(checkpoint=str(cp),task=meta['task'],**{k:v for k,v in result.items() if k not in ('checkpoint','task')})
        index['evaluations'].append(item)
        if task.get('best_score') is None or score>task['best_score']:
            if task.get('best') and task['best']!=str(cp):task['best_history'].append(task['best'])
            task.update(best=str(cp),best_score=score,best_evaluation=item)
        task['last_evaluation']=item

def annotations(path,task):
    index=read_json(INDEX,{'tasks':{},'evaluations':[]});t=index['tasks'].get(task,{})
    ev=next((e for e in reversed(index['evaluations']) if e['checkpoint']==str(path)),None)
    return dict(is_latest=t.get('latest')==str(path),is_best_evaluated=t.get('best')==str(path),evaluation=ev)

def retain(task):
    """Prune only unattended routine checkpoints; preserve milestone/best/stop history."""
    from .common import checkpoint_entries
    entries=[e for e in checkpoint_entries() if e['task']==task and e.get('purpose')=='autopilot']
    t=read_json(INDEX,{'tasks':{}})['tasks'].get(task,{})
    keep={t.get('latest'),t.get('best'),*t.get('best_history',[])[-3:]}
    keep.update(e['checkpoint'] for e in entries[:3])
    for e in entries:
        if e.get('milestones') or e.get('reason')=='safe stop':keep.add(e['checkpoint'])
    for e in entries:
        if e['checkpoint'] in keep:continue
        folder=Path(e['checkpoint']).parent
        # Persist metadata for ancestry/audit even when a redundant routine policy is retired.
        write_json(folder.parents[2]/'retired'/f'{folder.name}.json',dict(e,retired_at=now(),retirement_reason='routine checkpoint retention',model_available=False))
        if folder.is_relative_to(SKILLS) and folder.name.startswith('step-'):shutil.rmtree(folder)
