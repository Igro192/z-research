"""Run only small PPO updates and the real native viewer. Never a long training job."""
import argparse
import os
from pathlib import Path
import subprocess
import time
import traceback

from .common import ROOT, REPO, PYTHON, MJPYTHON, REPORTS, read_json, write_json, now, checkpoint_entries, sha256
from .server import start_training, stop_training, processes

def command(args, log):
    env=os.environ.copy()
    env.update(PYTHONPATH=str(ROOT),JAX_PLATFORMS='cpu',WANDB_MODE='disabled',PYTHONUNBUFFERED='1')
    env.pop('MUJOCO_GL',None)
    with Path(log).open('w') as stream:
        proc=subprocess.run(args,cwd=REPO,env=env,stdout=stream,stderr=subprocess.STDOUT)
    if proc.returncode: raise RuntimeError(f'Failed with exit {proc.returncode}: {log}')

def wait_training(job, stop=False):
    started=time.monotonic()
    requested=False
    config=read_json(Path(job['run_dir'])/'config.json')
    parent=config.get('checkpoint')
    initial_steps=read_json(Path(parent).parent/'metadata.json')['training_steps'] if parent else 0
    while True:
        jobs=processes()
        current=next(j for j in jobs if j['pid']==job['pid'])
        status=read_json(Path(job['run_dir'])/'status.json',{})
        if stop and status.get('training_steps',0)>initial_steps and not requested and current['active']:
            stop_training()
            requested=True
        if not current['active']:
            if status.get('state') not in ('completed','stopped safely'):
                raise RuntimeError(f'Training failed: {job["log"]}; status={status}')
            if stop and status['state']!='stopped safely': raise AssertionError('Safe stop did not occur.')
            return status
        if time.monotonic()-started > 600: raise TimeoutError('Short PPO update exceeded 10 minutes. Inspect logs before proceeding.')
        time.sleep(2)

def main(skip_initial_viewer=False):
    report=dict(passed=False,task='g1-walk-v0',started_at=now(),tests={},long_training_started=False)
    target=REPORTS/'smoke-test.json'
    def passed(name,details=True):
        report['tests'][name]=details
        write_json(target,report)
        print('PASS '+name,flush=True)
    try:
        tasks=read_json(REPORTS/'tasks.json',[])
        walk=next(t for t in tasks if t['env_id']=='g1-walk-v0')
        assert walk['status']=='passes'
        passed('official_environment_load_and_random_actions',walk)
        if not skip_initial_viewer:
            command([str(MJPYTHON),'-m','control.play','--env','g1-walk-v0','--running','--random',
                     '--seconds','20','--report',str(REPORTS/'g1-native-random.json')],REPORTS/'g1-native-random.log')
            native=read_json(REPORTS/'g1-native-random.json')
            assert native['native_passive_viewer'] and native['steps']>100
            passed('g1_native_viewer_random_physics',native)
        else:
            passed('g1_native_viewer_random_physics',read_json(REPORTS/'g1-native-random.json'))
        job=start_training(dict(env_id='g1-walk-v0',operation='new',steps=2048,seed=7,purpose='smoke-test'))
        status=wait_training(job)
        path=status['checkpoint']
        original_hash=sha256(path)
        meta=read_json(Path(path).parent/'metadata.json')
        assert meta['training_steps']==2048 and meta['updates']>0
        passed('official_ppo_update_and_checkpoint',meta)
        command([str(PYTHON),'-m','control.verify_resume','--checkpoint',path,'--report',str(REPORTS/'resume-validation.json')],REPORTS/'resume-validation.log')
        passed('checkpoint_reload_policy_optimizer_counters',read_json(REPORTS/'resume-validation.json'))
        resumed=start_training(dict(env_id='g1-walk-v0',operation='resume',steps=2048,checkpoint=path,purpose='smoke-test'))
        resumed_status=wait_training(resumed)
        assert resumed_status['training_steps']==4096
        passed('resume_training_continues_to_4096',resumed_status)
        reloaded=resumed_status['checkpoint']
        command([str(PYTHON),'-m','control.evaluate','--env','g1-walk-v0','--checkpoint',reloaded,
                 '--report',str(REPORTS/'policy-evaluation.json')],REPORTS/'policy-evaluation.log')
        passed('headless_saved_policy_evaluation',read_json(REPORTS/'policy-evaluation.json'))
        command([str(MJPYTHON),'-m','control.play','--env','g1-walk-v0','--checkpoint',reloaded,
                 '--running','--seconds','20','--report',str(REPORTS/'g1-native-policy.json')],REPORTS/'g1-native-policy.log')
        native=read_json(REPORTS/'g1-native-policy.json')
        assert native['policy_reloaded'] and native['steps']>100
        passed('native_viewer_reloaded_policy',native)
        assert sha256(path)==original_hash
        assert Path(path).is_file() and Path(reloaded).is_file()
        passed('parent_checkpoint_preserved',dict(checkpoint=path,sha256=original_hash))
        report.update(passed=True,finished_at=now(),ready_task='g1-walk-v0',
                      example_checkpoint=resumed_status['checkpoint'],
                      note='Infrastructure smoke tests only. These short policies are not trained locomotion skills.')
        write_json(target,report)
        print('SMOKE TEST PASSED',flush=True)
    except BaseException:
        report.update(error=traceback.format_exc(),failed_at=now())
        write_json(target,report)
        raise

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--skip-initial-viewer',action='store_true')
    main(p.parse_args().skip_initial_viewer)
