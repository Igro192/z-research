"""Double-click launcher; reuse the local server or start it without a terminal."""
import json
import os
import subprocess
import time
import urllib.request
import webbrowser
from .common import ROOT, PYTHON

URL='http://127.0.0.1:8765/'

def ready():
    try:
        with urllib.request.urlopen(URL+'api/state',timeout=1) as response:
            value=json.load(response)
        return value.get('workspace')==str(ROOT) and 'diagnostics' in value
    except (OSError,ValueError): return False

def main():
    if not ready():
        state=ROOT/'state'
        state.mkdir(exist_ok=True)
        env=os.environ.copy()
        env.update(PYTHONPATH=str(ROOT),JAX_PLATFORMS='cpu',PYTHONUNBUFFERED='1')
        with (state/'control-center.log').open('a') as stream:
            proc=subprocess.Popen([str(PYTHON),'-m','control.server'],cwd=ROOT,env=env,
                                  stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        for _ in range(30):
            if ready(): break
            if proc.poll() is not None:
                raise RuntimeError('Control Center could not start. See state/control-center.log.')
            time.sleep(.25)
        else: raise RuntimeError('Control Center startup timed out. See state/control-center.log.')
    webbrowser.open(URL)
    print('HumanoidBench Control Center: '+URL)

if __name__=='__main__': main()
