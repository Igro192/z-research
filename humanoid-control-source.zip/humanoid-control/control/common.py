from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import json
import os
from pathlib import Path
import subprocess
import uuid

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / 'vendor' / 'humanoid-bench'
PYTHON = ROOT / 'runtime' / 'python311' / 'bin' / 'python'
MJPYTHON = ROOT / 'runtime' / 'python311' / 'bin' / 'mjpython'
SKILLS = ROOT / 'skills'
REPORTS = ROOT / 'reports'
PRIMARY = {'Stand': 'stand', 'Walk': 'walk', 'Run': 'run', 'Crawl': 'crawl',
           'Hurdle': 'hurdle', 'Stair': 'stair', 'Balance': 'balance_simple'}

def now():
    return datetime.now(ZoneInfo('Asia/Almaty')).isoformat()

def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name('.' + path.name + '.' + uuid.uuid4().hex)
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False))
    os.replace(tmp, path)

def read_json(path, fallback=None):
    try:
        return json.loads(Path(path).read_text())
    except (OSError, ValueError):
        return fallback

def commit():
    return subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip()

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def state_digest(value):
    """Stable digest of model/optimizer values, independent of serialization containers."""
    import numpy as np
    import torch
    digest = hashlib.sha256()
    def visit(x):
        if isinstance(x, dict):
            for k in sorted(x, key=repr):
                digest.update(repr(k).encode()); visit(x[k])
        elif isinstance(x, (tuple, list)):
            for v in x: visit(v)
        elif isinstance(x, torch.Tensor):
            a=x.detach().cpu().numpy()
            digest.update(str(a.dtype).encode()); digest.update(str(a.shape).encode()); digest.update(a.tobytes())
        elif isinstance(x, np.ndarray):
            digest.update(str(x.dtype).encode()); digest.update(str(x.shape).encode()); digest.update(x.tobytes())
        else: digest.update(repr(x).encode())
    visit(value)
    return digest.hexdigest()

def skill_for(env_id):
    task = env_id.removeprefix('g1-').removesuffix('-v0')
    return next((name for name, t in PRIMARY.items() if task == t),
                'Balance' if task.startswith('balance_') else 'Other')

def checkpoint_entries():
    entries = []
    for path in SKILLS.glob('*/runs/*/checkpoints/*/metadata.json'):
        data = read_json(path, {})
        if data.get('complete') and (path.parent / 'policy.zip').is_file():
            data['checkpoint'] = str(path.parent / 'policy.zip')
            from .models import annotations
            data.update(annotations(data['checkpoint'],data['task']))
            data.setdefault('skill',skill_for(data['task']))
            data.setdefault('environment',data['task'])
            data.setdefault('wall_clock_training_seconds',0)
            entries.append(data)
    return sorted(entries, key=lambda x: x['created_at'], reverse=True)

def checked_checkpoint(path):
    p = Path(path).resolve()
    if not p.is_relative_to(SKILLS.resolve()) or p.name != 'policy.zip':
        raise ValueError('Choose a checkpoint from this workspace skill library.')
    meta = read_json(p.parent / 'metadata.json')
    if not meta or not meta.get('complete') or sha256(p) != meta['sha256']:
        raise ValueError('Checkpoint is incomplete or its checksum changed.')
    return p, meta

def make_official_env(env_id, seed=0):
    import gymnasium as gym
    import humanoid_bench
    env = gym.make(env_id, render_mode=None)
    env.action_space.seed(seed)
    return env

def signature(env):
    import inspect
    import numpy as np
    raw = env.unwrapped
    def bounds(a):
        return [float(x) if np.isfinite(x) else ('inf' if x > 0 else '-inf') for x in a.flat]
    return dict(robot=type(raw.robot).__name__, observation_shape=list(env.observation_space.shape),
                observation_dtype=str(env.observation_space.dtype),
                observation_low=bounds(env.observation_space.low), observation_high=bounds(env.observation_space.high),
                action_shape=list(env.action_space.shape), action_low=bounds(env.action_space.low),
                action_high=bounds(env.action_space.high),
                observation_layout='official flat qpos followed by qvel',
                observation_implementation=hashlib.sha256(inspect.getsource(type(raw.task).get_obs).encode()).hexdigest(),
                joints=[raw.model.joint(i).name for i in range(raw.model.njnt)],
                actuators=[raw.model.actuator(i).name for i in range(raw.model.nu)],
                policy='stable_baselines3.ppo.MlpPolicy',
                architecture={'pi': [64, 64], 'vf': [64, 64], 'activation': 'Tanh'})

def require_compatible(meta, env, operation):
    if meta['git_commit'] != commit():
        raise ValueError('Checkpoint uses a different official repository commit.')
    current = signature(env)
    differences = [k for k in current if meta['signature'].get(k) != current[k]]
    if differences:
        raise ValueError('Incompatible checkpoint fields: ' + ', '.join(differences))
    if operation == 'resume' and meta['task'] != env.spec.id:
        raise ValueError('Resume requires the exact same task. Select Transfer for a different compatible task.')
    return current
