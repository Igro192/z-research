"""Run both bounded strategy measurements under one exclusive backend job."""
import argparse,signal,subprocess,time
from pathlib import Path
from .common import ROOT,PYTHON,read_json,write_json

def main(root):
    root=Path(root);child=None;stopped=False
    def stop(*unused):
        nonlocal stopped
        stopped=True
        if child and child.poll() is None:child.send_signal(signal.SIGTERM)
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    for name,module in [('parallel','control.benchmark'),('concurrency','control.concurrency_benchmark')]:
        run=root/name;run.mkdir(parents=True,exist_ok=True)
        with (run/'supervisor.log').open('w') as f:
            child=subprocess.Popen([str(PYTHON),'-m',module,'--run-dir',str(run)],stdout=f,stderr=subprocess.STDOUT)
            while child.poll() is None:
                write_json(root/'status.json',dict(read_json(run/'status.json',{'state':'starting'}),benchmark_stage=name))
                time.sleep(.3)
        if stopped or child.returncode:
            write_json(root/'status.json',dict(state='cancelled' if stopped else 'failed',benchmark_stage=name,error=(run/'supervisor.log').read_text()[-5000:]));raise SystemExit(1)
    write_json(root/'status.json',dict(state='completed',**read_json(ROOT/'state/training-defaults.json')))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run-dir',required=True);main(p.parse_args().run_dir)
