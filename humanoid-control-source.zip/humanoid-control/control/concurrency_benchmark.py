"""Compare equal headless work with one vs two simultaneous official PPO jobs."""
import argparse,json,os,subprocess,time,signal
from pathlib import Path
import psutil
from .common import ROOT,REPO,PYTHON,REPORTS,read_json,write_json,now,sha256,state_digest

STEPS=32768
TASKS=('g1-walk-v0','g1-stand-v0')

def main(root):
    root=Path(root); root.mkdir(parents=True,exist_ok=True)
    count=read_json(ROOT/'state/training-defaults.json')['num_envs']
    results=[]; interrupted=False; children=[]
    def stop(*unused):
        nonlocal interrupted
        interrupted=True
        for p in children:
            if p.poll() is None:p.send_signal(signal.SIGTERM)
    signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGTERM,stop)
    env=os.environ.copy();env.update(PYTHONPATH=str(ROOT),JAX_PLATFORMS='cpu',WANDB_MODE='disabled',OMP_NUM_THREADS='4',PYTHONUNBUFFERED='1');env.pop('MUJOCO_GL',None)
    for slots in (1,2):
        if interrupted:break
        runs=[]; running={}; todo=list(TASKS); cpu={};peak=0;min_available=psutil.virtual_memory().available;cpu_machine=[]
        initial_swap=psutil.swap_memory().sout;safe=True;reason=None;started=time.monotonic();psutil.cpu_percent()
        while todo or running:
            while todo and len(running)<slots and safe and not interrupted:
                task=todo.pop(0);run=root/f'jobs-{slots}'/task;run.mkdir(parents=True,exist_ok=False)
                cfg=dict(env_id=task,operation='new',checkpoint=None,run_dir=str(run),steps=STEPS,num_envs=count,seed=7,checkpoint_every=8192,vectorization='subproc',purpose='concurrency-benchmark',created_at=now())
                write_json(run/'config.json',cfg)
                with (run/'training.log').open('w') as f:p=subprocess.Popen([str(PYTHON),'-m','control.train','--config',str(run/'config.json')],cwd=REPO,env=env,stdout=f,stderr=subprocess.STDOUT)
                children.append(p);running[p.pid]=(p,run);runs.append(run)
            rss=0
            for pid,(p,run) in list(running.items()):
                try:
                    parent=psutil.Process(pid)
                    for proc in [parent,*parent.children(recursive=True)]:
                        try:
                            rss+=proc.memory_info().rss;t=proc.cpu_times();key=(proc.pid,proc.create_time());cpu[key]=max(cpu.get(key,0),t.user+t.system)
                        except psutil.Error:pass
                except psutil.Error:pass
                if p.poll() is not None:running.pop(pid)
            peak=max(peak,rss);available=psutil.virtual_memory().available;min_available=min(min_available,available)
            swap_delta=max(0,psutil.swap_memory().sout-initial_swap)
            if (available<4*1024**3 or swap_delta>128*1024**2) and safe:
                safe=False;reason='Available RAM below 4 GiB reserve or >128 MiB additional swap-out; safe stop requested.'
                todo.clear()
                for p,run in running.values():p.send_signal(signal.SIGTERM)
            if interrupted:todo.clear()
            cpu_machine.append(psutil.cpu_percent(interval=.1))
            write_json(root/'status.json',dict(state='benchmarking concurrency',slots=slots,num_envs=count,completed_steps=sum(read_json(r/'status.json',{}).get('training_steps',0) for r in runs),active_jobs=len(running),safe=safe))
        wall=time.monotonic()-started
        stable=safe and len(runs)==2 and all(read_json(r/'status.json',{}).get('state')=='completed' and read_json(r/'status.json',{}).get('training_steps')==STEPS for r in runs)
        if stable:
            from stable_baselines3 import PPO
            import torch
            for run in runs:
                cp=Path(read_json(run/'status.json')['checkpoint']);meta=read_json(cp.parent/'metadata.json');model=PPO.load(cp,device='cpu')
                assert sha256(cp)==meta['sha256'] and model.num_timesteps==STEPS
                assert state_digest(model.policy.optimizer.state_dict())==meta['optimizer_sha256']
                assert all(torch.isfinite(v).all() for v in model.policy.state_dict().values())
                del model
        result=dict(max_simultaneous_jobs=slots,num_envs_per_job=count,total_requested_steps=2*STEPS,completed_steps=sum(read_json(r/'status.json',{}).get('training_steps',0) for r in runs),wall_clock_seconds=wall,aggregate_steps_per_second=2*STEPS/wall if stable else None,process_tree_cpu_percent=100*sum(cpu.values())/wall,machine_cpu_percent_mean=sum(cpu_machine)/len(cpu_machine),peak_ram_bytes=peak,min_available_ram_bytes=min_available,swap_out_delta_bytes=max(0,psutil.swap_memory().sout-initial_swap),stable=stable,memory_safe=safe,error=reason,checkpoint_reloads_verified=stable,runs=[str(r) for r in runs],measured_at=now())
        results.append(result);print(json.dumps(result),flush=True)
        write_json(root/'result.json',dict(state='running',results=results))
    if interrupted:
        write_json(root/'status.json',dict(state='cancelled',results=results))
        raise SystemExit(1)
    stable=[r for r in results if r['stable']]
    if not stable:raise RuntimeError('No stable safe concurrency strategy; retain prior settings and inspect benchmark logs.')
    winner=max(stable,key=lambda r:r['aggregate_steps_per_second'])
    cfg=read_json(ROOT/'state/training-defaults.json');cfg.update(max_jobs=winner['max_simultaneous_jobs'],aggregate_steps_per_second=winner['aggregate_steps_per_second'],concurrency_source=str(REPORTS/'concurrency-benchmark.json'));write_json(ROOT/'state/training-defaults.json',cfg)
    result=dict(passed=len(results)==2 and not interrupted,results=results,selected_max_jobs=winner['max_simultaneous_jobs'],selection_rule='Highest aggregate full-wall throughput among numerically stable equal-work runs with >=4 GiB available memory reserve and <=128 MiB new swap-out.',measured_at=now())
    write_json(REPORTS/'concurrency-benchmark.json',result);write_json(root/'result.json',result);write_json(root/'status.json',dict(state='completed',**cfg));print(json.dumps(result,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run-dir',required=True);main(p.parse_args().run_dir)
