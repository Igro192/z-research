import CoreVideo
import XCTest
@testable import LearnerApp
import LearnerCore

final class SessionRecorderTests: XCTestCase {
    func testCorrectionLearnerChangesTheNextSimilarDecisionImmediately() {
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("LearnerCorrection-\(UUID().uuidString).json")
        defer { try? FileManager.default.removeItem(at: url) }
        let learner = CorrectionLearner(url: url, controls: ["Space", "Left Arrow"], width: 8, height: 6)
        let pixels = Array(repeating: UInt8(80), count: 48)
        let state = learner.stateKey(pixels)
        XCTAssertFalse(learner.adjusted([], state: state).contains("Space"))
        learner.learn(
            state: state,
            proposed: ["Left Arrow"],
            human: InputEventRecord(timestampNs: 0, type: .keyDown, keyCode: 49, key: "Space")
        )
        let corrected = learner.adjusted(["Left Arrow"], state: state)
        XCTAssertTrue(corrected.contains("Space"))
        XCTAssertFalse(corrected.contains("Left Arrow"))
        XCTAssertTrue(FileManager.default.fileExists(atPath: url.path))
    }

    func testLegacyDatasetMigratesToGameWithoutDeletingOriginal() throws {
        let temporaryRoot = FileManager.default.temporaryDirectory
            .appendingPathComponent("LearnerMigrationTests-\(UUID().uuidString)", isDirectory: true)
        defer { try? FileManager.default.removeItem(at: temporaryRoot) }
        let firstStore = SessionStore(rootURL: temporaryRoot)
        let sessionID = UUID()
        let dataset = try firstStore.createDataset(name: "Existing Game", sessionIDs: [sessionID])

        let migratedStore = SessionStore(rootURL: temporaryRoot)
        let game = try XCTUnwrap(migratedStore.listGames().first(where: { $0.id == dataset.id }))
        XCTAssertEqual(game.name, "Existing Game")
        XCTAssertEqual(game.sessionIDs, [sessionID])
        XCTAssertEqual(game.legacyDatasetIDs, [dataset.id])
        XCTAssertEqual(migratedStore.listDatasets().map(\.0.id), [dataset.id])
    }

    func testHeartbeatKeepsTimelineAndObservationsAliveWithoutNewCaptureFrames() async throws {
        let temporaryRoot = FileManager.default.temporaryDirectory
            .appendingPathComponent("LearnerRecorderTests-\(UUID().uuidString)", isDirectory: true)
        defer { try? FileManager.default.removeItem(at: temporaryRoot) }

        let store = SessionStore(rootURL: temporaryRoot)
        let dimensions = VideoDimensions(width: 64, height: 64)
        let source = CaptureSourceDescriptor(
            kind: .window,
            windowID: 1,
            ownerPID: 1,
            applicationName: "Static Test Window",
            windowTitle: "No new frames",
            bounds: .init(x: 0, y: 0, width: 64, height: 64)
        )
        let recorder = try SessionRecorder(
            store: store,
            source: source,
            configuration: VisionConfiguration(fps: 30),
            dimensions: dimensions
        )

        var buffer: CVPixelBuffer?
        XCTAssertEqual(
            CVPixelBufferCreate(
                nil,
                dimensions.width,
                dimensions.height,
                kCVPixelFormatType_32BGRA,
                [kCVPixelBufferIOSurfacePropertiesKey as String: [:]] as CFDictionary,
                &buffer
            ),
            kCVReturnSuccess
        )
        let firstTimestamp = DispatchTime.now().uptimeNanoseconds
        recorder.appendFrame(try XCTUnwrap(buffer), dimensions: dimensions, rawTimestampNs: firstTimestamp)

        try await Task.sleep(for: .milliseconds(1_100))
        recorder.heartbeat()
        let summary = try await recorder.stop()

        XCTAssertGreaterThanOrEqual(summary.metadata.durationNs, 1_000_000_000)
        // Static games and menus must still produce a dense, synchronized frame
        // timeline. The encoder can cheaply compress the duplicate frames.
        XCTAssertGreaterThanOrEqual(summary.metadata.frameCount, 20)
        XCTAssertEqual(store.loadFrames(for: summary).count, summary.metadata.frameCount)
        XCTAssertEqual(summary.metadata.status, .complete)
    }
}
