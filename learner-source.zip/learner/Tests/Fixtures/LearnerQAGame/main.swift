import AppKit

final class ArenaView: NSView {
    private var playerX: CGFloat = 0.5
    private var playerY: CGFloat = 0.16
    private var verticalVelocity: CGFloat = 0
    private var held = Set<UInt16>()
    private var score = 0
    private var misses = 0
    private var level = 1
    private var target = CGPoint(x: 0.72, y: 0.62)
    private var targetVelocity = CGPoint(x: -0.15, y: 0.11)
    private var lastTick = Date()
    private var timer: Timer?
    private var flashUntil = Date.distantPast

    override var acceptsFirstResponder: Bool { true }
    override var isFlipped: Bool { true }

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
        timer = Timer.scheduledTimer(withTimeInterval: 1.0 / 60.0, repeats: true) { [weak self] _ in
            self?.tick()
        }
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    deinit { timer?.invalidate() }

    private func tick() {
        let now = Date()
        let dt = min(0.05, now.timeIntervalSince(lastTick))
        lastTick = now
        let speed = CGFloat(dt) * 0.42
        if held.contains(123) || held.contains(0) { playerX -= speed }
        if held.contains(124) || held.contains(2) { playerX += speed }
        playerX = min(max(playerX, 0.05), 0.95)

        verticalVelocity += CGFloat(dt) * 1.7
        playerY += verticalVelocity * CGFloat(dt)
        if playerY > 0.16 { playerY = 0.16; verticalVelocity = 0 }

        target.x += targetVelocity.x * CGFloat(dt)
        target.y += targetVelocity.y * CGFloat(dt)
        if target.x < 0.12 || target.x > 0.88 { targetVelocity.x *= -1 }
        if target.y < 0.30 || target.y > 0.76 { targetVelocity.y *= -1 }
        needsDisplay = true
    }

    override func keyDown(with event: NSEvent) {
        held.insert(event.keyCode)
        if event.keyCode == 49, playerY >= 0.159 { verticalVelocity = -0.72 }
        if event.keyCode == 15 { resetArena() }
    }

    override func keyUp(with event: NSEvent) { held.remove(event.keyCode) }

    override func mouseDown(with event: NSEvent) {
        let point = convert(event.locationInWindow, from: nil)
        let normalized = CGPoint(x: point.x / bounds.width, y: point.y / bounds.height)
        let distance = hypot(normalized.x - target.x, normalized.y - target.y)
        if distance < 0.095 {
            score += 1
            level = 1 + score / 4
            flashUntil = Date().addingTimeInterval(0.22)
            target = CGPoint(
                x: 0.18 + CGFloat((score * 37) % 64) / 100,
                y: 0.32 + CGFloat((score * 23) % 42) / 100
            )
        } else {
            misses += 1
        }
        needsDisplay = true
    }

    override func rightMouseDown(with event: NSEvent) { resetArena() }
    override func scrollWheel(with event: NSEvent) {
        targetVelocity.x += event.scrollingDeltaY > 0 ? 0.015 : -0.015
        targetVelocity.x = min(max(targetVelocity.x, -0.35), 0.35)
    }

    private func resetArena() {
        score = 0; misses = 0; level = 1
        playerX = 0.5; playerY = 0.16; verticalVelocity = 0
        target = CGPoint(x: 0.72, y: 0.62)
        targetVelocity = CGPoint(x: -0.15, y: 0.11)
        flashUntil = Date().addingTimeInterval(0.15)
        needsDisplay = true
    }

    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
        let palette: [(NSColor, NSColor)] = [
            (NSColor(calibratedRed: 0.035, green: 0.055, blue: 0.11, alpha: 1), .systemCyan),
            (NSColor(calibratedRed: 0.09, green: 0.035, blue: 0.13, alpha: 1), .systemPink),
            (NSColor(calibratedRed: 0.025, green: 0.11, blue: 0.085, alpha: 1), .systemGreen),
        ]
        let colors = palette[(level - 1) % palette.count]
        colors.0.setFill(); bounds.fill()

        let grid = NSBezierPath()
        for column in 1..<10 {
            let x = CGFloat(column) * bounds.width / 10
            grid.move(to: CGPoint(x: x, y: 0)); grid.line(to: CGPoint(x: x, y: bounds.height))
        }
        for row in 1..<7 {
            let y = CGFloat(row) * bounds.height / 7
            grid.move(to: CGPoint(x: 0, y: y)); grid.line(to: CGPoint(x: bounds.width, y: y))
        }
        NSColor.white.withAlphaComponent(0.045).setStroke(); grid.lineWidth = 1; grid.stroke()

        let targetPoint = CGPoint(x: target.x * bounds.width, y: target.y * bounds.height)
        let radius: CGFloat = Date() < flashUntil ? 44 : 32
        let targetRect = CGRect(x: targetPoint.x - radius, y: targetPoint.y - radius, width: radius * 2, height: radius * 2)
        colors.1.withAlphaComponent(0.22).setFill(); NSBezierPath(ovalIn: targetRect.insetBy(dx: -14, dy: -14)).fill()
        colors.1.setFill(); NSBezierPath(ovalIn: targetRect).fill()
        NSColor.white.setStroke()
        let cross = NSBezierPath()
        cross.move(to: CGPoint(x: targetPoint.x - 16, y: targetPoint.y)); cross.line(to: CGPoint(x: targetPoint.x + 16, y: targetPoint.y))
        cross.move(to: CGPoint(x: targetPoint.x, y: targetPoint.y - 16)); cross.line(to: CGPoint(x: targetPoint.x, y: targetPoint.y + 16))
        cross.lineWidth = 3; cross.stroke()

        let playerPoint = CGPoint(x: playerX * bounds.width, y: playerY * bounds.height)
        let playerRect = CGRect(x: playerPoint.x - 24, y: playerPoint.y - 24, width: 48, height: 48)
        NSColor.systemYellow.setFill(); NSBezierPath(roundedRect: playerRect, xRadius: 12, yRadius: 12).fill()

        let title = "LEARNER QA ARENA"
        title.draw(at: CGPoint(x: 28, y: 24), withAttributes: [
            .font: NSFont.systemFont(ofSize: 22, weight: .bold), .foregroundColor: NSColor.white
        ])
        "Level \(level)    Score \(score)    Misses \(misses)".draw(at: CGPoint(x: 28, y: 58), withAttributes: [
            .font: NSFont.monospacedDigitSystemFont(ofSize: 18, weight: .semibold), .foregroundColor: colors.1
        ])
        "Move: A/D or ←/→    Jump: Space    Click the moving target    Reset: R/right-click".draw(
            at: CGPoint(x: 28, y: bounds.height - 42),
            withAttributes: [.font: NSFont.systemFont(ofSize: 14), .foregroundColor: NSColor.white.withAlphaComponent(0.72)]
        )
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate {
    private var window: NSWindow!

    func applicationDidFinishLaunching(_ notification: Notification) {
        let rect = NSRect(x: 0, y: 0, width: 960, height: 640)
        window = NSWindow(
            contentRect: rect,
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.title = "Learner QA Arena"
        window.center()
        window.delegate = self
        window.contentView = ArenaView(frame: rect)
        window.makeKeyAndOrderFront(nil)
        window.makeFirstResponder(window.contentView)
        NSApp.activate(ignoringOtherApps: true)
    }

    func windowWillClose(_ notification: Notification) { NSApp.terminate(nil) }
}

let app = NSApplication.shared
app.setActivationPolicy(.regular)
let delegate = AppDelegate()
app.delegate = delegate
app.run()
