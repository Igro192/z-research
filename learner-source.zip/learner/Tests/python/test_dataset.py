import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[2] / "python"))

from learner_dataset import FrameReference, LearnerDataset


def _write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


def _write_jsonl(path: Path, values: list[object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(value) + "\n" for value in values), encoding="utf-8")


def _session(path: Path, session_id: str) -> None:
    _write_json(
        path / "metadata.json",
        {
            "schemaVersion": 1,
            "id": session_id,
            "videoPath": "video/observation.mp4",
            "vision": {"regions": []},
        },
    )
    _write_jsonl(
        path / "observations/frames.jsonl",
        [
            {"frameIndex": 0, "timestampNs": 100, "videoPtsNs": 100},
            {"frameIndex": 1, "timestampNs": 200, "videoPtsNs": 200},
            {"frameIndex": 2, "timestampNs": 300, "videoPtsNs": 300},
        ],
    )
    _write_jsonl(
        path / "actions/events.jsonl",
        [
            {"timestampNs": 150, "type": "keyDown", "key": "W"},
            {"timestampNs": 250, "type": "keyUp", "key": "W"},
        ],
    )
    _write_jsonl(path / "markers/labels.jsonl", [])


class LearnerDatasetTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def test_causal_transition_index(self) -> None:
        session = self.root / "session"
        _session(session, "abc")
        dataset = LearnerDataset(session, decode_video=False)

        self.assertEqual(len(dataset), 2)
        self.assertIsInstance(dataset[0].observation, FrameReference)
        self.assertEqual(dataset[0].observation.frame_index, 0)
        self.assertEqual(dataset[0].next_observation.frame_index, 1)
        self.assertEqual([event["type"] for event in dataset[0].action], ["keyDown"])
        self.assertEqual([event["type"] for event in dataset[1].action], ["keyUp"])

    def test_history_and_combined_manifest(self) -> None:
        root = self.root / "Learner"
        session = root / "Sessions" / "abc"
        _session(session, "abc")
        dataset_path = root / "Datasets" / "set"
        _write_json(dataset_path / "dataset.json", {"schemaVersion": 1, "sessionIDs": ["abc"]})

        dataset = LearnerDataset(dataset_path, decode_video=False, history=2)
        self.assertEqual(len(dataset), 2)
        self.assertEqual(len(dataset[0].previous_observations), 0)
        self.assertEqual([ref.frame_index for ref in dataset[1].previous_observations], [0])

    def test_game_manifest_uses_explicit_sessions_root(self) -> None:
        root = self.root / "Learner"
        session = root / "Sessions" / "abc"
        _session(session, "abc")
        game = root / "Games" / "game-id"
        _write_json(
            game / "learning" / "experience.json",
            {"schemaVersion": 2, "sessionIDs": ["abc"], "sessionsRoot": str(root / "Sessions")},
        )
        dataset = LearnerDataset(game, decode_video=False)
        self.assertEqual(len(dataset), 2)
        self.assertEqual(dataset[0].session_id, "abc")

    def test_ignore_labels_exclude_transition(self) -> None:
        session = self.root / "session"
        _session(session, "abc")
        _write_jsonl(
            session / "markers/labels.jsonl",
            [{"timestampNs": 120, "endTimestampNs": 190, "label": "IGNORE", "id": "m"}],
        )
        self.assertEqual(len(LearnerDataset(session, decode_video=False)), 1)
        self.assertEqual(len(LearnerDataset(session, decode_video=False, include_ignored=True)), 2)


if __name__ == "__main__":
    unittest.main()
