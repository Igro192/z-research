import json
import sys
import tempfile
import unittest
from pathlib import Path

import av
import numpy as np

sys.path.insert(0, str(Path(__file__).parents[2] / "python"))

from learner_dataset.analysis import analyze


class DiscoveryTests(unittest.TestCase):
    def test_discovers_real_states_and_repeated_action_sequences(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "Learner"
            session = root / "Sessions" / "episode"
            video = session / "video" / "observation.mp4"
            video.parent.mkdir(parents=True)
            container = av.open(str(video), mode="w")
            stream = container.add_stream("mpeg4", rate=10)
            stream.width = 64
            stream.height = 36
            stream.pix_fmt = "yuv420p"
            for index in range(30):
                image = np.zeros((36, 64, 3), dtype=np.uint8)
                image[:, :, :] = 20 if index < 15 else 220
                frame = av.VideoFrame.from_ndarray(image, format="rgb24")
                for packet in stream.encode(frame):
                    container.mux(packet)
            for packet in stream.encode():
                container.mux(packet)
            container.close()

            (session / "actions").mkdir()
            actions = []
            for offset in (200_000_000, 1_200_000_000, 2_200_000_000):
                actions.extend([
                    {"timestampNs": offset, "type": "keyDown", "key": "W", "keyCode": 13, "isRepeat": False},
                    {"timestampNs": offset + 300_000_000, "type": "keyUp", "key": "W", "keyCode": 13},
                ])
            (session / "actions" / "events.jsonl").write_text(
                "".join(json.dumps(row) + "\n" for row in actions), encoding="utf-8"
            )
            (session / "metadata.json").write_text(json.dumps({
                "id": "episode",
                "videoPath": "video/observation.mp4",
                "durationNs": 3_000_000_000,
                "vision": {"fps": 10},
            }), encoding="utf-8")
            manifest = root / "Games" / "game" / "learning" / "experience.json"
            manifest.parent.mkdir(parents=True)
            manifest.write_text(json.dumps({
                "sessionIDs": ["episode"],
                "sessionsRoot": str(root / "Sessions"),
            }), encoding="utf-8")
            output = manifest.parents[1] / "understanding.json"
            result = analyze(manifest, output)
            self.assertGreaterEqual(len(result["states"]), 2)
            self.assertGreaterEqual(len(result["skills"]), 1)
            self.assertGreaterEqual(len(result["transitions"]), 1)
            self.assertTrue(output.exists())


if __name__ == "__main__":
    unittest.main()
