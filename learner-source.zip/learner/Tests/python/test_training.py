import sys
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parents[2] / "python"))

from learner_dataset.training import TrainingData, export_model, train


class TrainingTests(unittest.TestCase):
    def test_small_model_learns_separable_actions(self) -> None:
        rng = np.random.default_rng(3)
        features = rng.standard_normal((240, 12), dtype=np.float32)
        labels = np.stack(
            [features[:, 0] > 0, features[:, 1] > 0, features[:, 2] + features[:, 3] > 0], axis=1
        ).astype(np.float32)
        data = TrainingData(features, labels, ["test"], len(features))
        _, metrics = train(data, hidden_size=12, epochs=40, batch_size=32)
        for key_metrics in metrics["validation"].values():
            self.assertGreater(key_metrics["f1"], 0.65)

    def test_corrections_are_counted_as_weighted_examples(self) -> None:
        rng = np.random.default_rng(8)
        features = rng.standard_normal((60, 8), dtype=np.float32)
        labels = (features[:, :3] > 0).astype(np.float32)
        weights = np.ones(60, dtype=np.float32)
        weights[-7:] = 5.0
        data = TrainingData(features, labels, ["correction"], len(features), sample_weights=weights)
        _, metrics = train(data, hidden_size=8, epochs=2, batch_size=16)
        self.assertEqual(metrics["correctionWeightedFrames"], 7)

    def test_goal_model_exports_visual_memory_and_online_learning(self) -> None:
        rng = np.random.default_rng(4)
        features = rng.standard_normal((80, 12), dtype=np.float32)
        labels = (rng.random((80, 3)) > 0.7).astype(np.float32)
        memories = rng.integers(0, 256, size=(10, 2, 3), dtype=np.uint8)
        actions = np.asarray([0, 2, 2, 6, 2, 0, 1, 5, 1, 0], dtype=np.uint8)
        data = TrainingData(
            features,
            labels,
            ["episode"],
            len(features),
            memory_frames=memories,
            memory_actions=actions,
            episode_starts=[0],
            episode_ends=[9],
        )
        parameters, metrics = train(data, hidden_size=8, epochs=2, batch_size=16)
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "model.json"
            export_model(output, parameters, metrics, data, width=3, height=2)
            payload = json.loads(output.read_text())
        self.assertEqual(payload["format"], "learner-goal-policy-v3")
        self.assertEqual(payload["visualMemory"]["frameCount"], 10)
        self.assertEqual(payload["visualMemory"]["episodeEnds"], [9])
        self.assertEqual(payload["visualMemory"]["actionMaskBytes"], 4)
        self.assertEqual(payload["keys"], ["Left Arrow", "Right Arrow", "Up Arrow"])
        self.assertEqual(payload["onlineLearning"]["algorithm"], "visual-progress-q-learning-v1")


if __name__ == "__main__":
    unittest.main()
