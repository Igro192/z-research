import XCTest
@testable import LearnerCore

final class LearnerCoreTests: XCTestCase {
    func testNormalizedRectClampsInsideUnitSquare() {
        let rect = NormalizedRect(x: -0.2, y: 0.8, width: 2, height: 1)
        XCTAssertEqual(rect.x, 0)
        XCTAssertEqual(rect.y, 0.8, accuracy: 0.0001)
        XCTAssertEqual(rect.width, 1)
        XCTAssertEqual(rect.height, 0.2, accuracy: 0.0001)
    }

    func testSampleIndexAssignsActionsBetweenAdjacentFrames() {
        let sessionID = UUID()
        let frames = [
            FrameRecord(frameIndex: 0, timestampNs: 100, videoPtsNs: 0),
            FrameRecord(frameIndex: 1, timestampNs: 200, videoPtsNs: 100),
            FrameRecord(frameIndex: 2, timestampNs: 300, videoPtsNs: 200),
        ]
        let actions = [
            InputEventRecord(timestampNs: 150, type: .keyDown, key: "W"),
            InputEventRecord(timestampNs: 250, type: .keyUp, key: "W"),
        ]
        let samples = SampleIndexBuilder.build(sessionID: sessionID, frames: frames, actions: actions)

        XCTAssertEqual(samples.count, 2)
        XCTAssertEqual(samples[0].actionRange, 0..<1)
        XCTAssertEqual(samples[1].actionRange, 1..<2)
    }

    func testMetadataRoundTrip() throws {
        let source = CaptureSourceDescriptor(
            kind: .window,
            windowID: 42,
            ownerPID: 9,
            applicationName: "Example",
            windowTitle: "Document",
            bounds: .init(x: 1, y: 2, width: 800, height: 600)
        )
        let metadata = SessionMetadata(
            name: "Test",
            target: source,
            vision: .init(),
            output: .init(width: 1280, height: 720)
        )
        let data = try JSONEncoder().encode(metadata)
        XCTAssertEqual(try JSONDecoder().decode(SessionMetadata.self, from: data), metadata)
    }

    func testGameProjectAndKnowledgeRoundTrip() throws {
        let sessionID = UUID()
        let project = GameProject(name: "Browser Game", sessionIDs: [sessionID])
        let knowledge = ProjectKnowledge(
            processedSessionIDs: [sessionID],
            states: [.init(id: 0, observations: 14, firstSeenSeconds: 0, lastSeenSeconds: 8)],
            skills: [.init(id: "skill-001", actionSequence: ["press W", "release W"], occurrences: 4, averageDurationSeconds: 0.5)],
            correctionCount: 2
        )
        let encoder = JSONEncoder()
        let decoder = JSONDecoder()
        XCTAssertEqual(try decoder.decode(GameProject.self, from: encoder.encode(project)), project)
        XCTAssertEqual(try decoder.decode(ProjectKnowledge.self, from: encoder.encode(knowledge)), knowledge)
    }
}
