# Learner

Original Swift and Python learning/recording tool source and tests. User recordings, datasets, models and packaged binaries are excluded.

## Run

See Package.swift and python/pyproject.toml.

This is a source snapshot from Z. Research. No license is granted for third-party content or trademarks.
