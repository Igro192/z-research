from __future__ import annotations

import json
import re
from bisect import bisect_right
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator, Sequence


@dataclass(frozen=True)
class FrameReference:
    """A lazy reference useful when callers want to decode video themselves."""

    video_path: Path
    frame_index: int
    timestamp_ns: int


@dataclass(frozen=True)
class LearnerSample:
    observation: Any
    action: list[dict[str, Any]]
    next_observation: Any
    timestamp: int
    session_id: str
    previous_observations: tuple[Any, ...] = ()
    region_observations: dict[str, Any] | None = None
    labels: tuple[str, ...] = ()

    @property
    def timestamp_seconds(self) -> float:
        return self.timestamp / 1_000_000_000


@dataclass
class _Session:
    path: Path
    metadata: dict[str, Any]
    frames: list[dict[str, Any]]
    actions: list[dict[str, Any]]
    markers: list[dict[str, Any]]
    action_timestamps: list[int]


@dataclass(frozen=True)
class _SampleIndex:
    session_index: int
    frame_offset: int
    action_start: int
    action_end: int


class _VideoDecoder:
    def __init__(self, path: Path, cache_size: int = 24) -> None:
        try:
            import av  # type: ignore
        except ImportError as error:  # pragma: no cover - dependency message
            raise ImportError(
                "Video decoding requires PyAV. Install with: pip install learner-dataset"
            ) from error
        self._av = av
        self.path = path
        self.cache_size = cache_size
        self.cache: OrderedDict[int, Any] = OrderedDict()
        self._container = None
        self._iterator = None
        self._next_index = 0

    def frame(self, index: int) -> Any:
        if index in self.cache:
            value = self.cache.pop(index)
            self.cache[index] = value
            return value
        if self._iterator is None or index < self._next_index:
            self._reopen()
        assert self._iterator is not None
        while self._next_index <= index:
            try:
                frame = next(self._iterator)
            except StopIteration as error:
                raise IndexError(f"Video {self.path} has no frame {index}") from error
            array = frame.to_ndarray(format="rgb24")
            self._remember(self._next_index, array)
            self._next_index += 1
        return self.cache[index]

    def _reopen(self) -> None:
        if self._container is not None:
            self._container.close()
        self._container = self._av.open(str(self.path))
        self._iterator = self._container.decode(video=0)
        self._next_index = 0

    def _remember(self, index: int, value: Any) -> None:
        self.cache[index] = value
        while len(self.cache) > self.cache_size:
            self.cache.popitem(last=False)


class LearnerDataset(Sequence[LearnerSample]):
    """
    A causal view of one Learner session or a combined dataset.

    Every item pairs frame N with frame N+1 and includes all input events whose
    timestamps fall in ``(frame_N, frame_N+1]``. Observations are RGB NumPy arrays
    by default, or :class:`FrameReference` values when ``decode_video=False``.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        decode_video: bool = True,
        history: int = 0,
        include_ignored: bool = False,
    ) -> None:
        self.path = Path(path).expanduser().resolve()
        self.decode_video = decode_video
        self.history = max(0, history)
        self.include_ignored = include_ignored
        self.sessions = [self._load_session(item) for item in self._resolve_sessions(self.path)]
        self._samples: list[_SampleIndex] = []
        self._decoders: dict[Path, _VideoDecoder] = {}
        self._build_index()

    def __len__(self) -> int:
        return len(self._samples)

    def __getitem__(self, index: int | slice) -> LearnerSample | list[LearnerSample]:
        if isinstance(index, slice):
            return [self[item] for item in range(*index.indices(len(self)))]
        if index < 0:
            index += len(self)
        if index < 0 or index >= len(self):
            raise IndexError(index)
        item = self._samples[index]
        session = self.sessions[item.session_index]
        current = session.frames[item.frame_offset]
        next_frame = session.frames[item.frame_offset + 1]
        video_path = session.path / session.metadata["videoPath"]
        observation = self._observation(video_path, current)
        next_observation = self._observation(video_path, next_frame)
        previous = tuple(
            self._observation(video_path, session.frames[offset])
            for offset in range(max(0, item.frame_offset - self.history), item.frame_offset)
        )
        region_observations = self._regions(session, current)
        labels = self._labels(session, int(current["timestampNs"]), int(next_frame["timestampNs"]))
        return LearnerSample(
            observation=observation,
            action=session.actions[item.action_start:item.action_end],
            next_observation=next_observation,
            timestamp=int(current["timestampNs"]),
            session_id=str(session.metadata["id"]),
            previous_observations=previous,
            region_observations=region_observations,
            labels=labels,
        )

    def __iter__(self) -> Iterator[LearnerSample]:
        for index in range(len(self)):
            yield self[index]

    def torch(self, index: int) -> dict[str, Any]:
        """Return one item with image arrays converted to CHW float tensors."""
        try:
            import torch  # type: ignore
        except ImportError as error:  # pragma: no cover
            raise ImportError("Install the torch extra: pip install learner-dataset[torch]") from error
        sample = self[index]

        def convert(value: Any) -> Any:
            if isinstance(value, FrameReference):
                raise ValueError("torch() requires decode_video=True")
            return torch.from_numpy(value.copy()).permute(2, 0, 1).float().div_(255)

        return {
            "observation": convert(sample.observation),
            "action": sample.action,
            "next_observation": convert(sample.next_observation),
            "timestamp_ns": sample.timestamp,
            "session_id": sample.session_id,
            "labels": sample.labels,
        }

    def _resolve_sessions(self, path: Path) -> list[Path]:
        if (path / "metadata.json").exists():
            return [path]
        if path.is_file():
            manifest_path = path
        elif (path / "dataset.json").exists():
            manifest_path = path / "dataset.json"
        elif (path / "learning" / "experience.json").exists():
            manifest_path = path / "learning" / "experience.json"
        else:
            manifest_path = path / "experience.json"
        if manifest_path.exists():
            manifest = _read_json(manifest_path)
            if manifest.get("sessionsRoot"):
                sessions_root = Path(manifest["sessionsRoot"])
            else:
                learner_root = manifest_path.parent.parent.parent
                sessions_root = learner_root / "Sessions"
            result = [sessions_root / session_id for session_id in manifest["sessionIDs"]]
            missing = [item for item in result if not (item / "metadata.json").exists()]
            if missing:
                raise FileNotFoundError(f"Dataset references missing sessions: {missing}")
            return result
        raise FileNotFoundError(f"Expected a Learner session, legacy dataset, or Game manifest at {path}")

    def _load_session(self, path: Path) -> _Session:
        metadata = _read_json(path / "metadata.json")
        if int(metadata.get("schemaVersion", 0)) != 1:
            raise ValueError(f"Unsupported Learner schema: {metadata.get('schemaVersion')}")
        frames = sorted(_read_jsonl(path / "observations" / "frames.jsonl"), key=lambda x: int(x["timestampNs"]))
        actions = sorted(_read_jsonl(path / "actions" / "events.jsonl"), key=lambda x: int(x["timestampNs"]))
        markers = _read_jsonl(path / "markers" / "labels.jsonl")
        return _Session(path, metadata, frames, actions, markers, [int(a["timestampNs"]) for a in actions])

    def _build_index(self) -> None:
        for session_index, session in enumerate(self.sessions):
            lower = 0
            for frame_offset in range(max(0, len(session.frames) - 1)):
                start = int(session.frames[frame_offset]["timestampNs"])
                end = int(session.frames[frame_offset + 1]["timestampNs"])
                lower = bisect_right(session.action_timestamps, start, lo=lower)
                upper = bisect_right(session.action_timestamps, end, lo=lower)
                labels = self._labels(session, start, end)
                if self.include_ignored or "IGNORE" not in labels:
                    self._samples.append(_SampleIndex(session_index, frame_offset, lower, upper))
                lower = upper

    def _observation(self, video_path: Path, frame: dict[str, Any]) -> Any:
        reference = FrameReference(video_path, int(frame["frameIndex"]), int(frame["timestampNs"]))
        if not self.decode_video:
            return reference
        decoder = self._decoders.setdefault(video_path, _VideoDecoder(video_path))
        return decoder.frame(reference.frame_index)

    def _regions(self, session: _Session, frame: dict[str, Any]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        regions = session.metadata.get("vision", {}).get("regions", [])
        for region in regions:
            if not region.get("exportSeparately"):
                continue
            name = str(region.get("name", region.get("id", "region")))
            safe_name = re.sub(r"[^a-zA-Z0-9_-]", "_", name) or str(region["id"])
            path = session.path / "regions" / f"{safe_name}.mp4"
            if path.exists():
                result[name] = self._observation(path, frame)
        return result

    @staticmethod
    def _labels(session: _Session, start_ns: int, end_ns: int) -> tuple[str, ...]:
        labels: list[str] = []
        for marker in session.markers:
            marker_start = int(marker["timestampNs"])
            marker_end = int(marker.get("endTimestampNs") or marker_start)
            if marker_start <= end_ns and marker_end >= start_ns:
                labels.append(str(marker["label"]))
        return tuple(dict.fromkeys(labels))


def _read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    result = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                result.append(json.loads(line))
    return result
