from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np

from .training import _json, _jsonl, resolve_sessions


def _iso_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _event(kind: str, seconds: float, detail: str) -> dict[str, Any]:
    # Stable IDs make a full re-analysis idempotent.
    digest = hashlib.sha1(f"{kind}:{seconds:.2f}:{detail}".encode()).hexdigest()[:32]
    return {
        "id": f"{digest[:8]}-{digest[8:12]}-4{digest[13:16]}-a{digest[17:20]}-{digest[20:32]}",
        "kind": kind,
        "timestampSeconds": round(seconds, 3),
        "detail": detail,
    }


def _action_tokens(actions: list[dict[str, Any]]) -> list[tuple[int, str]]:
    tokens: list[tuple[int, str]] = []
    motion_x = motion_y = 0.0
    motion_start = 0
    for row in actions:
        timestamp = int(row.get("timestampNs", 0))
        event_type = row.get("type")
        if event_type == "keyDown" and row.get("key") and not row.get("isRepeat"):
            tokens.append((timestamp, f"press {row['key']}"))
        elif event_type == "keyUp" and row.get("key"):
            tokens.append((timestamp, f"release {row['key']}"))
        elif event_type == "mouseButtonDown":
            x = round(float(row.get("x", 0.5)) * 4) / 4
            y = round(float(row.get("y", 0.5)) * 4) / 4
            tokens.append((timestamp, f"click {row.get('button', 'Left')} at {x:.2f},{y:.2f}"))
        elif event_type == "scroll":
            amount = float(row.get("scrollY") or 0)
            if abs(amount) >= 1:
                tokens.append((timestamp, "scroll up" if amount > 0 else "scroll down"))
        elif event_type == "mouseMove":
            if motion_start == 0:
                motion_start = timestamp
            motion_x += float(row.get("deltaX") or 0)
            motion_y += float(row.get("deltaY") or 0)
            if timestamp - motion_start >= 250_000_000:
                if abs(motion_x) + abs(motion_y) >= 30:
                    if abs(motion_x) >= abs(motion_y):
                        tokens.append((timestamp, "look right" if motion_x > 0 else "look left"))
                    else:
                        tokens.append((timestamp, "look down" if motion_y > 0 else "look up"))
                motion_x = motion_y = 0
                motion_start = timestamp
    return tokens


def analyze(manifest: Path, output: Path) -> dict[str, Any]:
    import av

    session_paths = resolve_sessions(manifest)
    centroids: list[np.ndarray] = []
    state_counts: Counter[int] = Counter()
    state_first: dict[int, float] = {}
    state_last: dict[int, float] = {}
    state_positions: defaultdict[int, list[float]] = defaultdict(list)
    session_timelines: dict[str, list[tuple[int, int]]] = {}
    events: list[dict[str, Any]] = []
    all_token_streams: list[list[tuple[int, str, int | None]]] = []
    processed_ids: list[str] = []

    for session_path in session_paths:
        metadata_path = session_path / "metadata.json"
        if not metadata_path.exists():
            continue
        metadata = _json(metadata_path)
        video_path = session_path / metadata["videoPath"]
        if not video_path.exists():
            continue
        fps = max(1, int(metadata.get("vision", {}).get("fps", 30)))
        sample_every = max(1, fps // 5)
        duration = max(0.001, float(metadata.get("durationNs", 1)) / 1_000_000_000)
        timeline: list[tuple[int, int]] = []
        previous_embedding: np.ndarray | None = None
        previous_state: int | None = None
        unchanged_since: float | None = None
        emitted_inactivity = False

        container = av.open(str(video_path))
        stream = container.streams.video[0]
        time_base = float(stream.time_base)
        sampled_index = 0
        for frame_index, frame in enumerate(container.decode(video=0)):
            if frame_index % sample_every:
                continue
            seconds = float(frame.pts or frame_index) * time_base
            embedding = frame.reformat(width=8, height=6, format="gray").to_ndarray().astype(np.float32).reshape(-1)
            if centroids:
                distances = [float(np.mean(np.abs(embedding - center))) for center in centroids]
                state = int(np.argmin(distances))
                if distances[state] > 18.0 and len(centroids) < 512:
                    state = len(centroids)
                    centroids.append(embedding.copy())
                    events.append(_event("newVisualState", seconds, f"Discovered State Cluster {state + 1}"))
                else:
                    count = state_counts[state]
                    centroids[state] = (centroids[state] * count + embedding) / (count + 1)
            else:
                state = 0
                centroids.append(embedding.copy())
                events.append(_event("newVisualState", seconds, "Discovered State Cluster 1"))

            state_counts[state] += 1
            state_first.setdefault(state, seconds)
            state_last[state] = seconds
            state_positions[state].append(min(1.0, max(0.0, seconds / duration)))
            timestamp_ns = int(seconds * 1_000_000_000)
            timeline.append((timestamp_ns, state))

            if previous_embedding is not None:
                change = float(np.mean(np.abs(embedding - previous_embedding)))
                if change > 45:
                    events.append(_event("majorVisualChange", seconds, "Large visual transition"))
                if change < 1.2:
                    unchanged_since = unchanged_since if unchanged_since is not None else seconds
                    if seconds - unchanged_since >= 3 and not emitted_inactivity:
                        events.append(_event("inactivity", seconds, "Visual scene remained nearly unchanged"))
                        emitted_inactivity = True
                else:
                    unchanged_since = None
                    emitted_inactivity = False
                if state == 0 and previous_state not in {None, 0} and seconds >= 5:
                    events.append(_event("probableReset", seconds, "Returned to an early familiar visual state"))
            previous_embedding = embedding
            previous_state = state
            sampled_index += 1
        container.close()

        session_id = str(metadata["id"])
        processed_ids.append(session_id)
        session_timelines[session_id] = timeline
        actions = sorted(_jsonl(session_path / "actions/events.jsonl"), key=lambda row: row.get("timestampNs", 0))
        tokens = _action_tokens(actions)
        with_states: list[tuple[int, str, int | None]] = []
        cursor = 0
        state: int | None = None
        for timestamp, token in tokens:
            while cursor < len(timeline) and timeline[cursor][0] <= timestamp:
                state = timeline[cursor][1]
                cursor += 1
            with_states.append((timestamp, token, state))
        if with_states:
            all_token_streams.append(with_states)

    ngrams: Counter[tuple[str, ...]] = Counter()
    durations: defaultdict[tuple[str, ...], list[float]] = defaultdict(list)
    related_states: defaultdict[tuple[str, ...], set[int]] = defaultdict(set)
    for stream in all_token_streams:
        for size in range(2, 6):
            for index in range(0, len(stream) - size + 1):
                window = stream[index : index + size]
                if window[-1][0] - window[0][0] > 8_000_000_000:
                    continue
                sequence = tuple(item[1] for item in window)
                ngrams[sequence] += 1
                durations[sequence].append((window[-1][0] - window[0][0]) / 1_000_000_000)
                related_states[sequence].update(item[2] for item in window if item[2] is not None)

    candidates = [(sequence, count) for sequence, count in ngrams.items() if count >= 2]
    candidates.sort(key=lambda item: (-item[1], -len(item[0]), item[0]))
    skills: list[dict[str, Any]] = []
    for index, (sequence, count) in enumerate(candidates[:64], start=1):
        skill_id = f"skill-{index:03d}"
        observed_durations = durations[sequence]
        mean_duration = float(np.mean(observed_durations))
        duration_consistency = 1.0 / (1.0 + float(np.std(observed_durations)) / max(0.05, mean_duration))
        confidence = (count / (count + 3.0)) * duration_consistency
        skills.append({
            "id": skill_id,
            "actionSequence": list(sequence),
            "occurrences": count,
            "averageDurationSeconds": round(mean_duration, 3),
            "confidence": round(confidence, 4),
            "relatedStateIDs": sorted(related_states[sequence]),
            "dependencies": [],
        })
        events.append(_event("actionSequence", 0, f"Discovered {skill_id} from {count} repeated sequences"))

    # A compact embedding world model: count actual visual-state transitions and
    # label them with the nearest observed action token.
    transition_counts: Counter[tuple[int, str, int]] = Counter()
    for stream, session_path in zip(all_token_streams, [p for p in session_paths if _jsonl(p / "actions/events.jsonl")]):
        metadata = _json(session_path / "metadata.json")
        timeline = session_timelines.get(str(metadata["id"]), [])
        if len(timeline) < 2:
            continue
        action_cursor = 0
        active_skill = "observe"
        for (timestamp, from_state), (next_timestamp, to_state) in zip(timeline, timeline[1:]):
            while action_cursor < len(stream) and stream[action_cursor][0] <= next_timestamp:
                active_skill = stream[action_cursor][1]
                action_cursor += 1
            if from_state != to_state:
                transition_counts[(from_state, active_skill, to_state)] += 1

    transitions = []
    for (from_state, skill, to_state), count in transition_counts.most_common(256):
        from_progress = float(np.mean(state_positions[from_state])) if state_positions[from_state] else 0
        to_progress = float(np.mean(state_positions[to_state])) if state_positions[to_state] else 0
        transitions.append({
            "fromState": from_state,
            "skillID": skill,
            "toState": to_state,
            "observations": count,
            "averageProgressDelta": round(to_progress - from_progress, 4),
        })

    states = []
    for state in sorted(state_counts):
        mean_position = float(np.mean(state_positions[state])) if state_positions[state] else 0.5
        states.append({
            "id": state,
            "observations": state_counts[state],
            "firstSeenSeconds": round(state_first[state], 3),
            "lastSeenSeconds": round(state_last[state], 3),
            # This is explicitly an uncertain demonstration-order estimate, not a
            # claim that the game has disclosed a reward value.
            "progressEstimate": round((mean_position - 0.5) * 2, 4),
        })

    game_directory = output.parent
    corrections = _jsonl(game_directory / "corrections.jsonl")
    for correction in corrections[-20:]:
        events.append(_event("humanCorrection", 0, "Human replaced an agent action"))

    result = {
        "schemaVersion": 1,
        "updatedAt": _iso_now(),
        "processedSessionIDs": processed_ids,
        "states": states,
        "skills": skills,
        "transitions": transitions,
        "recentEvents": events[-40:],
        "correctionCount": len(corrections),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Discover reusable visual states, events, skills, and transitions.")
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.manifest, args.output)
    print(json.dumps({
        "states": len(result["states"]),
        "skills": len(result["skills"]),
        "transitions": len(result["transitions"]),
        "events": len(result["recentEvents"]),
    }))


if __name__ == "__main__":
    main()
