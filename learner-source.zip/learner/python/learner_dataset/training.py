from __future__ import annotations

import argparse
import base64
import bisect
from collections import Counter
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np


DEFAULT_KEYS = ("Left Arrow", "Right Arrow", "Up Arrow")
MAX_CONTROLS = 24
IGNORED_KEYS = {"Escape", "Command", "Option", "Fn", "Caps Lock"}
SUPPORTED_MODIFIERS = {"Shift", "Right Shift", "Control", "Right Control"}


@dataclass
class TrainingData:
    features: np.ndarray
    labels: np.ndarray
    session_ids: list[str]
    frame_count: int
    sample_weights: np.ndarray | None = None
    memory_frames: np.ndarray | None = None
    memory_actions: np.ndarray | None = None
    episode_starts: list[int] | None = None
    episode_ends: list[int] | None = None
    keys: list[str] | None = None
    key_codes: list[int] | None = None
    memory_pointer_actions: np.ndarray | None = None
    recovery_clicks: list[dict[str, Any]] | None = None


def _json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def resolve_sessions(path: Path) -> list[Path]:
    path = path.expanduser().resolve()
    if (path / "metadata.json").exists():
        return [path]
    if path.is_file():
        manifest_path = path
    elif (path / "dataset.json").exists():
        manifest_path = path / "dataset.json"
    else:
        manifest_path = path / "experience.json"
    manifest = _json(manifest_path)
    sessions_root = Path(manifest["sessionsRoot"]) if manifest.get("sessionsRoot") else manifest_path.parent.parent.parent / "Sessions"
    return [sessions_root / session_id for session_id in manifest["sessionIDs"]]


def load_training_data(path: Path, width: int = 64, height: int = 36) -> TrainingData:
    import av

    feature_rows: list[np.ndarray] = []
    label_rows: list[np.ndarray] = []
    weight_rows: list[float] = []
    session_ids: list[str] = []
    total_frames = 0
    memory_frames: list[np.ndarray] = []
    memory_actions: list[int] = []
    memory_pointer_actions: list[tuple[int, int, int, int, int, int]] = []
    episode_starts: list[int] = []
    episode_ends: list[int] = []

    session_paths = resolve_sessions(path)
    action_cache = {
        session_path: sorted(_jsonl(session_path / "actions/events.jsonl"), key=lambda row: row["timestampNs"])
        for session_path in session_paths
    }
    key_counts: Counter[str] = Counter()
    mouse_counts: Counter[str] = Counter()
    key_codes_by_name: dict[str, int] = {}
    first_seen: dict[str, int] = {}
    seen_order = 0
    total_mouse_delta = 0.0
    total_recorded_seconds = 0.0
    recovery_clicks: list[dict[str, Any]] = []
    for actions in action_cache.values():
        if actions:
            total_recorded_seconds += max(1.0, float(actions[-1]["timestampNs"]) / 1_000_000_000)
        for row in actions:
            total_mouse_delta += abs(float(row.get("deltaX") or 0)) + abs(float(row.get("deltaY") or 0))
            if row.get("type") == "keyDown" and row.get("key"):
                key = str(row["key"])
                key_counts[key] += 1
                if row.get("keyCode") is not None:
                    key_codes_by_name[key] = int(row["keyCode"])
                if key not in first_seen:
                    first_seen[key] = seen_order
                    seen_order += 1
            if row.get("type") == "mouseButtonDown" and row.get("button"):
                name = f"Mouse {row['button']}"
                mouse_counts[name] += 1
                if row.get("x") is not None and row.get("y") is not None:
                    click = {
                        "button": str(row["button"]),
                        "x": round(float(row["x"]), 4),
                        "y": round(float(row["y"]), 4),
                    }
                    # Nearby clicks on the same menu control are one recovery target.
                    if not any(
                        prior["button"] == click["button"]
                        and abs(prior["x"] - click["x"]) < 0.04
                        and abs(prior["y"] - click["y"]) < 0.04
                        for prior in recovery_clicks
                    ):
                        recovery_clicks.append(click)
                if name not in first_seen:
                    first_seen[name] = seen_order
                    seen_order += 1
            for modifier in row.get("modifiers", []):
                if modifier in SUPPORTED_MODIFIERS:
                    key_counts[modifier] += 1
                    if modifier not in first_seen:
                        first_seen[modifier] = seen_order
                        seen_order += 1

    # Return and a single R press are commonly restart delimiters, not desired
    # policy output. Frequently demonstrated R presses remain available for games
    # that genuinely use the key.
    ignored = set(IGNORED_KEYS) | {"Return"}
    if key_counts["R"] <= 2:
        ignored.add("R")
    candidates = [key for key in key_counts if key not in ignored]
    strongest_keyboard = max(key_counts.values(), default=0)
    # A couple of menu/start clicks should not become random gameplay actions.
    # Mouse-controlled games still keep their button because it will be frequent,
    # and mouse-only recordings have no keyboard count to suppress it.
    minimum_mouse_uses = 1 if strongest_keyboard == 0 else max(5, math.ceil(strongest_keyboard * 0.1))
    candidates += [name for name, count in mouse_counts.items() if count >= minimum_mouse_uses]
    look_controls: list[str] = []
    if total_mouse_delta / max(1, total_recorded_seconds) >= 300:
        look_controls = ["Mouse Look Left", "Mouse Look Right", "Mouse Look Up", "Mouse Look Down"]
        for name in look_controls:
            first_seen[name] = seen_order
            seen_order += 1
    candidates.sort(key=lambda name: (-((key_counts | mouse_counts)[name]), first_seen.get(name, 1_000_000)))
    controls = (candidates + look_controls)[:MAX_CONTROLS]
    if not controls:
        raise ValueError("No keyboard or mouse-button controls were found in the selected sessions.")
    control_index = {name: index for index, name in enumerate(controls)}
    control_codes = [key_codes_by_name.get(name, -1) for name in controls]

    for session_path in session_paths:
        metadata = _json(session_path / "metadata.json")
        learning_role = metadata.get("learningRole") or "legacy"
        # A correction is a direct preference: the demonstrated human action is
        # intentionally more valuable than an ordinary imitation frame.
        role_weight = {"practice": 4.0, "autopilot": 4.0, "correction": 5.0}.get(learning_role, 1.0)
        frames = sorted(_jsonl(session_path / "observations/frames.jsonl"), key=lambda row: row["frameIndex"])
        actions = action_cache[session_path]
        if not frames or not actions:
            continue

        container = av.open(str(session_path / metadata["videoPath"]))
        decoded = container.decode(video=0)
        previous: np.ndarray | None = None
        action_index = 0
        held: set[str] = set()
        held_buttons: set[str] = set()
        modifiers: set[str] = set()
        pointer_delta_x = 0.0
        pointer_delta_y = 0.0
        frame_delta_x = 0.0
        frame_delta_y = 0.0
        pointer_scroll_x = 0.0
        pointer_scroll_y = 0.0
        pointer_x = 0.5
        pointer_y = 0.5
        used = 0
        reset_timestamps = [
            int(row["timestampNs"])
            for row in actions
            if row.get("type") == "keyDown" and row.get("key") in {"Return", "R"}
        ]
        segments: dict[int, list[tuple[np.ndarray, int]]] = {}

        for frame_index, video_frame in enumerate(decoded):
            if frame_index >= len(frames):
                break
            frame_info = frames[frame_index]
            while action_index < len(actions) and int(actions[action_index]["timestampNs"]) <= int(frame_info["timestampNs"]):
                action = actions[action_index]
                held = set(action.get("heldKeys", []))
                held_buttons = {f"Mouse {button}" for button in action.get("heldButtons", [])}
                modifiers = set(action.get("modifiers", [])) & SUPPORTED_MODIFIERS
                pointer_delta_x += float(action.get("deltaX") or 0)
                pointer_delta_y += float(action.get("deltaY") or 0)
                frame_delta_x += float(action.get("deltaX") or 0)
                frame_delta_y += float(action.get("deltaY") or 0)
                pointer_scroll_x += float(action.get("scrollX") or 0)
                pointer_scroll_y += float(action.get("scrollY") or 0)
                if action.get("x") is not None:
                    pointer_x = float(action["x"])
                if action.get("y") is not None:
                    pointer_y = float(action["y"])
                action_index += 1

            gray = video_frame.reformat(width=width, height=height, format="gray").to_ndarray().astype(np.float32)
            gray = gray.reshape(height, width) / 127.5 - 1.0
            delta = np.zeros_like(gray) if previous is None else gray - previous
            feature_rows.append(np.concatenate((gray.ravel(), delta.ravel())))
            active_controls = held | held_buttons | modifiers
            if "Mouse Look Left" in control_index and frame_delta_x < -1:
                active_controls.add("Mouse Look Left")
            if "Mouse Look Right" in control_index and frame_delta_x > 1:
                active_controls.add("Mouse Look Right")
            if "Mouse Look Up" in control_index and frame_delta_y < -1:
                active_controls.add("Mouse Look Up")
            if "Mouse Look Down" in control_index and frame_delta_y > 1:
                active_controls.add("Mouse Look Down")
            label_rows.append(np.asarray([key in active_controls for key in controls], dtype=np.float32))
            weight_rows.append(role_weight)
            frame_delta_x = frame_delta_y = 0.0
            # Fifteen visual memories per second are enough for trajectory matching
            # while keeping the model compact. Reset/restart keys split episodes.
            if frame_index % 2 == 0:
                segment = bisect.bisect_right(reset_timestamps, int(frame_info["timestampNs"]))
                action_mask = sum(1 << control_index[key] for key in active_controls if key in control_index)
                memory = np.clip((gray + 1.0) * 127.5, 0, 255).astype(np.uint8)
                pointer = (
                    int(np.clip(round(pointer_delta_x), -32768, 32767)),
                    int(np.clip(round(pointer_delta_y), -32768, 32767)),
                    int(np.clip(round(pointer_scroll_x), -32768, 32767)),
                    int(np.clip(round(pointer_scroll_y), -32768, 32767)),
                    int(np.clip(round(pointer_x * 32767), 0, 32767)),
                    int(np.clip(round(pointer_y * 32767), 0, 32767)),
                )
                segments.setdefault(segment, []).append((memory, action_mask, pointer))
                pointer_delta_x = pointer_delta_y = 0.0
                pointer_scroll_x = pointer_scroll_y = 0.0
            previous = gray
            used += 1

        container.close()
        if used:
            session_ids.append(str(metadata["id"]))
            total_frames += used
            for segment in sorted(segments):
                rows = segments[segment]
                # Idle material after a restart is not a demonstrated attempt and
                # must never replace the actual completed run as the visual goal.
                if len(rows) < 2 or not any(action or any(pointer[:4]) for _, action, pointer in rows):
                    continue
                episode_starts.append(len(memory_frames))
                memory_frames.extend(frame for frame, _, _ in rows)
                memory_actions.extend(action for _, action, _ in rows)
                memory_pointer_actions.extend(pointer for _, _, pointer in rows)
                episode_ends.append(len(memory_frames) - 1)

    if not feature_rows:
        raise ValueError("No sessions with both video frames and input actions were found.")
    return TrainingData(
        features=np.stack(feature_rows),
        labels=np.stack(label_rows),
        session_ids=session_ids,
        frame_count=total_frames,
        sample_weights=np.asarray(weight_rows, dtype=np.float32),
        memory_frames=np.stack(memory_frames) if memory_frames else None,
        memory_actions=np.asarray(memory_actions, dtype=np.uint32) if memory_actions else None,
        episode_starts=episode_starts,
        episode_ends=episode_ends,
        keys=controls,
        key_codes=control_codes,
        memory_pointer_actions=np.asarray(memory_pointer_actions, dtype=np.int16) if memory_pointer_actions else None,
        recovery_clicks=recovery_clicks,
    )


def _sigmoid(value: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(value, -20, 20)))


class Adam:
    def __init__(self, parameters: list[np.ndarray], learning_rate: float = 1e-3) -> None:
        self.parameters = parameters
        self.learning_rate = learning_rate
        self.m = [np.zeros_like(value) for value in parameters]
        self.v = [np.zeros_like(value) for value in parameters]
        self.step = 0

    def update(self, gradients: list[np.ndarray]) -> None:
        self.step += 1
        for index, (parameter, gradient) in enumerate(zip(self.parameters, gradients)):
            self.m[index] = 0.9 * self.m[index] + 0.1 * gradient
            self.v[index] = 0.999 * self.v[index] + 0.001 * gradient * gradient
            m_hat = self.m[index] / (1 - 0.9**self.step)
            v_hat = self.v[index] / (1 - 0.999**self.step)
            parameter -= self.learning_rate * m_hat / (np.sqrt(v_hat) + 1e-8)


def train(
    data: TrainingData,
    *,
    hidden_size: int = 64,
    epochs: int = 30,
    batch_size: int = 64,
    seed: int = 7,
) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    rng = np.random.default_rng(seed)
    features = data.features.astype(np.float32)
    labels = data.labels.astype(np.float32)
    count, input_size = features.shape
    order = rng.permutation(count)
    validation_count = max(1, int(count * 0.15))
    validation_indices = order[:validation_count]
    training_indices = order[validation_count:]
    train_x, train_y = features[training_indices], labels[training_indices]
    val_x, val_y = features[validation_indices], labels[validation_indices]
    all_weights = data.sample_weights if data.sample_weights is not None else np.ones(count, dtype=np.float32)
    train_example_weights = all_weights[training_indices]

    w1 = (rng.standard_normal((input_size, hidden_size), dtype=np.float32) * math.sqrt(2 / input_size)).astype(np.float32)
    b1 = np.zeros(hidden_size, dtype=np.float32)
    keys = data.keys or list(DEFAULT_KEYS)
    w2 = (rng.standard_normal((hidden_size, len(keys)), dtype=np.float32) * math.sqrt(2 / hidden_size)).astype(np.float32)
    b2 = np.zeros(len(keys), dtype=np.float32)
    optimizer = Adam([w1, b1, w2, b2], learning_rate=1.5e-3)

    positives = train_y.sum(axis=0)
    positive_weight = np.clip((len(train_y) - positives) / np.maximum(positives, 1), 1, 20).astype(np.float32)
    history: list[float] = []

    for epoch in range(epochs):
        shuffled = rng.permutation(len(train_x))
        losses: list[float] = []
        for start in range(0, len(shuffled), batch_size):
            indices = shuffled[start : start + batch_size]
            x, y = train_x[indices].copy(), train_y[indices]
            example_weights = train_example_weights[indices].reshape(-1, 1)
            # Small translations and brightness variation make the policy react to
            # local geometry instead of memorizing one level's exact pixels. This
            # is especially important for procedurally changing browser games.
            if data.memory_frames is not None:
                image_height, image_width = data.memory_frames.shape[1:3]
                views = x.reshape(len(x), 2, image_height, image_width)
                for sample in range(len(views)):
                    if rng.random() < 0.7:
                        dy = int(rng.integers(-2, 3))
                        dx = int(rng.integers(-2, 3))
                        original = views[sample].copy()
                        views[sample] = np.roll(views[sample], shift=(dy, dx), axis=(1, 2))
                        if dy > 0:
                            views[sample, :, :dy, :] = original[:, :1, :]
                        elif dy < 0:
                            views[sample, :, dy:, :] = original[:, -1:, :]
                        if dx > 0:
                            views[sample, :, :, :dx] = original[:, :, :1]
                        elif dx < 0:
                            views[sample, :, :, dx:] = original[:, :, -1:]
                    if rng.random() < 0.5:
                        contrast = float(rng.uniform(0.82, 1.18))
                        views[sample, 0] = np.clip(views[sample, 0] * contrast, -1, 1)
            hidden_pre = x @ w1 + b1
            hidden = np.maximum(hidden_pre, 0)
            probabilities = _sigmoid(hidden @ w2 + b2)
            sample_weight = np.where(y > 0.5, positive_weight, 1.0) * example_weights
            loss = -(sample_weight * (y * np.log(probabilities + 1e-7) + (1 - y) * np.log(1 - probabilities + 1e-7))).mean()
            losses.append(float(loss))

            output_gradient = (probabilities - y) * sample_weight / (len(indices) * len(keys))
            grad_w2 = hidden.T @ output_gradient
            grad_b2 = output_gradient.sum(axis=0)
            hidden_gradient = output_gradient @ w2.T
            hidden_gradient[hidden_pre <= 0] = 0
            grad_w1 = x.T @ hidden_gradient
            grad_b1 = hidden_gradient.sum(axis=0)
            optimizer.update([grad_w1, grad_b1, grad_w2, grad_b2])
        history.append(float(np.mean(losses)))

    val_hidden = np.maximum(val_x @ w1 + b1, 0)
    val_probabilities = _sigmoid(val_hidden @ w2 + b2)
    thresholds: list[float] = []
    metrics: dict[str, Any] = {}
    for key_index, key in enumerate(keys):
        truth = val_y[:, key_index] > 0.5
        best = (0.0, 0.5, 0.0, 0.0)
        for threshold in np.linspace(0.2, 0.8, 25):
            predicted = val_probabilities[:, key_index] >= threshold
            tp = int(np.logical_and(predicted, truth).sum())
            fp = int(np.logical_and(predicted, ~truth).sum())
            fn = int(np.logical_and(~predicted, truth).sum())
            precision = tp / max(1, tp + fp)
            recall = tp / max(1, tp + fn)
            f1 = 2 * precision * recall / max(1e-9, precision + recall)
            if f1 > best[0]:
                best = (f1, float(threshold), precision, recall)
        thresholds.append(best[1])
        metrics[key] = {
            "support": int(truth.sum()),
            "f1": round(best[0], 4),
            "precision": round(best[2], 4),
            "recall": round(best[3], 4),
            "threshold": round(best[1], 4),
        }

    return (
        {"w1": w1, "b1": b1, "w2": w2, "b2": b2, "thresholds": np.asarray(thresholds, dtype=np.float32)},
        {
            "trainFrames": int(len(train_x)),
            "validationFrames": int(len(val_x)),
            "finalLoss": round(history[-1], 6),
            "correctionWeightedFrames": int(np.sum(all_weights > 1.0)),
            "positiveFractions": {key: round(float(labels[:, i].mean()), 4) for i, key in enumerate(keys)},
            "validation": metrics,
        },
    )


def _encoded(array: np.ndarray) -> str:
    return base64.b64encode(np.ascontiguousarray(array, dtype="<f4").tobytes()).decode("ascii")


def _encoded_bytes(array: np.ndarray) -> str:
    return base64.b64encode(np.ascontiguousarray(array, dtype=np.uint8).tobytes()).decode("ascii")


def _encoded_uint32(array: np.ndarray) -> str:
    return base64.b64encode(np.ascontiguousarray(array, dtype="<u4").tobytes()).decode("ascii")


def _encoded_int16(array: np.ndarray) -> str:
    return base64.b64encode(np.ascontiguousarray(array, dtype="<i2").tobytes()).decode("ascii")


def _inferred_goal(data: TrainingData) -> str:
    controls = set(data.keys or DEFAULT_KEYS)
    has_recovery = bool(data.recovery_clicks)
    directional = bool(controls & {"A", "D", "W", "S", "Left Arrow", "Right Arrow", "Up Arrow", "Down Arrow"})
    simple_timing = controls <= {"Space", "Mouse Left", "Up Arrow"}
    if simple_timing:
        return (
            "Stay alive, make forward progress, and restart automatically after failure"
            if has_recovery
            else "Stay alive and make forward progress for as long as possible"
        )
    if directional and any(control.startswith("Mouse Look ") for control in controls):
        return "Navigate and explore while increasing progress toward successful demonstrated states"
    if directional:
        return (
            "Advance through the level, recover after failure, and reach the demonstrated finish"
            if has_recovery
            else "Advance through the level and reach the demonstrated finish"
        )
    if any(control.startswith("Mouse ") for control in controls):
        return "Complete the demonstrated visual interaction sequence"
    return "Improve progress toward the final successful demonstrated visual state"


def export_model(
    output: Path,
    parameters: dict[str, np.ndarray],
    metrics: dict[str, Any],
    data: TrainingData,
    width: int,
    height: int,
) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    # Swift inference uses output-major matrices for cache-friendly dot products.
    payload = {
        "format": "learner-goal-policy-v3" if data.memory_frames is not None else "learner-behavior-cloning-mlp-v1",
        "policyMode": "reactive-visual" if data.memory_frames is not None else "behavior-cloning",
        "inputWidth": width,
        "inputHeight": height,
        "featureChannels": ["grayscale", "frame_delta"],
        "keys": data.keys or list(DEFAULT_KEYS),
        "keyCodes": data.key_codes or [-1] * len(data.keys or DEFAULT_KEYS),
        "recoveryClicks": data.recovery_clicks or [],
        "hiddenSize": int(parameters["b1"].shape[0]),
        "thresholds": [float(value) for value in parameters["thresholds"]],
        "weights": {
            "w1": _encoded(parameters["w1"].T),
            "b1": _encoded(parameters["b1"]),
            "w2": _encoded(parameters["w2"].T),
            "b2": _encoded(parameters["b2"]),
        },
        "training": {
            "sessionIDs": data.session_ids,
            "frameCount": data.frame_count,
            **metrics,
        },
    }
    if data.memory_frames is not None and data.memory_actions is not None:
        payload["visualMemory"] = {
            "width": width,
            "height": height,
            "frameCount": int(len(data.memory_frames)),
            "observations": _encoded_bytes(data.memory_frames),
            "actionMasks": _encoded_uint32(data.memory_actions),
            "actionMaskBytes": 4,
            "pointerActions": _encoded_int16(data.memory_pointer_actions) if data.memory_pointer_actions is not None else None,
            "episodeStarts": data.episode_starts or [0],
            "episodeEnds": data.episode_ends or [len(data.memory_frames) - 1],
            "goalDescription": _inferred_goal(data),
            "samplesPerSecond": 15,
        }
        action_counts = Counter(int(mask) for mask in data.memory_actions if int(mask) != 0)
        learned_actions = [mask for mask, _ in action_counts.most_common(12)]
        for index in range(len(data.keys or DEFAULT_KEYS)):
            single = 1 << index
            if single not in learned_actions:
                learned_actions.append(single)
        learned_actions = learned_actions[:24]
        if 0 not in learned_actions:
            learned_actions.append(0)
        payload["onlineLearning"] = {
            "algorithm": "visual-progress-q-learning-v1",
            "actions": learned_actions,
            "learningRate": 0.22,
            "discount": 0.9,
            "exploration": 0.18,
        }
    output.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Train a compact Learner behavior-cloning model.")
    parser.add_argument("dataset", type=Path, help="Session directory, dataset directory, or dataset.json")
    parser.add_argument("--output", type=Path, required=True, help="Destination model.json")
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--hidden-size", type=int, default=64)
    args = parser.parse_args()

    data = load_training_data(args.dataset)
    parameters, metrics = train(data, hidden_size=args.hidden_size, epochs=args.epochs)
    export_model(args.output, parameters, metrics, data, width=64, height=36)
    print(json.dumps({"output": str(args.output), **metrics}, indent=2))


if __name__ == "__main__":
    main()
