// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "Learner",
    platforms: [.macOS(.v14)],
    products: [
        .executable(name: "Learner", targets: ["LearnerApp"]),
        .library(name: "LearnerCore", targets: ["LearnerCore"]),
    ],
    targets: [
        .target(
            name: "LearnerCore",
            path: "Sources/LearnerCore"
        ),
        .executableTarget(
            name: "LearnerApp",
            dependencies: ["LearnerCore"],
            path: "Sources/LearnerApp",
            linkerSettings: [
                .linkedFramework("ScreenCaptureKit"),
                .linkedFramework("AVFoundation"),
                .linkedFramework("CoreImage"),
                .linkedFramework("Metal"),
                .linkedFramework("ApplicationServices"),
            ]
        ),
        .testTarget(
            name: "LearnerCoreTests",
            dependencies: ["LearnerCore"],
            path: "Tests/LearnerCoreTests"
        ),
        .testTarget(
            name: "LearnerAppTests",
            dependencies: ["LearnerApp", "LearnerCore"],
            path: "Tests/LearnerAppTests"
        ),
    ],
    swiftLanguageModes: [.v5]
)
