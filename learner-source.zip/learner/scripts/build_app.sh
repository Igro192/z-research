#!/bin/zsh
set -euo pipefail

PROJECT_DIR="${0:A:h:h}"
OUTPUT_DIR="$PROJECT_DIR/outputs"
TEMP_DIR="$(mktemp -d -t learner-build.XXXXXX)"
APP_PATH="$TEMP_DIR/Learner.app"
OUTPUT_APP="$OUTPUT_DIR/Learner.app"
trap '/bin/rm -rf "$TEMP_DIR"' EXIT

cd "$PROJECT_DIR"
swift build -c release

/bin/mkdir -p "$APP_PATH/Contents/MacOS" "$APP_PATH/Contents/Resources"
/bin/cp "$PROJECT_DIR/.build/release/Learner" "$APP_PATH/Contents/MacOS/Learner"
/bin/cp "$PROJECT_DIR/scripts/Info.plist" "$APP_PATH/Contents/Info.plist"
/bin/mkdir -p "$APP_PATH/Contents/Resources/python"
/usr/bin/ditto --norsrc --noextattr --noacl "$PROJECT_DIR/python/learner_dataset" "$APP_PATH/Contents/Resources/python/learner_dataset"
if [[ -d "$PROJECT_DIR/work/reader-venv/lib/python3.13/site-packages" ]]; then
    /usr/bin/ditto --norsrc --noextattr --noacl "$PROJECT_DIR/work/reader-venv/lib/python3.13/site-packages" "$APP_PATH/Contents/Resources/python/site-packages"
fi

ICONSET="$TEMP_DIR/AppIcon.iconset"
/bin/mkdir -p "$ICONSET"
swift "$PROJECT_DIR/scripts/make_icon.swift" "$TEMP_DIR/icon_1024.png"
function make_icon_size() {
    local pixels="$1"
    local name="$2"
    /usr/bin/sips -z "$pixels" "$pixels" "$TEMP_DIR/icon_1024.png" --out "$ICONSET/$name" >/dev/null
}
make_icon_size 16 icon_16x16.png
make_icon_size 32 icon_16x16@2x.png
make_icon_size 32 icon_32x32.png
make_icon_size 64 icon_32x32@2x.png
make_icon_size 128 icon_128x128.png
make_icon_size 256 icon_128x128@2x.png
make_icon_size 256 icon_256x256.png
make_icon_size 512 icon_256x256@2x.png
make_icon_size 512 icon_512x512.png
make_icon_size 1024 icon_512x512@2x.png
/usr/bin/iconutil -c icns "$ICONSET" -o "$APP_PATH/Contents/Resources/AppIcon.icns"
/usr/bin/xattr -cr "$APP_PATH"
/usr/bin/codesign --force --deep --sign - --requirements '=designated => identifier "com.local.learner"' "$APP_PATH"
/usr/bin/xattr -cr "$APP_PATH"
if [[ -d "$OUTPUT_APP" ]]; then /bin/rm -rf "$OUTPUT_APP"; fi
/usr/bin/ditto --norsrc --noextattr --noacl "$APP_PATH" "$OUTPUT_APP"
/bin/rm -f "$OUTPUT_DIR/Learner-macOS.zip"
/usr/bin/ditto --norsrc --noextattr --noacl -c -k --keepParent "$APP_PATH" "$OUTPUT_DIR/Learner-macOS.zip"
echo "$OUTPUT_APP"
