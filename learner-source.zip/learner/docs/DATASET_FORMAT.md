# Learner dataset format v1

Each session is independent and append-friendly:

```text
<session-id>/
  metadata.json
  video/observation.mp4
  actions/events.jsonl
  observations/frames.jsonl
  markers/labels.jsonl
  regions/<name>.mp4
```

`observation.mp4` is a fragmented H.264 stream. Each row of `frames.jsonl` maps a monotonically increasing frame index to the session clock. Each row of `events.jsonl` is an actual keyboard or mouse event, not a polled state snapshot. Events also contain held-key, modifier, and held-button state to make random access straightforward.

The session clock is monotonic nanoseconds from the beginning of active recording. Paused time is removed. A causal transition contains frame `N`, all actions in `(timestamp[N], timestamp[N+1]]`, and frame `N+1`.

Session metadata is atomically checkpointed during recording. MP4 movie fragments are emitted every two seconds. On next launch, an unfinished recording is marked `interrupted` rather than hidden.

Combined datasets contain a small `dataset.json` manifest with session UUIDs. Sessions are not copied, so combining is immediate and disk-efficient.

## Game projects

The current UI groups experience into a Game without changing the v1 session contract:

```text
Games/<game-id>/
  game.json
  learning/experience.json
  understanding.json
  corrections.jsonl
  experience/agent-decisions.jsonl
  model/model.json
  model/correction_learning.json
```

`game.json` references session UUIDs. `understanding.json` contains measured visual-state clusters, repeated action sequences, detected events, and observed embedding transitions. `corrections.jsonl` records the agent proposal, confidence, and the human replacement action. Legacy `Datasets/` and `Models/latest/` content is retained unchanged.
