import Foundation

struct BehaviorModelDocument: Decodable {
    let format: String
    let policyMode: String?
    let inputWidth: Int
    let inputHeight: Int
    let featureChannels: [String]
    let keys: [String]
    let keyCodes: [Int]?
    let hiddenSize: Int
    let thresholds: [Float]
    let weights: EncodedWeights
    let training: TrainingMetadata
    let visualMemory: VisualMemoryDocument?
    let onlineLearning: OnlineLearningDocument?
    let recoveryClicks: [RecoveryClickDocument]?

    struct EncodedWeights: Decodable {
        let w1: String
        let b1: String
        let w2: String
        let b2: String
    }

    struct TrainingMetadata: Decodable {
        let sessionIDs: [String]
        let frameCount: Int
        let trainFrames: Int
        let validationFrames: Int
        let finalLoss: Double
    }

    struct VisualMemoryDocument: Decodable {
        let width: Int
        let height: Int
        let frameCount: Int
        let observations: String
        let actionMasks: String
        let actionMaskBytes: Int?
        let pointerActions: String?
        let episodeStarts: [Int]
        let episodeEnds: [Int]
        let goalDescription: String
        let samplesPerSecond: Int
    }

    struct OnlineLearningDocument: Decodable {
        let algorithm: String
        let actions: [UInt64]
        let learningRate: Float
        let discount: Float
        let exploration: Float
    }

    struct RecoveryClickDocument: Decodable {
        let button: String
        let x: Double
        let y: Double
    }
}

final class BehaviorModel {
    struct RecoveryClick {
        let button: String
        let x: Double
        let y: Double
    }

    struct VisualMemory {
        struct PointerAction {
            let deltaX: Int16
            let deltaY: Int16
            let scrollX: Int16
            let scrollY: Int16
            let x: Int16
            let y: Int16

            static let zero = PointerAction(deltaX: 0, deltaY: 0, scrollX: 0, scrollY: 0, x: 16_384, y: 16_384)
        }

        let width: Int
        let height: Int
        let frameCount: Int
        let observations: [UInt8]
        let actionMasks: [UInt64]
        let pointerActions: [PointerAction]
        let episodeStarts: [Int]
        let episodeEnds: [Int]
        let goalDescription: String
        let samplesPerSecond: Int

        var pixelsPerFrame: Int { width * height }
    }

    struct OnlineSettings {
        let actions: [UInt64]
        let learningRate: Float
        let discount: Float
        let exploration: Float
    }

    let inputWidth: Int
    let inputHeight: Int
    let keys: [String]
    let keyCodes: [Int]
    let thresholds: [Float]
    let trainingFrameCount: Int
    let trainingSessionIDs: [String]
    let visualMemory: VisualMemory?
    let onlineSettings: OnlineSettings?
    let policyMode: String
    let recoveryClicks: [RecoveryClick]

    private let inputSize: Int
    private let hiddenSize: Int
    private let w1: [Float] // hidden-major
    private let b1: [Float]
    private let w2: [Float] // output-major
    private let b2: [Float]

    init(url: URL) throws {
        let decoder = JSONDecoder()
        let document = try decoder.decode(BehaviorModelDocument.self, from: Data(contentsOf: url))
        guard ["learner-behavior-cloning-mlp-v1", "learner-goal-policy-v2", "learner-goal-policy-v3"].contains(document.format),
              document.inputWidth > 0,
              document.inputHeight > 0,
              document.featureChannels == ["grayscale", "frame_delta"],
              document.thresholds.count == document.keys.count else {
            throw ModelError.unsupportedFormat
        }
        inputWidth = document.inputWidth
        inputHeight = document.inputHeight
        inputSize = inputWidth * inputHeight * 2
        keys = document.keys
        if let encodedCodes = document.keyCodes, encodedCodes.count == document.keys.count {
            keyCodes = encodedCodes
        } else {
            keyCodes = document.keys.map { Self.legacyKeyCodes[$0] ?? -1 }
        }
        thresholds = document.thresholds
        hiddenSize = document.hiddenSize
        trainingFrameCount = document.training.frameCount
        trainingSessionIDs = document.training.sessionIDs
        policyMode = document.policyMode ?? (document.format == "learner-goal-policy-v3" ? "reactive-visual" : "trajectory")
        let parsedRecoveryClicks = (document.recoveryClicks ?? []).map {
            RecoveryClick(button: $0.button, x: min(max($0.x, 0), 1), y: min(max($0.y, 0), 1))
        }
        recoveryClicks = parsedRecoveryClicks
        w1 = try Self.decodeFloats(document.weights.w1)
        b1 = try Self.decodeFloats(document.weights.b1)
        w2 = try Self.decodeFloats(document.weights.w2)
        b2 = try Self.decodeFloats(document.weights.b2)
        guard w1.count == hiddenSize * inputSize,
              b1.count == hiddenSize,
              w2.count == keys.count * hiddenSize,
              b2.count == keys.count else {
            throw ModelError.invalidWeights
        }

        if let memory = document.visualMemory {
            let observations = try Self.decodeBytes(memory.observations)
            let actions = try Self.decodeActionMasks(memory.actionMasks, bytesPerMask: memory.actionMaskBytes ?? 1)
            let pointers = try Self.decodePointerActions(memory.pointerActions, frameCount: memory.frameCount)
            guard memory.width == inputWidth,
                  memory.height == inputHeight,
                  memory.frameCount > 1,
                  observations.count == memory.frameCount * memory.width * memory.height,
                  actions.count == memory.frameCount,
                  pointers.count == memory.frameCount,
                  memory.episodeStarts.count == memory.episodeEnds.count,
                  !memory.episodeStarts.isEmpty,
                  zip(memory.episodeStarts, memory.episodeEnds).allSatisfy({ start, end in
                      start >= 0 && end >= start && end < memory.frameCount
                  }) else { throw ModelError.invalidVisualMemory }
            visualMemory = VisualMemory(
                width: memory.width,
                height: memory.height,
                frameCount: memory.frameCount,
                observations: observations,
                actionMasks: actions,
                pointerActions: pointers,
                episodeStarts: memory.episodeStarts,
                episodeEnds: memory.episodeEnds,
                goalDescription: Self.inferredGoalDescription(
                    controls: document.keys,
                    hasRecoveryClicks: !parsedRecoveryClicks.isEmpty,
                    fallback: memory.goalDescription
                ),
                samplesPerSecond: memory.samplesPerSecond
            )
        } else {
            visualMemory = nil
        }
        if let online = document.onlineLearning, online.algorithm == "visual-progress-q-learning-v1", !online.actions.isEmpty {
            onlineSettings = OnlineSettings(
                actions: online.actions,
                learningRate: online.learningRate,
                discount: online.discount,
                exploration: online.exploration
            )
        } else {
            onlineSettings = nil
        }
    }

    func predict(features: [Float]) -> [Float] {
        guard features.count == inputSize else { return Array(repeating: 0, count: keys.count) }
        var hidden = Array(repeating: Float(0), count: hiddenSize)
        for row in 0..<hiddenSize {
            var sum = b1[row]
            let offset = row * inputSize
            for column in 0..<inputSize { sum += w1[offset + column] * features[column] }
            hidden[row] = max(0, sum)
        }
        var output = Array(repeating: Float(0), count: keys.count)
        for row in 0..<keys.count {
            var sum = b2[row]
            let offset = row * hiddenSize
            for column in 0..<hiddenSize { sum += w2[offset + column] * hidden[column] }
            output[row] = 1 / (1 + exp(-max(-20, min(20, sum))))
        }
        return output
    }

    private static func decodeFloats(_ encoded: String) throws -> [Float] {
        guard let data = Data(base64Encoded: encoded), data.count.isMultiple(of: MemoryLayout<Float>.size) else {
            throw ModelError.invalidWeights
        }
        var values = Array(repeating: Float(0), count: data.count / MemoryLayout<Float>.size)
        _ = values.withUnsafeMutableBytes { destination in
            data.copyBytes(to: destination)
        }
        return values
    }

    private static func decodeBytes(_ encoded: String) throws -> [UInt8] {
        guard let data = Data(base64Encoded: encoded) else { throw ModelError.invalidVisualMemory }
        return Array(data)
    }

    private static func decodeActionMasks(_ encoded: String, bytesPerMask: Int) throws -> [UInt64] {
        guard let data = Data(base64Encoded: encoded), [1, 2, 4, 8].contains(bytesPerMask), data.count.isMultiple(of: bytesPerMask) else {
            throw ModelError.invalidVisualMemory
        }
        let bytes = Array(data)
        return stride(from: 0, to: bytes.count, by: bytesPerMask).map { offset in
            var value: UInt64 = 0
            for byte in 0..<bytesPerMask { value |= UInt64(bytes[offset + byte]) << UInt64(byte * 8) }
            return value
        }
    }

    private static func decodePointerActions(_ encoded: String?, frameCount: Int) throws -> [VisualMemory.PointerAction] {
        guard let encoded else { return Array(repeating: .zero, count: frameCount) }
        guard let data = Data(base64Encoded: encoded), data.count == frameCount * 12 else {
            throw ModelError.invalidVisualMemory
        }
        let bytes = Array(data)
        func value(_ offset: Int) -> Int16 {
            Int16(bitPattern: UInt16(bytes[offset]) | UInt16(bytes[offset + 1]) << 8)
        }
        return (0..<frameCount).map { frame in
            let offset = frame * 12
            return VisualMemory.PointerAction(
                deltaX: value(offset), deltaY: value(offset + 2),
                scrollX: value(offset + 4), scrollY: value(offset + 6),
                x: value(offset + 8), y: value(offset + 10)
            )
        }
    }

    private static func inferredGoalDescription(controls: [String], hasRecoveryClicks: Bool, fallback: String) -> String {
        let controlSet = Set(controls)
        let directional = !controlSet.intersection(["A", "D", "W", "S", "Left Arrow", "Right Arrow", "Up Arrow", "Down Arrow"]).isEmpty
        let usesLook = controls.contains { $0.hasPrefix("Mouse Look ") }
        let simpleTiming = controlSet.isSubset(of: ["Space", "Mouse Left", "Up Arrow"])
        if simpleTiming {
            return hasRecoveryClicks
                ? "Stay alive, make forward progress, and restart automatically after failure"
                : "Stay alive and make forward progress for as long as possible"
        }
        if usesLook && directional {
            return "Navigate and explore while increasing progress toward successful demonstrated states"
        }
        if directional {
            return hasRecoveryClicks
                ? "Advance through the level, recover after failure, and reach the demonstrated finish"
                : "Advance through the level and reach the demonstrated finish"
        }
        if controls.contains(where: { $0.hasPrefix("Mouse ") }) {
            return "Complete the demonstrated visual interaction sequence"
        }
        return fallback
    }

    private static let legacyKeyCodes: [String: Int] = [
        "A": 0, "S": 1, "D": 2, "F": 3, "H": 4, "G": 5, "Z": 6, "X": 7, "C": 8, "V": 9,
        "B": 11, "Q": 12, "W": 13, "E": 14, "R": 15, "Y": 16, "T": 17, "1": 18, "2": 19,
        "3": 20, "4": 21, "6": 22, "5": 23, "9": 25, "7": 26, "8": 28, "0": 29, "O": 31,
        "U": 32, "I": 34, "P": 35, "Return": 36, "L": 37, "J": 38, "K": 40, "N": 45, "M": 46,
        "Tab": 48, "Space": 49, "Delete": 51, "Shift": 56, "Control": 59,
        "Left Arrow": 123, "Right Arrow": 124, "Down Arrow": 125, "Up Arrow": 126,
    ]

    enum ModelError: LocalizedError {
        case unsupportedFormat
        case invalidWeights
        case invalidVisualMemory
        var errorDescription: String? {
            switch self {
            case .unsupportedFormat: "This behavior model uses an unsupported format."
            case .invalidWeights: "The behavior model is incomplete or corrupt."
            case .invalidVisualMemory: "The model’s visual goal memory is incomplete or corrupt."
            }
        }
    }
}
