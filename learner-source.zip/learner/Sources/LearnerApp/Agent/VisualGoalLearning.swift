import Foundation

struct VisualGoalMatch {
    let index: Int
    let distance: Double
    let progress: Double
    let episodeStart: Int
    let episodeEnd: Int
}

final class VisualGoalNavigator {
    private let memory: BehaviorModel.VisualMemory
    private var cursor: Int?
    private var episodeStart = 0
    private var episodeEnd = 0
    private var calls = 0

    init(memory: BehaviorModel.VisualMemory) {
        self.memory = memory
        episodeStart = memory.episodeStarts[0]
        episodeEnd = memory.episodeEnds[0]
    }

    func locate(_ observation: [UInt8]) -> VisualGoalMatch? {
        guard observation.count == memory.pixelsPerFrame else { return nil }
        calls += 1

        let candidate: (Int, Double)
        if let cursor {
            let lower = max(episodeStart, cursor - 10)
            let upper = min(episodeEnd, cursor + max(45, memory.samplesPerSecond * 4))
            var local = nearest(observation, range: lower...upper, expected: min(episodeEnd, cursor + 1))

            // Periodic global relocalization lets the learner recover after death,
            // manual reset, a missed transition, or switching to another episode.
            if calls.isMultiple(of: max(10, memory.samplesPerSecond)) {
                let global = nearestAcrossEpisodes(observation)
                if global.1 + 0.55 < local.1 || (global.0 < episodeStart + memory.samplesPerSecond && local.1 > 4.5) {
                    local = global
                    selectEpisode(containing: global.0)
                }
            }
            candidate = local
        } else {
            candidate = nearestAcrossEpisodes(observation)
            selectEpisode(containing: candidate.0)
        }

        cursor = candidate.0
        let span = max(1, episodeEnd - episodeStart)
        let progress = Double(candidate.0 - episodeStart) / Double(span)
        return VisualGoalMatch(
            index: candidate.0,
            distance: candidate.1,
            progress: min(max(progress, 0), 1),
            episodeStart: episodeStart,
            episodeEnd: episodeEnd
        )
    }

    func demonstratedAction(near index: Int) -> UInt64 {
        let target = min(episodeEnd, index + 2)
        // A demonstration often starts with several seconds of waiting while the
        // player gets ready.  A purely visual matcher cannot move past those
        // near-identical frames on its own, so begin the next demonstrated action
        // instead of reproducing the hesitation.
        var mask = memory.actionMasks[target]
        if mask == 0 {
            let actionSearchEnd = min(episodeEnd, target + memory.samplesPerSecond * 3)
            if target <= actionSearchEnd,
               let nextAction = (target...actionSearchEnd).first(where: { memory.actionMasks[$0] != 0 }) {
                mask = memory.actionMasks[nextAction]
            }
        }

        // Preserve short pulses in any control (jump, click, dodge, interact).
        // Looking roughly a third of a second ahead makes rare actions survive
        // temporal downsampling instead of being averaged away.
        let lookAheadEnd = min(episodeEnd, target + max(4, memory.samplesPerSecond / 3))
        if target <= lookAheadEnd {
            for frame in target...lookAheadEnd {
                let future = memory.actionMasks[frame]
                if future != 0 { mask |= future }
            }
        }
        return mask
    }

    func demonstratedPointer(near index: Int) -> BehaviorModel.VisualMemory.PointerAction {
        memory.pointerActions[min(episodeEnd, index + 1)]
    }

    private func nearestAcrossEpisodes(_ observation: [UInt8]) -> (Int, Double) {
        var best = (memory.episodeStarts[0], Double.greatestFiniteMagnitude)
        for (start, end) in zip(memory.episodeStarts, memory.episodeEnds) {
            let candidate = nearest(observation, range: start...end, expected: nil)
            if candidate.1 < best.1 { best = candidate }
        }
        return best
    }

    private func nearest(_ observation: [UInt8], range: ClosedRange<Int>, expected: Int?) -> (Int, Double) {
        var bestIndex = range.lowerBound
        var bestScore = Double.greatestFiniteMagnitude
        var bestDistance = bestScore
        let pixels = memory.pixelsPerFrame
        for frame in range {
            let offset = frame * pixels
            var difference = 0
            // Every pixel remains cheap at 64×36 and retains the tiny player sprite.
            for pixel in 0..<pixels {
                difference += abs(Int(observation[pixel]) - Int(memory.observations[offset + pixel]))
            }
            let distance = Double(difference) / Double(pixels)
            let continuity = expected.map { Double(abs(frame - $0)) * 0.012 } ?? 0
            let score = distance + continuity
            if score < bestScore {
                bestScore = score
                bestDistance = distance
                bestIndex = frame
            }
        }
        return (bestIndex, bestDistance)
    }

    private func selectEpisode(containing index: Int) {
        for (start, end) in zip(memory.episodeStarts, memory.episodeEnds) where index >= start && index <= end {
            episodeStart = start
            episodeEnd = end
            return
        }
    }
}

struct OnlineGoalDecision {
    let actionMask: UInt64
    let reward: Double
    let exploring: Bool
    let updates: Int
}

final class OnlineGoalLearner {
    private struct Persisted: Codable {
        var version = 1
        var totalUpdates: Int
        var qValues: [String: [Float]]
        var visits: [String: [Int]]
        var bestProgress: Double
        var updatedAt: Date
    }

    private let settings: BehaviorModel.OnlineSettings
    private let url: URL
    private var qValues: [String: [Float]] = [:]
    private var visits: [String: [Int]] = [:]
    private var previousState: String?
    private var previousActionIndex: Int?
    private var previousMatch: Int?
    private var bestMatch: Int?
    private var bestProgress = 0.0
    private var lastProgressNs: UInt64 = 0
    private var explorationUntilNs: UInt64 = 0
    private var explorationMask: UInt64 = 0
    private var totalUpdates = 0
    private var lastSaveNs: UInt64 = 0

    init(settings: BehaviorModel.OnlineSettings, url: URL) {
        self.settings = settings
        self.url = url
        load()
    }

    func choose(imitationMask: UInt64, match: VisualGoalMatch, timestampNs: UInt64) -> OnlineGoalDecision {
        let state = stateKey(match.index)
        ensureState(state)
        let delta = previousMatch.map { match.index - $0 } ?? 0
        var reward = Double(max(-8, min(8, delta))) / 8.0
        if let previousMatch, match.index + settings.actions.count < previousMatch {
            // Death, restart, or a level reload begins a new attempt. Without
            // this reset the learner would think it was permanently stalled below
            // an old high-water mark and explore continuously.
            bestMatch = match.index
            lastProgressNs = timestampNs
            explorationUntilNs = 0
        }
        if bestMatch == nil || match.index > bestMatch! {
            bestMatch = match.index
            lastProgressNs = timestampNs
            reward += 0.2
        }
        if match.progress > bestProgress {
            bestProgress = match.progress
            reward += 0.1
        }
        if match.progress >= 0.985 { reward += 2.0 }
        if lastProgressNs == 0 { lastProgressNs = timestampNs }

        if let previousState, let previousActionIndex {
            ensureState(previousState)
            let future = qValues[state]?.max() ?? 0
            let old = qValues[previousState]![previousActionIndex]
            let target = Float(reward) + settings.discount * future
            qValues[previousState]![previousActionIndex] = old + settings.learningRate * (target - old)
            visits[previousState]![previousActionIndex] += 1
            totalUpdates += 1
        }

        let stalled = timestampNs > lastProgressNs + 700_000_000
        var actionMask = imitationMask
        var exploring = false
        if timestampNs < explorationUntilNs {
            actionMask = explorationMask
            exploring = true
        } else if stalled {
            let actionIndex = explorationAction(for: state, imitationMask: imitationMask)
            actionMask = settings.actions[actionIndex]
            explorationMask = actionMask
            explorationUntilNs = timestampNs + 360_000_000
            previousActionIndex = actionIndex
            exploring = true
            lastProgressNs = timestampNs
        } else {
            previousActionIndex = actionIndex(for: imitationMask)
        }

        previousState = state
        previousMatch = match.index
        if timestampNs > lastSaveNs + 5_000_000_000 {
            save()
            lastSaveNs = timestampNs
        }
        return OnlineGoalDecision(actionMask: actionMask, reward: reward, exploring: exploring, updates: totalUpdates)
    }

    func save() {
        let document = Persisted(
            totalUpdates: totalUpdates,
            qValues: qValues,
            visits: visits,
            bestProgress: bestProgress,
            updatedAt: Date()
        )
        guard let data = try? JSONEncoder().encode(document) else { return }
        try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try? data.write(to: url, options: .atomic)
    }

    private func explorationAction(for state: String, imitationMask: UInt64) -> Int {
        ensureState(state)
        // The exported action set comes from this game's own demonstration, so
        // exploration works for arrows, WASD, Space, clicks, or combinations
        // without baking platformer-specific controls into the runtime.
        let indices = [actionIndex(for: imitationMask)] + Array(settings.actions.indices)
        var unique: [Int] = []
        for index in indices where !unique.contains(index) { unique.append(index) }
        let visitTotal = visits[state]!.reduce(0, +)
        let effectiveExploration = settings.exploration / sqrt(Float(max(1, visitTotal / 4)))
        if Float.random(in: 0...1) < effectiveExploration, let random = unique.randomElement() { return random }
        return unique.min { left, right in
            let leftVisits = visits[state]![left]
            let rightVisits = visits[state]![right]
            let minimumVisits = visits[state]!.min() ?? 0
            if minimumVisits < 2, leftVisits != rightVisits { return leftVisits < rightVisits }
            return qValues[state]![left] > qValues[state]![right]
        } ?? 0
    }

    private func actionIndex(for mask: UInt64) -> Int {
        if let exact = settings.actions.firstIndex(of: mask) { return exact }
        return settings.actions.indices.min { left, right in
            (settings.actions[left] ^ mask).nonzeroBitCount < (settings.actions[right] ^ mask).nonzeroBitCount
        } ?? 0
    }

    private func stateKey(_ match: Int) -> String { String(match / 3) }

    private func ensureState(_ state: String) {
        if qValues[state] == nil { qValues[state] = Array(repeating: 0, count: settings.actions.count) }
        if visits[state] == nil { visits[state] = Array(repeating: 0, count: settings.actions.count) }
    }

    private func load() {
        guard let data = try? Data(contentsOf: url),
              let document = try? JSONDecoder().decode(Persisted.self, from: data),
              document.version == 1 else { return }
        qValues = document.qValues.filter { $0.value.count == settings.actions.count }
        visits = document.visits.filter { $0.value.count == settings.actions.count }
        totalUpdates = document.totalUpdates
        bestProgress = document.bestProgress
    }
}

/// Lightweight persistent reinforcement for layouts that change every attempt.
/// It follows the demonstrated visual policy while the scene is progressing, then
/// learns which demonstrated action restarts or unsticks visually static states.
final class ReactiveOnlineLearner {
    private struct Persisted: Codable {
        var version = 1
        var totalUpdates: Int
        var qValues: [String: [Float]]
        var visits: [String: [Int]]
        var updatedAt: Date
    }

    private let settings: BehaviorModel.OnlineSettings
    private let url: URL
    private let width: Int
    private let height: Int
    private var qValues: [String: [Float]] = [:]
    private var visits: [String: [Int]] = [:]
    private var previousState: String?
    private var previousAction = 0
    private var staticSinceNs: UInt64 = 0
    private var explorationUntilNs: UInt64 = 0
    private var explorationMask: UInt64 = 0
    private var totalUpdates = 0
    private var lastSaveNs: UInt64 = 0

    init(settings: BehaviorModel.OnlineSettings, width: Int, height: Int, url: URL) {
        self.settings = settings
        self.width = width
        self.height = height
        self.url = url
        load()
    }

    func choose(imitationMask: UInt64, pixels: [UInt8], motion: Double, timestampNs: UInt64) -> OnlineGoalDecision {
        let state = stateKey(pixels)
        ensureState(state)
        // Continuous visual motion is a deliberately generic local reward: in a
        // scrolling game it means survival/progress, while a static death/menu
        // screen becomes a state in which the learner should try a restart action.
        let reward = min(1, motion * 12) + (motion > 0.004 ? 0.025 : -0.08)
        if let previousState {
            ensureState(previousState)
            let future = qValues[state]?.max() ?? 0
            let old = qValues[previousState]![previousAction]
            let target = Float(reward) + settings.discount * future
            qValues[previousState]![previousAction] = old + settings.learningRate * (target - old)
            visits[previousState]![previousAction] += 1
            totalUpdates += 1
        }

        if motion > 0.004 {
            staticSinceNs = 0
        } else if staticSinceNs == 0 {
            staticSinceNs = timestampNs
        }

        let stuck = staticSinceNs > 0 && timestampNs > staticSinceNs + 850_000_000
        var mask = imitationMask
        var exploring = false
        if timestampNs < explorationUntilNs {
            mask = explorationMask
            exploring = true
        } else if stuck {
            let index = recoveryAction(for: state, imitationMask: imitationMask)
            mask = settings.actions[index]
            explorationMask = mask
            explorationUntilNs = timestampNs + 420_000_000
            staticSinceNs = timestampNs
            exploring = true
        }

        previousState = state
        previousAction = actionIndex(for: mask)
        if timestampNs > lastSaveNs + 5_000_000_000 {
            save()
            lastSaveNs = timestampNs
        }
        return OnlineGoalDecision(actionMask: mask, reward: reward, exploring: exploring, updates: totalUpdates)
    }

    func save() {
        let document = Persisted(totalUpdates: totalUpdates, qValues: qValues, visits: visits, updatedAt: Date())
        guard let data = try? JSONEncoder().encode(document) else { return }
        try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try? data.write(to: url, options: .atomic)
    }

    private func recoveryAction(for state: String, imitationMask: UInt64) -> Int {
        ensureState(state)
        let imitation = actionIndex(for: imitationMask)
        let order = [imitation] + Array(settings.actions.indices).filter { $0 != imitation }
        let minimumVisits = order.map { visits[state]![$0] }.min() ?? 0
        if minimumVisits < 2 {
            return order.min { visits[state]![$0] < visits[state]![$1] } ?? imitation
        }
        let visitTotal = visits[state]!.reduce(0, +)
        let epsilon = settings.exploration / sqrt(Float(max(1, visitTotal / 4)))
        if Float.random(in: 0...1) < epsilon { return order.randomElement() ?? imitation }
        return order.max { qValues[state]![$0] < qValues[state]![$1] } ?? imitation
    }

    private func actionIndex(for mask: UInt64) -> Int {
        if let exact = settings.actions.firstIndex(of: mask) { return exact }
        return settings.actions.indices.min {
            (settings.actions[$0] ^ mask).nonzeroBitCount < (settings.actions[$1] ^ mask).nonzeroBitCount
        } ?? 0
    }

    private func stateKey(_ pixels: [UInt8]) -> String {
        var key = ""
        key.reserveCapacity(48)
        for row in 0..<6 {
            let y = min(height - 1, row * height / 6 + height / 12)
            for column in 0..<8 {
                let x = min(width - 1, column * width / 8 + width / 16)
                key.append(String(format: "%X", pixels[y * width + x] >> 5))
            }
        }
        return key
    }

    private func ensureState(_ state: String) {
        if qValues[state] == nil { qValues[state] = Array(repeating: 0, count: settings.actions.count) }
        if visits[state] == nil { visits[state] = Array(repeating: 0, count: settings.actions.count) }
    }

    private func load() {
        guard let data = try? Data(contentsOf: url),
              let document = try? JSONDecoder().decode(Persisted.self, from: data),
              document.version == 1 else { return }
        qValues = document.qValues.filter { $0.value.count == settings.actions.count }
        visits = document.visits.filter { $0.value.count == settings.actions.count }
        totalUpdates = document.totalUpdates
    }
}
