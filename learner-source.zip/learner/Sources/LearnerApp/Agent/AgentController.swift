import AppKit
import ApplicationServices
import CoreImage
import CoreVideo
import LearnerCore
import Metal

final class AgentController: @unchecked Sendable {
    var onPrediction: (([String: Double]) -> Void)?

    let model: BehaviorModel
    private let targetPID: pid_t?
    private let targetBounds: CodableRect
    private let context: CIContext
    private let pool: CVPixelBufferPool
    private let navigator: VisualGoalNavigator?
    private let onlineLearner: OnlineGoalLearner?
    private let reactiveLearner: ReactiveOnlineLearner?
    private let correctionLearner: CorrectionLearner
    private let lock = NSLock()
    private var previousGray: [Float]?
    private var heldKeys = Set<String>()
    private var heldButtons = Set<String>()
    private var lastInferenceNs: UInt64 = 0
    private var staticSinceNs: UInt64?
    private var lastRecoveryClickNs: UInt64 = 0
    private var recoveryClickIndex = 0
    private var running = true
    private var suppressedForHuman = false
    private var currentCorrectionState = "unknown"
    private var lastDesiredControls = Set<String>()

    init(modelURL: URL, targetPID: pid_t?, targetBounds: CodableRect) throws {
        model = try BehaviorModel(url: modelURL)
        self.targetPID = targetPID
        self.targetBounds = targetBounds
        correctionLearner = CorrectionLearner(
            url: modelURL.deletingLastPathComponent().appendingPathComponent("correction_learning.json"),
            controls: model.keys,
            width: model.inputWidth,
            height: model.inputHeight
        )
        if let memory = model.visualMemory {
            navigator = VisualGoalNavigator(memory: memory)
        } else {
            navigator = nil
        }
        if let settings = model.onlineSettings, model.visualMemory != nil, model.policyMode == "reactive-visual" {
            onlineLearner = nil
            reactiveLearner = ReactiveOnlineLearner(
                settings: settings,
                width: model.inputWidth,
                height: model.inputHeight,
                url: modelURL.deletingLastPathComponent().appendingPathComponent("reactive_learning.json")
            )
        } else if let settings = model.onlineSettings, model.visualMemory != nil {
            onlineLearner = OnlineGoalLearner(
                settings: settings,
                url: modelURL.deletingLastPathComponent().appendingPathComponent("online_learning.json")
            )
            reactiveLearner = nil
        } else {
            onlineLearner = nil
            reactiveLearner = nil
        }
        if let device = MTLCreateSystemDefaultDevice() {
            context = CIContext(mtlDevice: device, options: [.cacheIntermediates: false])
        } else {
            context = CIContext(options: [.cacheIntermediates: false])
        }
        var createdPool: CVPixelBufferPool?
        let attributes: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: model.inputWidth,
            kCVPixelBufferHeightKey as String: model.inputHeight,
            kCVPixelBufferIOSurfacePropertiesKey as String: [:],
        ]
        guard CVPixelBufferPoolCreate(nil, nil, attributes as CFDictionary, &createdPool) == kCVReturnSuccess,
              let createdPool else { throw ControllerError.cannotPrepareInput }
        pool = createdPool
    }

    func process(_ source: CVPixelBuffer, timestampNs: UInt64) {
        lock.lock()
        let isRunning = running
        let isSuppressed = suppressedForHuman
        lock.unlock()
        guard isRunning, timestampNs - lastInferenceNs >= 66_000_000 else { return }
        lastInferenceNs = timestampNs

        guard let pixels = downsample(source) else { return }
        let correctionState = correctionLearner.stateKey(pixels)
        lock.lock()
        currentCorrectionState = correctionState
        lock.unlock()
        let gray = pixels.map { Float($0) / 127.5 - 1 }
        let priorGray = previousGray
        previousGray = gray

        if isSuppressed {
            var prediction: [String: Double] = ["humanOverride": 1]
            if let priorGray {
                let delta = zip(gray, priorGray).map { current, previous in current - previous }
                let probabilities = model.predict(features: gray + delta)
                for (key, value) in zip(model.keys, probabilities) { prediction[key] = Double(value) }
                prediction["confidence"] = familiarityConfidence(pixels: pixels, probabilities: probabilities)
            }
            onPrediction?(prediction)
            return
        }

        // Randomized and scrolling games cannot be solved by replaying positions
        // from one map. V3 models use the learned visual reaction policy as the
        // controller and keep trajectory matching only for progress telemetry.
        if model.policyMode == "reactive-visual" {
            guard let priorGray else { return }
            let delta = zip(gray, priorGray).map { current, previous in current - previous }
            let probabilities = model.predict(features: gray + delta)
            var prediction = Dictionary(uniqueKeysWithValues: zip(model.keys, probabilities.map(Double.init)))
            var desired = Set<String>()
            for (index, key) in model.keys.enumerated() where probabilities[index] >= model.thresholds[index] {
                desired.insert(key)
            }
            let imitationMask = mask(for: desired)
            let motion = delta.reduce(0) { $0 + Double(abs($1)) } / Double(max(1, delta.count))
            let decision = reactiveLearner?.choose(
                imitationMask: imitationMask,
                pixels: pixels,
                motion: motion,
                timestampNs: timestampNs
            )
            if let decision { desired = keys(for: decision.actionMask) }
            desired = correctionLearner.adjusted(desired, state: correctionState)
            removeOpposites(from: &desired, prediction: prediction)
            apply(desired: desired)
            if let match = navigator?.locate(pixels) {
                prediction["goalProgress"] = match.progress
                prediction["visualMatch"] = max(0, 1 - match.distance / 20)
            }
            prediction["confidence"] = prediction["visualMatch"]
                ?? (probabilities.map { abs(Double($0) - 0.5) * 2 }.max() ?? 0)
            prediction["reactivePolicy"] = 1
            prediction["onlineReward"] = decision?.reward ?? motion
            prediction["learningUpdates"] = Double(decision?.updates ?? 0)
            prediction["exploring"] = decision?.exploring == true ? 1 : 0
            prediction["activeKeys"] = Double(desired.count)
            prediction["autoRecovery"] = handleRecoveryIfNeeded(motion: motion, timestampNs: timestampNs) ? 1 : 0
            onPrediction?(prediction)
            return
        }

        if let navigator, let match = navigator.locate(pixels) {
            let demonstrated = navigator.demonstratedAction(near: match.index)
            let decision = onlineLearner?.choose(imitationMask: demonstrated, match: match, timestampNs: timestampNs)
            let mask = decision?.actionMask ?? demonstrated
            var desired = keys(for: mask)
            desired = correctionLearner.adjusted(desired, state: correctionState)
            removeOpposites(from: &desired)
            apply(desired: desired)
            apply(pointer: navigator.demonstratedPointer(near: match.index))
            var prediction = Dictionary(uniqueKeysWithValues: model.keys.map { ($0, desired.contains($0) ? 1.0 : 0.0) })
            prediction["goalProgress"] = match.progress
            prediction["visualMatch"] = max(0, 1 - match.distance / 20)
            prediction["onlineReward"] = decision?.reward ?? 0
            prediction["learningUpdates"] = Double(decision?.updates ?? 0)
            prediction["exploring"] = decision?.exploring == true ? 1 : 0
            prediction["activeKeys"] = Double(desired.count)
            prediction["confidence"] = max(0, 1 - match.distance / 20)
            if let priorGray {
                let motion = zip(gray, priorGray).reduce(0.0) { partial, pair in
                    partial + Double(abs(pair.0 - pair.1))
                } / Double(max(1, gray.count))
                prediction["autoRecovery"] = handleRecoveryIfNeeded(motion: motion, timestampNs: timestampNs) ? 1 : 0
            }
            onPrediction?(prediction)
            return
        }

        guard let priorGray else { return }
        let delta = zip(gray, priorGray).map { current, previous in current - previous }
        let probabilities = model.predict(features: gray + delta)
        var prediction = Dictionary(uniqueKeysWithValues: zip(model.keys, probabilities.map(Double.init)))
        var desired = Set<String>()
        for (index, key) in model.keys.enumerated() where probabilities[index] >= model.thresholds[index] {
            desired.insert(key)
        }
        desired = correctionLearner.adjusted(desired, state: correctionState)

        // Directional opposites can never be useful together. Keep the more confident one.
        removeOpposites(from: &desired, prediction: prediction)
        apply(desired: desired)
        prediction["activeKeys"] = Double(desired.count)
        prediction["confidence"] = probabilities.map(Double.init).max() ?? 0
        onPrediction?(prediction)
    }

    func stop() {
        lock.lock()
        running = false
        lock.unlock()
        releaseAll()
        onlineLearner?.save()
        reactiveLearner?.save()
        correctionLearner.save()
        previousGray = nil
    }

    func pauseForHuman() {
        lock.lock()
        suppressedForHuman = true
        lock.unlock()
        releaseAll()
    }

    func resumeAfterHuman() {
        lock.lock()
        suppressedForHuman = false
        lock.unlock()
    }

    func learnCorrection(_ event: InputEventRecord) {
        lock.lock()
        let state = currentCorrectionState
        let proposed = lastDesiredControls
        lock.unlock()
        correctionLearner.learn(state: state, proposed: proposed, human: event)
    }

    func click(normalizedX: Double, normalizedY: Double, button: String = "Left") {
        postAbsoluteClick(
            BehaviorModel.RecoveryClick(
                button: button,
                x: min(max(normalizedX, 0), 1),
                y: min(max(normalizedY, 0), 1)
            )
        )
    }

    private func downsample(_ source: CVPixelBuffer) -> [UInt8]? {
        var destination: CVPixelBuffer?
        guard CVPixelBufferPoolCreatePixelBuffer(nil, pool, &destination) == kCVReturnSuccess, let destination else { return nil }
        let image = CIImage(cvPixelBuffer: source)
        let scaled = image.transformed(by: CGAffineTransform(
            scaleX: Double(model.inputWidth) / image.extent.width,
            y: Double(model.inputHeight) / image.extent.height
        ))
        context.render(scaled, to: destination, bounds: CGRect(x: 0, y: 0, width: model.inputWidth, height: model.inputHeight), colorSpace: CGColorSpace(name: CGColorSpace.sRGB))
        CVPixelBufferLockBaseAddress(destination, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(destination, .readOnly) }
        guard let base = CVPixelBufferGetBaseAddress(destination) else { return nil }
        let bytesPerRow = CVPixelBufferGetBytesPerRow(destination)
        var values = Array(repeating: UInt8(0), count: model.inputWidth * model.inputHeight)
        for y in 0..<model.inputHeight {
            let row = base.advanced(by: y * bytesPerRow).assumingMemoryBound(to: UInt8.self)
            for x in 0..<model.inputWidth {
                let offset = x * 4
                let blue = Double(row[offset])
                let green = Double(row[offset + 1])
                let red = Double(row[offset + 2])
                values[y * model.inputWidth + x] = UInt8(clamping: Int(0.114 * blue + 0.587 * green + 0.299 * red))
            }
        }
        return values
    }

    private func keys(for mask: UInt64) -> Set<String> {
        var result = Set<String>()
        for (index, key) in model.keys.enumerated() where mask & (UInt64(1) << UInt64(index)) != 0 {
            result.insert(key)
        }
        return result
    }

    private func mask(for controls: Set<String>) -> UInt64 {
        var result: UInt64 = 0
        for (index, control) in model.keys.enumerated() where controls.contains(control) {
            result |= UInt64(1) << UInt64(index)
        }
        return result
    }

    private func apply(desired: Set<String>) {
        let desiredLook = Set(desired.filter { $0.hasPrefix("Mouse Look ") })
        let desiredButtons = Set(desired.filter { $0.hasPrefix("Mouse ") && !$0.hasPrefix("Mouse Look ") })
        let desiredKeys = desired.subtracting(desiredButtons).subtracting(desiredLook)
        lock.lock()
        lastDesiredControls = desired
        let keysToRelease = heldKeys.subtracting(desiredKeys)
        let keysToPress = desiredKeys.subtracting(heldKeys)
        let buttonsToRelease = heldButtons.subtracting(desiredButtons)
        let buttonsToPress = desiredButtons.subtracting(heldButtons)
        heldKeys = desiredKeys
        heldButtons = desiredButtons
        lock.unlock()
        for key in keysToRelease { post(key: key, down: false) }
        for key in keysToPress { post(key: key, down: true) }
        for button in buttonsToRelease { post(button: button, down: false) }
        for button in buttonsToPress { post(button: button, down: true) }
        var deltaX: Int16 = 0
        var deltaY: Int16 = 0
        if desiredLook.contains("Mouse Look Left") { deltaX -= 10 }
        if desiredLook.contains("Mouse Look Right") { deltaX += 10 }
        if desiredLook.contains("Mouse Look Up") { deltaY -= 10 }
        if desiredLook.contains("Mouse Look Down") { deltaY += 10 }
        if deltaX != 0 || deltaY != 0 { postRelativeMouse(deltaX: deltaX, deltaY: deltaY) }
    }

    private func releaseAll() {
        lock.lock()
        let keys = heldKeys
        let buttons = heldButtons
        heldKeys.removeAll()
        heldButtons.removeAll()
        lock.unlock()
        for key in keys { post(key: key, down: false) }
        for button in buttons { post(button: button, down: false) }
    }

    private func post(key: String, down: Bool) {
        guard let index = model.keys.firstIndex(of: key), model.keyCodes.indices.contains(index), model.keyCodes[index] >= 0,
              let event = CGEvent(keyboardEventSource: nil, virtualKey: CGKeyCode(model.keyCodes[index]), keyDown: down) else { return }
        event.setIntegerValueField(.eventSourceUserData, value: 0x4C4541524E4552)
        post(event)
    }

    private func post(button name: String, down: Bool) {
        let button: CGMouseButton
        let type: CGEventType
        switch name {
        case "Mouse Left":
            button = .left; type = down ? .leftMouseDown : .leftMouseUp
        case "Mouse Right":
            button = .right; type = down ? .rightMouseDown : .rightMouseUp
        default:
            button = .center; type = down ? .otherMouseDown : .otherMouseUp
        }
        let location = CGEvent(source: nil)?.location ?? .zero
        guard let event = CGEvent(mouseEventSource: nil, mouseType: type, mouseCursorPosition: location, mouseButton: button) else { return }
        event.setIntegerValueField(.eventSourceUserData, value: 0x4C4541524E4552)
        post(event)
    }

    private func apply(pointer: BehaviorModel.VisualMemory.PointerAction) {
        if pointer.deltaX != 0 || pointer.deltaY != 0 {
            postRelativeMouse(deltaX: pointer.deltaX, deltaY: pointer.deltaY)
        }
        if pointer.scrollX != 0 || pointer.scrollY != 0,
           let event = CGEvent(
            scrollWheelEvent2Source: nil, units: .pixel, wheelCount: 2,
            wheel1: Int32(pointer.scrollY), wheel2: Int32(pointer.scrollX), wheel3: 0
           ) {
            event.setIntegerValueField(.eventSourceUserData, value: 0x4C4541524E4552)
            post(event)
        }
    }

    private func postRelativeMouse(deltaX: Int16, deltaY: Int16) {
        let location = CGEvent(source: nil)?.location ?? .zero
        if let event = CGEvent(mouseEventSource: nil, mouseType: .mouseMoved, mouseCursorPosition: location, mouseButton: .left) {
            event.setIntegerValueField(.mouseEventDeltaX, value: Int64(deltaX))
            event.setIntegerValueField(.mouseEventDeltaY, value: Int64(deltaY))
            event.setIntegerValueField(.eventSourceUserData, value: 0x4C4541524E4552)
            post(event)
        }
    }

    private func handleRecoveryIfNeeded(motion: Double, timestampNs: UInt64) -> Bool {
        guard !model.recoveryClicks.isEmpty else { return false }
        if motion > 0.0025 {
            staticSinceNs = nil
            return false
        }
        if staticSinceNs == nil { staticSinceNs = timestampNs }
        guard let staticSinceNs,
              timestampNs >= staticSinceNs + 1_200_000_000,
              timestampNs >= lastRecoveryClickNs + 2_000_000_000 else { return false }
        let click = model.recoveryClicks[recoveryClickIndex % model.recoveryClicks.count]
        recoveryClickIndex += 1
        lastRecoveryClickNs = timestampNs
        postAbsoluteClick(click)
        return true
    }

    private func postAbsoluteClick(_ click: BehaviorModel.RecoveryClick) {
        let point = CGPoint(
            x: targetBounds.x + click.x * targetBounds.width,
            y: targetBounds.y + click.y * targetBounds.height
        )
        let button: CGMouseButton
        let downType: CGEventType
        let upType: CGEventType
        switch click.button {
        case "Right":
            button = .right; downType = .rightMouseDown; upType = .rightMouseUp
        case "Middle":
            button = .center; downType = .otherMouseDown; upType = .otherMouseUp
        default:
            button = .left; downType = .leftMouseDown; upType = .leftMouseUp
        }
        for type in [downType, upType] {
            guard let event = CGEvent(
                mouseEventSource: nil,
                mouseType: type,
                mouseCursorPosition: point,
                mouseButton: button
            ) else { continue }
            event.setIntegerValueField(.eventSourceUserData, value: 0x4C4541524E4552)
            post(event)
        }
    }

    private func post(_ event: CGEvent) {
        if let targetPID { event.postToPid(targetPID) }
        else { event.post(tap: .cghidEventTap) }
    }

    private func familiarityConfidence(pixels: [UInt8], probabilities: [Float]) -> Double {
        if let match = navigator?.locate(pixels) {
            return min(max(1 - match.distance / 20, 0), 1)
        }
        // Without visual memory, calibrated output certainty is the only real
        // familiarity signal available from the basic behavior policy.
        return probabilities.map { abs(Double($0) - 0.5) * 2 }.max() ?? 0
    }

    private func removeOpposites(from desired: inout Set<String>, prediction: [String: Double] = [:]) {
        for (negative, positive) in [
            ("Left Arrow", "Right Arrow"), ("A", "D"), ("Up Arrow", "Down Arrow"), ("W", "S"),
            ("Mouse Look Left", "Mouse Look Right"), ("Mouse Look Up", "Mouse Look Down"),
        ] {
            guard desired.contains(negative), desired.contains(positive) else { continue }
            if prediction[negative, default: 0] > prediction[positive, default: 0] { desired.remove(positive) }
            else { desired.remove(negative) }
        }
    }

    enum ControllerError: LocalizedError {
        case cannotPrepareInput
        var errorDescription: String? { "The agent could not prepare its visual input buffer." }
    }
}
