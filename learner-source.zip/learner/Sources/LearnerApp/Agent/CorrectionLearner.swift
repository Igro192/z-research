import Foundation
import LearnerCore

/// Small state-conditioned preference overlay updated immediately from takeover
/// actions. It complements background behavior cloning instead of retraining the
/// complete model for every key press.
final class CorrectionLearner: @unchecked Sendable {
    private struct Persisted: Codable {
        var version = 1
        var preferences: [String: [String: Float]]
        var corrections: Int
        var updatedAt: Date
    }

    private let url: URL
    private let controls: Set<String>
    private let width: Int
    private let height: Int
    private let lock = NSLock()
    private var preferences: [String: [String: Float]] = [:]
    private var corrections = 0

    init(url: URL, controls: [String], width: Int, height: Int) {
        self.url = url
        self.controls = Set(controls)
        self.width = width
        self.height = height
        load()
    }

    func stateKey(_ pixels: [UInt8]) -> String {
        guard pixels.count == width * height else { return "unknown" }
        var key = ""
        key.reserveCapacity(12)
        for row in 0..<3 {
            let y = min(height - 1, row * height / 3 + height / 6)
            for column in 0..<4 {
                let x = min(width - 1, column * width / 4 + width / 8)
                key.append(String(format: "%X", pixels[y * width + x] >> 6))
            }
        }
        return key
    }

    func adjusted(_ desired: Set<String>, state: String) -> Set<String> {
        lock.lock()
        let values = preferences[state] ?? [:]
        lock.unlock()
        var result = desired
        for (control, value) in values where controls.contains(control) {
            if value >= 0.8 { result.insert(control) }
            if value <= -0.8 { result.remove(control) }
        }
        return result
    }

    func learn(state: String, proposed: Set<String>, human event: InputEventRecord) {
        guard state != "unknown" else { return }
        var preferred: String?
        var preferredValue: Float = 1
        switch event.type {
        case .keyDown:
            preferred = event.key
        case .keyUp:
            preferred = event.key
            preferredValue = -1
        case .mouseButtonDown:
            preferred = event.button.map { "Mouse \($0)" }
        case .mouseButtonUp:
            preferred = event.button.map { "Mouse \($0)" }
            preferredValue = -1
        case .mouseMove:
            let dx = event.deltaX ?? 0
            let dy = event.deltaY ?? 0
            if abs(dx) >= abs(dy), abs(dx) >= 3 { preferred = dx > 0 ? "Mouse Look Right" : "Mouse Look Left" }
            else if abs(dy) >= 3 { preferred = dy > 0 ? "Mouse Look Down" : "Mouse Look Up" }
        default:
            break
        }

        let canLearnPreferred = preferred.map(controls.contains) ?? false
        guard canLearnPreferred || !proposed.isEmpty else { return }

        lock.lock()
        var values = preferences[state] ?? [:]
        for control in proposed where control != preferred {
            values[control] = max(-5, (values[control] ?? 0) - 1.0)
        }
        if let preferred, controls.contains(preferred) {
            values[preferred] = min(5, max(-5, (values[preferred] ?? 0) + preferredValue))
        }
        preferences[state] = values
        corrections += 1
        let snapshot = Persisted(preferences: preferences, corrections: corrections, updatedAt: Date())
        let shouldPersistNow = corrections == 1 || corrections.isMultiple(of: 16)
        lock.unlock()
        // Keep takeover response cheap. The runtime saves on stop and this
        // periodic checkpoint limits loss after a crash without writing a file
        // for every mouse-movement event.
        if shouldPersistNow { save(snapshot) }
    }

    func save() {
        lock.lock()
        let snapshot = Persisted(preferences: preferences, corrections: corrections, updatedAt: Date())
        lock.unlock()
        save(snapshot)
    }

    private func save(_ document: Persisted) {
        guard let data = try? JSONEncoder().encode(document) else { return }
        try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try? data.write(to: url, options: .atomic)
    }

    private func load() {
        guard let data = try? Data(contentsOf: url),
              let document = try? JSONDecoder().decode(Persisted.self, from: data),
              document.version == 1 else { return }
        preferences = document.preferences
        corrections = document.corrections
    }
}
