import AppKit
import SwiftUI

@main
struct LearnerApplication: App {
    @StateObject private var model = AppModel()

    var body: some Scene {
        WindowGroup("Learner", id: "main") {
            RootView()
                .environmentObject(model)
                .frame(minWidth: 1050, minHeight: 700)
        }
        .windowStyle(.titleBar)
        .windowToolbarStyle(.unified(showsTitle: false))
        .commands {
            CommandGroup(after: .newItem) {
                Button("Record My Gameplay") { model.startTeach(switchToTarget: true) }
                    .keyboardShortcut("r", modifiers: [.command, .shift])
                    .disabled(model.phase != .idle || model.selectedSource == nil)
                Button(model.phase == .paused ? "Resume Recording" : "Pause Recording") {
                    if model.phase == .paused { model.resumeRecording() }
                    else { model.pauseRecording() }
                }
                .keyboardShortcut("p", modifiers: [.command, .shift])
                .disabled(model.phase != .recording && model.phase != .paused)
                Button("Stop & Save Recording") {
                    Task { await model.stopRecording() }
                }
                .keyboardShortcut("s", modifiers: [.command, .shift])
                .disabled(model.phase != .recording && model.phase != .paused)
            }
        }

        MenuBarExtra {
            LearnerMenuBarView()
                .environmentObject(model)
        } label: {
            Image(systemName: model.learningMode == .teach ? "record.circle.fill" : model.humanOverride ? "hand.raised.fill" : model.learningMode == .practice ? "person.2.fill" : model.learningMode == .autopilot ? "sparkles" : model.isMenuBarPreparingRecording ? "hourglass.circle" : "brain.head.profile")
        }
        .menuBarExtraStyle(.menu)
    }
}

private struct LearnerMenuBarView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        if model.learningMode == .teach {
            Label(
                model.phase == .paused ? "Recording paused" : model.phase == .stopping ? "Saving and learning…" : "Recording gameplay",
                systemImage: model.phase == .paused ? "pause.circle.fill" : "record.circle.fill"
            )
            Text(model.selectedSource?.displayName ?? "Selected target")
            Text("Elapsed: \(LearnerFormatters.duration(model.stats.elapsedNs))")
            Text("Frames: \(model.stats.frameCount.formatted()) · Actions: \(model.stats.actionCount.formatted())")

            Button(model.phase == .paused ? "Resume Recording" : "Pause Recording") {
                if model.phase == .paused { model.resumeRecording() }
                else { model.pauseRecording() }
            }
            .disabled(model.phase == .stopping)

            Button("Mark Important") { model.markImportant() }
                .disabled(model.phase != .recording)

            Button("Stop & Save") {
                Task { await model.stopRecording() }
            }
            .disabled(model.phase == .stopping)
        } else if model.learningMode == .practice || model.learningMode == .autopilot {
            Label(
                model.humanOverride ? "Human override" : model.agentPaused ? "Paused" : model.learningMode.title,
                systemImage: model.humanOverride ? "hand.raised.fill" : "sparkles"
            )
            Text(model.selectedSource?.applicationName ?? "Selected target")
            if model.humanOverride {
                Button("Resume AI") { model.resumeAI() }
            } else {
                Button("Take Control") { model.takeControl() }
            }
            Button(model.agentPaused ? "Resume" : "Pause") { model.toggleAgentPause() }
            Button("Stop") { model.stopAgent() }
        } else {
            Button {
                model.startCurrentDisplayRecording()
            } label: {
                Label("Record Current Screen", systemImage: "display")
            }
            .disabled(model.isMenuBarPreparingRecording)

            if model.isMenuBarPreparingRecording {
                Text("Preparing full-screen recording…")
            }

            if model.selectedSource != nil {
                Button("Record Selected Target") {
                    model.startTeach(switchToTarget: true)
                }
                .disabled(model.isMenuBarPreparingRecording)
            }

            if model.errorMessage != nil {
                Text("Learner needs attention. Open the app for details.")
            }
        }

        Divider()

        Button("Open Learner") {
            openWindow(id: "main")
            NSRunningApplication.current.activate(options: [.activateAllWindows])
        }

        if model.phase == .idle && model.selectedSource == nil {
            Button("Choose a Game or App…") {
                model.navigation = .home
                openWindow(id: "main")
                NSRunningApplication.current.activate(options: [.activateAllWindows])
            }
        }

        Button("Quit Learner") { NSApp.terminate(nil) }
            .disabled(model.phase != .idle)
    }
}
