import AppKit
import ApplicationServices
import CoreGraphics

struct PermissionStatus: Equatable {
    var screenRecording: Bool
    var inputMonitoring: Bool
    var accessibility: Bool
}

enum PermissionCenter {
    static func current() -> PermissionStatus {
        PermissionStatus(
            screenRecording: CGPreflightScreenCaptureAccess(),
            inputMonitoring: CGPreflightListenEventAccess(),
            accessibility: AXIsProcessTrusted()
        )
    }

    @discardableResult
    static func requestScreenRecording() -> Bool {
        CGRequestScreenCaptureAccess()
    }

    @discardableResult
    static func requestInputMonitoring() -> Bool {
        CGRequestListenEventAccess()
    }

    static func requestAccessibility() {
        let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
        AXIsProcessTrustedWithOptions(options)
    }

    static func openSettings(_ pane: Pane) {
        let suffix: String
        switch pane {
        case .screenRecording: suffix = "Privacy_ScreenCapture"
        case .inputMonitoring: suffix = "Privacy_ListenEvent"
        case .accessibility: suffix = "Privacy_Accessibility"
        }
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?\(suffix)") {
            NSWorkspace.shared.open(url)
        }
    }

    enum Pane { case screenRecording, inputMonitoring, accessibility }
}
