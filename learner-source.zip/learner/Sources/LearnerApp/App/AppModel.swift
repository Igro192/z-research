import AppKit
import Combine
import CoreGraphics
import Foundation
import LearnerCore

enum NavigationSection: String, CaseIterable, Identifiable {
    case home = "Games"
    case activity = "Activity"
    case developer = "Developer"
    case settings = "Settings"
    // Kept only as migration destinations for older view code. These cases are
    // intentionally absent from the normal sidebar.
    case record = "Legacy Record"
    case agent = "Legacy Agent"
    case sessions = "Legacy Sessions"
    case datasets = "Legacy Datasets"
    var id: String { rawValue }
    static var visibleCases: [NavigationSection] { [.home, .activity, .developer, .settings] }
    var icon: String {
        switch self {
        case .home: "gamecontroller.fill"
        case .activity: "clock.arrow.circlepath"
        case .developer: "wrench.and.screwdriver"
        case .record: "record.circle"
        case .agent: "gamecontroller"
        case .sessions: "rectangle.stack"
        case .datasets: "square.stack.3d.up"
        case .settings: "gearshape"
        }
    }
}

enum LearningMode: String, Equatable {
    case none
    case teach
    case practice
    case autopilot

    var title: String {
        switch self {
        case .none: "Ready"
        case .teach: "Teaching"
        case .practice: "Practice"
        case .autopilot: "Autopilot"
        }
    }
}

enum RecordingPhase: Equatable {
    case idle
    case recording
    case paused
    case stopping
    case agent
}

@MainActor
final class AppModel: ObservableObject {
    @Published var navigation: NavigationSection = .home
    @Published var selectedSource: CaptureSourceDescriptor?
    @Published var availableSources: [CaptureSourceDescriptor] = []
    @Published var isLoadingSources = false
    @Published var vision = VisionConfiguration()
    @Published var previewImage: CGImage?
    @Published var previewDimensions: VideoDimensions?
    @Published var phase: RecordingPhase = .idle
    @Published var stats = SessionRecorder.Stats(elapsedNs: 0, frameCount: 0, actionCount: 0)
    @Published var liveInput = InputLiveState()
    @Published var approximateDiskBytes: Int64 = 0
    @Published var sessions: [SessionSummary] = []
    @Published var datasets: [(DatasetManifest, URL)] = []
    @Published var permissions = PermissionCenter.current()
    @Published var errorMessage: String?
    @Published var statusMessage: String?
    @Published var targetInterrupted = false
    @Published var trainedModelURL: URL?
    @Published var agentProbabilities: [String: Double] = [:]
    @Published var agentTrainingFrames = 0
    @Published var agentMemoryFrames = 0
    @Published var agentGoalDescription = ""
    @Published var agentControls: [String] = []
    @Published var agentPolicyMode = ""
    @Published var trainedSessionIDs = Set<String>()
    @Published var trainingDatasetID: UUID?
    @Published var trainingMessage = ""
    @Published var isAutoSelectingTarget = false
    @Published var isMenuBarPreparingRecording = false
    @Published var isPreparingAgent = false
    @Published var games: [GameProject] = []
    @Published var currentGameID: UUID?
    @Published var projectKnowledge = ProjectKnowledge()
    @Published var learningMode: LearningMode = .none
    @Published var humanOverride = false
    @Published var agentPaused = false
    @Published var processingGameID: UUID?
    @Published var processingMessage = ""
    @Published var agentConfidence = 0.0
    @Published var currentAgentControls: [String] = []

    let store: SessionStore
    private let captureEngine: CaptureEngine
    private let inputRecorder = InputRecorder()
    private var recorder: SessionRecorder?
    private var agentController: AgentController?
    private var previewInputController: InputController?
    private var agentSessionRecorder: SessionRecorder?
    private var activeRecordingGameID: UUID?
    private var activeRecordingRole: ExperienceRole?
    private var activeAgentGameID: UUID?
    private var agentExperienceStore: AgentExperienceStore?
    private var pendingAgentMode: LearningMode = .practice
    private var learningQueue: [(gameID: UUID, trainPolicy: Bool)] = []
    private var agentStartedNs: UInt64 = 0
    private var observedTakeoverArmedNs: UInt64 = 0
    private var lowConfidenceTicks = 0
    private var watchdog: Timer?
    private var diskTimer: Timer?
    private var captureStreamFailed = false
    private var isReconnectingCapture = false
    private var lastReconnectAttemptNs: UInt64 = 0

    var currentGame: GameProject? { games.first(where: { $0.id == currentGameID }) }

    var currentGameSessions: [SessionSummary] {
        guard let currentGame else { return [] }
        return sessions.filter { currentGame.sessionIDs.contains($0.id) }
    }

    var currentGameExperienceNs: UInt64 {
        currentGameSessions.reduce(0) { $0 + $1.metadata.durationNs }
    }

    var currentGameModelURL: URL? {
        guard let currentGameID else { return nil }
        let url = store.modelURL(for: currentGameID)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    init(store: SessionStore = SessionStore()) {
        self.store = store
        captureEngine = CaptureEngine(configuration: VisionConfiguration())
        captureEngine.onPreview = { [weak self] image, dimensions in
            Task { @MainActor in
                guard let self else { return }
                self.previewImage = image
                self.previewDimensions = dimensions
                if self.phase == .recording || self.phase == .agent {
                    self.targetInterrupted = false
                    self.captureStreamFailed = false
                }
            }
        }
        captureEngine.onStopped = { [weak self] error in
            Task { @MainActor in self?.captureDidStop(error) }
        }
        inputRecorder.onState = { [weak self] state in
            Task { @MainActor in self?.liveInput = state }
        }
        refreshLibrary()
        scheduleKnowledgeRefreshIfNeeded()
        startWatchdog()
    }

    deinit {
        watchdog?.invalidate()
        diskTimer?.invalidate()
    }

    func refreshPermissions() {
        permissions = PermissionCenter.current()
    }

    func loadSources() async {
        isLoadingSources = true
        defer { isLoadingSources = false }
        if !permissions.screenRecording {
            _ = PermissionCenter.requestScreenRecording()
            refreshPermissions()
        }
        do {
            availableSources = try await CaptureSourceProvider.availableSources()
            // ScreenCaptureKit is the source of truth. CGPreflightScreenCaptureAccess
            // can remain stale on newer macOS releases until a later app activation.
            if !availableSources.isEmpty { permissions.screenRecording = true }
        } catch {
            availableSources = []
            if permissions.screenRecording {
                errorMessage = "Learner couldn’t list capture targets. \(error.localizedDescription)"
            }
        }
    }

    /// The fastest setup path: hide Learner, identify the application macOS
    /// reveals behind it, and select that app's largest captureable window.
    /// The user still sees and verifies the live preview before recording.
    func selectAppBehindLearner() {
        guard phase == .idle, !isAutoSelectingTarget else { return }
        refreshPermissions()
        if !permissions.screenRecording {
            _ = PermissionCenter.requestScreenRecording()
            refreshPermissions()
        }

        isAutoSelectingTarget = true
        statusMessage = "Hiding Learner to find the game behind it…"
        NSApp.hide(nil)

        Task { [weak self] in
            guard let self else { return }
            let learnerPID = ProcessInfo.processInfo.processIdentifier
            var targetPID: pid_t?
            for _ in 0..<12 {
                try? await Task.sleep(for: .milliseconds(150))
                if let pid = NSWorkspace.shared.frontmostApplication?.processIdentifier,
                   pid != learnerPID {
                    targetPID = pid
                    break
                }
            }

            do {
                let sources = try await CaptureSourceProvider.availableSources()
                self.availableSources = sources
                let target = sources
                    .filter { $0.kind == .window && $0.ownerPID == targetPID }
                    .max { left, right in
                        left.bounds.width * left.bounds.height < right.bounds.width * right.bounds.height
                    }
                self.restoreLearnerWindow()
                guard let target else {
                    self.errorMessage = "Learner couldn’t find a normal window for that app. Choose Fullscreen Game in the visual target picker instead."
                    self.isAutoSelectingTarget = false
                    return
                }
                await self.selectSource(target)
                self.statusMessage = "Found \(target.applicationName). Check the preview, then start recording."
            } catch {
                self.restoreLearnerWindow()
                self.errorMessage = "Learner couldn’t inspect the app behind it. \(error.localizedDescription)"
            }
            self.isAutoSelectingTarget = false
        }
    }

    func selectSource(_ source: CaptureSourceDescriptor) async {
        guard phase == .idle else { return }
        statusMessage = "Connecting to \(source.displayName)…"
        previewImage = nil
        previewDimensions = nil
        targetInterrupted = false
        if selectedSource?.id != source.id {
            vision.crop = NormalizedRect()
            vision.masks = []
            vision.regions = []
        }
        do {
            try await captureEngine.update(configuration: vision)
            try await captureEngine.start(source: source)
            selectedSource = source
            // Some Metal/browser/settings surfaces provide a picker snapshot but
            // defer their first stream sample until content changes. Seed the
            // exact same processing pipeline from a one-shot capture so the user
            // never gets a selected target with an unusable blank preview.
            for _ in 0..<10 where previewDimensions == nil {
                try? await Task.sleep(for: .milliseconds(75))
            }
            if previewDimensions == nil,
               let screenshot = try? await CaptureSourceProvider.thumbnail(
                   for: source,
                   maximumSize: CGSize(width: 4096, height: 2304)
               ), let (preview, dimensions) = captureEngine.seedFrame(from: screenshot) {
                previewImage = preview
                previewDimensions = dimensions
            }
            previewInputController = InputController(targetPID: resolvedTargetPID(for: source), bounds: source.bounds)
            statusMessage = nil
        } catch {
            selectedSource = nil
            statusMessage = nil
            errorMessage = "Couldn’t capture that target. \(error.localizedDescription)"
        }
        refreshPermissions()
    }

    func clearSource() async {
        guard phase == .idle else { return }
        await captureEngine.stop()
        selectedSource = nil
        previewImage = nil
        previewDimensions = nil
    }

    func updateVision(_ update: (inout VisionConfiguration) -> Void) {
        guard phase == .idle else { return }
        update(&vision)
        let current = vision
        Task {
            do { try await captureEngine.update(configuration: current) }
            catch { errorMessage = "Couldn’t update the capture preview. \(error.localizedDescription)" }
        }
    }

    func startRecording(gameID: UUID? = nil, role: ExperienceRole = .teach) {
        guard phase == .idle, let source = selectedSource, let dimensions = previewDimensions else {
            errorMessage = "Select a target and wait for its live preview before recording."
            return
        }
        guard source.kind != .region || vision.crop != NormalizedRect() else {
            errorMessage = "Choose the rectangular area Learner should see before teaching."
            return
        }
        refreshPermissions()
        if !permissions.inputMonitoring {
            _ = PermissionCenter.requestInputMonitoring()
            refreshPermissions()
            guard permissions.inputMonitoring else {
                errorMessage = "Input Monitoring is not active for /Applications/Learner.app. Add Learner in System Settings → Privacy & Security → Input Monitoring before recording."
                return
            }
        }
        do {
            try inputRecorder.start(for: source)
            permissions.inputMonitoring = true
            let newRecorder = try SessionRecorder(
                store: store,
                source: source,
                configuration: vision,
                dimensions: dimensions,
                gameID: gameID,
                learningRole: role
            )
            newRecorder.onStats = { [weak self] stats in
                Task { @MainActor in self?.stats = stats }
            }
            recorder = newRecorder
            activeRecordingGameID = gameID
            activeRecordingRole = role
            captureEngine.onFrame = { [weak newRecorder] buffer, dimensions, timestamp in
                newRecorder?.appendFrame(buffer, dimensions: dimensions, rawTimestampNs: timestamp)
            }
            // Seed the session with the exact frame already shown in the preview.
            // A completely static source may not deliver another frame after the
            // user presses Record, but the session must still be usable.
            if let (buffer, dimensions, _) = captureEngine.latestFrame() {
                newRecorder.appendFrame(
                    buffer,
                    dimensions: dimensions,
                    rawTimestampNs: DispatchTime.now().uptimeNanoseconds
                )
            }
            inputRecorder.onEvent = { [weak newRecorder] event, timestamp in
                newRecorder?.appendAction(event, rawTimestampNs: timestamp)
            }
            stats = .init(elapsedNs: 0, frameCount: 0, actionCount: 0)
            approximateDiskBytes = 0
            phase = .recording
            learningMode = .teach
            targetInterrupted = false
            captureStreamFailed = false
            startDiskTimer()
        } catch {
            recorder = nil
            activeRecordingGameID = nil
            activeRecordingRole = nil
            captureEngine.onFrame = nil
            inputRecorder.stop()
            errorMessage = "Recording could not start. \(error.localizedDescription)"
        }
    }

    func startRecordingAndSwitchToTarget() {
        startTeach(switchToTarget: true)
    }

    func startTeach(switchToTarget: Bool = false) {
        guard let game = currentGame else {
            errorMessage = "Create or choose a Game before teaching."
            return
        }
        startRecording(gameID: game.id, role: .teach)
        guard phase == .recording else { return }
        statusMessage = "Recording \(game.name). Learner is learning while you play, and everything saves automatically when you stop."
        guard switchToTarget else { return }
        Task { [weak self] in
            try? await Task.sleep(for: .milliseconds(250))
            guard let self, self.phase == .recording else { return }
            if let pid = self.selectedSource?.ownerPID,
               let application = NSRunningApplication(processIdentifier: pid) {
                application.activate(options: [.activateAllWindows])
            } else {
                // Display and region capture have no owner process. Hiding
                // Learner reveals the game without guessing another target.
                NSApp.hide(nil)
            }
        }
    }

    /// One-click menu-bar capture. It records the complete display currently
    /// under the pointer, which is the display containing the menu-bar item the
    /// user just clicked. No window selection or preview setup is required.
    func startCurrentDisplayRecording() {
        guard phase == .idle, !isMenuBarPreparingRecording else { return }
        isMenuBarPreparingRecording = true
        errorMessage = nil
        statusMessage = "Preparing the current display…"

        Task { [weak self] in
            guard let self else { return }
            do {
                let sources = try await CaptureSourceProvider.availableSources()
                self.availableSources = sources
                if !sources.isEmpty { self.permissions.screenRecording = true }
                guard let display = self.currentDisplaySource(in: sources) else {
                    throw MenuBarRecordingError.noDisplay
                }

                // This command explicitly means the entire display, so remove
                // any crop/masks left over from a prior custom recording.
                self.vision.crop = NormalizedRect()
                self.vision.masks = []
                self.vision.regions = []
                await self.selectSource(display)
                guard self.selectedSource?.id == display.id else {
                    self.isMenuBarPreparingRecording = false
                    return
                }

                // ScreenCaptureKit starts asynchronously. Wait for the first
                // processed frame so the recorder is initialized with the exact
                // output dimensions instead of stale dimensions from another target.
                for _ in 0..<40 where self.previewDimensions == nil {
                    try await Task.sleep(for: .milliseconds(100))
                }
                if self.previewDimensions == nil,
                   let screenshot = try? await CaptureSourceProvider.thumbnail(
                       for: display,
                       maximumSize: CGSize(width: 4096, height: 2304)
                   ),
                   let (preview, dimensions) = self.captureEngine.seedFrame(from: screenshot) {
                    self.previewImage = preview
                    self.previewDimensions = dimensions
                }

                if self.currentGame == nil {
                    self.createGame(named: "Screen Learning", preferredTarget: display)
                }
                self.startRecording(gameID: self.currentGameID, role: .teach)
                if self.phase == .recording {
                    self.statusMessage = "Teaching from the entire \(display.applicationName). Stop from the menu-bar icon; saving and learning are automatic."
                    NSApp.hide(nil)
                }
            } catch {
                self.errorMessage = "Current-screen recording could not start. \(error.localizedDescription)"
            }
            self.isMenuBarPreparingRecording = false
        }
    }

    func startAgent() {
        startPractice()
    }

    func startPractice() {
        startControl(mode: .practice)
    }

    func startAutopilot() {
        startControl(mode: .autopilot)
    }

    private func startControl(mode: LearningMode) {
        guard phase == .idle, let source = selectedSource else {
            errorMessage = "Choose the game window or fullscreen display first."
            return
        }
        guard source.kind != .region || vision.crop != NormalizedRect() else {
            errorMessage = "Choose the rectangular area Learner should see before starting AI control."
            return
        }
        guard let game = currentGame, let modelURL = currentGameModelURL else {
            trainedModelURL = nil
            errorMessage = "This Game needs a demonstration first. Use TEACH, play normally, then stop; Learner will prepare Practice automatically."
            return
        }

        // Never leave Run Agent as an unpressable control just because a game
        // compositor is late. The button actively waits, restarts capture once,
        // and can seed the exact same processing path from a one-shot screenshot.
        guard previewImage != nil else {
            pendingAgentMode = mode
            prepareAgentWhenPreviewIsReady(source: source, mode: mode)
            return
        }

        refreshPermissions()
        if !permissions.inputMonitoring {
            _ = PermissionCenter.requestInputMonitoring()
            refreshPermissions()
            guard permissions.inputMonitoring else {
                errorMessage = "Input Monitoring is required so Escape can stop the agent immediately. Allow Learner in System Settings → Privacy & Security → Input Monitoring."
                return
            }
        }
        if !permissions.accessibility {
            PermissionCenter.requestAccessibility()
            refreshPermissions()
            guard permissions.accessibility else {
                errorMessage = "Agent control permission is off. Allow Learner in System Settings → Privacy & Security → Device Control and Data Access, then try again."
                return
            }
        }

        do {
            // Window capture has an exact process. Fullscreen/display capture
            // uses the visually frontmost user window discovered by the picker;
            // if none exists, HID delivery remains as the universal fallback.
            let targetPID = resolvedTargetPID(for: source)
            let controller = try AgentController(
                modelURL: modelURL,
                targetPID: targetPID,
                targetBounds: source.bounds
            )
            let experienceRecorder = try SessionRecorder(
                store: store,
                source: source,
                configuration: vision,
                dimensions: previewDimensions!,
                gameID: game.id,
                learningRole: mode == .practice ? .practice : .autopilot
            )
            let experienceStore = try AgentExperienceStore(
                directory: store.gameDirectory(game.id).appendingPathComponent("experience", isDirectory: true)
            )
            let sessionID = experienceRecorder.sessionID
            controller.onPrediction = { [weak self] prediction in
                let selected = controller.model.keys.filter { prediction[$0, default: 0] >= 0.5 }
                experienceStore.append(AgentExperienceRecord(
                    createdAt: Date(),
                    sessionID: sessionID,
                    timestampNs: DispatchTime.now().uptimeNanoseconds,
                    mode: mode.rawValue,
                    confidence: prediction["confidence"] ?? 0,
                    selectedControls: selected,
                    probabilities: prediction,
                    humanOverride: prediction["humanOverride"] == 1
                ))
                Task { @MainActor in
                    self?.agentProbabilities = prediction
                    self?.agentConfidence = prediction["confidence"] ?? 0
                    self?.currentAgentControls = selected
                    self?.evaluatePracticeConfidence()
                }
            }
            try inputRecorder.start(for: source, observeGlobally: true, ignoreLearnerEvents: true)
            inputRecorder.onEvent = { [weak self] event, timestamp in
                if event.type == .keyDown, event.key == "Escape" {
                    Task { @MainActor in self?.stopAgent() }
                    return
                }
                Task { @MainActor in self?.handleObservedHumanInput(event, rawTimestampNs: timestamp) }
            }
            captureEngine.onFrame = { [weak controller, weak experienceRecorder] buffer, dimensions, timestamp in
                experienceRecorder?.appendFrame(buffer, dimensions: dimensions, rawTimestampNs: timestamp)
                controller?.process(buffer, timestampNs: timestamp)
            }
            experienceRecorder.onStats = { [weak self] stats in
                Task { @MainActor in self?.stats = stats }
            }
            if let (buffer, dimensions, _) = captureEngine.latestFrame() {
                experienceRecorder.appendFrame(buffer, dimensions: dimensions, rawTimestampNs: DispatchTime.now().uptimeNanoseconds)
            }
            agentController = controller
            agentSessionRecorder = experienceRecorder
            agentExperienceStore = experienceStore
            activeAgentGameID = game.id
            previewInputController = InputController(targetPID: targetPID, bounds: source.bounds)
            trainedModelURL = modelURL
            agentTrainingFrames = controller.model.trainingFrameCount
            agentControls = controller.model.keys
            agentPolicyMode = controller.model.policyMode
            agentProbabilities = [:]
            agentConfidence = 0
            currentAgentControls = []
            phase = .agent
            agentStartedNs = DispatchTime.now().uptimeNanoseconds
            observedTakeoverArmedNs = agentStartedNs + 750_000_000
            lowConfidenceTicks = 0
            learningMode = mode
            humanOverride = false
            agentPaused = false
            targetInterrupted = false
            statusMessage = mode == .practice
                ? "Practice started. Touch any control to take over instantly; your correction will be learned."
                : "Autopilot started. You can take control at any moment."
        } catch {
            captureEngine.onFrame = nil
            inputRecorder.stop()
            agentController?.stop()
            agentController = nil
            agentSessionRecorder = nil
            agentExperienceStore?.close()
            agentExperienceStore = nil
            errorMessage = "Practice could not start. \(error.localizedDescription)"
        }
    }

    func stopAgent() {
        guard phase == .agent else { return }
        Task { await stopControl() }
    }

    private func stopControl() async {
        guard phase == .agent, let experienceRecorder = agentSessionRecorder else { return }
        phase = .stopping
        captureEngine.onFrame = nil
        inputRecorder.stop()
        agentController?.stop()
        agentController = nil
        agentExperienceStore?.close()
        agentExperienceStore = nil
        previewInputController = nil
        let gameID = activeAgentGameID
        let summary = try? await experienceRecorder.stop()
        agentSessionRecorder = nil
        activeAgentGameID = nil
        agentProbabilities = [:]
        agentConfidence = 0
        agentStartedNs = 0
        observedTakeoverArmedNs = 0
        lowConfidenceTicks = 0
        currentAgentControls = []
        humanOverride = false
        agentPaused = false
        learningMode = .none
        phase = .idle
        if let summary, let gameID {
            try? store.attach(sessionID: summary.id, to: gameID, preferredTarget: summary.metadata.target)
            refreshLibrary()
            beginBackgroundLearning(gameID: gameID, trainPolicy: summary.metadata.actionCount > 0)
            statusMessage = summary.metadata.actionCount > 0
                ? "Correction saved. Learner is updating this Game in the background."
                : "Practice experience saved locally."
        } else {
            statusMessage = "Practice stopped and all controlled inputs were released."
        }
    }

    private func prepareAgentWhenPreviewIsReady(source: CaptureSourceDescriptor, mode: LearningMode = .practice) {
        guard !isPreparingAgent else { return }
        isPreparingAgent = true
        errorMessage = nil
        statusMessage = "Connecting to the game and preparing the agent…"

        Task { [weak self] in
            guard let self else { return }
            for attempt in 0..<50 {
                guard self.phase == .idle, self.selectedSource?.id == source.id else {
                    self.isPreparingAgent = false
                    return
                }
                if self.previewImage != nil {
                    self.isPreparingAgent = false
                    self.startControl(mode: mode)
                    return
                }
                if attempt == 20 {
                    try? await self.captureEngine.start(source: source)
                }
                try? await Task.sleep(for: .milliseconds(100))
            }

            if let screenshot = try? await CaptureSourceProvider.thumbnail(
                for: source,
                maximumSize: CGSize(width: 4096, height: 2304)
            ), let (preview, dimensions) = self.captureEngine.seedFrame(from: screenshot) {
                self.previewImage = preview
                self.previewDimensions = dimensions
            }
            self.isPreparingAgent = false
            if self.previewImage != nil {
                self.startControl(mode: mode)
            } else {
                self.errorMessage = "Learner could not capture this target. Choose Fullscreen Game in the target picker and try again."
            }
        }
    }

    func clickAgentPreview(normalizedX: Double, normalizedY: Double) {
        let down = InputEventRecord(
            timestampNs: 0,
            type: .mouseButtonDown,
            x: normalizedX,
            y: normalizedY,
            button: "Left"
        )
        let up = InputEventRecord(
            timestampNs: 0,
            type: .mouseButtonUp,
            x: normalizedX,
            y: normalizedY,
            button: "Left"
        )
        handlePreviewInput(down)
        handlePreviewInput(up)
    }

    func takeControl() {
        guard phase == .agent else { return }
        agentController?.pauseForHuman()
        humanOverride = true
        agentPaused = false
        statusMessage = "You have control. Every correction is being saved with extra learning weight."
    }

    func resumeAI() {
        guard phase == .agent else { return }
        humanOverride = false
        agentPaused = false
        observedTakeoverArmedNs = DispatchTime.now().uptimeNanoseconds + 750_000_000
        agentController?.resumeAfterHuman()
        statusMessage = learningMode == .autopilot ? "Autopilot resumed." : "AI practice resumed."
    }

    func toggleAgentPause() {
        guard phase == .agent else { return }
        if agentPaused {
            agentPaused = false
            if !humanOverride {
                observedTakeoverArmedNs = DispatchTime.now().uptimeNanoseconds + 750_000_000
                agentController?.resumeAfterHuman()
            }
        } else {
            agentPaused = true
            agentController?.pauseForHuman()
        }
    }

    func handlePreviewInput(_ event: InputEventRecord) {
        guard phase == .recording || phase == .agent || phase == .paused else { return }
        let timestamp = DispatchTime.now().uptimeNanoseconds
        if previewInputController == nil, let source = selectedSource {
            previewInputController = InputController(targetPID: resolvedTargetPID(for: source), bounds: source.bounds)
        }
        previewInputController?.send(event)
        if phase == .recording || phase == .paused {
            recorder?.appendAction(event, rawTimestampNs: timestamp)
        } else {
            handleObservedHumanInput(event, rawTimestampNs: timestamp, bypassGlobalGuard: true)
        }
    }

    private func handleObservedHumanInput(
        _ event: InputEventRecord,
        rawTimestampNs: UInt64,
        bypassGlobalGuard: Bool = false
    ) {
        guard phase == .agent else { return }
        guard bypassGlobalGuard || rawTimestampNs >= observedTakeoverArmedNs else { return }
        let meaningful = isMeaningfulHumanInput(event)
        let beganOverride = !humanOverride && meaningful
        if beganOverride { takeControl() }
        guard humanOverride else { return }
        if meaningful { agentController?.learnCorrection(event) }
        agentSessionRecorder?.appendAction(event, rawTimestampNs: rawTimestampNs)
        // The complete corrected action stream stays in the Practice session,
        // while the user-facing correction count represents takeover episodes,
        // not every mouse delta produced during one correction.
        guard beganOverride, let gameID = activeAgentGameID else { return }
        let correction = CorrectionRecord(
            sessionID: agentSessionRecorder?.sessionID,
            timestampNs: rawTimestampNs,
            agentConfidence: agentConfidence,
            proposedControls: currentAgentControls,
            humanAction: event
        )
        try? store.appendCorrection(correction, gameID: gameID)
        projectKnowledge.correctionCount = store.correctionCount(for: gameID)
    }

    private func isMeaningfulHumanInput(_ event: InputEventRecord) -> Bool {
        switch event.type {
        case .keyDown, .mouseButtonDown, .scroll: true
        case .mouseMove: abs(event.deltaX ?? 0) + abs(event.deltaY ?? 0) >= 3
        default: false
        }
    }

    private func evaluatePracticeConfidence() {
        guard phase == .agent, learningMode == .practice, !humanOverride, !agentPaused,
              DispatchTime.now().uptimeNanoseconds > agentStartedNs + 2_000_000_000 else { return }
        if agentConfidence < 0.12 { lowConfidenceTicks += 1 }
        else { lowConfidenceTicks = 0 }
        if lowConfidenceTicks >= 8 {
            takeControl()
            statusMessage = "This situation is unfamiliar, so Practice paused for your help. Demonstrate the right response, then Resume AI."
            lowConfidenceTicks = 0
        }
    }

    func pauseRecording() {
        guard phase == .recording else { return }
        recorder?.pause()
        phase = .paused
    }

    func resumeRecording() {
        guard phase == .paused else { return }
        recorder?.resume()
        phase = .recording
        targetInterrupted = false
    }

    func stopRecording() async {
        guard let recorder, phase == .recording || phase == .paused else { return }
        let gameID = activeRecordingGameID
        phase = .stopping
        inputRecorder.stop()
        captureEngine.onFrame = nil
        diskTimer?.invalidate()
        diskTimer = nil
        do {
            let summary = try await recorder.stop()
            self.recorder = nil
            activeRecordingGameID = nil
            activeRecordingRole = nil
            previewInputController = nil
            learningMode = .none
            phase = .idle
            stats = .init(elapsedNs: 0, frameCount: 0, actionCount: 0)
            approximateDiskBytes = summary.sizeBytes
            if let gameID {
                try store.attach(sessionID: summary.id, to: gameID, preferredTarget: summary.metadata.target)
            }
            refreshLibrary()
            if let gameID {
                beginBackgroundLearning(gameID: gameID, trainPolicy: summary.metadata.actionCount > 0)
                statusMessage = "Gameplay saved automatically. Learning from it in the background…"
            } else {
                statusMessage = "Saved “\(summary.metadata.name)” locally."
            }
        } catch {
            self.recorder = nil
            activeRecordingGameID = nil
            activeRecordingRole = nil
            learningMode = .none
            phase = .idle
            refreshLibrary()
            errorMessage = "The session stopped, but finalizing its video failed. \(error.localizedDescription)"
        }
    }

    func markImportant() {
        guard phase == .recording else { return }
        recorder?.addMarker(.important)
        statusMessage = "Important moment marked."
    }

    func refreshLibrary() {
        sessions = store.listSessions()
        datasets = store.listDatasets()
        games = store.listGames()
        if currentGameID == nil,
           let stored = UserDefaults.standard.string(forKey: "LearnerCurrentGameID"),
           let id = UUID(uuidString: stored), games.contains(where: { $0.id == id }) {
            currentGameID = id
        }
        if currentGame == nil { currentGameID = games.first?.id }
        if let currentGameID {
            UserDefaults.standard.set(currentGameID.uuidString, forKey: "LearnerCurrentGameID")
            projectKnowledge = store.loadKnowledge(for: currentGameID)
            projectKnowledge.correctionCount = store.correctionCount(for: currentGameID)
        } else {
            projectKnowledge = ProjectKnowledge()
        }
        trainedModelURL = currentGameModelURL ?? store.latestModelURL()
        if let trainedModelURL, let trained = try? BehaviorModel(url: trainedModelURL) {
            agentTrainingFrames = trained.trainingFrameCount
            agentMemoryFrames = trained.visualMemory?.frameCount ?? 0
            agentGoalDescription = trained.visualMemory?.goalDescription ?? "Imitate demonstrated actions"
            agentControls = trained.keys
            agentPolicyMode = trained.policyMode
            trainedSessionIDs = Set(trained.trainingSessionIDs)
        } else {
            agentTrainingFrames = 0
            agentMemoryFrames = 0
            agentGoalDescription = ""
            agentControls = []
            agentPolicyMode = ""
            trainedSessionIDs = []
        }
    }

    func createGame(named name: String, preferredTarget: CaptureSourceDescriptor? = nil) {
        do {
            let project = try store.createGame(name: name, preferredTarget: preferredTarget)
            currentGameID = project.id
            refreshLibrary()
            statusMessage = "Created \(project.name). Choose a target and start teaching."
        } catch {
            errorMessage = "Couldn’t create the Game. \(error.localizedDescription)"
        }
    }

    func selectGame(_ id: UUID) {
        guard phase == .idle, games.contains(where: { $0.id == id }) else { return }
        currentGameID = id
        UserDefaults.standard.set(id.uuidString, forKey: "LearnerCurrentGameID")
        refreshLibrary()
        scheduleKnowledgeRefreshIfNeeded()
    }

    private func scheduleKnowledgeRefreshIfNeeded() {
        guard let game = currentGame, !game.sessionIDs.isEmpty,
              Set(projectKnowledge.processedSessionIDs) != Set(game.sessionIDs) else { return }
        let hasHumanActions = currentGameSessions.contains { $0.metadata.actionCount > 0 }
        beginBackgroundLearning(gameID: game.id, trainPolicy: currentGameModelURL == nil && hasHumanActions)
    }

    func rename(_ session: SessionSummary, to name: String) {
        guard !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        do {
            try store.rename(session: session, to: name)
            refreshLibrary()
        } catch { errorMessage = "Couldn’t rename the session. \(error.localizedDescription)" }
    }

    func delete(_ session: SessionSummary) {
        do {
            try store.delete(session: session)
            refreshLibrary()
        } catch { errorMessage = "Couldn’t delete the session. \(error.localizedDescription)" }
    }

    func export(_ session: SessionSummary) {
        let panel = NSSavePanel()
        panel.title = "Export Learner Session"
        panel.nameFieldStringValue = "\(session.metadata.name).learner-session.zip"
        panel.allowedContentTypes = [.zip]
        guard panel.runModal() == .OK, let destination = panel.url else { return }
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/ditto")
        process.arguments = ["-c", "-k", "--sequesterRsrc", "--keepParent", session.directoryURL.path, destination.path]
        do {
            try process.run()
            process.waitUntilExit()
            if process.terminationStatus == 0 { statusMessage = "Session exported successfully." }
            else { errorMessage = "The session archive could not be created." }
        } catch { errorMessage = "The session archive could not be created. \(error.localizedDescription)" }
    }

    func createDataset(name: String, sessionIDs: [UUID], trainImmediately: Bool = false) {
        guard !sessionIDs.isEmpty else { return }
        do {
            let manifest = try store.createDataset(name: name, sessionIDs: sessionIDs)
            let datasetURL = store.datasetsURL.appendingPathComponent(manifest.id.uuidString, isDirectory: true)
            refreshLibrary()
            navigation = .datasets
            if trainImmediately {
                statusMessage = "Dataset created. Training its game agent now…"
                trainDataset(manifest, at: datasetURL)
            } else {
                statusMessage = "Dataset created from \(sessionIDs.count) session\(sessionIDs.count == 1 ? "" : "s")."
            }
        } catch { errorMessage = "Couldn’t create the dataset. \(error.localizedDescription)" }
    }

    func deleteDataset(at url: URL) {
        do {
            try store.deleteDataset(at: url)
            refreshLibrary()
        } catch { errorMessage = "Couldn’t delete the dataset. \(error.localizedDescription)" }
    }

    func trainDataset(_ manifest: DatasetManifest, at datasetURL: URL) {
        guard trainingDatasetID == nil else { return }
        let candidates = [
            "/Library/Frameworks/Python.framework/Versions/Current/bin/python3",
            "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3",
            "/opt/homebrew/bin/python3",
            "/usr/local/bin/python3",
            "/usr/bin/python3",
        ]
        guard let python = candidates.first(where: { FileManager.default.isExecutableFile(atPath: $0) }),
              let resources = Bundle.main.resourceURL else {
            errorMessage = "Learner couldn’t find its local training runtime. Reinstall the latest Learner build."
            return
        }
        let package = resources.appendingPathComponent("python", isDirectory: true)
        guard FileManager.default.fileExists(atPath: package.appendingPathComponent("learner_dataset/training.py").path) else {
            errorMessage = "Learner’s local trainer is missing. Reinstall the latest Learner build."
            return
        }

        let destinationDirectory = store.modelsURL.appendingPathComponent("latest", isDirectory: true)
        let pending = destinationDirectory.appendingPathComponent("model.next.json")
        trainingDatasetID = manifest.id
        trainingMessage = "Reading demonstrations and discovering controls…"
        statusMessage = nil

        Task { [weak self] in
            let failure = await Task.detached(priority: .userInitiated) { () -> String? in
                do {
                try FileManager.default.createDirectory(at: destinationDirectory, withIntermediateDirectories: true)
                let process = Process()
                let output = Pipe()
                process.executableURL = URL(fileURLWithPath: python)
                process.arguments = [
                    "-m", "learner_dataset.training", datasetURL.path,
                    "--output", pending.path,
                ]
                var environment = ProcessInfo.processInfo.environment
                let bundledPackages = resources.appendingPathComponent("python/site-packages", isDirectory: true)
                environment["PYTHONPATH"] = [package.path, bundledPackages.path].joined(separator: ":")
                environment["PYTHONUNBUFFERED"] = "1"
                process.environment = environment
                process.standardOutput = output
                process.standardError = output
                try process.run()
                process.waitUntilExit()
                let log = String(data: output.fileHandleForReading.readDataToEndOfFile(), encoding: .utf8) ?? ""
                guard process.terminationStatus == 0, FileManager.default.fileExists(atPath: pending.path) else {
                    throw TrainingError.failed(log.trimmingCharacters(in: .whitespacesAndNewlines))
                }
                let final = destinationDirectory.appendingPathComponent("model.json")
                if FileManager.default.fileExists(atPath: final.path) {
                    _ = try FileManager.default.replaceItemAt(final, withItemAt: pending)
                } else {
                    try FileManager.default.moveItem(at: pending, to: final)
                }
                let online = destinationDirectory.appendingPathComponent("online_learning.json")
                try? FileManager.default.removeItem(at: online)
                    return nil
                } catch {
                    try? FileManager.default.removeItem(at: pending)
                    return error.localizedDescription
                }
            }.value
            guard let self else { return }
            trainingDatasetID = nil
            trainingMessage = ""
            if let failure {
                errorMessage = "Training failed. \(failure)"
            } else {
                refreshLibrary()
                navigation = .agent
                statusMessage = agentGoalDescription.isEmpty
                    ? "Training complete. Choose the game or screen and click Run Agent."
                    : "Training complete. Inferred goal: \(agentGoalDescription)"
            }
        }
    }

    private enum TrainingError: LocalizedError {
        case failed(String)
        var errorDescription: String? {
            switch self {
            case .failed(let log):
                return log.isEmpty ? "The local trainer exited unexpectedly." : String(log.suffix(800))
            }
        }
    }

    func beginBackgroundLearning(gameID: UUID, trainPolicy: Bool = true) {
        if let index = learningQueue.firstIndex(where: { $0.gameID == gameID }) {
            learningQueue[index].trainPolicy = learningQueue[index].trainPolicy || trainPolicy
        } else if processingGameID == gameID {
            // The current pass already snapshots all attached sessions. A later
            // correction arriving during it is queued for one additional pass.
            learningQueue.append((gameID, trainPolicy))
        } else {
            learningQueue.append((gameID, trainPolicy))
        }
        runNextLearningJobIfNeeded()
    }

    private func runNextLearningJobIfNeeded() {
        guard processingGameID == nil, !learningQueue.isEmpty else { return }
        let job = learningQueue.removeFirst()
        guard let project = games.first(where: { $0.id == job.gameID }) else {
            runNextLearningJobIfNeeded()
            return
        }
        guard let pythonContext = pythonRuntimeContext() else {
            errorMessage = "Learner’s local learning runtime is unavailable. Reinstall the current build."
            runNextLearningJobIfNeeded()
            return
        }
        let manifest: URL
        do { manifest = try store.writeTrainingManifest(for: project) }
        catch {
            errorMessage = "Couldn’t prepare this Game’s experience. \(error.localizedDescription)"
            runNextLearningJobIfNeeded()
            return
        }

        processingGameID = job.gameID
        processingMessage = "Discovering visual situations and repeated behaviors…"
        let knowledgeFinal = store.learningURL(for: job.gameID)
        let knowledgePending = knowledgeFinal.deletingLastPathComponent().appendingPathComponent("understanding.next.json")
        let modelFinal = store.modelURL(for: job.gameID)
        let modelPending = modelFinal.deletingLastPathComponent().appendingPathComponent("model.next.json")

        Task { [weak self] in
            let analysisFailure = await Task.detached(priority: .utility) {
                Self.runPythonProcess(
                    python: pythonContext.python,
                    module: "learner_dataset.analysis",
                    arguments: [manifest.path, "--output", knowledgePending.path],
                    environment: pythonContext.environment
                )
            }.value
            guard let self else { return }
            if analysisFailure == nil, FileManager.default.fileExists(atPath: knowledgePending.path) {
                try? FileManager.default.createDirectory(at: knowledgeFinal.deletingLastPathComponent(), withIntermediateDirectories: true)
                if FileManager.default.fileExists(atPath: knowledgeFinal.path) {
                    _ = try? FileManager.default.replaceItemAt(knowledgeFinal, withItemAt: knowledgePending)
                } else {
                    try? FileManager.default.moveItem(at: knowledgePending, to: knowledgeFinal)
                }
            }

            var trainingFailure: String?
            if job.trainPolicy {
                self.processingMessage = "Updating the temporal imitation policy and visual memory…"
                trainingFailure = await Task.detached(priority: .utility) {
                    Self.runPythonProcess(
                        python: pythonContext.python,
                        module: "learner_dataset.training",
                        arguments: [manifest.path, "--output", modelPending.path, "--epochs", "18"],
                        environment: pythonContext.environment
                    )
                }.value
                if trainingFailure == nil, FileManager.default.fileExists(atPath: modelPending.path) {
                    try? FileManager.default.createDirectory(at: modelFinal.deletingLastPathComponent(), withIntermediateDirectories: true)
                    if FileManager.default.fileExists(atPath: modelFinal.path) {
                        _ = try? FileManager.default.replaceItemAt(modelFinal, withItemAt: modelPending)
                    } else {
                        try? FileManager.default.moveItem(at: modelPending, to: modelFinal)
                    }
                }
            }

            self.processingGameID = nil
            self.processingMessage = ""
            self.refreshLibrary()
            if let failure = trainingFailure ?? analysisFailure {
                self.errorMessage = "Background learning could not finish. \(String(failure.suffix(600)))"
            } else if self.currentGameID == job.gameID {
                self.statusMessage = job.trainPolicy
                    ? "Learning finished. Practice is ready with the latest demonstrations and corrections."
                    : "Latest experience analysis finished."
            }
            self.runNextLearningJobIfNeeded()
        }
    }

    private func pythonRuntimeContext() -> (python: String, environment: [String: String])? {
        let candidates = [
            "/Library/Frameworks/Python.framework/Versions/Current/bin/python3",
            "/Library/Frameworks/Python.framework/Versions/3.13/bin/python3",
            "/opt/homebrew/bin/python3",
            "/usr/local/bin/python3",
            "/usr/bin/python3",
        ]
        guard let python = candidates.first(where: { FileManager.default.isExecutableFile(atPath: $0) }),
              let resources = Bundle.main.resourceURL else { return nil }
        let package = resources.appendingPathComponent("python", isDirectory: true)
        guard FileManager.default.fileExists(atPath: package.appendingPathComponent("learner_dataset/training.py").path),
              FileManager.default.fileExists(atPath: package.appendingPathComponent("learner_dataset/analysis.py").path) else { return nil }
        var environment = ProcessInfo.processInfo.environment
        let bundledPackages = resources.appendingPathComponent("python/site-packages", isDirectory: true)
        environment["PYTHONPATH"] = [package.path, bundledPackages.path].joined(separator: ":")
        environment["PYTHONUNBUFFERED"] = "1"
        return (python, environment)
    }

    nonisolated private static func runPythonProcess(
        python: String,
        module: String,
        arguments: [String],
        environment: [String: String]
    ) -> String? {
        do {
            let process = Process()
            let output = Pipe()
            process.executableURL = URL(fileURLWithPath: python)
            process.arguments = ["-m", module] + arguments
            process.environment = environment
            process.standardOutput = output
            process.standardError = output
            try process.run()
            process.waitUntilExit()
            let log = String(data: output.fileHandleForReading.readDataToEndOfFile(), encoding: .utf8) ?? ""
            return process.terminationStatus == 0 ? nil : (log.isEmpty ? "The local learner exited unexpectedly." : log)
        } catch {
            return error.localizedDescription
        }
    }

    func reveal(_ url: URL) {
        NSWorkspace.shared.activateFileViewerSelecting([url])
    }

    func addMarker(_ label: MarkerLabel, at timestampNs: UInt64, endTimestampNs: UInt64? = nil, session: SessionSummary) {
        do {
            let start = min(timestampNs, endTimestampNs ?? timestampNs)
            let end = max(timestampNs, endTimestampNs ?? timestampNs)
            try store.append(marker: TimelineMarker(timestampNs: start, endTimestampNs: end == start ? nil : end, label: label), to: session)
            statusMessage = "\(label.rawValue) label added."
        } catch { errorMessage = "Couldn’t save the label. \(error.localizedDescription)" }
    }

    private func captureDidStop(_ error: Error) {
        if phase == .agent {
            captureStreamFailed = true
            reconnectCaptureIfNeeded()
            return
        }
        if phase == .recording {
            captureStreamFailed = true
            reconnectCaptureIfNeeded()
            return
        }
        if phase == .paused {
            captureStreamFailed = true
            return
        }
        errorMessage = "Capture stopped because the selected target disappeared or stopped. \(error.localizedDescription)"
    }

    private func startWatchdog() {
        watchdog = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] _ in
            Task { @MainActor in
                guard let self else { return }
                if self.phase == .recording {
                    // SessionRecorder has its own full-rate frame clock. This is
                    // only a secondary metadata checkpoint and reconnection loop.
                    self.recorder?.heartbeat()
                    if self.captureStreamFailed { self.reconnectCaptureIfNeeded() }
                } else if self.phase == .agent {
                    // Static games may not emit a new ScreenCaptureKit sample.
                    // Re-run inference on the last exact observation so recovery
                    // and online learning continue instead of freezing.
                    if self.captureEngine.secondsSinceLastFrame() > 0.3 {
                        self.captureEngine.replayLatestFrame()
                    }
                    if self.captureStreamFailed { self.reconnectCaptureIfNeeded() }
                }
            }
        }
    }

    private func reconnectCaptureIfNeeded() {
        guard phase == .recording || phase == .agent,
              captureStreamFailed,
              !isReconnectingCapture,
              let source = selectedSource else { return }

        let now = DispatchTime.now().uptimeNanoseconds
        guard now >= lastReconnectAttemptNs + 5_000_000_000 else { return }
        lastReconnectAttemptNs = now
        isReconnectingCapture = true

        Task { [weak self] in
            guard let self else { return }
            do {
                try await self.captureEngine.start(source: source)
                self.captureStreamFailed = false
            } catch {
                // Fullscreen transitions and game renderers can recreate their
                // window surface with a new ScreenCaptureKit ID. Resolve the
                // closest replacement instead of asking the user to select again.
                if let replacement = await self.replacementSource(for: source) {
                    do {
                        try await self.captureEngine.start(source: replacement)
                        self.selectedSource = replacement
                        self.previewInputController = InputController(
                            targetPID: self.resolvedTargetPID(for: replacement),
                            bounds: replacement.bounds
                        )
                        self.captureStreamFailed = false
                    } catch {
                        // Retry silently. The recorder's frame clock and the
                        // agent's last observation keep both workflows alive.
                    }
                }
            }
            self.isReconnectingCapture = false
        }
    }

    private func replacementSource(for source: CaptureSourceDescriptor) async -> CaptureSourceDescriptor? {
        guard let sources = try? await CaptureSourceProvider.availableSources() else { return nil }
        availableSources = sources
        switch source.kind {
        case .window:
            let candidates = sources.filter { candidate in
                guard candidate.kind == .window else { return false }
                if let bundle = source.bundleIdentifier, candidate.bundleIdentifier == bundle { return true }
                if let pid = source.ownerPID, candidate.ownerPID == pid { return true }
                return candidate.applicationName == source.applicationName
            }
            return candidates.max { left, right in
                let leftTitle = left.windowTitle == source.windowTitle ? 1 : 0
                let rightTitle = right.windowTitle == source.windowTitle ? 1 : 0
                if leftTitle != rightTitle { return leftTitle < rightTitle }
                return left.bounds.width * left.bounds.height < right.bounds.width * right.bounds.height
            }
        case .display, .region:
            return sources.first(where: { $0.kind == source.kind && $0.displayID == source.displayID })
                ?? sources.first(where: { $0.kind == source.kind })
        }
    }

    private func restoreLearnerWindow() {
        NSApp.unhide(nil)
        NSRunningApplication.current.activate(options: [.activateAllWindows])
    }

    private func currentDisplaySource(in sources: [CaptureSourceDescriptor]) -> CaptureSourceDescriptor? {
        let displays = sources.filter { $0.kind == .display }
        if let point = CGEvent(source: nil)?.location {
            var matchingDisplays = [CGDirectDisplayID](repeating: 0, count: 8)
            var matchCount: UInt32 = 0
            let result = CGGetDisplaysWithPoint(point, UInt32(matchingDisplays.count), &matchingDisplays, &matchCount)
            if result == .success, matchCount > 0,
               let containing = displays.first(where: { $0.displayID == matchingDisplays[0] }) {
                return containing
            }
        }
        let mainDisplayID = CGMainDisplayID()
        return displays.first(where: { $0.displayID == mainDisplayID }) ?? displays.first
    }

    private func resolvedTargetPID(for source: CaptureSourceDescriptor) -> pid_t? {
        source.ownerPID ?? availableSources.first(where: {
            $0.kind == .window && $0.ownerPID != ProcessInfo.processInfo.processIdentifier
        })?.ownerPID
    }

    private enum MenuBarRecordingError: LocalizedError {
        case noDisplay

        var errorDescription: String? {
            switch self {
            case .noDisplay: "No display is available to capture. Check Screen Recording permission."
            }
        }
    }

    private func startDiskTimer() {
        diskTimer?.invalidate()
        diskTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            Task { @MainActor in
                guard let self, let recorder = self.recorder else { return }
                self.approximateDiskBytes = self.store.directorySize(recorder.directoryURL)
            }
        }
    }
}
