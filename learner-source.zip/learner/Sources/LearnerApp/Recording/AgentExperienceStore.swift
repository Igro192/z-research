import Foundation

struct AgentExperienceRecord: Codable, Sendable {
    var createdAt: Date
    var sessionID: UUID
    var timestampNs: UInt64
    var mode: String
    var confidence: Double
    var selectedControls: [String]
    var probabilities: [String: Double]
    var humanOverride: Bool
}

/// Append-only experience telemetry used by correction learning and later
/// planners. It never runs on the capture callback and cannot block recording.
final class AgentExperienceStore: @unchecked Sendable {
    private let queue = DispatchQueue(label: "app.learner.agent-experience", qos: .utility)
    private let writer: JSONLinesWriter

    init(directory: URL) throws {
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        writer = try JSONLinesWriter(url: directory.appendingPathComponent("agent-decisions.jsonl"))
    }

    func append(_ record: AgentExperienceRecord) {
        queue.async { [writer] in try? writer.append(record) }
    }

    func close() {
        queue.sync { [writer] in
            try? writer.synchronize()
            try? writer.close()
        }
    }
}
