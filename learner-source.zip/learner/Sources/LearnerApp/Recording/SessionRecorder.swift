import CoreVideo
import Foundation
import LearnerCore

final class SessionRecorder: @unchecked Sendable {
    struct Stats: Sendable {
        var elapsedNs: UInt64
        var frameCount: Int
        var actionCount: Int
        var sampleCount: Int { max(0, frameCount - 1) }
    }

    let sessionID: UUID
    let directoryURL: URL
    var onStats: ((Stats) -> Void)?

    private let queue = DispatchQueue(label: "app.learner.session-writer", qos: .userInitiated)
    private let store: SessionStore
    private let videoWriter: VideoWriter
    private let regionExporter: RegionVideoExporter
    private let frameWriter: JSONLinesWriter
    private let actionWriter: JSONLinesWriter
    private let markerWriter: JSONLinesWriter
    private var metadata: SessionMetadata
    private var startRawNs: UInt64
    private var pauseRawNs: UInt64?
    private var totalPausedNs: UInt64 = 0
    private var stopped = false
    private var lastCheckpointRawNs: UInt64 = 0
    private var lastFrameBuffer: CVPixelBuffer?
    private var lastFrameTimelineNs: UInt64?
    private let holdFrameIntervalNs: UInt64
    private var frameClock: DispatchSourceTimer?

    init(
        store: SessionStore,
        source: CaptureSourceDescriptor,
        configuration: VisionConfiguration,
        dimensions: VideoDimensions,
        gameID: UUID? = nil,
        learningRole: ExperienceRole? = nil
    ) throws {
        self.store = store
        sessionID = UUID()
        directoryURL = try store.createSessionDirectory(id: sessionID)
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d, yyyy 'at' HH:mm"
        metadata = SessionMetadata(
            id: sessionID,
            name: "\(source.applicationName) — \(formatter.string(from: Date()))",
            target: source,
            vision: configuration,
            output: dimensions,
            gameID: gameID,
            learningRole: learningRole
        )
        try store.writeMetadata(metadata, to: directoryURL)
        videoWriter = try VideoWriter(
            url: directoryURL.appendingPathComponent(metadata.videoPath),
            dimensions: dimensions,
            fps: configuration.fps
        )
        regionExporter = try RegionVideoExporter(
            directory: directoryURL.appendingPathComponent("regions"),
            regions: configuration.regions,
            fullDimensions: dimensions,
            fps: configuration.fps
        )
        frameWriter = try JSONLinesWriter(url: directoryURL.appendingPathComponent("observations/frames.jsonl"))
        actionWriter = try JSONLinesWriter(url: directoryURL.appendingPathComponent("actions/events.jsonl"))
        markerWriter = try JSONLinesWriter(url: directoryURL.appendingPathComponent("markers/labels.jsonl"))
        holdFrameIntervalNs = 1_000_000_000 / UInt64(max(1, configuration.fps))
        startRawNs = DispatchTime.now().uptimeNanoseconds

        // ScreenCaptureKit is allowed to suppress unchanged frames. The dataset
        // recorder is not: maintain the configured observation cadence using the
        // last real frame so training never sees a mysterious missing-frame gap.
        let clock = DispatchSource.makeTimerSource(queue: queue)
        clock.schedule(
            deadline: .now() + .nanoseconds(Int(holdFrameIntervalNs)),
            repeating: .nanoseconds(Int(holdFrameIntervalNs)),
            leeway: .milliseconds(2)
        )
        clock.setEventHandler { [weak self] in
            self?.advanceFrameClock(rawTimestampNs: DispatchTime.now().uptimeNanoseconds)
        }
        frameClock = clock
        clock.resume()
    }

    func appendFrame(_ buffer: CVPixelBuffer, dimensions: VideoDimensions, rawTimestampNs: UInt64) {
        queue.async { [self] in
            guard !stopped, let timestamp = timelineTimestamp(rawTimestampNs) else { return }
            guard dimensions == metadata.output else { return }
            if appendRecordedFrame(buffer, timestampNs: timestamp) {
                // Retaining the latest processed buffer lets the recorder preserve
                // timeline continuity if ScreenCaptureKit temporarily emits no
                // frames (static content, loading screens, or an obscured window).
                lastFrameBuffer = buffer
                lastFrameTimelineNs = timestamp
            }
            metadata.durationNs = max(metadata.durationNs, timestamp)
            emitStatsAndCheckpoint(rawTimestampNs)
        }
    }

    func appendAction(_ action: InputEventRecord, rawTimestampNs: UInt64) {
        queue.async { [self] in
            guard !stopped, let timestamp = timelineTimestamp(rawTimestampNs) else { return }
            var adjusted = action
            adjusted.timestampNs = timestamp
            try? actionWriter.append(adjusted)
            metadata.actionCount += 1
            metadata.durationNs = max(metadata.durationNs, timestamp)
            emitStatsAndCheckpoint(rawTimestampNs)
        }
    }

    func addMarker(_ label: MarkerLabel) {
        let raw = DispatchTime.now().uptimeNanoseconds
        queue.async { [self] in
            guard !stopped, let timestamp = timelineTimestamp(raw) else { return }
            try? markerWriter.append(TimelineMarker(timestampNs: timestamp, label: label))
        }
    }

    /// Advances the recording clock independently of frame delivery. The internal
    /// frame clock calls the same path at the configured FPS; this method remains
    /// available for explicit crash checkpoints and tests.
    func heartbeat(rawTimestampNs: UInt64 = DispatchTime.now().uptimeNanoseconds) {
        queue.async { [self] in
            advanceFrameClock(rawTimestampNs: rawTimestampNs)
        }
    }

    func pause() {
        let raw = DispatchTime.now().uptimeNanoseconds
        queue.async { [self] in
            guard pauseRawNs == nil, !stopped else { return }
            pauseRawNs = raw
            metadata.status = .paused
            metadata.updatedAt = Date()
            try? store.writeMetadata(metadata, to: directoryURL)
        }
    }

    func resume() {
        let raw = DispatchTime.now().uptimeNanoseconds
        queue.async { [self] in
            guard let pausedAt = pauseRawNs, !stopped else { return }
            totalPausedNs += raw - pausedAt
            pauseRawNs = nil
            metadata.status = .recording
            metadata.updatedAt = Date()
            try? store.writeMetadata(metadata, to: directoryURL)
        }
    }

    func stop() async throws -> SessionSummary {
        try await withCheckedThrowingContinuation { continuation in
            queue.async { [self] in
                guard !stopped else {
                    continuation.resume(throwing: RecorderError.alreadyStopped)
                    return
                }
                let raw = DispatchTime.now().uptimeNanoseconds
                if let timestamp = timelineTimestamp(raw) {
                    metadata.durationNs = max(metadata.durationNs, timestamp)
                    appendHoldFrameIfNeeded(at: timestamp)
                }
                frameClock?.setEventHandler {}
                frameClock?.cancel()
                frameClock = nil
                stopped = true
                if let pausedAt = pauseRawNs {
                    totalPausedNs += DispatchTime.now().uptimeNanoseconds - pausedAt
                    pauseRawNs = nil
                }
                try? frameWriter.synchronize()
                try? actionWriter.synchronize()
                try? markerWriter.synchronize()
                try? frameWriter.close()
                try? actionWriter.close()
                try? markerWriter.close()

                videoWriter.finish { [self] videoError in
                    regionExporter.finish { [self] in
                        metadata.status = videoError == nil ? .complete : .failed
                        metadata.updatedAt = Date()
                        do {
                            try store.writeMetadata(metadata, to: directoryURL)
                            let summary = SessionSummary(
                                metadata: metadata,
                                directoryURL: directoryURL,
                                sizeBytes: store.directorySize(directoryURL)
                            )
                            if let videoError { continuation.resume(throwing: videoError) }
                            else { continuation.resume(returning: summary) }
                        } catch {
                            continuation.resume(throwing: error)
                        }
                    }
                }
            }
        }
    }

    private func timelineTimestamp(_ raw: UInt64) -> UInt64? {
        guard pauseRawNs == nil else { return nil }
        return raw >= startRawNs + totalPausedNs ? raw - startRawNs - totalPausedNs : 0
    }

    @discardableResult
    private func appendRecordedFrame(_ buffer: CVPixelBuffer, timestampNs: UInt64) -> Bool {
        guard videoWriter.append(buffer, timestampNs: timestampNs) else { return false }
        let frame = FrameRecord(
            frameIndex: metadata.frameCount,
            timestampNs: timestampNs,
            videoPtsNs: timestampNs
        )
        try? frameWriter.append(frame)
        regionExporter.append(buffer, timestampNs: timestampNs)
        metadata.frameCount += 1
        return true
    }

    private func appendHoldFrameIfNeeded(at timestamp: UInt64) {
        guard let buffer = lastFrameBuffer,
              let previous = lastFrameTimelineNs,
              timestamp >= previous + holdFrameIntervalNs,
              appendRecordedFrame(buffer, timestampNs: timestamp) else { return }
        lastFrameTimelineNs = timestamp
    }

    private func advanceFrameClock(rawTimestampNs: UInt64) {
        guard !stopped, let timestamp = timelineTimestamp(rawTimestampNs) else { return }
        metadata.durationNs = max(metadata.durationNs, timestamp)
        appendHoldFrameIfNeeded(at: timestamp)
        emitStatsAndCheckpoint(rawTimestampNs)
    }

    private func emitStatsAndCheckpoint(_ raw: UInt64) {
        let stats = Stats(elapsedNs: metadata.durationNs, frameCount: metadata.frameCount, actionCount: metadata.actionCount)
        onStats?(stats)
        if raw - lastCheckpointRawNs > 2_000_000_000 {
            lastCheckpointRawNs = raw
            metadata.updatedAt = Date()
            try? frameWriter.synchronize()
            try? actionWriter.synchronize()
            try? store.writeMetadata(metadata, to: directoryURL)
        }
    }

    enum RecorderError: LocalizedError {
        case alreadyStopped
        var errorDescription: String? { "This recording has already stopped." }
    }
}
