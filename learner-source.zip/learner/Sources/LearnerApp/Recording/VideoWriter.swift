import AVFoundation
import CoreImage
import CoreVideo
import Metal
import LearnerCore

final class VideoWriter {
    private let writer: AVAssetWriter
    private let input: AVAssetWriterInput
    private let adaptor: AVAssetWriterInputPixelBufferAdaptor
    private var started = false
    private var lastPresentationTime = CMTime.invalid

    init(url: URL, dimensions: VideoDimensions, fps: Int) throws {
        writer = try AVAssetWriter(outputURL: url, fileType: .mp4)
        writer.movieFragmentInterval = CMTime(seconds: 2, preferredTimescale: 600)
        let pixels = dimensions.width * dimensions.height
        let bitRate = min(24_000_000, max(2_000_000, pixels * fps / 7))
        let settings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: dimensions.width,
            AVVideoHeightKey: dimensions.height,
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: bitRate,
                AVVideoExpectedSourceFrameRateKey: fps,
                AVVideoMaxKeyFrameIntervalKey: fps * 2,
                AVVideoAllowFrameReorderingKey: false,
                AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel,
            ],
        ]
        input = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
        input.expectsMediaDataInRealTime = true
        adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: input,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: dimensions.width,
                kCVPixelBufferHeightKey as String: dimensions.height,
                kCVPixelBufferIOSurfacePropertiesKey as String: [:],
            ]
        )
        guard writer.canAdd(input) else { throw WriterError.cannotAddInput }
        writer.add(input)
    }

    func append(_ buffer: CVPixelBuffer, timestampNs: UInt64) -> Bool {
        if !started {
            guard writer.startWriting() else { return false }
            writer.startSession(atSourceTime: .zero)
            started = true
        }
        guard input.isReadyForMoreMediaData else { return false }
        var presentation = CMTime(value: CMTimeValue(timestampNs), timescale: 1_000_000_000)
        if lastPresentationTime.isValid && presentation <= lastPresentationTime {
            presentation = lastPresentationTime + CMTime(value: 1, timescale: 1_000_000_000)
        }
        let appended = adaptor.append(buffer, withPresentationTime: presentation)
        if appended { lastPresentationTime = presentation }
        return appended
    }

    func finish(_ completion: @escaping (Error?) -> Void) {
        guard started else {
            writer.cancelWriting()
            completion(nil)
            return
        }
        input.markAsFinished()
        writer.finishWriting { [writer] in completion(writer.error) }
    }

    enum WriterError: LocalizedError {
        case cannotAddInput
        var errorDescription: String? { "The hardware video encoder could not be configured." }
    }
}

final class RegionVideoExporter {
    struct Entry {
        let region: ObservationRegion
        let dimensions: VideoDimensions
        let writer: VideoWriter
        let pool: CVPixelBufferPool
    }

    private let context: CIContext
    private var entries: [Entry] = []

    init(directory: URL, regions: [ObservationRegion], fullDimensions: VideoDimensions, fps: Int) throws {
        if let device = MTLCreateSystemDefaultDevice() {
            context = CIContext(mtlDevice: device, options: [.cacheIntermediates: false])
        } else {
            context = CIContext(options: [.cacheIntermediates: false])
        }
        for region in regions where region.exportSeparately {
            let rect = region.rect.clamped()
            let width = Self.even(max(2, Int(Double(fullDimensions.width) * rect.width)))
            let height = Self.even(max(2, Int(Double(fullDimensions.height) * rect.height)))
            let dimensions = VideoDimensions(width: width, height: height)
            let safeName = region.name.replacingOccurrences(of: "[^a-zA-Z0-9_-]", with: "_", options: .regularExpression)
            let url = directory.appendingPathComponent("\(safeName.isEmpty ? region.id.uuidString : safeName).mp4")
            let writer = try VideoWriter(url: url, dimensions: dimensions, fps: fps)
            var pool: CVPixelBufferPool?
            let attributes: [String: Any] = [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: width,
                kCVPixelBufferHeightKey as String: height,
                kCVPixelBufferIOSurfacePropertiesKey as String: [:],
            ]
            CVPixelBufferPoolCreate(nil, nil, attributes as CFDictionary, &pool)
            if let pool { entries.append(Entry(region: region, dimensions: dimensions, writer: writer, pool: pool)) }
        }
    }

    func append(_ fullBuffer: CVPixelBuffer, timestampNs: UInt64) {
        let fullWidth = CVPixelBufferGetWidth(fullBuffer)
        let fullHeight = CVPixelBufferGetHeight(fullBuffer)
        let fullImage = CIImage(cvPixelBuffer: fullBuffer)
        for entry in entries {
            var destination: CVPixelBuffer?
            guard CVPixelBufferPoolCreatePixelBuffer(nil, entry.pool, &destination) == kCVReturnSuccess, let destination else { continue }
            let rect = entry.region.rect.clamped()
            let crop = CGRect(
                x: rect.x * Double(fullWidth),
                y: (1 - rect.y - rect.height) * Double(fullHeight),
                width: rect.width * Double(fullWidth),
                height: rect.height * Double(fullHeight)
            ).integral
            var image = fullImage.cropped(to: crop)
                .transformed(by: CGAffineTransform(translationX: -crop.minX, y: -crop.minY))
            image = image.transformed(by: CGAffineTransform(
                scaleX: Double(entry.dimensions.width) / crop.width,
                y: Double(entry.dimensions.height) / crop.height
            ))
            context.render(image, to: destination)
            _ = entry.writer.append(destination, timestampNs: timestampNs)
        }
    }

    func finish(_ completion: @escaping () -> Void) {
        guard !entries.isEmpty else { completion(); return }
        let group = DispatchGroup()
        for entry in entries {
            group.enter()
            entry.writer.finish { _ in group.leave() }
        }
        group.notify(queue: .global(qos: .utility), execute: completion)
    }

    private static func even(_ value: Int) -> Int { value.isMultiple(of: 2) ? value : value - 1 }
}
