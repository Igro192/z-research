import Foundation
import LearnerCore

final class SessionStore: @unchecked Sendable {
    let rootURL: URL
    let sessionsURL: URL
    let datasetsURL: URL
    let modelsURL: URL
    let gamesURL: URL

    private let encoder: JSONEncoder = {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }()
    private let decoder: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }()

    init(rootURL: URL? = nil) {
        let applicationSupport = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        self.rootURL = rootURL ?? applicationSupport.appendingPathComponent("Learner", isDirectory: true)
        self.sessionsURL = self.rootURL.appendingPathComponent("Sessions", isDirectory: true)
        self.datasetsURL = self.rootURL.appendingPathComponent("Datasets", isDirectory: true)
        self.modelsURL = self.rootURL.appendingPathComponent("Models", isDirectory: true)
        self.gamesURL = self.rootURL.appendingPathComponent("Games", isDirectory: true)
        try? FileManager.default.createDirectory(at: sessionsURL, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: datasetsURL, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: modelsURL, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: gamesURL, withIntermediateDirectories: true)
        recoverInterruptedSessions()
        migrateLegacyData()
    }

    func createSessionDirectory(id: UUID) throws -> URL {
        let directory = sessionsURL.appendingPathComponent(id.uuidString, isDirectory: true)
        for component in ["video", "actions", "observations", "markers", "regions"] {
            try FileManager.default.createDirectory(
                at: directory.appendingPathComponent(component, isDirectory: true),
                withIntermediateDirectories: true
            )
        }
        return directory
    }

    func writeMetadata(_ metadata: SessionMetadata, to directory: URL) throws {
        let data = try encoder.encode(metadata)
        try data.write(to: directory.appendingPathComponent("metadata.json"), options: .atomic)
    }

    func loadMetadata(from directory: URL) throws -> SessionMetadata {
        let data = try Data(contentsOf: directory.appendingPathComponent("metadata.json"))
        return try decoder.decode(SessionMetadata.self, from: data)
    }

    func listSessions() -> [SessionSummary] {
        guard let directories = try? FileManager.default.contentsOfDirectory(
            at: sessionsURL,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return [] }

        return directories.compactMap { directory in
            guard let metadata = try? loadMetadata(from: directory) else { return nil }
            return SessionSummary(metadata: metadata, directoryURL: directory, sizeBytes: directorySize(directory))
        }.sorted { $0.metadata.createdAt > $1.metadata.createdAt }
    }

    func rename(session: SessionSummary, to name: String) throws {
        var metadata = session.metadata
        metadata.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        metadata.updatedAt = Date()
        try writeMetadata(metadata, to: session.directoryURL)
    }

    func delete(session: SessionSummary) throws {
        try FileManager.default.removeItem(at: session.directoryURL)
    }

    func append(marker: TimelineMarker, to session: SessionSummary) throws {
        let url = session.directoryURL.appendingPathComponent("markers/labels.jsonl")
        let writer = try JSONLinesWriter(url: url)
        try writer.append(marker)
        try writer.close()
    }

    func loadFrames(for session: SessionSummary) -> [FrameRecord] {
        readJSONLines(session.directoryURL.appendingPathComponent("observations/frames.jsonl"), as: FrameRecord.self)
    }

    func loadActions(for session: SessionSummary) -> [InputEventRecord] {
        readJSONLines(session.directoryURL.appendingPathComponent("actions/events.jsonl"), as: InputEventRecord.self)
    }

    func loadMarkers(for session: SessionSummary) -> [TimelineMarker] {
        readJSONLines(session.directoryURL.appendingPathComponent("markers/labels.jsonl"), as: TimelineMarker.self)
    }

    func createDataset(name: String, sessionIDs: [UUID]) throws -> DatasetManifest {
        let manifest = DatasetManifest(name: name, sessionIDs: sessionIDs)
        let directory = datasetsURL.appendingPathComponent(manifest.id.uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let data = try encoder.encode(manifest)
        try data.write(to: directory.appendingPathComponent("dataset.json"), options: .atomic)
        return manifest
    }

    func listDatasets() -> [(DatasetManifest, URL)] {
        guard let directories = try? FileManager.default.contentsOfDirectory(at: datasetsURL, includingPropertiesForKeys: nil) else { return [] }
        return directories.compactMap { directory in
            let url = directory.appendingPathComponent("dataset.json")
            guard let data = try? Data(contentsOf: url), let manifest = try? decoder.decode(DatasetManifest.self, from: data) else { return nil }
            return (manifest, directory)
        }.sorted { $0.0.createdAt > $1.0.createdAt }
    }

    func deleteDataset(at directory: URL) throws {
        try FileManager.default.removeItem(at: directory)
    }

    func latestModelURL() -> URL? {
        let direct = modelsURL.appendingPathComponent("latest/model.json")
        if FileManager.default.fileExists(atPath: direct.path) { return direct }
        guard let enumerator = FileManager.default.enumerator(at: modelsURL, includingPropertiesForKeys: [.contentModificationDateKey]) else { return nil }
        return (enumerator.allObjects as? [URL])?
            .filter { $0.lastPathComponent == "model.json" }
            .max { left, right in
                let l = (try? left.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
                let r = (try? right.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
                return l < r
            }
    }

    // MARK: - Game projects

    func createGame(name: String, preferredTarget: CaptureSourceDescriptor? = nil) throws -> GameProject {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let project = GameProject(name: trimmed.isEmpty ? "Untitled Game" : trimmed, preferredTarget: preferredTarget)
        try writeGame(project)
        return project
    }

    func writeGame(_ project: GameProject) throws {
        let directory = gameDirectory(project.id)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let data = try encoder.encode(project)
        try data.write(to: directory.appendingPathComponent("game.json"), options: .atomic)
    }

    func listGames() -> [GameProject] {
        guard let directories = try? FileManager.default.contentsOfDirectory(
            at: gamesURL,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ) else { return [] }
        return directories.compactMap { directory in
            let url = directory.appendingPathComponent("game.json")
            guard let data = try? Data(contentsOf: url) else { return nil }
            return try? decoder.decode(GameProject.self, from: data)
        }.sorted { $0.updatedAt > $1.updatedAt }
    }

    func attach(sessionID: UUID, to gameID: UUID, preferredTarget: CaptureSourceDescriptor? = nil) throws {
        guard var project = listGames().first(where: { $0.id == gameID }) else { return }
        if !project.sessionIDs.contains(sessionID) { project.sessionIDs.append(sessionID) }
        if let preferredTarget { project.preferredTarget = preferredTarget }
        project.updatedAt = Date()
        try writeGame(project)
    }

    func gameDirectory(_ id: UUID) -> URL {
        gamesURL.appendingPathComponent(id.uuidString, isDirectory: true)
    }

    func modelURL(for gameID: UUID) -> URL {
        gameDirectory(gameID).appendingPathComponent("model/model.json")
    }

    func learningURL(for gameID: UUID) -> URL {
        gameDirectory(gameID).appendingPathComponent("understanding.json")
    }

    func loadKnowledge(for gameID: UUID) -> ProjectKnowledge {
        guard let data = try? Data(contentsOf: learningURL(for: gameID)),
              let knowledge = try? decoder.decode(ProjectKnowledge.self, from: data) else { return ProjectKnowledge() }
        return knowledge
    }

    func writeKnowledge(_ knowledge: ProjectKnowledge, for gameID: UUID) throws {
        try FileManager.default.createDirectory(at: gameDirectory(gameID), withIntermediateDirectories: true)
        try encoder.encode(knowledge).write(to: learningURL(for: gameID), options: .atomic)
    }

    func appendCorrection(_ correction: CorrectionRecord, gameID: UUID) throws {
        let directory = gameDirectory(gameID)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let writer = try JSONLinesWriter(url: directory.appendingPathComponent("corrections.jsonl"))
        try writer.append(correction)
        try writer.close()
    }

    func correctionCount(for gameID: UUID) -> Int {
        let url = gameDirectory(gameID).appendingPathComponent("corrections.jsonl")
        guard let text = try? String(contentsOf: url, encoding: .utf8) else { return 0 }
        return text.split(separator: "\n").count
    }

    /// Creates a private trainer manifest. It is intentionally not placed in the
    /// legacy Datasets library and therefore does not reintroduce that concept in UI.
    func writeTrainingManifest(for project: GameProject) throws -> URL {
        let directory = gameDirectory(project.id).appendingPathComponent("learning", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let url = directory.appendingPathComponent("experience.json")
        let payload: [String: Any] = [
            "schemaVersion": 2,
            "gameID": project.id.uuidString,
            "name": project.name,
            "sessionIDs": project.sessionIDs.map(\.uuidString),
            "sessionsRoot": sessionsURL.path,
        ]
        let data = try JSONSerialization.data(withJSONObject: payload, options: [.prettyPrinted, .sortedKeys])
        try data.write(to: url, options: .atomic)
        return url
    }

    func directorySize(_ directory: URL) -> Int64 {
        guard let enumerator = FileManager.default.enumerator(
            at: directory,
            includingPropertiesForKeys: [.fileSizeKey, .isRegularFileKey],
            options: [.skipsHiddenFiles]
        ) else { return 0 }
        var size: Int64 = 0
        for case let fileURL as URL in enumerator {
            guard let values = try? fileURL.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey]), values.isRegularFile == true else { continue }
            size += Int64(values.fileSize ?? 0)
        }
        return size
    }

    private func readJSONLines<T: Decodable>(_ url: URL, as type: T.Type) -> [T] {
        guard let text = try? String(contentsOf: url, encoding: .utf8) else { return [] }
        return text.split(separator: "\n").compactMap { line in
            try? decoder.decode(T.self, from: Data(line.utf8))
        }
    }

    private func recoverInterruptedSessions() {
        guard let directories = try? FileManager.default.contentsOfDirectory(at: sessionsURL, includingPropertiesForKeys: nil) else { return }
        for directory in directories {
            guard var metadata = try? loadMetadata(from: directory), metadata.status == .recording || metadata.status == .paused else { continue }
            metadata.status = .interrupted
            metadata.recoveredAfterCrash = true
            metadata.updatedAt = Date()
            try? writeMetadata(metadata, to: directory)
        }
    }

    /// Idempotent migration: legacy datasets and orphan recordings remain in
    /// place, while Games provide the new user-facing view over the same data.
    private func migrateLegacyData() {
        var covered = Set(listGames().flatMap(\.sessionIDs))
        let legacyModel = latestModelURL()
        let legacyModelSessions = legacyModel.flatMap(modelSessionIDs)

        for (manifest, _) in listDatasets() where !FileManager.default.fileExists(
            atPath: gameDirectory(manifest.id).appendingPathComponent("game.json").path
        ) {
            let firstTarget = listSessions().first(where: { manifest.sessionIDs.contains($0.id) })?.metadata.target
            let project = GameProject(
                id: manifest.id,
                name: manifest.name,
                createdAt: manifest.createdAt,
                updatedAt: manifest.createdAt,
                sessionIDs: manifest.sessionIDs,
                legacyDatasetIDs: [manifest.id],
                preferredTarget: firstTarget
            )
            try? writeGame(project)
            covered.formUnion(manifest.sessionIDs)
            if let legacyModel, legacyModelSessions == Set(manifest.sessionIDs.map(\.uuidString)) {
                let destination = modelURL(for: project.id)
                try? FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
                if !FileManager.default.fileExists(atPath: destination.path) {
                    try? FileManager.default.copyItem(at: legacyModel, to: destination)
                }
            }
        }

        let orphaned = listSessions().filter { !covered.contains($0.id) }
        let groups = Dictionary(grouping: orphaned) {
            $0.metadata.target.bundleIdentifier ?? $0.metadata.target.applicationName
        }
        for (_, sessions) in groups where !sessions.isEmpty {
            let project = GameProject(
                name: sessions[0].metadata.target.applicationName,
                createdAt: sessions.map(\.metadata.createdAt).min() ?? Date(),
                updatedAt: sessions.map(\.metadata.updatedAt).max() ?? Date(),
                sessionIDs: sessions.map(\.id),
                preferredTarget: sessions[0].metadata.target
            )
            try? writeGame(project)
        }
    }

    private func modelSessionIDs(_ url: URL) -> Set<String>? {
        guard let data = try? Data(contentsOf: url),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let training = object["training"] as? [String: Any],
              let ids = training["sessionIDs"] as? [String] else { return nil }
        return Set(ids)
    }
}

final class JSONLinesWriter {
    private let handle: FileHandle
    private let encoder: JSONEncoder

    init(url: URL) throws {
        if !FileManager.default.fileExists(atPath: url.path) {
            FileManager.default.createFile(atPath: url.path, contents: nil)
        }
        handle = try FileHandle(forWritingTo: url)
        try handle.seekToEnd()
        encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.sortedKeys, .withoutEscapingSlashes]
    }

    func append<T: Encodable>(_ value: T) throws {
        var data = try encoder.encode(value)
        data.append(0x0A)
        try handle.write(contentsOf: data)
    }

    func synchronize() throws { try handle.synchronize() }
    func close() throws { try handle.close() }
}
