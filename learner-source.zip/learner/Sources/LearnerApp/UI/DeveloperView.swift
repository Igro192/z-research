import SwiftUI

struct DeveloperView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Developer").font(.title.weight(.semibold))
                    Text("Inspect real internal state. Normal teaching does not require anything on this screen.")
                        .foregroundStyle(.secondary)
                }

                SurfaceCard {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Current Game").font(.headline)
                        diagnostic("Project", model.currentGame?.name ?? "None")
                        diagnostic("Stored sessions", model.currentGameSessions.count.formatted())
                        diagnostic("Processed sessions", model.projectKnowledge.processedSessionIDs.count.formatted())
                        diagnostic("Visual state clusters", model.projectKnowledge.states.count.formatted())
                        diagnostic("Repeated behavior sequences", model.projectKnowledge.skills.count.formatted())
                        diagnostic("Observed state transitions", model.projectKnowledge.transitions.count.formatted())
                        diagnostic("Correction records", model.projectKnowledge.correctionCount.formatted())
                        diagnostic("Temporal policy", model.currentGameModelURL == nil ? "Not learned yet" : "Available")
                        diagnostic("World model", model.projectKnowledge.transitions.isEmpty ? "Not enough transitions yet" : "Embedding transition statistics available")
                        diagnostic("Hierarchical planner", "Not enabled yet")
                    }
                }

                SurfaceCard {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Capture diagnostics").font(.headline)
                        diagnostic("Target", model.selectedSource?.displayName ?? "None")
                        diagnostic("Capture state", captureState)
                        diagnostic("Observation size", model.previewDimensions.map { "\($0.width) × \($0.height)" } ?? "Waiting")
                        diagnostic("Configured cadence", "\(model.vision.fps) FPS")
                        Text("Static or interrupted targets use the most recent exact observation at the configured cadence while capture reconnects silently.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }

                SurfaceCard {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Legacy data migration").font(.headline)
                        Text("Existing datasets and checkpoints are preserved. Learner creates a Game view over them and copies compatible models; it never deletes the originals.")
                            .foregroundStyle(.secondary)
                        diagnostic("Legacy datasets preserved", model.datasets.count.formatted())
                        Button("Show Learner Data in Finder") { model.reveal(model.store.rootURL) }
                    }
                }

                if !model.projectKnowledge.skills.isEmpty {
                    SurfaceCard {
                        VStack(alignment: .leading, spacing: 9) {
                            Text("Discovered behavior sequences").font(.headline)
                            ForEach(model.projectKnowledge.skills.prefix(12)) { skill in
                                HStack {
                                    Text(skill.id).font(.caption.monospaced()).foregroundStyle(.secondary)
                                    Text(skill.actionSequence.joined(separator: " → ")).lineLimit(1)
                                    Spacer()
                                    Text(skill.confidence.map {
                                        "\(skill.occurrences)× · \($0.formatted(.percent.precision(.fractionLength(0))))"
                                    } ?? "\(skill.occurrences)× · confidence pending")
                                        .font(.caption.monospacedDigit())
                                }
                            }
                        }
                    }
                }
            }
            .padding(24)
            .frame(maxWidth: 900, alignment: .leading)
        }
    }

    private var captureState: String {
        switch model.phase {
        case .idle: model.previewImage == nil ? "No target" : "Live preview"
        case .recording: "Teaching · recording"
        case .paused: "Teaching · paused"
        case .stopping: "Finalizing safely"
        case .agent: model.humanOverride ? "Human correction" : model.learningMode.title
        }
    }

    private func diagnostic(_ name: String, _ value: String) -> some View {
        HStack {
            Text(name).foregroundStyle(.secondary)
            Spacer()
            Text(value).font(.callout.weight(.medium))
        }
    }
}
