import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Settings").font(.title.weight(.semibold))
                    Text("Permissions, privacy, and local storage.").foregroundStyle(.secondary)
                }
                SurfaceCard(content: VStack(alignment: .leading, spacing: 16) {
                    Text("Permissions").font(.headline)
                    PermissionRow(
                        icon: "rectangle.dashed.badge.record",
                        title: "Screen Recording",
                        detail: "Captures only your selected window, display, or region.",
                        granted: model.permissions.screenRecording,
                        request: { _ = PermissionCenter.requestScreenRecording(); model.refreshPermissions() },
                        settings: { PermissionCenter.openSettings(.screenRecording) }
                    )
                    Divider()
                    PermissionRow(
                        icon: "keyboard",
                        title: "Input Monitoring",
                        detail: "Observes event timing while the selected target is active.",
                        granted: model.permissions.inputMonitoring,
                        request: { _ = PermissionCenter.requestInputMonitoring(); model.refreshPermissions() },
                        settings: { PermissionCenter.openSettings(.inputMonitoring) }
                    )
                    Divider()
                    PermissionRow(
                        icon: "hand.raised",
                        title: "Agent Control",
                        detail: "Optional for recording. macOS lists this under Device Control and Data Access; it is required only when you run an agent.",
                        granted: model.permissions.accessibility,
                        required: false,
                        request: { PermissionCenter.requestAccessibility(); model.refreshPermissions() },
                        settings: { PermissionCenter.openSettings(.accessibility) }
                    )
                })

                SurfaceCard(content: VStack(alignment: .leading, spacing: 12) {
                    Text("Local Storage").font(.headline)
                    Text(model.store.rootURL.path)
                        .font(.callout.monospaced()).textSelection(.enabled)
                        .foregroundStyle(.secondary)
                    HStack {
                        Button("Show in Finder") { model.reveal(model.store.rootURL) }
                        Spacer()
                        Text("\(model.sessions.count) sessions")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                })

                SurfaceCard(content: VStack(alignment: .leading, spacing: 10) {
                    Label("Privacy by default", systemImage: "lock.shield.fill").font(.headline).foregroundStyle(.green)
                    Text("Learner does not capture microphone, camera, clipboard, or windows outside the selected target. Data is never uploaded. If a selected window stops producing frames, recording time and input continue while Learner stores efficient held observations and waits for that exact target to return.")
                        .foregroundStyle(.secondary)
                    Text("Password fields cannot be identified without accessibility metadata, so use a mask or pause recording before typing sensitive text inside the selected target.")
                        .font(.caption).foregroundStyle(.orange)
                })
            }
            .padding(24)
            .frame(maxWidth: 820, alignment: .leading)
        }
    }
}

private struct PermissionRow: View {
    let icon: String
    let title: String
    let detail: String
    let granted: Bool
    var required: Bool = true
    let request: () -> Void
    let settings: () -> Void

    var body: some View {
        HStack(spacing: 13) {
            Image(systemName: icon).font(.title3).frame(width: 28).foregroundStyle(granted ? .green : .orange)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.callout.weight(.semibold))
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Label(granted ? "Allowed" : required ? "Required" : "Optional", systemImage: granted ? "checkmark.circle.fill" : required ? "exclamationmark.circle.fill" : "info.circle")
                .font(.caption.weight(.semibold)).foregroundStyle(granted ? .green : required ? .orange : .secondary)
            if !granted {
                Button(required ? "Request" : "Enable", action: request)
                if required { Button("Open Settings", action: settings) }
            }
        }
    }
}
