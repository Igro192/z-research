import SwiftUI
import LearnerCore

struct AgentView: View {
    @EnvironmentObject private var model: AppModel
    @State private var showingSources = false

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            ScrollView {
                VStack(spacing: 18) {
                    steps
                    if model.trainedModelURL == nil {
                        noModel
                    } else {
                        playWorkspace
                    }
                }
                .padding(24)
                .frame(maxWidth: 1450)
                .frame(maxWidth: .infinity)
            }
        }
        .sheet(isPresented: $showingSources) { SourcePickerView() }
        .onAppear {
            model.refreshPermissions()
            model.refreshLibrary()
        }
    }

    private var header: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 9) {
                    Text("Play").font(.title.weight(.semibold))
                    Text("EXPERIMENTAL")
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.purple)
                        .padding(.horizontal, 7).padding(.vertical, 4)
                        .background(Color.purple.opacity(0.12), in: Capsule())
                }
                Text("A goal-directed agent that remembers the demonstration and improves while playing.")
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if let source = model.selectedSource {
                Label(source.applicationName, systemImage: source.kind == .window ? "macwindow" : "display")
                    .font(.callout.weight(.medium))
                    .lineLimit(1)
                Button("Change Target") { showingSources = true }
                    .disabled(model.phase != .idle)
            }
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 17)
    }

    private var steps: some View {
        HStack(spacing: 10) {
            PlayStep(number: 1, title: "Choose game", detail: "Window or fullscreen", complete: model.selectedSource != nil)
            Image(systemName: "chevron.right").foregroundStyle(.tertiary)
            PlayStep(number: 2, title: "Check preview", detail: "See what AI sees", complete: model.previewImage != nil)
            Image(systemName: "chevron.right").foregroundStyle(.tertiary)
            PlayStep(number: 3, title: "Learn & play", detail: "Escape always stops", complete: model.phase == .agent)
        }
    }

    private var noModel: some View {
        SurfaceCard {
            VStack(spacing: 14) {
                Image(systemName: "brain.head.profile").font(.system(size: 38)).foregroundStyle(.secondary)
                Text("No trained agent yet").font(.title3.weight(.semibold))
                Text("Record demonstrations, add them to a dataset, then train a behavior model before using Play.")
                    .foregroundStyle(.secondary).multilineTextAlignment(.center)
                Button("Go to Datasets") { model.navigation = .datasets }
                    .buttonStyle(.borderedProminent)
            }
            .frame(maxWidth: .infinity)
            .padding(30)
        }
    }

    private var playWorkspace: some View {
        VStack(spacing: 18) {
            SurfaceCard {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Label("AI VISION", systemImage: "eye.fill")
                            .font(.caption.weight(.bold)).foregroundStyle(.secondary)
                        Spacer()
                        if let dimensions = model.previewDimensions {
                            Text("\(dimensions.width) × \(dimensions.height)")
                                .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                        }
                    }
                    ZStack {
                        RoundedRectangle(cornerRadius: 12).fill(.black)
                        if let image = model.previewImage {
                            Image(decorative: image, scale: 1)
                                .resizable()
                                .interpolation(.medium)
                                .aspectRatio(contentMode: .fit)
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                                .overlay {
                                    GeometryReader { geometry in
                                        Color.clear
                                            .contentShape(Rectangle())
                                            .gesture(
                                                DragGesture(minimumDistance: 0)
                                                    .onEnded { value in
                                                        if let point = normalizedPreviewPoint(
                                                            value.location,
                                                            container: geometry.size,
                                                            image: image
                                                        ) {
                                                            model.clickAgentPreview(
                                                                normalizedX: point.x,
                                                                normalizedY: point.y
                                                            )
                                                        }
                                                    }
                                            )
                                    }
                                }
                        } else if model.selectedSource == nil {
                            VStack(spacing: 12) {
                                Image(systemName: "macwindow.badge.plus").font(.system(size: 38)).foregroundStyle(.white.opacity(0.7))
                                Text("Choose the game or screen").foregroundStyle(.white.opacity(0.9))
                                Button("Select Target") { showingSources = true }
                                    .buttonStyle(.borderedProminent)
                            }
                        } else {
                            ProgressView("Connecting to window…").foregroundStyle(.white)
                        }
                        if model.phase == .agent {
                            VStack { HStack {
                                Label(model.agentPolicyMode == "reactive-visual" ? "REACTIVE" : ((model.agentProbabilities["exploring"] ?? 0) > 0 ? "EXPLORING" : "LEARNING"), systemImage: "sparkles")
                                    .font(.caption.weight(.bold)).foregroundStyle(.white)
                                    .padding(.horizontal, 9).padding(.vertical, 6)
                                    .background(.purple, in: Capsule())
                                Spacer()
                            }; Spacer() }.padding(12)
                        }
                    }
                    .aspectRatio(16 / 9, contentMode: .fit)
                    .frame(maxWidth: .infinity)
                    Text(model.phase == .agent
                         ? "This is exactly what the agent sees. Click anywhere in the preview to send that click to the game."
                         : "This processed preview is exactly what the agent receives.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .frame(maxWidth: .infinity)

            HStack(alignment: .top, spacing: 14) {
                controlCard
                permissionCard
                safetyCard
            }
        }
    }

    private var controlCard: some View {
        SurfaceCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Label(model.agentMemoryFrames > 0 ? "Goal agent ready" : "Agent ready", systemImage: "checkmark.seal.fill")
                        .font(.headline).foregroundStyle(.green)
                    Spacer()
                }
                Text(model.agentPolicyMode == "reactive-visual" ? "Learns reactions from \(model.agentTrainingFrames.formatted()) visual frames; it does not replay one fixed map" : (model.agentMemoryFrames > 0 ? "Remembers \(model.agentMemoryFrames.formatted()) trajectory states across the completed run" : "Learned from \(model.agentTrainingFrames.formatted()) visual frames"))
                    .font(.caption).foregroundStyle(.secondary)
                if !model.agentGoalDescription.isEmpty {
                    Label("Goal: \(model.agentGoalDescription)", systemImage: "flag.checkered")
                        .font(.caption.weight(.medium)).foregroundStyle(.purple)
                }

                if model.phase == .agent {
                    Divider()
                    if model.agentPolicyMode != "reactive-visual" {
                        ConfidenceBar(label: "Goal progress", value: model.agentProbabilities["goalProgress"] ?? 0)
                    }
                    HStack {
                        Label(model.agentPolicyMode == "reactive-visual" ? "Reading the current layout" : ((model.agentProbabilities["exploring"] ?? 0) > 0 ? "Trying a correction" : "Learning from progress"), systemImage: "brain.head.profile")
                            .font(.caption).foregroundStyle(.purple)
                        Spacer()
                        Text("\(Int(model.agentProbabilities["learningUpdates"] ?? 0)) updates")
                            .font(.caption2.monospacedDigit()).foregroundStyle(.secondary)
                    }
                    if (model.agentProbabilities["autoRecovery"] ?? 0) > 0 {
                        Label("Recovered from the failure screen automatically", systemImage: "arrow.counterclockwise.circle.fill")
                            .font(.caption.weight(.semibold)).foregroundStyle(.green)
                    }
                    FlowTokens(
                        values: model.agentControls.filter { (model.agentProbabilities[$0] ?? 0) > 0 },
                        empty: "No control active",
                        tint: .purple
                    )
                    Button { model.stopAgent() } label: {
                        Label("Stop Agent", systemImage: "stop.fill").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent).tint(.red).controlSize(.large)
                } else {
                    Button {
                        if model.selectedSource == nil { showingSources = true }
                        else { model.startAgent() }
                    } label: {
                        Label(
                            model.selectedSource == nil ? "Choose Game or Screen" : model.isPreparingAgent ? "Starting Agent…" : "Run Agent",
                            systemImage: model.selectedSource == nil ? "plus.viewfinder" : model.isPreparingAgent ? "hourglass" : "play.fill"
                        )
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent).tint(.purple).controlSize(.large)
                    .disabled(model.phase != .idle || model.isPreparingAgent)
                    Text(model.selectedSource == nil ? "Start here. Learner will show a preview before anything can run." : "Click Run Agent. Learner follows remembered visual progress and learns corrective actions while it plays—even if you switch apps.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
        }
    }

    private var permissionCard: some View {
        SurfaceCard {
            VStack(alignment: .leading, spacing: 10) {
                Text("PERMISSIONS").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                PermissionCheck(name: "Screen capture", allowed: model.permissions.screenRecording)
                PermissionCheck(name: "Emergency stop", allowed: model.permissions.inputMonitoring)
                PermissionCheck(name: "Agent control", allowed: model.permissions.accessibility)
                if !model.permissions.accessibility {
                    Button("Open Agent Permission") { PermissionCenter.openSettings(.accessibility) }
                        .controlSize(.small)
                }
            }
        }
    }

    private var safetyCard: some View {
        SurfaceCard {
            VStack(alignment: .leading, spacing: 7) {
                Label("Escape always stops", systemImage: "escape")
                    .font(.callout.weight(.semibold))
                Text("Controls are sent only to the selected game process, so the agent keeps playing safely when you switch apps. Nothing is uploaded.")
                    .font(.caption).foregroundStyle(.secondary)
                if model.agentMemoryFrames > 0 {
                    Label("Learning is saved locally", systemImage: "internaldrive.fill")
                        .font(.caption.weight(.medium)).foregroundStyle(.green)
                }
            }
        }
    }

    private func normalizedPreviewPoint(_ location: CGPoint, container: CGSize, image: CGImage) -> CGPoint? {
        let imageSize = CGSize(width: image.width, height: image.height)
        guard imageSize.width > 0, imageSize.height > 0 else { return nil }
        let scale = min(container.width / imageSize.width, container.height / imageSize.height)
        let shown = CGSize(width: imageSize.width * scale, height: imageSize.height * scale)
        let origin = CGPoint(
            x: (container.width - shown.width) / 2,
            y: (container.height - shown.height) / 2
        )
        guard location.x >= origin.x, location.x <= origin.x + shown.width,
              location.y >= origin.y, location.y <= origin.y + shown.height else { return nil }
        return CGPoint(
            x: (location.x - origin.x) / shown.width,
            y: (location.y - origin.y) / shown.height
        )
    }
}

private struct PlayStep: View {
    let number: Int
    let title: String
    let detail: String
    let complete: Bool

    var body: some View {
        HStack(spacing: 10) {
            ZStack {
                Circle().fill(complete ? Color.green : Color.accentColor.opacity(0.14)).frame(width: 30, height: 30)
                if complete { Image(systemName: "checkmark").font(.caption.bold()).foregroundStyle(.white) }
                else { Text("\(number)").font(.caption.bold()).foregroundStyle(Color.accentColor) }
            }
            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.callout.weight(.semibold))
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

private struct PermissionCheck: View {
    let name: String
    let allowed: Bool
    var body: some View {
        HStack {
            Image(systemName: allowed ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                .foregroundStyle(allowed ? .green : .orange)
            Text(name).font(.caption)
            Spacer()
            Text(allowed ? "Ready" : "Needed").font(.caption.weight(.medium)).foregroundStyle(allowed ? .green : .orange)
        }
    }
}

private struct ConfidenceBar: View {
    let label: String
    let value: Double
    var body: some View {
        VStack(spacing: 4) {
            HStack {
                Text(label).font(.caption)
                Spacer()
                Text(value, format: .percent.precision(.fractionLength(0))).font(.caption.monospacedDigit())
            }
            ProgressView(value: value).tint(.purple)
        }
    }
}

private struct ActionState: View {
    let name: String
    let active: Bool
    var body: some View {
        Text(name)
            .font(.caption2.weight(.semibold))
            .foregroundStyle(active ? .white : .secondary)
            .padding(.horizontal, 8).padding(.vertical, 5)
            .background(active ? Color.purple : Color.secondary.opacity(0.12), in: Capsule())
    }
}
