import SwiftUI

struct DatasetsView: View {
    @EnvironmentObject private var model: AppModel
    @State private var deletingURL: URL?

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Train Games").font(.title.weight(.semibold))
                    Text("Each dataset becomes its own playable agent. Training and learning stay entirely on this Mac.").foregroundStyle(.secondary)
                }
                Spacer()
            }
            .padding(24)
            Divider()
            if model.trainingDatasetID != nil {
                HStack(spacing: 12) {
                    ProgressView().controlSize(.small)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Training locally").font(.callout.weight(.semibold))
                        Text(model.trainingMessage).font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Text("No upload").font(.caption.weight(.medium)).foregroundStyle(.green)
                }
                .padding(.horizontal, 24).padding(.vertical, 12)
                .background(Color.green.opacity(0.06))
                Divider()
            }
            if model.trainedModelURL != nil {
                HStack(spacing: 14) {
                    Image(systemName: "gamecontroller.fill")
                        .font(.title2).foregroundStyle(.purple)
                        .frame(width: 42, height: 42)
                        .background(Color.purple.opacity(0.12), in: RoundedRectangle(cornerRadius: 11))
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Trained agent ready").font(.headline)
                        Text(model.agentGoalDescription.isEmpty
                             ? "Learned from \(model.agentTrainingFrames.formatted()) frames. Choose the matching game window or fullscreen capture and run it now."
                             : "Inferred goal: \(model.agentGoalDescription)")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button { model.navigation = .agent } label: {
                        Label("Run Agent Now", systemImage: "play.fill")
                    }
                    .buttonStyle(.borderedProminent).tint(.purple)
                }
                .padding(.horizontal, 24).padding(.vertical, 14)
                .background(Color.purple.opacity(0.05))
                Divider()
            }
            if model.datasets.isEmpty {
                VStack { Spacer(); EmptyState(icon: "square.stack.3d.up", title: "No datasets yet", message: "Select recordings in Sessions and combine them. Source sessions remain independent."); Spacer() }
            } else {
                ScrollView {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 300), spacing: 16)], spacing: 16) {
                        ForEach(model.datasets, id: \.0.id) { manifest, url in
                            let sessionIDs = Set(manifest.sessionIDs.map(\.uuidString))
                            let isTrained = !sessionIDs.isEmpty && sessionIDs == model.trainedSessionIDs
                            SurfaceCard(content: VStack(alignment: .leading, spacing: 14) {
                                HStack {
                                    Image(systemName: "square.stack.3d.up.fill")
                                        .font(.title2).foregroundStyle(Color.accentColor)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(manifest.name).font(.headline)
                                        Text(manifest.createdAt.formatted(date: .abbreviated, time: .shortened))
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    if isTrained {
                                        Label("TRAINED", systemImage: "checkmark.seal.fill")
                                            .font(.caption2.weight(.bold)).foregroundStyle(.green)
                                    }
                                }
                                Divider()
                                HStack {
                                    StatCell(label: "Sessions", value: manifest.sessionIDs.count.formatted())
                                    StatCell(label: "Samples", value: totalSamples(manifest.sessionIDs).formatted())
                                    StatCell(label: "Format", value: "v\(manifest.schemaVersion)")
                                }
                                HStack {
                                    if isTrained {
                                        Button {
                                            model.navigation = .agent
                                        } label: {
                                            Label("Play \(manifest.name)", systemImage: "play.fill")
                                        }
                                        .buttonStyle(.borderedProminent).tint(.purple)
                                    } else {
                                        Button {
                                            model.trainDataset(manifest, at: url)
                                        } label: {
                                            if model.trainingDatasetID == manifest.id {
                                                Label("Training…", systemImage: "brain.head.profile")
                                            } else {
                                                Label("Train & Create Agent", systemImage: "brain.head.profile")
                                            }
                                        }
                                        .buttonStyle(.borderedProminent).tint(.purple)
                                        .disabled(model.trainingDatasetID != nil)
                                    }
                                    Button("Show in Finder") { model.reveal(url) }
                                    Spacer()
                                    Button(role: .destructive) { deletingURL = url } label: { Image(systemName: "trash") }
                                }
                            })
                        }
                    }
                    .padding(24)
                }
            }
        }
        .alert("Delete Dataset?", isPresented: Binding(get: { deletingURL != nil }, set: { if !$0 { deletingURL = nil } })) {
            Button("Cancel", role: .cancel) { deletingURL = nil }
            Button("Delete", role: .destructive) { if let deletingURL { model.deleteDataset(at: deletingURL) }; deletingURL = nil }
        } message: {
            Text("The manifest will be deleted. Its source sessions are not affected.")
        }
    }

    private func totalSamples(_ ids: [UUID]) -> Int {
        model.sessions.filter { ids.contains($0.id) }.reduce(0) { $0 + max(0, $1.metadata.frameCount - 1) }
    }
}
