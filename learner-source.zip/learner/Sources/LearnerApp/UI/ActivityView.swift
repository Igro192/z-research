import SwiftUI
import LearnerCore

struct ActivityView: View {
    @EnvironmentObject private var model: AppModel
    @State private var inspected: SessionSummary?

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Activity").font(.title.weight(.semibold))
                    Text("Automatically saved teaching, practice, autopilot, and correction experience.")
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Button { model.refreshLibrary() } label: { Image(systemName: "arrow.clockwise") }
            }
            .padding(24)
            Divider()

            if model.currentGame == nil {
                EmptyState(icon: "gamecontroller", title: "No Game selected", message: "Create or choose a Game first.")
            } else if model.currentGameSessions.isEmpty {
                EmptyState(icon: "clock.arrow.circlepath", title: "No experience yet", message: "A session appears here automatically after TEACH, PRACTICE, or AUTOPILOT stops.")
            } else {
                List(model.currentGameSessions) { session in
                    HStack(spacing: 14) {
                        Image(systemName: roleIcon(session.metadata.learningRole))
                            .font(.title2)
                            .foregroundStyle(roleColor(session.metadata.learningRole))
                            .frame(width: 42, height: 42)
                            .background(roleColor(session.metadata.learningRole).opacity(0.12), in: RoundedRectangle(cornerRadius: 10))
                        VStack(alignment: .leading, spacing: 3) {
                            Text(roleName(session.metadata.learningRole)).font(.headline)
                            Text(session.metadata.createdAt.formatted(date: .abbreviated, time: .shortened))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        StatCell(label: "Duration", value: LearnerFormatters.duration(session.metadata.durationNs))
                            .frame(width: 90)
                        StatCell(label: "Frames", value: session.metadata.frameCount.formatted())
                            .frame(width: 82)
                        StatCell(label: "Human actions", value: session.metadata.actionCount.formatted())
                            .frame(width: 95)
                        Button("Inspect") { inspected = session }.buttonStyle(.borderless)
                    }
                    .padding(.vertical, 5)
                }
            }
        }
        .sheet(item: $inspected) { TimelineView(session: $0) }
    }

    private func roleName(_ role: ExperienceRole?) -> String {
        switch role ?? .legacy {
        case .teach: "Teaching demonstration"
        case .practice: "Practice and corrections"
        case .autopilot: "Autopilot experience"
        case .correction: "Human correction"
        case .legacy: "Legacy recording"
        }
    }

    private func roleIcon(_ role: ExperienceRole?) -> String {
        switch role ?? .legacy {
        case .teach: "person.fill"
        case .practice: "person.2.fill"
        case .autopilot: "sparkles"
        case .correction: "hand.raised.fill"
        case .legacy: "video.fill"
        }
    }

    private func roleColor(_ role: ExperienceRole?) -> Color {
        switch role ?? .legacy {
        case .teach: .blue
        case .practice: .purple
        case .autopilot: .indigo
        case .correction: .orange
        case .legacy: .secondary
        }
    }
}

