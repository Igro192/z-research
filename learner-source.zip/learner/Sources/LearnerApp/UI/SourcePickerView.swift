import AppKit
import SwiftUI
import LearnerCore

struct SourcePickerView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    let windowOnly: Bool
    @State private var kind: CaptureSourceKind = .window
    @State private var search = ""
    @State private var connectingID: String?

    init(windowOnly: Bool = false) {
        self.windowOnly = windowOnly
    }

    private var filtered: [CaptureSourceDescriptor] {
        model.availableSources.filter {
            $0.kind == kind && (search.isEmpty || $0.displayName.localizedCaseInsensitiveContains(search))
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            VStack(spacing: 14) {
                if !windowOnly { sourceTypePicker }
                guidance
                if kind == .window { searchField }
            }
            .padding(.horizontal, 22)
            .padding(.vertical, 16)

            if model.isLoadingSources {
                VStack { Spacer(); ProgressView("Finding targets…"); Spacer() }
            } else if filtered.isEmpty {
                EmptyState(
                    icon: kind == .window ? "macwindow" : kind == .display ? "display" : "viewfinder",
                    title: "No matching targets",
                    message: kind == .window ? "Open the app you want to capture, then choose Refresh." : "Make sure Screen Recording is allowed, then choose Refresh."
                )
                .frame(maxHeight: .infinity)
            } else {
                ScrollView {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 300), spacing: 14)], spacing: 14) {
                        ForEach(filtered) { source in
                            Button { choose(source) } label: {
                                TargetCard(
                                    source: source,
                                    selected: model.selectedSource?.id == source.id,
                                    connecting: connectingID == source.id,
                                    recommended: kind == .window && search.isEmpty && source.id == filtered.first?.id
                                )
                            }
                            .buttonStyle(.plain)
                            .disabled(connectingID != nil)
                        }
                    }
                    .padding(.horizontal, 22)
                    .padding(.bottom, 20)
                }
            }

            footer
        }
        .frame(width: 840, height: 700)
        .task { await model.loadSources() }
        .onChange(of: kind) { _, _ in search = "" }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("Choose your game visually").font(.title2.weight(.semibold))
                Text(windowOnly ? "Choose the game window the agent may control." : "Click the picture that matches your game. You will verify it live before recording.")
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Button("Cancel") { dismiss() }.keyboardShortcut(.cancelAction)
        }
        .padding(22)
    }

    private var sourceTypePicker: some View {
        Picker("Capture type", selection: $kind) {
            Label("Game / Window", systemImage: "macwindow").tag(CaptureSourceKind.window)
            Label("Fullscreen Game", systemImage: "display").tag(CaptureSourceKind.display)
            Label("Screen Area", systemImage: "viewfinder").tag(CaptureSourceKind.region)
        }
        .pickerStyle(.segmented)
        .controlSize(.large)
    }

    private var guidance: some View {
        HStack(spacing: 11) {
            Image(systemName: guidanceIcon)
                .font(.title3).foregroundStyle(Color.accentColor)
                .frame(width: 30)
            VStack(alignment: .leading, spacing: 2) {
                Text(guidanceTitle).font(.callout.weight(.semibold))
                Text(guidanceText).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(12)
        .background(Color.accentColor.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
    }

    private var searchField: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
            TextField("Search apps and window titles", text: $search)
                .textFieldStyle(.plain)
            if !search.isEmpty {
                Button { search = "" } label: { Image(systemName: "xmark.circle.fill") }
                    .buttonStyle(.plain).foregroundStyle(.secondary)
            }
        }
        .padding(.horizontal, 11).padding(.vertical, 8)
        .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 9))
        .overlay { RoundedRectangle(cornerRadius: 9).stroke(Color.primary.opacity(0.1)) }
    }

    private var footer: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("\(filtered.count) target\(filtered.count == 1 ? "" : "s") available")
                    .font(.caption).foregroundStyle(.secondary)
                if kind == .window {
                    Text("Game missing? Choose Fullscreen Game above.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
            Spacer()
            Button { Task { await model.loadSources() } } label: {
                Label("Refresh", systemImage: "arrow.clockwise")
            }
        }
        .padding(16)
        .background(.bar)
    }

    private var guidanceIcon: String {
        switch kind { case .window: "macwindow"; case .display: "display"; case .region: "crop" }
    }

    private var guidanceTitle: String {
        switch kind { case .window: "Private and recommended"; case .display: "Compatibility mode for fullscreen games"; case .region: "Capture only a rectangular area" }
    }

    private var guidanceText: String {
        switch kind {
        case .window: "Only the chosen game or app is captured. The frontmost recent window appears first."
        case .display: "Use this when a game uses exclusive fullscreen, Metal, Wine, or does not appear as a normal window."
        case .region: "Choose a display, then drag over the live preview. Only that rectangle is stored."
        }
    }

    private func choose(_ source: CaptureSourceDescriptor) {
        connectingID = source.id
        Task {
            await model.selectSource(source)
            connectingID = nil
            if model.selectedSource?.id == source.id { dismiss() }
        }
    }
}

private struct TargetCard: View {
    let source: CaptureSourceDescriptor
    let selected: Bool
    let connecting: Bool
    let recommended: Bool
    @State private var thumbnail: CGImage?
    @State private var thumbnailFailed = false

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.black.opacity(0.88))
                if let thumbnail {
                    Image(decorative: thumbnail, scale: 1)
                        .resizable()
                        .scaledToFit()
                } else if thumbnailFailed {
                    TargetIcon(source: source)
                } else {
                    ProgressView().controlSize(.small).tint(.white)
                }
                if recommended {
                    VStack { HStack {
                        Label("Likely target", systemImage: "sparkles")
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 8).padding(.vertical, 5)
                            .background(Color.accentColor, in: Capsule())
                        Spacer()
                    }; Spacer() }
                    .padding(8)
                }
            }
            .frame(maxWidth: .infinity)
            .aspectRatio(16 / 9, contentMode: .fit)
            .clipped()

            HStack {
                TargetIcon(source: source)
                VStack(alignment: .leading, spacing: 3) {
                    Text(primaryTitle).font(.callout.weight(.semibold)).foregroundStyle(.primary).lineLimit(1)
                    Text(secondaryTitle).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 8)
                if connecting { ProgressView().controlSize(.small) }
                else if selected { Image(systemName: "checkmark.circle.fill").foregroundStyle(.green) }
                else { Image(systemName: "chevron.right").foregroundStyle(.tertiary) }
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, minHeight: 225, alignment: .leading)
        .background(selected ? Color.green.opacity(0.08) : Color(nsColor: .controlBackgroundColor).opacity(0.7), in: RoundedRectangle(cornerRadius: 14))
        .overlay {
            RoundedRectangle(cornerRadius: 14)
                .stroke(selected ? Color.green.opacity(0.7) : Color.primary.opacity(0.1), lineWidth: selected ? 1.5 : 1)
        }
        .contentShape(RoundedRectangle(cornerRadius: 14))
        .task(id: source.id) {
            do {
                thumbnail = try await CaptureSourceProvider.thumbnail(for: source)
            } catch {
                thumbnailFailed = true
            }
        }
    }

    private var primaryTitle: String {
        switch source.kind {
        case .window: source.applicationName
        case .display: source.applicationName
        case .region: source.applicationName.replacingOccurrences(of: "Custom Region — ", with: "")
        }
    }

    private var secondaryTitle: String {
        switch source.kind {
        case .window: source.windowTitle == "Untitled Window" ? "Main window" : source.windowTitle
        case .display: "Full display · \(source.windowTitle)"
        case .region: "Choose this display, then drag your area"
        }
    }
}

private struct TargetIcon: View {
    let source: CaptureSourceDescriptor

    var body: some View {
        Group {
            if source.kind == .window, let icon = appIcon {
                Image(nsImage: icon).resizable().scaledToFit().padding(5)
            } else {
                Image(systemName: source.kind == .display ? "display" : source.kind == .region ? "crop" : "macwindow")
                    .font(.title2).foregroundStyle(Color.accentColor)
            }
        }
        .frame(width: 42, height: 42)
        .background(Color.accentColor.opacity(0.1), in: RoundedRectangle(cornerRadius: 11))
    }

    private var appIcon: NSImage? {
        guard let identifier = source.bundleIdentifier,
              let url = NSWorkspace.shared.urlForApplication(withBundleIdentifier: identifier) else { return nil }
        return NSWorkspace.shared.icon(forFile: url.path)
    }
}
