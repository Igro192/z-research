import SwiftUI
import LearnerCore

struct GameHomeView: View {
    @EnvironmentObject private var model: AppModel
    @State private var showingSources = false
    @State private var showingNewGame = false
    @State private var showingVisionEditor = false

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            if model.currentGame == nil {
                onboarding
            } else {
                ScrollView {
                    VStack(spacing: 18) {
                        projectSummary
                        targetAndPreview
                        modeCards
                        recentLearning
                    }
                    .padding(22)
                    .frame(maxWidth: 1500)
                    .frame(maxWidth: .infinity)
                }
            }
        }
        .sheet(isPresented: $showingSources) { SourcePickerView() }
        .sheet(isPresented: $showingNewGame) { NewGameSheet() }
        .sheet(isPresented: $showingVisionEditor) { VisionEditorSheet() }
        .onChange(of: showingSources) { _, isShowing in
            guard !isShowing,
                  model.selectedSource?.kind == .region,
                  model.vision.crop == NormalizedRect() else { return }
            Task { @MainActor in
                try? await Task.sleep(for: .milliseconds(180))
                showingVisionEditor = true
            }
        }
        .onAppear { model.refreshLibrary() }
    }

    private var header: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                Text(model.currentGame?.name ?? "Learner").font(.title.weight(.semibold))
                Text("Teach by playing. Correct mistakes. Hand over control when it is ready.")
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if !model.games.isEmpty {
                Picker("Game", selection: Binding(
                    get: { model.currentGameID ?? model.games[0].id },
                    set: { model.selectGame($0) }
                )) {
                    ForEach(model.games) { game in Text(game.name).tag(game.id) }
                }
                .frame(maxWidth: 260)
                .disabled(model.phase != .idle)
            }
            Button { showingNewGame = true } label: {
                Label("New Game", systemImage: "plus")
            }
            .disabled(model.phase != .idle)
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 16)
    }

    private var onboarding: some View {
        VStack(spacing: 18) {
            Spacer()
            EmptyState(
                icon: "gamecontroller.fill",
                title: "Create your first Game",
                message: "A Game keeps its demonstrations, corrections, visual situations, behaviors, and learned controller together."
            )
            Button { showingNewGame = true } label: {
                Label("Create Game", systemImage: "plus.circle.fill")
                    .frame(minWidth: 160)
            }
            .buttonStyle(.borderedProminent).controlSize(.large)
            Spacer()
        }
    }

    private var projectSummary: some View {
        SurfaceCard {
            HStack(spacing: 24) {
                Label(understandingLabel, systemImage: "brain.head.profile")
                    .font(.headline)
                    .foregroundStyle(understandingColor)
                Divider().frame(height: 42)
                StatCell(label: "Experience", value: LearnerFormatters.duration(model.currentGameExperienceNs))
                StatCell(label: "Sessions", value: model.currentGameSessions.count.formatted())
                StatCell(label: "Known situations", value: model.projectKnowledge.states.count.formatted())
                StatCell(label: "Behaviors", value: model.projectKnowledge.skills.count.formatted())
                StatCell(label: "Corrections", value: model.projectKnowledge.correctionCount.formatted())
                if model.phase == .agent {
                    StatCell(label: "AI confidence", value: model.agentConfidence.formatted(.percent.precision(.fractionLength(0))))
                }
            }
        }
    }

    private var targetAndPreview: some View {
        SurfaceCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Label("WHAT LEARNER SEES", systemImage: "eye.fill")
                        .font(.caption.weight(.bold)).foregroundStyle(.secondary)
                    Spacer()
                    if let source = model.selectedSource {
                        Text(source.displayName).font(.caption).lineLimit(1)
                        Button(source.kind == .region && model.vision.crop == NormalizedRect() ? "Choose Area" : "Edit Vision") {
                            showingVisionEditor = true
                        }
                        .disabled(model.phase != .idle || model.previewImage == nil)
                        Button("Change Target") { showingSources = true }
                            .disabled(model.phase != .idle)
                    } else {
                        Button { showingSources = true } label: {
                            Label("Choose Window or Screen", systemImage: "plus.viewfinder")
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }

                ZStack {
                    RoundedRectangle(cornerRadius: 14).fill(.black)
                    if let image = model.previewImage {
                        Image(decorative: image, scale: 1)
                            .resizable()
                            .interpolation(.medium)
                            .aspectRatio(contentMode: .fit)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .overlay {
                                InteractivePreviewSurface(
                                    imageSize: CGSize(width: image.width, height: image.height),
                                    enabled: model.phase == .recording || model.phase == .agent || model.phase == .paused,
                                    onInput: model.handlePreviewInput
                                )
                            }
                    } else {
                        VStack(spacing: 12) {
                            Image(systemName: "rectangle.dashed.badge.record")
                                .font(.system(size: 40)).foregroundStyle(.white.opacity(0.75))
                            Text("Choose the game, app, display, or region")
                                .foregroundStyle(.white.opacity(0.9))
                            Button("Select Target") { showingSources = true }
                                .buttonStyle(.borderedProminent)
                        }
                    }
                    modeBadge
                }
                .aspectRatio(16 / 9, contentMode: .fit)
                .frame(maxWidth: .infinity, minHeight: 430)

                HStack {
                    Text(model.phase == .recording || model.phase == .agent
                         ? "Click the preview, use the keyboard, move the mouse, or scroll to control the selected target directly."
                         : "The preview shows the exact processed pixels used for learning.")
                        .font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    if model.phase == .idle {
                        Button(action: recordGameplay) {
                            Label(
                                targetReady ? "RECORD MY GAMEPLAY" : "SELECT TARGET TO RECORD",
                                systemImage: "record.circle.fill"
                            )
                            .font(.headline)
                            .frame(minWidth: 225)
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)
                        .tint(.red)
                    }
                    if let dimensions = model.previewDimensions {
                        Text("\(dimensions.width) × \(dimensions.height) · \(model.vision.fps) FPS")
                            .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                    }
                }
                if model.phase != .idle { liveControls }
            }
        }
    }

    @ViewBuilder private var modeBadge: some View {
        if model.phase != .idle {
            VStack {
                HStack {
                    Label(
                        model.humanOverride ? "HUMAN OVERRIDE" : model.agentPaused ? "PAUSED" : model.learningMode == .teach ? "RECORDING • LEARNING" : model.learningMode.title.uppercased(),
                        systemImage: model.humanOverride ? "hand.raised.fill" : model.learningMode == .teach ? "record.circle.fill" : "sparkles"
                    )
                    .font(.caption.weight(.bold)).foregroundStyle(.white)
                    .padding(.horizontal, 10).padding(.vertical, 7)
                    .background(model.humanOverride ? Color.orange : model.learningMode == .teach ? Color.red : Color.purple, in: Capsule())
                    Spacer()
                }
                Spacer()
            }
            .padding(12)
            .allowsHitTesting(false)
        }
    }

    private var liveControls: some View {
        HStack(spacing: 10) {
            if model.learningMode == .teach {
                Button(model.phase == .paused ? "Resume" : "Pause") {
                    if model.phase == .paused { model.resumeRecording() } else { model.pauseRecording() }
                }
                Button { model.markImportant() } label: { Label("Mark Important", systemImage: "flag.fill") }
                Button { Task { await model.stopRecording() } } label: {
                    Label(model.phase == .stopping ? "Saving…" : "STOP & SAVE", systemImage: "stop.fill")
                }
                .buttonStyle(.borderedProminent).tint(.red)
            } else {
                if model.humanOverride {
                    Button { model.resumeAI() } label: { Label("Resume AI", systemImage: "play.fill") }
                        .buttonStyle(.borderedProminent).tint(.purple)
                } else {
                    Button { model.takeControl() } label: { Label("Take Control", systemImage: "hand.raised.fill") }
                        .buttonStyle(.borderedProminent).tint(.orange)
                }
                Button(model.agentPaused ? "Resume" : "Pause") { model.toggleAgentPause() }
                Button { model.stopAgent() } label: { Label("Stop", systemImage: "stop.fill") }
                    .buttonStyle(.borderedProminent).tint(.red)
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text("AI confidence \(model.agentConfidence.formatted(.percent.precision(.fractionLength(0))))")
                        .font(.callout.weight(.semibold))
                    FlowTokens(values: model.currentAgentControls, empty: "No AI control active", tint: .purple)
                }
            }
            Spacer()
            Text("\(LearnerFormatters.duration(model.stats.elapsedNs)) · \(model.stats.frameCount.formatted()) frames")
                .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
        }
    }

    private var modeCards: some View {
        HStack(alignment: .top, spacing: 14) {
            modeCard(
                title: "TEACH / RECORD",
                icon: "record.circle.fill",
                color: .red,
                description: "Record yourself playing. Learner watches, saves automatically, and begins learning when you stop.",
                status: targetReady ? "Ready" : model.selectedSource?.kind == .region ? "Choose the area" : "Choose a target",
                button: targetReady ? "Record My Gameplay" : model.selectedSource?.kind == .region ? "Choose Area" : "Choose Target"
            ) {
                if model.selectedSource?.kind == .region && model.vision.crop == NormalizedRect() { showingVisionEditor = true }
                else if model.selectedSource == nil { showingSources = true }
                else { model.startTeach() }
            }
            modeCard(
                title: "PRACTICE",
                icon: "person.2.fill",
                color: .purple,
                description: "AI tries. Any key, click, scroll, or meaningful mouse move gives you instant control and becomes a correction.",
                status: !targetReady ? (model.selectedSource?.kind == .region ? "Choose the area" : "Choose a target") : practiceReady ? "Ready" : practiceReason,
                button: !targetReady ? (model.selectedSource?.kind == .region ? "Choose Area" : "Choose Target") : practiceReady ? "Start Practice" : "Teach First"
            ) {
                if !targetReady {
                    if model.selectedSource?.kind == .region { showingVisionEditor = true } else { showingSources = true }
                } else if !practiceReady {
                    if model.selectedSource == nil { showingSources = true } else { model.startTeach() }
                } else { model.startPractice() }
            }
            modeCard(
                title: "AUTOPILOT",
                icon: "sparkles",
                color: .indigo,
                description: "AI controls independently and keeps collecting experience. Human takeover remains available.",
                status: !targetReady ? (model.selectedSource?.kind == .region ? "Choose the area" : "Choose a target") : practiceReady ? "Available" : practiceReason,
                button: !targetReady ? (model.selectedSource?.kind == .region ? "Choose Area" : "Choose Target") : practiceReady ? "Start Autopilot" : "Teach First"
            ) {
                if !targetReady {
                    if model.selectedSource?.kind == .region { showingVisionEditor = true } else { showingSources = true }
                } else if !practiceReady {
                    if model.selectedSource == nil { showingSources = true } else { model.startTeach() }
                } else { model.startAutopilot() }
            }
        }
        .disabled(model.phase != .idle)
    }

    private func modeCard(
        title: String,
        icon: String,
        color: Color,
        description: String,
        status: String,
        button: String,
        action: @escaping () -> Void
    ) -> some View {
        SurfaceCard {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Label(title, systemImage: icon).font(.headline).foregroundStyle(color)
                    Spacer()
                    Text(status).font(.caption.weight(.semibold))
                        .foregroundStyle(status == "Ready" || status == "Available" ? .green : .secondary)
                }
                Text(description).font(.callout).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                Button(button, action: action)
                    .buttonStyle(.borderedProminent).tint(color).controlSize(.large)
                    .frame(maxWidth: .infinity)
            }
            .frame(maxWidth: .infinity, minHeight: 150, alignment: .topLeading)
        }
    }

    private var recentLearning: some View {
        SurfaceCard {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Text("RECENT LEARNING").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                    Spacer()
                    if model.processingGameID == model.currentGameID {
                        ProgressView().controlSize(.small)
                        Text(model.processingMessage).font(.caption).foregroundStyle(.secondary)
                    }
                }
                if model.projectKnowledge.recentEvents.isEmpty {
                    Text(model.processingGameID == model.currentGameID
                         ? "Analyzing the latest experience…"
                         : "No discovered events yet. Start TEACH and play normally.")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(model.projectKnowledge.recentEvents.suffix(6).reversed()) { event in
                        Label(event.detail, systemImage: eventIcon(event.kind))
                            .font(.callout)
                    }
                }
            }
        }
    }

    private var practiceReady: Bool { model.currentGameModelURL != nil }

    private func recordGameplay() {
        if model.selectedSource?.kind == .region && model.vision.crop == NormalizedRect() {
            showingVisionEditor = true
        } else if model.selectedSource == nil {
            showingSources = true
        } else {
            model.startTeach()
        }
    }

    private var targetReady: Bool {
        guard let source = model.selectedSource else { return false }
        return source.kind != .region || model.vision.crop != NormalizedRect()
    }
    private var practiceReason: String {
        if model.processingGameID == model.currentGameID { return "Learning from demonstration" }
        let seconds = model.currentGameExperienceNs / 1_000_000_000
        return seconds == 0 ? "Needs a demonstration" : "Needs useful control examples"
    }

    private var understandingLabel: String {
        let seconds = model.currentGameExperienceNs / 1_000_000_000
        if seconds < 30 { return "Very little experience" }
        if seconds < 300 || model.projectKnowledge.states.count < 8 { return "Learning basics" }
        if seconds < 1_800 || model.projectKnowledge.skills.count < 5 { return "Familiar" }
        return "Strong experience"
    }

    private var understandingColor: Color {
        switch understandingLabel {
        case "Strong experience": .green
        case "Familiar": .blue
        case "Learning basics": .orange
        default: .secondary
        }
    }

    private func eventIcon(_ kind: LearningEventKind) -> String {
        switch kind {
        case .newVisualState: "square.grid.3x3.fill"
        case .majorVisualChange: "bolt.fill"
        case .inactivity: "pause.circle"
        case .probableReset: "arrow.counterclockwise"
        case .humanCorrection: "hand.raised.fill"
        case .actionSequence: "point.3.connected.trianglepath.dotted"
        }
    }
}

private struct NewGameSheet: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("New Game").font(.title2.weight(.semibold))
            Text("Use any name: Minecraft, Browser Game, Test Game, or the task you want Learner to master.")
                .foregroundStyle(.secondary)
            TextField("Game name", text: $name)
                .textFieldStyle(.roundedBorder)
                .onSubmit(create)
            HStack {
                Spacer()
                Button("Cancel") { dismiss() }
                Button("Create", action: create)
                    .buttonStyle(.borderedProminent)
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
        .padding(24)
        .frame(width: 480)
    }

    private func create() {
        guard !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        model.createGame(named: name, preferredTarget: model.selectedSource)
        dismiss()
    }
}
