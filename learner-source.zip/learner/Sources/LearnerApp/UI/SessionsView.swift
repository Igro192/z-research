import AVKit
import SwiftUI
import LearnerCore

struct SessionsView: View {
    @EnvironmentObject private var model: AppModel
    @State private var selected = Set<UUID>()
    @State private var inspected: SessionSummary?
    @State private var renaming: SessionSummary?
    @State private var renameText = ""
    @State private var deleting: SessionSummary?
    @State private var showingDatasetName = false
    @State private var datasetName = "Game 1"

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Sessions").font(.title.weight(.semibold))
                    Text("Independent recordings you can inspect, export, or combine.").foregroundStyle(.secondary)
                }
                Spacer()
                if !selected.isEmpty {
                    Button { showingDatasetName = true } label: {
                        Label("Train \(selected.count) Recording\(selected.count == 1 ? "" : "s")", systemImage: "brain.head.profile")
                    }
                    .buttonStyle(.borderedProminent)
                }
                Button { model.refreshLibrary() } label: { Image(systemName: "arrow.clockwise") }
            }
            .padding(24)
            Divider()

            if model.sessions.isEmpty {
                VStack { Spacer(); EmptyState(icon: "rectangle.stack", title: "No sessions yet", message: "Your completed recordings appear here, ready for inspection and dataset use."); Spacer() }
            } else {
                List(model.sessions, selection: $selected) { session in
                    sessionRow(session)
                        .tag(session.id)
                        .contextMenu {
                            Button("Inspect") { inspected = session }
                            Button("Rename") { beginRename(session) }
                            Button("Export…") { model.export(session) }
                            Button("Show in Finder") { model.reveal(session.directoryURL) }
                            Divider()
                            Button("Delete", role: .destructive) { deleting = session }
                        }
                }
                .environment(\.defaultMinListRowHeight, 66)
            }
        }
        .sheet(item: $inspected) { session in TimelineView(session: session) }
        .alert("Rename Session", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })) {
            TextField("Name", text: $renameText)
            Button("Cancel", role: .cancel) { renaming = nil }
            Button("Rename") { if let renaming { model.rename(renaming, to: renameText) }; renaming = nil }
        }
        .alert("Delete Session?", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } })) {
            Button("Cancel", role: .cancel) { deleting = nil }
            Button("Delete", role: .destructive) { if let deleting { model.delete(deleting) }; deleting = nil }
        } message: {
            Text("This permanently removes the local video and input data for “\(deleting?.metadata.name ?? "this session")”.")
        }
        .alert("Create Game Agent", isPresented: $showingDatasetName) {
            TextField("Game or agent name", text: $datasetName)
            Button("Cancel", role: .cancel) {}
            Button("Create & Train") {
                model.createDataset(name: datasetName, sessionIDs: Array(selected), trainImmediately: true)
                selected.removeAll()
            }
        } message: {
            Text("Learner will combine these demonstrations, infer the game’s goal and controls, then create a playable agent automatically.")
        }
    }

    private func sessionRow(_ session: SessionSummary) -> some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(Color.accentColor.opacity(0.12))
                Image(systemName: session.metadata.target.kind == .window ? "macwindow" : "display")
                    .font(.title2).foregroundStyle(Color.accentColor)
            }
            .frame(width: 46, height: 46)
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 7) {
                    Text(session.metadata.name).font(.headline).lineLimit(1)
                    if session.metadata.status != .complete {
                        Text(session.metadata.status.rawValue.uppercased())
                            .font(.caption2.weight(.bold))
                            .padding(.horizontal, 6).padding(.vertical, 2)
                            .background(Color.orange.opacity(0.15), in: Capsule())
                    }
                }
                Text("\(session.metadata.target.applicationName)  •  \(session.metadata.createdAt.formatted(date: .abbreviated, time: .shortened))")
                    .font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer()
            sessionMetric("Duration", LearnerFormatters.duration(session.metadata.durationNs))
            sessionMetric("Frames", session.metadata.frameCount.formatted())
            sessionMetric("Actions", session.metadata.actionCount.formatted())
            sessionMetric("Capture", "\(session.metadata.output.width)×\(session.metadata.output.height) @ \(session.metadata.vision.fps)")
            sessionMetric("Size", LearnerFormatters.bytes(session.sizeBytes))
            Button("Inspect") { inspected = session }.buttonStyle(.borderless)
        }
        .padding(.vertical, 5)
    }

    private func sessionMetric(_ title: String, _ value: String) -> some View {
        VStack(alignment: .trailing, spacing: 2) {
            Text(title).font(.caption2).foregroundStyle(.tertiary)
            Text(value).font(.caption.monospacedDigit()).lineLimit(1)
        }
        .frame(minWidth: 62, alignment: .trailing)
    }

    private func beginRename(_ session: SessionSummary) {
        renameText = session.metadata.name
        renaming = session
    }
}

struct TimelineView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    let session: SessionSummary

    @State private var player = AVPlayer()
    @State private var actions: [InputEventRecord] = []
    @State private var markers: [TimelineMarker] = []
    @State private var currentSeconds = 0.0
    @State private var isScrubbing = false
    @State private var observer: Any?
    @State private var rangeStartNs: UInt64?

    private var durationSeconds: Double { max(0.001, Double(session.metadata.durationNs) / 1_000_000_000) }
    private var currentNs: UInt64 { UInt64(max(0, currentSeconds) * 1_000_000_000) }
    private var currentAction: InputEventRecord? { actions.last { $0.timestampNs <= currentNs } }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text(session.metadata.name).font(.title2.weight(.semibold))
                    Text("\(session.metadata.target.displayName) • \(session.metadata.output.width)×\(session.metadata.output.height) @ \(session.metadata.vision.fps) FPS")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Button("Show in Finder") { model.reveal(session.directoryURL) }
                Button("Done") { dismiss() }.keyboardShortcut(.defaultAction)
            }
            .padding(18)
            Divider()

            HStack(alignment: .top, spacing: 18) {
                VStack(spacing: 14) {
                    VideoPlayer(player: player)
                        .aspectRatio(CGFloat(session.metadata.output.width) / CGFloat(session.metadata.output.height), contentMode: .fit)
                        .background(Color.black)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    timeline
                }
                .frame(maxWidth: .infinity)

                VStack(alignment: .leading, spacing: 18) {
                    Text("STATE AT CURSOR").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                    inspectorGroup("Pressed keys") {
                        FlowTokens(values: currentAction?.heldKeys ?? [], empty: "None", tint: .blue)
                    }
                    inspectorGroup("Modifiers") {
                        FlowTokens(values: currentAction?.modifiers ?? [], empty: "None", tint: .indigo)
                    }
                    inspectorGroup("Mouse buttons") {
                        FlowTokens(values: currentAction?.heldButtons ?? [], empty: "None", tint: .purple)
                    }
                    inspectorGroup("Cursor") {
                        Text(String(format: "x %.3f   y %.3f", currentAction?.x ?? 0, currentAction?.y ?? 0))
                            .font(.callout.monospacedDigit())
                    }
                    Divider()
                    Text("LABEL THIS MOMENT").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                    HStack {
                        Button(rangeStartNs == nil ? "Set Range Start" : "Clear Range") {
                            if rangeStartNs == nil { rangeStartNs = currentNs } else { rangeStartNs = nil }
                        }
                        if let rangeStartNs {
                            Text("From \(LearnerFormatters.duration(rangeStartNs))")
                                .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                        }
                    }
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                        ForEach(MarkerLabel.allCases, id: \.self) { label in
                            Button(label.rawValue) {
                                model.addMarker(label, at: rangeStartNs ?? currentNs, endTimestampNs: rangeStartNs == nil ? nil : currentNs, session: session)
                                markers = model.store.loadMarkers(for: session)
                                rangeStartNs = nil
                            }
                            .buttonStyle(.bordered)
                            .tint(markerColor(label))
                        }
                    }
                    Text("Labels are stored as timestamped metadata; the original recording stays unchanged.")
                        .font(.caption).foregroundStyle(.secondary)
                    Spacer()
                }
                .padding(16)
                .frame(width: 270, alignment: .topLeading)
                .frame(maxHeight: .infinity, alignment: .topLeading)
                .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 14))
            }
            .padding(18)
        }
        .frame(minWidth: 980, minHeight: 700)
        .onAppear(perform: load)
        .onDisappear {
            if let observer { player.removeTimeObserver(observer) }
            player.pause()
        }
    }

    private var timeline: some View {
        VStack(spacing: 8) {
            TimelineActivityTrack(actions: actions, markers: markers, durationNs: session.metadata.durationNs, currentNs: currentNs)
                .frame(height: 56)
            HStack {
                Text(LearnerFormatters.duration(currentNs)).font(.caption.monospacedDigit())
                Slider(value: $currentSeconds, in: 0...durationSeconds) { editing in
                    isScrubbing = editing
                    if !editing {
                        player.seek(to: CMTime(seconds: currentSeconds, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero)
                    }
                }
                Text(LearnerFormatters.duration(session.metadata.durationNs)).font(.caption.monospacedDigit()).foregroundStyle(.secondary)
            }
        }
    }

    private func inspectorGroup<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            content()
        }
    }

    private func load() {
        actions = model.store.loadActions(for: session)
        markers = model.store.loadMarkers(for: session)
        let video = session.directoryURL.appendingPathComponent(session.metadata.videoPath)
        player.replaceCurrentItem(with: AVPlayerItem(url: video))
        observer = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.05, preferredTimescale: 600), queue: .main) { time in
            if !isScrubbing { currentSeconds = min(durationSeconds, max(0, time.seconds)) }
        }
    }

    private func markerColor(_ label: MarkerLabel) -> Color {
        switch label { case .good: .green; case .bad: .red; case .important: .orange; case .ignore: .gray }
    }
}

struct TimelineActivityTrack: View {
    let actions: [InputEventRecord]
    let markers: [TimelineMarker]
    let durationNs: UInt64
    let currentNs: UInt64

    var body: some View {
        Canvas { context, size in
            let width = max(1, size.width)
            let duration = Double(max(1, durationNs))
            context.fill(Path(CGRect(x: 0, y: 0, width: width, height: size.height)), with: .color(.primary.opacity(0.045)))
            for action in actions {
                let x = Double(action.timestampNs) / duration * width
                let color: Color = action.type == .mouseMove ? .purple.opacity(0.35) : action.type == .scroll ? .orange : .blue
                var path = Path()
                path.move(to: CGPoint(x: x, y: 8)); path.addLine(to: CGPoint(x: x, y: size.height - 8))
                context.stroke(path, with: .color(color), lineWidth: action.type == .mouseMove ? 0.5 : 1.5)
            }
            for marker in markers {
                let x = Double(marker.timestampNs) / duration * width
                let endX = Double(marker.endTimestampNs ?? marker.timestampNs) / duration * width
                let rect = CGRect(x: x - 2, y: 2, width: max(4, endX - x + 4), height: size.height - 4)
                context.fill(Path(roundedRect: rect, cornerRadius: 2), with: .color(.yellow))
            }
            let cursorX = Double(currentNs) / duration * width
            var cursor = Path(); cursor.move(to: CGPoint(x: cursorX, y: 0)); cursor.addLine(to: CGPoint(x: cursorX, y: size.height))
            context.stroke(cursor, with: .color(.red), lineWidth: 2)
        }
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .overlay { RoundedRectangle(cornerRadius: 8).stroke(Color.primary.opacity(0.1)) }
    }
}
