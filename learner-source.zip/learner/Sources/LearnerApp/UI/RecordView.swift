import SwiftUI
import LearnerCore

struct RecordView: View {
    @EnvironmentObject private var model: AppModel
    @State private var showingSources = false
    @State private var tool: VisionTool = .inspect

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            if let source = model.selectedSource {
                selectedLayout(source)
            } else {
                unselectedLayout
            }
        }
        .sheet(isPresented: $showingSources) { SourcePickerView() }
        .onChange(of: model.selectedSource?.id) { _, _ in
            if model.selectedSource?.kind == .region { tool = .crop }
        }
    }

    private var header: some View {
        HStack(spacing: 16) {
            VStack(alignment: .leading, spacing: 3) {
                Text("Record").font(.title.weight(.semibold))
                HStack(spacing: 7) {
                    Text("SELECT").foregroundStyle(model.selectedSource == nil ? Color.accentColor : .secondary)
                    Image(systemName: "arrow.right").foregroundStyle(.tertiary)
                    Text("SEE").foregroundStyle(model.selectedSource != nil && model.previewImage == nil ? Color.accentColor : .secondary)
                    Image(systemName: "arrow.right").foregroundStyle(.tertiary)
                    Text("RECORD").foregroundStyle(model.previewImage != nil ? Color.accentColor : .secondary)
                }
                .font(.caption.weight(.bold))
            }
            Spacer()
            if let source = model.selectedSource {
                VStack(alignment: .trailing, spacing: 2) {
                    Text(source.applicationName).font(.callout.weight(.semibold)).lineLimit(1)
                    Text(source.kind.label).font(.caption).foregroundStyle(.secondary)
                }
                Button("Change Target") { showingSources = true }
                    .disabled(model.phase != .idle)
            } else {
                Button { showingSources = true } label: {
                    Label("Select Target", systemImage: "plus.viewfinder")
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
            }
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 17)
    }

    private var unselectedLayout: some View {
        VStack {
            Spacer()
            EmptyState(
                icon: "gamecontroller.fill",
                title: "Put your game behind Learner",
                message: "Learner can find it automatically, or you can choose from live pictures of every available window and display."
            )
            HStack(spacing: 12) {
                Button { model.selectAppBehindLearner() } label: {
                    Label(model.isAutoSelectingTarget ? "Finding Game…" : "Use App Behind Learner", systemImage: "sparkles.rectangle.stack")
                        .frame(minWidth: 190)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .disabled(model.isAutoSelectingTarget)
                Button { showingSources = true } label: {
                    Label("Choose from Pictures", systemImage: "photo.on.rectangle.angled")
                        .frame(minWidth: 170)
                }
                .buttonStyle(.bordered)
                .controlSize(.large)
                if model.trainedModelURL != nil {
                    Button { model.navigation = .agent } label: {
                        Label("Let Agent Play", systemImage: "gamecontroller.fill")
                            .frame(minWidth: 150)
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.large)
                }
            }
            Text("Fullscreen or unusual game? Choose from Pictures → Fullscreen Game.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .padding(.top, 8)
            Spacer()
            privacyFooter
        }
    }

    private func selectedLayout(_ source: CaptureSourceDescriptor) -> some View {
        VStack(spacing: 0) {
            if model.phase == .idle && tool != .inspect {
                HStack(spacing: 10) {
                    Image(systemName: tool.icon).foregroundStyle(tool == .mask ? .red : tool == .region ? .cyan : .yellow)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(tool == .crop ? "Drag over the preview to choose the exact area" : tool == .mask ? "Drag over anything the AI must not see" : "Drag over an optional observation region")
                            .font(.callout.weight(.semibold))
                        Text("Click and drag from one corner to the opposite corner. You can undo it from the panel on the right.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button("Cancel") { tool = .inspect }
                }
                .padding(.horizontal, 18).padding(.vertical, 10)
                .background(Color.accentColor.opacity(0.08))
            }
            HStack(spacing: 0) {
                VStack(spacing: 12) {
                    previewToolbar
                    preview
                    if model.phase == .recording || model.phase == .paused || model.phase == .stopping {
                        liveReadout
                    } else if model.phase == .agent {
                        agentReadout
                    }
                    recordingControls
                }
                .padding(18)
                .frame(maxWidth: .infinity, maxHeight: .infinity)

                Divider()
                inspector(source)
                    .frame(width: 285)
                    .background(Color(nsColor: .controlBackgroundColor).opacity(0.45))
            }
        }
    }

    private var previewToolbar: some View {
        HStack {
            Picker("Vision tool", selection: $tool) {
                ForEach(VisionTool.allCases) { tool in
                    Label(tool.rawValue, systemImage: tool.icon).tag(tool)
                }
            }
            .pickerStyle(.segmented)
            .frame(maxWidth: 430)
            .disabled(model.phase != .idle)
            Spacer()
            if model.vision.crop != NormalizedRect() {
                Button(model.selectedSource?.kind == .region ? "Choose Area Again" : "Reset Crop") {
                    model.updateVision { $0.crop = NormalizedRect() }
                    if model.selectedSource?.kind == .region { tool = .crop }
                }
                    .disabled(model.phase != .idle)
            }
            if let dimensions = model.previewDimensions {
                Text("\(dimensions.width) × \(dimensions.height)")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var preview: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 14).fill(Color.black.opacity(0.92))
            if let image = model.previewImage {
                VisionCanvas(
                    image: image,
                    crop: model.vision.crop,
                    masks: model.vision.masks,
                    regions: model.vision.regions,
                    tool: tool,
                    onCrop: { rect in model.updateVision { $0.crop = rect }; tool = .inspect },
                    onMask: { rect in
                        model.updateVision { $0.masks.append(MaskRegion(name: "mask_\($0.masks.count + 1)", rect: rect)) }
                        tool = .inspect
                    },
                    onRegion: { rect in
                        model.updateVision { $0.regions.append(ObservationRegion(name: "region_\($0.regions.count + 1)", rect: rect)) }
                        tool = .inspect
                    }
                )
                .padding(3)
            } else {
                ProgressView("Starting private preview…")
                    .foregroundStyle(.white)
            }
            if model.phase == .paused {
                VStack(spacing: 8) {
                    Image(systemName: "pause.fill").font(.largeTitle)
                    Text("PAUSED").font(.headline)
                }
                .foregroundStyle(.white)
                .padding(20)
                .background(.black.opacity(0.7), in: RoundedRectangle(cornerRadius: 14))
            }
            if model.phase == .recording {
                VStack { HStack {
                    Label("REC", systemImage: "record.circle.fill")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 9).padding(.vertical, 6)
                        .background(Color.red, in: Capsule())
                    Spacer()
                }; Spacer() }
                .padding(12)
            }
            if model.phase == .agent {
                VStack { HStack {
                    Label("AGENT", systemImage: "sparkles")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 9).padding(.vertical, 6)
                        .background(Color.purple, in: Capsule())
                    Spacer()
                }; Spacer() }
                .padding(12)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .overlay {
            RoundedRectangle(cornerRadius: 14).stroke(Color.primary.opacity(0.12), lineWidth: 1)
        }
    }

    private var liveReadout: some View {
        SurfaceCard(content: HStack(spacing: 18) {
            StatCell(label: "Time", value: LearnerFormatters.duration(model.stats.elapsedNs))
            StatCell(label: "Frames", value: model.stats.frameCount.formatted())
            StatCell(label: "Samples", value: model.stats.sampleCount.formatted())
            StatCell(label: "Actions", value: model.stats.actionCount.formatted())
            StatCell(label: "Disk", value: LearnerFormatters.bytes(model.approximateDiskBytes))
            Divider().frame(height: 36)
            VStack(alignment: .leading, spacing: 4) {
                FlowTokens(values: model.liveInput.heldKeys + model.liveInput.modifiers, empty: "No keys held", tint: .blue)
                FlowTokens(values: model.liveInput.heldButtons, empty: "No mouse buttons", tint: .purple)
            }
            .frame(maxWidth: 260, alignment: .leading)
        })
    }

    private var agentReadout: some View {
        SurfaceCard(content: HStack(spacing: 18) {
            VStack(alignment: .leading, spacing: 4) {
                Text("EXPERIMENTAL AGENT").font(.caption.weight(.bold)).foregroundStyle(.purple)
                Text("Trained on \(model.agentTrainingFrames.formatted()) frames")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Divider().frame(height: 36)
            AgentConfidence(label: "Left", value: model.agentProbabilities["Left Arrow"] ?? 0)
            AgentConfidence(label: "Right", value: model.agentProbabilities["Right Arrow"] ?? 0)
            AgentConfidence(label: "Jump", value: model.agentProbabilities["Up Arrow"] ?? 0)
            Divider().frame(height: 36)
            VStack(alignment: .leading, spacing: 4) {
                Text("Keys being sent").font(.caption).foregroundStyle(.secondary)
                FlowTokens(values: model.liveInput.heldKeys, empty: "None — focus the game", tint: .purple)
            }
            .frame(maxWidth: 240, alignment: .leading)
        })
    }

    private var recordingControls: some View {
        HStack(spacing: 12) {
            if model.phase == .idle {
                Button { model.startRecordingAndSwitchToTarget() } label: {
                    Label("Start Recording & Play", systemImage: "record.circle.fill")
                        .frame(minWidth: 175)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .controlSize(.large)
                .disabled(model.previewImage == nil)
                if model.trainedModelURL != nil {
                    Button { model.startAgent() } label: {
                        Label(model.isPreparingAgent ? "Starting Agent…" : "Run Agent", systemImage: model.isPreparingAgent ? "hourglass" : "play.circle.fill")
                            .frame(minWidth: 120)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.purple)
                    .controlSize(.large)
                    .disabled(model.isPreparingAgent)
                }
            } else if model.phase == .agent {
                Button { model.stopAgent() } label: {
                    Label("Stop Agent", systemImage: "stop.fill")
                        .frame(minWidth: 130)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .controlSize(.large)
                Text("Escape stops immediately")
                    .font(.callout.weight(.medium))
                    .foregroundStyle(.secondary)
            } else {
                Button {
                    if model.phase == .paused { model.resumeRecording() } else { model.pauseRecording() }
                } label: {
                    Label(model.phase == .paused ? "Resume" : "Pause", systemImage: model.phase == .paused ? "play.fill" : "pause.fill")
                        .frame(minWidth: 90)
                }
                .controlSize(.large)
                .disabled(model.phase == .stopping)

                Button { Task { await model.stopRecording() } } label: {
                    Label(model.phase == .stopping ? "Saving…" : "Stop & Save", systemImage: "stop.fill")
                        .frame(minWidth: 110)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .disabled(model.phase == .stopping)

                Button { model.markImportant() } label: {
                    Label("Mark Important", systemImage: "flag.fill")
                }
                .controlSize(.large)
                .disabled(model.phase != .recording)
            }
            Spacer()
            Text("Stored only on this Mac")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private func inspector(_ source: CaptureSourceDescriptor) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                VStack(alignment: .leading, spacing: 6) {
                    Label(
                        model.previewImage == nil ? "Connecting…" : "Ready to record",
                        systemImage: model.previewImage == nil ? "ellipsis.circle" : "checkmark.circle.fill"
                    )
                    .font(.headline)
                    .foregroundStyle(model.previewImage == nil ? .orange : .green)
                    Text(model.previewImage == nil
                         ? "Wait for the first live frame."
                         : "Start Recording & Play switches straight back to your game. Stop from Learner’s menu-bar icon.")
                        .font(.caption).foregroundStyle(.secondary)
                }

                Divider()
                VStack(alignment: .leading, spacing: 8) {
                    Text("CAPTURE").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                    Picker("Frame rate", selection: Binding(
                        get: { model.vision.fps },
                        set: { value in model.updateVision { $0.fps = value } }
                    )) {
                        Text("15 FPS").tag(15); Text("30 FPS").tag(30); Text("60 FPS").tag(60)
                    }
                    Picker("Resolution", selection: Binding(
                        get: { model.vision.resolution },
                        set: { value in model.updateVision { $0.resolution = value } }
                    )) {
                        ForEach(CaptureResolution.allCases, id: \.self) { Text($0.label).tag($0) }
                    }
                    Text("Preview pixels are the same processed pixels written to the dataset.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                .disabled(model.phase != .idle)

                Divider()
                VStack(alignment: .leading, spacing: 10) {
                    HStack { Text("MASKS").font(.caption.weight(.bold)).foregroundStyle(.secondary); Spacer(); Text("\(model.vision.masks.count)").foregroundStyle(.tertiary) }
                    if model.vision.masks.isEmpty { Text("Draw rectangles with the Mask tool.").font(.caption).foregroundStyle(.secondary) }
                    ForEach(model.vision.masks) { mask in
                        HStack {
                            Image(systemName: "eye.slash.fill").foregroundStyle(.red)
                            Text(mask.name).lineLimit(1)
                            Spacer()
                            Button { model.updateVision { $0.masks.removeAll { $0.id == mask.id } } } label: { Image(systemName: "xmark") }
                                .buttonStyle(.plain)
                        }
                    }
                }

                Divider()
                VStack(alignment: .leading, spacing: 10) {
                    HStack { Text("OBSERVATION REGIONS").font(.caption.weight(.bold)).foregroundStyle(.secondary); Spacer(); Text("\(model.vision.regions.count)").foregroundStyle(.tertiary) }
                    if model.vision.regions.isEmpty { Text("Optional. Draw with the Region tool.").font(.caption).foregroundStyle(.secondary) }
                    ForEach(model.vision.regions) { region in
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                TextField("Region name", text: Binding(
                                    get: { model.vision.regions.first(where: { $0.id == region.id })?.name ?? region.name },
                                    set: { name in model.updateVision { config in if let i = config.regions.firstIndex(where: { $0.id == region.id }) { config.regions[i].name = name } } }
                                ))
                                Button { model.updateVision { $0.regions.removeAll { $0.id == region.id } } } label: { Image(systemName: "trash") }
                                    .buttonStyle(.plain)
                            }
                            Toggle("Export separate video", isOn: Binding(
                                get: { model.vision.regions.first(where: { $0.id == region.id })?.exportSeparately ?? false },
                                set: { value in model.updateVision { config in if let i = config.regions.firstIndex(where: { $0.id == region.id }) { config.regions[i].exportSeparately = value } } }
                            ))
                            .font(.caption)
                        }
                    }
                }
                .disabled(model.phase != .idle)

                Divider()
                VStack(alignment: .leading, spacing: 5) {
                    Text("TARGET").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                    Text(source.displayName).font(.callout).lineLimit(2)
                    Text(source.kind == .window
                         ? "Keyboard and mouse are recorded only while this game is active."
                         : "Keyboard and mouse are recorded while this display or area session is active.")
                        .font(.caption).foregroundStyle(.secondary)
                    if source.kind == .display {
                        Label("Fullscreen compatibility mode", systemImage: "display")
                            .font(.caption.weight(.semibold)).foregroundStyle(.blue)
                    }
                }
            }
            .padding(16)
        }
    }

    private var privacyFooter: some View {
        Label("No microphone, camera, clipboard, uploads, or unrelated windows", systemImage: "lock.shield")
            .font(.caption)
            .foregroundStyle(.secondary)
            .padding(.bottom, 20)
    }
}

private struct AgentConfidence: View {
    let label: String
    let value: Double

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label).font(.caption).foregroundStyle(.secondary)
            Text(value, format: .percent.precision(.fractionLength(0)))
                .font(.body.monospacedDigit().weight(.semibold))
        }
        .frame(minWidth: 54, alignment: .leading)
    }
}
