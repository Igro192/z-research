import SwiftUI

struct RootView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        NavigationSplitView {
            List(NavigationSection.visibleCases, selection: $model.navigation) { section in
                Label(section.rawValue, systemImage: section.icon)
                    .tag(section)
            }
            .navigationSplitViewColumnWidth(min: 180, ideal: 205, max: 240)
            .safeAreaInset(edge: .bottom) {
                HStack(spacing: 8) {
                    Circle()
                        .fill(model.learningMode == .teach ? Color.red : model.humanOverride ? Color.orange : model.phase == .agent ? Color.purple : Color.green)
                        .frame(width: 8, height: 8)
                    Text(model.learningMode == .teach ? "Teaching locally" : model.humanOverride ? "Human override" : model.learningMode == .practice ? "Practice active" : model.learningMode == .autopilot ? "Autopilot active" : "Local only")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Spacer()
                }
                .padding(12)
            }
        } detail: {
            Group {
                switch model.navigation {
                case .home, .record, .agent: GameHomeView()
                case .activity, .sessions: ActivityView()
                case .developer, .datasets: DeveloperView()
                case .settings: SettingsView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(nsColor: .windowBackgroundColor))
        }
        .alert("Learner", isPresented: Binding(
            get: { model.errorMessage != nil },
            set: { if !$0 { model.errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) { model.errorMessage = nil }
        } message: {
            Text(model.errorMessage ?? "")
        }
        .overlay(alignment: .bottom) {
            if let status = model.statusMessage {
                Text(status)
                    .font(.callout.weight(.medium))
                    .padding(.horizontal, 14)
                    .padding(.vertical, 9)
                    .background(.ultraThickMaterial, in: Capsule())
                    .shadow(radius: 8, y: 3)
                    .padding(.bottom, 18)
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                            if model.statusMessage == status { withAnimation { model.statusMessage = nil } }
                        }
                    }
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .animation(.easeInOut(duration: 0.2), value: model.statusMessage)
        .onReceive(NotificationCenter.default.publisher(for: NSApplication.didBecomeActiveNotification)) { _ in
            model.refreshPermissions()
            model.refreshLibrary()
        }
    }
}
