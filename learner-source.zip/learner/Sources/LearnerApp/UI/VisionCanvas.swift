import SwiftUI
import LearnerCore

enum VisionTool: String, CaseIterable, Identifiable {
    case inspect = "Preview"
    case crop = "Crop"
    case mask = "Mask"
    case region = "Region"
    var id: String { rawValue }
    var icon: String {
        switch self {
        case .inspect: "eye"
        case .crop: "crop"
        case .mask: "rectangle.dashed"
        case .region: "square.grid.2x2"
        }
    }
}

struct VisionCanvas: View {
    let image: CGImage
    let crop: NormalizedRect
    let masks: [MaskRegion]
    let regions: [ObservationRegion]
    let tool: VisionTool
    let onCrop: (NormalizedRect) -> Void
    let onMask: (NormalizedRect) -> Void
    let onRegion: (NormalizedRect) -> Void

    @State private var dragStart: CGPoint?
    @State private var dragCurrent: CGPoint?

    var body: some View {
        GeometryReader { proxy in
            let imageSize = CGSize(width: image.width, height: image.height)
            let fit = aspectFit(imageSize, in: proxy.size)
            ZStack {
                Color.black.opacity(0.92)
                Image(decorative: image, scale: 1)
                    .resizable()
                    .interpolation(.medium)
                    .frame(width: fit.width, height: fit.height)
                    .position(x: fit.midX, y: fit.midY)

                ForEach(masks) { mask in
                    overlayRect(mask.rect, in: fit)
                        .stroke(Color.red.opacity(0.9), style: StrokeStyle(lineWidth: 1.5, dash: [5, 4]))
                        .overlay(alignment: .topLeading) {
                            Text(mask.name).font(.caption2.weight(.semibold)).padding(4).foregroundStyle(.red)
                        }
                }
                ForEach(regions) { region in
                    overlayRect(region.rect, in: fit)
                        .stroke(Color.cyan, style: StrokeStyle(lineWidth: 1.5, dash: [5, 4]))
                        .overlay(alignment: .topLeading) {
                            Text(region.name).font(.caption2.weight(.semibold)).padding(4).foregroundStyle(.cyan)
                        }
                }
                if let selection = currentSelection(in: fit) {
                    Rectangle()
                        .path(in: selection)
                        .fill(selectionColor.opacity(0.18))
                    Rectangle()
                        .path(in: selection)
                        .stroke(selectionColor, style: StrokeStyle(lineWidth: 2, dash: [6, 4]))
                }
                if tool != .inspect {
                    VStack {
                        HStack {
                            Label(tool == .crop ? "Drag to crop" : tool == .mask ? "Drag to hide" : "Drag to name a region", systemImage: tool.icon)
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 10).padding(.vertical, 6)
                                .background(.ultraThickMaterial, in: Capsule())
                            Spacer()
                        }
                        Spacer()
                    }
                    .padding(12)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .contentShape(Rectangle())
            .gesture(DragGesture(minimumDistance: 4, coordinateSpace: .local)
                .onChanged { value in
                    guard tool != .inspect, fit.contains(value.startLocation) else { return }
                    dragStart = value.startLocation
                    dragCurrent = CGPoint(
                        x: min(max(value.location.x, fit.minX), fit.maxX),
                        y: min(max(value.location.y, fit.minY), fit.maxY)
                    )
                }
                .onEnded { _ in
                    defer { dragStart = nil; dragCurrent = nil }
                    guard let rect = normalizedSelection(in: fit), rect.isMeaningful else { return }
                    switch tool {
                    case .inspect: break
                    case .crop:
                        let composed = NormalizedRect(
                            x: crop.x + rect.x * crop.width,
                            y: crop.y + rect.y * crop.height,
                            width: rect.width * crop.width,
                            height: rect.height * crop.height
                        )
                        onCrop(composed)
                    case .mask: onMask(rect)
                    case .region: onRegion(rect)
                    }
                }
            )
        }
        .aspectRatio(CGFloat(image.width) / CGFloat(image.height), contentMode: .fit)
    }

    private var selectionColor: Color {
        switch tool { case .crop: .yellow; case .mask: .red; case .region: .cyan; case .inspect: .clear }
    }

    private func aspectFit(_ image: CGSize, in available: CGSize) -> CGRect {
        let scale = min(available.width / image.width, available.height / image.height)
        let size = CGSize(width: image.width * scale, height: image.height * scale)
        return CGRect(x: (available.width - size.width) / 2, y: (available.height - size.height) / 2, width: size.width, height: size.height)
    }

    private func overlayRect(_ normalized: NormalizedRect, in fit: CGRect) -> Path {
        let rect = CGRect(
            x: fit.minX + normalized.x * fit.width,
            y: fit.minY + normalized.y * fit.height,
            width: normalized.width * fit.width,
            height: normalized.height * fit.height
        )
        return Rectangle().path(in: rect)
    }

    private func currentSelection(in fit: CGRect) -> CGRect? {
        guard let start = dragStart, let current = dragCurrent else { return nil }
        return CGRect(x: min(start.x, current.x), y: min(start.y, current.y), width: abs(current.x - start.x), height: abs(current.y - start.y))
            .intersection(fit)
    }

    private func normalizedSelection(in fit: CGRect) -> NormalizedRect? {
        guard let rect = currentSelection(in: fit), rect.width > 4, rect.height > 4 else { return nil }
        return NormalizedRect(
            x: (rect.minX - fit.minX) / fit.width,
            y: (rect.minY - fit.minY) / fit.height,
            width: rect.width / fit.width,
            height: rect.height / fit.height
        )
    }
}
