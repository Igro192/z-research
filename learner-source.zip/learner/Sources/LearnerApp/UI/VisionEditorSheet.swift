import SwiftUI
import LearnerCore

/// A focused, approachable version of the recorder's vision editor. It keeps
/// crop, privacy masks, named regions, frame rate, and resolution available in
/// the new Game-first workflow without exposing the old recording UI.
struct VisionEditorSheet: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var tool: VisionTool = .inspect

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            HStack(spacing: 0) {
                editor
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .padding(18)
                Divider()
                inspector
                    .frame(width: 300)
                    .background(Color(nsColor: .controlBackgroundColor).opacity(0.45))
            }
        }
        .frame(minWidth: 980, idealWidth: 1120, minHeight: 680, idealHeight: 760)
        .onAppear {
            if model.selectedSource?.kind == .region && model.vision.crop == NormalizedRect() {
                tool = .crop
            }
        }
    }

    private var header: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                Text(model.selectedSource?.kind == .region ? "Choose the area Learner sees" : "Edit AI vision")
                    .font(.title2.weight(.semibold))
                Text("The image below is exactly what will be stored and learned from.")
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Button("Done") { dismiss() }
                .buttonStyle(.borderedProminent)
                .keyboardShortcut(.defaultAction)
        }
        .padding(20)
    }

    private var editor: some View {
        VStack(spacing: 14) {
            Picker("Vision tool", selection: $tool) {
                ForEach(VisionTool.allCases) { item in
                    Label(item.rawValue, systemImage: item.icon).tag(item)
                }
            }
            .pickerStyle(.segmented)
            .frame(maxWidth: 520)

            ZStack {
                RoundedRectangle(cornerRadius: 14).fill(.black)
                if let image = model.previewImage {
                    VisionCanvas(
                        image: image,
                        crop: model.vision.crop,
                        masks: model.vision.masks,
                        regions: model.vision.regions,
                        tool: tool,
                        onCrop: { rect in
                            model.updateVision { $0.crop = rect }
                            tool = .inspect
                        },
                        onMask: { rect in
                            model.updateVision {
                                $0.masks.append(MaskRegion(name: "mask_\($0.masks.count + 1)", rect: rect))
                            }
                            tool = .inspect
                        },
                        onRegion: { rect in
                            model.updateVision {
                                $0.regions.append(ObservationRegion(name: "region_\($0.regions.count + 1)", rect: rect))
                            }
                            tool = .inspect
                        }
                    )
                    .padding(3)
                } else {
                    ProgressView("Connecting to the target…").tint(.white).foregroundStyle(.white)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            HStack {
                Label(instruction, systemImage: tool.icon)
                    .font(.callout).foregroundStyle(.secondary)
                Spacer()
                if let dimensions = model.previewDimensions {
                    Text("\(dimensions.width) × \(dimensions.height)")
                        .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                }
            }
        }
    }

    private var instruction: String {
        switch tool {
        case .inspect: "Choose Crop, Mask, or Region, then drag directly on the image."
        case .crop: "Drag around the only area the AI should see."
        case .mask: "Drag over private content; those pixels are neutralized before storage."
        case .region: "Drag around a useful view such as score or minimap."
        }
    }

    private var inspector: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Group {
                    Text("CAPTURE").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                    Picker("Frame rate", selection: Binding(
                        get: { model.vision.fps },
                        set: { value in model.updateVision { $0.fps = value } }
                    )) {
                        Text("15 FPS").tag(15)
                        Text("30 FPS").tag(30)
                        Text("60 FPS").tag(60)
                    }
                    Picker("Resolution", selection: Binding(
                        get: { model.vision.resolution },
                        set: { value in model.updateVision { $0.resolution = value } }
                    )) {
                        ForEach(CaptureResolution.allCases, id: \.self) { Text($0.label).tag($0) }
                    }
                }

                Divider()
                HStack {
                    Text("CROP").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                    Spacer()
                    if model.vision.crop != NormalizedRect() {
                        Button("Reset") {
                            model.updateVision { $0.crop = NormalizedRect() }
                            if model.selectedSource?.kind == .region { tool = .crop }
                        }
                    }
                }
                Text(model.vision.crop == NormalizedRect() ? "Using the full target." : "Only the selected area is captured.")
                    .font(.caption).foregroundStyle(.secondary)

                Divider()
                HStack {
                    Text("PRIVACY MASKS").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                    Spacer()
                    Text(model.vision.masks.count.formatted()).foregroundStyle(.tertiary)
                }
                if model.vision.masks.isEmpty {
                    Text("Choose Mask and draw over anything the AI must not see.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                ForEach(model.vision.masks) { mask in
                    HStack {
                        Image(systemName: "eye.slash.fill").foregroundStyle(.red)
                        Text(mask.name).lineLimit(1)
                        Spacer()
                        Button {
                            model.updateVision { $0.masks.removeAll { $0.id == mask.id } }
                        } label: { Image(systemName: "trash") }
                        .buttonStyle(.plain)
                    }
                }

                Divider()
                HStack {
                    Text("NAMED REGIONS").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                    Spacer()
                    Text(model.vision.regions.count.formatted()).foregroundStyle(.tertiary)
                }
                if model.vision.regions.isEmpty {
                    Text("Optional. Regions can be exported separately for later learning.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                ForEach(model.vision.regions) { region in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            TextField("Region name", text: regionNameBinding(region))
                            Button {
                                model.updateVision { $0.regions.removeAll { $0.id == region.id } }
                            } label: { Image(systemName: "trash") }
                            .buttonStyle(.plain)
                        }
                        Toggle("Export separately", isOn: exportBinding(region))
                            .font(.caption)
                    }
                }

                Divider()
                Label("Masks are applied before pixels are written to disk.", systemImage: "lock.shield.fill")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .padding(16)
        }
    }

    private func regionNameBinding(_ region: ObservationRegion) -> Binding<String> {
        Binding(
            get: { model.vision.regions.first(where: { $0.id == region.id })?.name ?? region.name },
            set: { name in
                model.updateVision { config in
                    guard let index = config.regions.firstIndex(where: { $0.id == region.id }) else { return }
                    config.regions[index].name = name
                }
            }
        )
    }

    private func exportBinding(_ region: ObservationRegion) -> Binding<Bool> {
        Binding(
            get: { model.vision.regions.first(where: { $0.id == region.id })?.exportSeparately ?? false },
            set: { value in
                model.updateVision { config in
                    guard let index = config.regions.firstIndex(where: { $0.id == region.id }) else { return }
                    config.regions[index].exportSeparately = value
                }
            }
        )
    }
}
