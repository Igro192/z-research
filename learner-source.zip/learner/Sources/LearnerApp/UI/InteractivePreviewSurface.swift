import AppKit
import SwiftUI
import LearnerCore

/// Transparent native input surface placed over the aspect-fit preview. It lets
/// a person teach or correct the target without switching windows.
struct InteractivePreviewSurface: NSViewRepresentable {
    let imageSize: CGSize
    let enabled: Bool
    let onInput: (InputEventRecord) -> Void

    func makeNSView(context: Context) -> PreviewInputView {
        let view = PreviewInputView()
        view.onInput = onInput
        view.imageSize = imageSize
        view.enabled = enabled
        return view
    }

    func updateNSView(_ view: PreviewInputView, context: Context) {
        view.onInput = onInput
        view.imageSize = imageSize
        view.enabled = enabled
    }
}

final class PreviewInputView: NSView {
    var onInput: ((InputEventRecord) -> Void)?
    var imageSize: CGSize = CGSize(width: 16, height: 9)
    var enabled = true
    private var tracking: NSTrackingArea?
    private var heldKeys = Set<String>()
    private var heldButtons = Set<String>()

    override var isFlipped: Bool { true }
    override var acceptsFirstResponder: Bool { enabled }

    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        if let tracking { removeTrackingArea(tracking) }
        let area = NSTrackingArea(
            rect: bounds,
            options: [.activeInKeyWindow, .mouseMoved, .mouseEnteredAndExited, .inVisibleRect],
            owner: self
        )
        addTrackingArea(area)
        tracking = area
    }

    override func mouseDown(with event: NSEvent) { emitButton(event, name: "Left", down: true) }
    override func mouseUp(with event: NSEvent) { emitButton(event, name: "Left", down: false) }
    override func rightMouseDown(with event: NSEvent) { emitButton(event, name: "Right", down: true) }
    override func rightMouseUp(with event: NSEvent) { emitButton(event, name: "Right", down: false) }
    override func otherMouseDown(with event: NSEvent) { emitButton(event, name: "Middle", down: true) }
    override func otherMouseUp(with event: NSEvent) { emitButton(event, name: "Middle", down: false) }
    override func mouseMoved(with event: NSEvent) { emitMove(event) }
    override func mouseDragged(with event: NSEvent) { emitMove(event) }
    override func rightMouseDragged(with event: NSEvent) { emitMove(event) }
    override func otherMouseDragged(with event: NSEvent) { emitMove(event) }

    override func scrollWheel(with event: NSEvent) {
        guard enabled, let point = normalized(event) else { return }
        onInput?(InputEventRecord(
            timestampNs: 0,
            type: .scroll,
            heldKeys: heldKeys.sorted(),
            modifiers: modifierNames(event.modifierFlags),
            x: point.x,
            y: point.y,
            heldButtons: heldButtons.sorted(),
            scrollX: event.scrollingDeltaX,
            scrollY: event.scrollingDeltaY
        ))
    }

    override func keyDown(with event: NSEvent) { emitKey(event, down: true) }
    override func keyUp(with event: NSEvent) { emitKey(event, down: false) }
    override func flagsChanged(with event: NSEvent) {
        guard enabled else { return }
        onInput?(InputEventRecord(
            timestampNs: 0,
            type: .modifiersChanged,
            keyCode: Int(event.keyCode),
            key: keyName(event),
            heldKeys: heldKeys.sorted(),
            modifiers: modifierNames(event.modifierFlags),
            heldButtons: heldButtons.sorted()
        ))
    }

    private func emitKey(_ event: NSEvent, down: Bool) {
        guard enabled else { return }
        let name = keyName(event)
        if down { heldKeys.insert(name) } else { heldKeys.remove(name) }
        onInput?(InputEventRecord(
            timestampNs: 0,
            type: down ? .keyDown : .keyUp,
            keyCode: Int(event.keyCode),
            key: name,
            isRepeat: event.isARepeat,
            heldKeys: heldKeys.sorted(),
            modifiers: modifierNames(event.modifierFlags),
            heldButtons: heldButtons.sorted()
        ))
    }

    private func emitButton(_ event: NSEvent, name: String, down: Bool) {
        guard enabled, let point = normalized(event) else { return }
        window?.makeFirstResponder(self)
        if down { heldButtons.insert(name) } else { heldButtons.remove(name) }
        onInput?(InputEventRecord(
            timestampNs: 0,
            type: down ? .mouseButtonDown : .mouseButtonUp,
            heldKeys: heldKeys.sorted(),
            modifiers: modifierNames(event.modifierFlags),
            x: point.x,
            y: point.y,
            button: name,
            heldButtons: heldButtons.sorted()
        ))
    }

    private func emitMove(_ event: NSEvent) {
        guard enabled, let point = normalized(event) else { return }
        onInput?(InputEventRecord(
            timestampNs: 0,
            type: .mouseMove,
            heldKeys: heldKeys.sorted(),
            modifiers: modifierNames(event.modifierFlags),
            x: point.x,
            y: point.y,
            deltaX: event.deltaX,
            deltaY: event.deltaY,
            heldButtons: heldButtons.sorted()
        ))
    }

    private func normalized(_ event: NSEvent) -> (x: Double, y: Double)? {
        guard imageSize.width > 0, imageSize.height > 0 else { return nil }
        let location = convert(event.locationInWindow, from: nil)
        let scale = min(bounds.width / imageSize.width, bounds.height / imageSize.height)
        let shown = CGSize(width: imageSize.width * scale, height: imageSize.height * scale)
        let origin = CGPoint(x: (bounds.width - shown.width) / 2, y: (bounds.height - shown.height) / 2)
        guard location.x >= origin.x, location.x <= origin.x + shown.width,
              location.y >= origin.y, location.y <= origin.y + shown.height else { return nil }
        return (
            min(max((location.x - origin.x) / shown.width, 0), 1),
            min(max((location.y - origin.y) / shown.height, 0), 1)
        )
    }

    private func modifierNames(_ flags: NSEvent.ModifierFlags) -> [String] {
        var values: [String] = []
        if flags.contains(.command) { values.append("Command") }
        if flags.contains(.shift) { values.append("Shift") }
        if flags.contains(.control) { values.append("Control") }
        if flags.contains(.option) { values.append("Option") }
        if flags.contains(.function) { values.append("Fn") }
        return values
    }

    private func keyName(_ event: NSEvent) -> String {
        if let known = Self.keyNames[Int(event.keyCode)] { return known }
        return (event.charactersIgnoringModifiers ?? "Key \(event.keyCode)").uppercased()
    }

    private static let keyNames: [Int: String] = [
        0: "A", 1: "S", 2: "D", 3: "F", 4: "H", 5: "G", 6: "Z", 7: "X", 8: "C", 9: "V",
        11: "B", 12: "Q", 13: "W", 14: "E", 15: "R", 16: "Y", 17: "T", 18: "1", 19: "2",
        20: "3", 21: "4", 22: "6", 23: "5", 24: "=", 25: "9", 26: "7", 27: "-", 28: "8", 29: "0",
        36: "Return", 48: "Tab", 49: "Space", 51: "Delete", 53: "Escape",
        123: "Left Arrow", 124: "Right Arrow", 125: "Down Arrow", 126: "Up Arrow",
    ]
}
