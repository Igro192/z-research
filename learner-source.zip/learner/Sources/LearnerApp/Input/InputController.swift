import ApplicationServices
import CoreGraphics
import LearnerCore

/// Universal keyboard/mouse output. It depends only on normal macOS input
/// events and target geometry; no game API, accessibility tree, or integration.
final class InputController: @unchecked Sendable {
    let targetPID: pid_t?
    private let bounds: CodableRect

    init(targetPID: pid_t?, bounds: CodableRect) {
        self.targetPID = targetPID
        self.bounds = bounds
    }

    func send(_ action: InputEventRecord) {
        switch action.type {
        case .keyDown, .keyUp:
            guard let code = action.keyCode,
                  let event = CGEvent(
                    keyboardEventSource: nil,
                    virtualKey: CGKeyCode(code),
                    keyDown: action.type == .keyDown
                  ) else { return }
            post(event)
        case .mouseButtonDown, .mouseButtonUp:
            let button = mouseButton(action.button)
            let down = action.type == .mouseButtonDown
            let eventType: CGEventType = switch (button, down) {
            case (.left, true): .leftMouseDown
            case (.left, false): .leftMouseUp
            case (.right, true): .rightMouseDown
            case (.right, false): .rightMouseUp
            case (_, true): .otherMouseDown
            case (_, false): .otherMouseUp
            }
            guard let event = CGEvent(
                mouseEventSource: nil,
                mouseType: eventType,
                mouseCursorPosition: point(x: action.x, y: action.y),
                mouseButton: button
            ) else { return }
            post(event)
        case .mouseMove:
            guard let event = CGEvent(
                mouseEventSource: nil,
                mouseType: .mouseMoved,
                mouseCursorPosition: point(x: action.x, y: action.y),
                mouseButton: .left
            ) else { return }
            if let deltaX = action.deltaX { event.setDoubleValueField(.mouseEventDeltaX, value: deltaX) }
            if let deltaY = action.deltaY { event.setDoubleValueField(.mouseEventDeltaY, value: deltaY) }
            post(event)
        case .scroll:
            guard let event = CGEvent(
                scrollWheelEvent2Source: nil,
                units: .pixel,
                wheelCount: 2,
                wheel1: Int32(action.scrollY ?? 0),
                wheel2: Int32(action.scrollX ?? 0),
                wheel3: 0
            ) else { return }
            post(event)
        case .modifiersChanged:
            // The physical modifier remains active while a user is correcting.
            // Explicit key down/up records carry ordinary non-modifier controls.
            break
        }
    }

    func click(normalizedX: Double, normalizedY: Double, buttonName: String = "Left") {
        for type in [RecordedInputType.mouseButtonDown, .mouseButtonUp] {
            send(InputEventRecord(
                timestampNs: 0,
                type: type,
                x: normalizedX,
                y: normalizedY,
                button: buttonName
            ))
        }
    }

    private func point(x: Double?, y: Double?) -> CGPoint {
        CGPoint(
            x: bounds.x + min(max(x ?? 0.5, 0), 1) * bounds.width,
            y: bounds.y + min(max(y ?? 0.5, 0), 1) * bounds.height
        )
    }

    private func mouseButton(_ name: String?) -> CGMouseButton {
        switch name {
        case "Right": .right
        case "Middle": .center
        default: .left
        }
    }

    private func post(_ event: CGEvent) {
        event.setIntegerValueField(.eventSourceUserData, value: InputRecorder.synthesizedEventSignature)
        if let targetPID { event.postToPid(targetPID) }
        else { event.post(tap: .cghidEventTap) }
    }
}
