import AppKit
import ApplicationServices
import CoreGraphics
import LearnerCore

struct InputLiveState: Equatable, Sendable {
    var heldKeys: [String] = []
    var modifiers: [String] = []
    var heldButtons: [String] = []
    var cursorX: Double = 0
    var cursorY: Double = 0
    var deltaX: Double = 0
    var deltaY: Double = 0
}

final class InputRecorder: @unchecked Sendable {
    static let synthesizedEventSignature: Int64 = 0x4C4541524E4552
    var onEvent: ((InputEventRecord, UInt64) -> Void)?
    var onState: ((InputLiveState) -> Void)?

    private var eventTap: CFMachPort?
    private var runLoopSource: CFRunLoopSource?
    private var source: CaptureSourceDescriptor?
    private var heldKeys = Set<String>()
    private var heldButtons = Set<String>()
    private var lastFlags: CGEventFlags = []
    private var observeGlobally = false
    private var ignoreLearnerEvents = false

    func start(
        for source: CaptureSourceDescriptor,
        observeGlobally: Bool = false,
        ignoreLearnerEvents: Bool = false
    ) throws {
        stop()
        self.source = source
        self.observeGlobally = observeGlobally
        self.ignoreLearnerEvents = ignoreLearnerEvents
        let types: [CGEventType] = [
            .keyDown, .keyUp, .flagsChanged,
            .mouseMoved, .leftMouseDragged, .rightMouseDragged, .otherMouseDragged,
            .leftMouseDown, .leftMouseUp, .rightMouseDown, .rightMouseUp, .otherMouseDown, .otherMouseUp,
            .scrollWheel,
        ]
        let mask = types.reduce(CGEventMask(0)) { $0 | (CGEventMask(1) << CGEventMask($1.rawValue)) }
        let pointer = Unmanaged.passUnretained(self).toOpaque()
        guard let tap = CGEvent.tapCreate(
            tap: .cgSessionEventTap,
            place: .headInsertEventTap,
            options: .listenOnly,
            eventsOfInterest: mask,
            callback: { _, type, event, userInfo in
                guard let userInfo else { return Unmanaged.passUnretained(event) }
                let recorder = Unmanaged<InputRecorder>.fromOpaque(userInfo).takeUnretainedValue()
                recorder.handle(type: type, event: event)
                return Unmanaged.passUnretained(event)
            },
            userInfo: pointer
        ) else {
            throw InputError.permissionDenied
        }
        eventTap = tap
        let loopSource = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, tap, 0)
        runLoopSource = loopSource
        CFRunLoopAddSource(CFRunLoopGetMain(), loopSource, .commonModes)
        CGEvent.tapEnable(tap: tap, enable: true)
    }

    func stop() {
        if let eventTap { CGEvent.tapEnable(tap: eventTap, enable: false) }
        if let runLoopSource { CFRunLoopRemoveSource(CFRunLoopGetMain(), runLoopSource, .commonModes) }
        eventTap = nil
        runLoopSource = nil
        heldKeys.removeAll()
        heldButtons.removeAll()
        lastFlags = []
        observeGlobally = false
        ignoreLearnerEvents = false
        emitState(event: nil)
    }

    private func handle(type: CGEventType, event: CGEvent) {
        if type == .tapDisabledByTimeout || type == .tapDisabledByUserInput {
            if let eventTap { CGEvent.tapEnable(tap: eventTap, enable: true) }
            return
        }
        // Agent and preview-forwarded events carry this marker. They must never
        // masquerade as human corrections or trigger an override feedback loop.
        guard event.getIntegerValueField(.eventSourceUserData) != Self.synthesizedEventSignature,
              shouldRecordEvent(type: type, event: event) else { return }
        let rawTimestamp = DispatchTime.now().uptimeNanoseconds
        let modifiers = modifierNames(event.flags)
        let point = normalizedPoint(event.location)
        var record: InputEventRecord?

        switch type {
        case .keyDown, .keyUp:
            let code = Int(event.getIntegerValueField(.keyboardEventKeycode))
            let key = keyName(code: code, event: event)
            if type == .keyDown { heldKeys.insert(key) } else { heldKeys.remove(key) }
            record = InputEventRecord(
                timestampNs: 0,
                type: type == .keyDown ? .keyDown : .keyUp,
                keyCode: code,
                key: key,
                isRepeat: event.getIntegerValueField(.keyboardEventAutorepeat) != 0,
                heldKeys: heldKeys.sorted(),
                modifiers: modifiers,
                heldButtons: heldButtons.sorted()
            )
        case .flagsChanged:
            let code = Int(event.getIntegerValueField(.keyboardEventKeycode))
            let key = keyName(code: code, event: event)
            lastFlags = event.flags
            record = InputEventRecord(
                timestampNs: 0,
                type: .modifiersChanged,
                keyCode: code,
                key: key,
                heldKeys: heldKeys.sorted(),
                modifiers: modifiers,
                heldButtons: heldButtons.sorted()
            )
        case .mouseMoved, .leftMouseDragged, .rightMouseDragged, .otherMouseDragged:
            record = InputEventRecord(
                timestampNs: 0,
                type: .mouseMove,
                heldKeys: heldKeys.sorted(),
                modifiers: modifiers,
                x: point.x,
                y: point.y,
                deltaX: Double(event.getIntegerValueField(.mouseEventDeltaX)),
                deltaY: Double(event.getIntegerValueField(.mouseEventDeltaY)),
                heldButtons: heldButtons.sorted()
            )
        case .leftMouseDown, .rightMouseDown, .otherMouseDown, .leftMouseUp, .rightMouseUp, .otherMouseUp:
            let button = mouseButtonName(type: type, event: event)
            let isDown = type == .leftMouseDown || type == .rightMouseDown || type == .otherMouseDown
            if isDown { heldButtons.insert(button) } else { heldButtons.remove(button) }
            record = InputEventRecord(
                timestampNs: 0,
                type: isDown ? .mouseButtonDown : .mouseButtonUp,
                heldKeys: heldKeys.sorted(),
                modifiers: modifiers,
                x: point.x,
                y: point.y,
                button: button,
                heldButtons: heldButtons.sorted()
            )
        case .scrollWheel:
            record = InputEventRecord(
                timestampNs: 0,
                type: .scroll,
                heldKeys: heldKeys.sorted(),
                modifiers: modifiers,
                x: point.x,
                y: point.y,
                heldButtons: heldButtons.sorted(),
                scrollX: event.getDoubleValueField(.scrollWheelEventPointDeltaAxis2),
                scrollY: event.getDoubleValueField(.scrollWheelEventPointDeltaAxis1)
            )
        default:
            break
        }

        if let record {
            onEvent?(record, rawTimestamp)
            emitState(event: record)
        }
    }

    private func shouldRecordEvent(type: CGEventType, event: CGEvent) -> Bool {
        if ignoreLearnerEvents {
            let deliveredPID = pid_t(event.getIntegerValueField(.eventTargetUnixProcessID))
            let learnerPID = ProcessInfo.processInfo.processIdentifier
            if deliveredPID == learnerPID { return false }
            if deliveredPID > 0, let targetPID = source?.ownerPID, deliveredPID != targetPID {
                return false
            }

            // Practice observes globally so a person can grab the real target at
            // any time. Learner's own buttons and preview are not global
            // corrections: preview events are forwarded explicitly by AppModel.
            if NSApp.isActive ||
                NSWorkspace.shared.frontmostApplication?.processIdentifier == ProcessInfo.processInfo.processIdentifier {
                return false
            }

            // A click or software-cursor movement outside a selected window is
            // unrelated desktop input. Without this guard, moving across
            // Learner's controls could create hundreds of false corrections.
            if Self.pointerEventTypes.contains(type), let source, source.kind == .window {
                let bounds = CGRect(
                    x: source.bounds.x,
                    y: source.bounds.y,
                    width: source.bounds.width,
                    height: source.bounds.height
                )
                guard bounds.contains(event.location) else { return false }
            }

            // Keyboard input delivered to another app is not a correction for
            // this target. Input typed through Learner's preview arrives via
            // handlePreviewInput and therefore does not need this event tap.
            if Self.keyboardEventTypes.contains(type),
               let targetPID = source?.ownerPID,
               NSWorkspace.shared.frontmostApplication?.processIdentifier != targetPID {
                return false
            }
        }
        if observeGlobally { return true }
        guard let source, source.kind == .window, let targetPID = source.ownerPID else { return true }
        return NSWorkspace.shared.frontmostApplication?.processIdentifier == targetPID
    }

    private func normalizedPoint(_ point: CGPoint) -> (x: Double, y: Double) {
        guard let source else { return (point.x, point.y) }
        let bounds = source.bounds
        let x = (point.x - bounds.x) / max(1, bounds.width)
        let y = (point.y - bounds.y) / max(1, bounds.height)
        return (min(max(x, 0), 1), min(max(y, 0), 1))
    }

    private func emitState(event: InputEventRecord?) {
        let state = InputLiveState(
            heldKeys: heldKeys.sorted(),
            modifiers: event?.modifiers ?? modifierNames(lastFlags),
            heldButtons: heldButtons.sorted(),
            cursorX: event?.x ?? 0,
            cursorY: event?.y ?? 0,
            deltaX: event?.deltaX ?? 0,
            deltaY: event?.deltaY ?? 0
        )
        onState?(state)
    }

    private func modifierNames(_ flags: CGEventFlags) -> [String] {
        var names: [String] = []
        if flags.contains(.maskCommand) { names.append("Command") }
        if flags.contains(.maskShift) { names.append("Shift") }
        if flags.contains(.maskControl) { names.append("Control") }
        if flags.contains(.maskAlternate) { names.append("Option") }
        if flags.contains(.maskSecondaryFn) { names.append("Fn") }
        if flags.contains(.maskAlphaShift) { names.append("Caps Lock") }
        return names
    }

    private func mouseButtonName(type: CGEventType, event: CGEvent) -> String {
        switch type {
        case .leftMouseDown, .leftMouseUp: return "Left"
        case .rightMouseDown, .rightMouseUp: return "Right"
        default:
            let number = event.getIntegerValueField(.mouseEventButtonNumber)
            return number == 2 ? "Middle" : "Button \(number + 1)"
        }
    }

    private func keyName(code: Int, event: CGEvent) -> String {
        if let known = Self.keyNames[code] { return known }
        var length = 0
        var characters = [UniChar](repeating: 0, count: 8)
        event.keyboardGetUnicodeString(maxStringLength: characters.count, actualStringLength: &length, unicodeString: &characters)
        if length > 0 {
            return String(utf16CodeUnits: characters, count: length).uppercased()
        }
        return "Key \(code)"
    }

    enum InputError: LocalizedError {
        case permissionDenied
        var errorDescription: String? {
            "Input Monitoring permission is required to record keyboard and mouse events."
        }
    }

    private static let keyNames: [Int: String] = [
        0: "A", 1: "S", 2: "D", 3: "F", 4: "H", 5: "G", 6: "Z", 7: "X", 8: "C", 9: "V",
        11: "B", 12: "Q", 13: "W", 14: "E", 15: "R", 16: "Y", 17: "T", 18: "1", 19: "2", 20: "3",
        21: "4", 22: "6", 23: "5", 24: "=", 25: "9", 26: "7", 27: "-", 28: "8", 29: "0", 30: "]",
        31: "O", 32: "U", 33: "[", 34: "I", 35: "P", 36: "Return", 37: "L", 38: "J", 39: "'",
        40: "K", 41: ";", 42: "\\", 43: ",", 44: "/", 45: "N", 46: "M", 47: ".", 48: "Tab",
        49: "Space", 50: "`", 51: "Delete", 53: "Escape", 55: "Command", 56: "Shift", 57: "Caps Lock",
        58: "Option", 59: "Control", 60: "Right Shift", 61: "Right Option", 62: "Right Control", 63: "Fn",
        65: "Keypad .", 67: "Keypad *", 69: "Keypad +", 71: "Clear", 75: "Keypad /", 76: "Keypad Enter",
        78: "Keypad -", 81: "Keypad =", 82: "Keypad 0", 83: "Keypad 1", 84: "Keypad 2", 85: "Keypad 3",
        86: "Keypad 4", 87: "Keypad 5", 88: "Keypad 6", 89: "Keypad 7", 91: "Keypad 8", 92: "Keypad 9",
        96: "F5", 97: "F6", 98: "F7", 99: "F3", 100: "F8", 101: "F9", 103: "F11", 109: "F10",
        111: "F12", 115: "Home", 116: "Page Up", 117: "Forward Delete", 119: "End", 120: "F2",
        121: "Page Down", 122: "F1", 123: "Left Arrow", 124: "Right Arrow", 125: "Down Arrow", 126: "Up Arrow",
    ]

    private static let pointerEventTypes: Set<CGEventType> = [
        .mouseMoved, .leftMouseDragged, .rightMouseDragged, .otherMouseDragged,
        .leftMouseDown, .leftMouseUp, .rightMouseDown, .rightMouseUp,
        .otherMouseDown, .otherMouseUp, .scrollWheel,
    ]

    private static let keyboardEventTypes: Set<CGEventType> = [.keyDown, .keyUp, .flagsChanged]
}
