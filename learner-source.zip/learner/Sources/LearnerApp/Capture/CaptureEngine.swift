import AVFoundation
import CoreGraphics
import CoreMedia
import ScreenCaptureKit
import LearnerCore

final class CaptureEngine: NSObject, @unchecked Sendable {
    typealias FrameHandler = (CVPixelBuffer, VideoDimensions, UInt64) -> Void

    var onPreview: ((CGImage, VideoDimensions) -> Void)?
    var onFrame: FrameHandler?
    var onStopped: ((Error) -> Void)?

    private let outputQueue = DispatchQueue(label: "app.learner.capture", qos: .userInteractive)
    private var stream: SCStream?
    private var activeStreamConfiguration: SCStreamConfiguration?
    private var activeSourceSize: CGSize?
    private var processor: FrameProcessor
    private var configuration: VisionConfiguration
    private var lastPreviewNs: UInt64 = 0
    private let stateLock = NSLock()
    private(set) var lastFrameArrivalNs: UInt64 = 0
    private var latestFrameBuffer: CVPixelBuffer?
    private var latestFrameDimensions: VideoDimensions?

    init(configuration: VisionConfiguration) {
        self.configuration = configuration
        self.processor = FrameProcessor(configuration: configuration)
        super.init()
    }

    func start(source: CaptureSourceDescriptor) async throws {
        await stop()
        let (filter, sourceSize) = try await CaptureSourceProvider.resolve(source)
        let streamConfiguration = makeStreamConfiguration(sourceSize: sourceSize)
        activeStreamConfiguration = streamConfiguration
        activeSourceSize = sourceSize
        let newStream = SCStream(filter: filter, configuration: streamConfiguration, delegate: self)
        try newStream.addStreamOutput(self, type: .screen, sampleHandlerQueue: outputQueue)
        stream = newStream
        try await newStream.startCapture()
    }

    func stop() async {
        let previousStream = stream
        self.stream = nil
        activeStreamConfiguration = nil
        activeSourceSize = nil
        stateLock.withLock {
            lastFrameArrivalNs = 0
            latestFrameBuffer = nil
            latestFrameDimensions = nil
        }
        guard let previousStream else { return }
        try? await previousStream.stopCapture()
        try? previousStream.removeStreamOutput(self, type: .screen)
    }

    func update(configuration: VisionConfiguration) async throws {
        self.configuration = configuration
        processor.update(configuration: configuration)
        guard let stream, let sourceSize = activeSourceSize else { return }
        let current = makeStreamConfiguration(sourceSize: sourceSize)
        activeStreamConfiguration = current
        try await stream.updateConfiguration(current)
    }

    func secondsSinceLastFrame() -> Double {
        stateLock.lock()
        let last = lastFrameArrivalNs
        stateLock.unlock()
        guard last > 0 else { return .infinity }
        return Double(DispatchTime.now().uptimeNanoseconds - last) / 1_000_000_000
    }

    func latestFrame() -> (CVPixelBuffer, VideoDimensions, UInt64)? {
        stateLock.lock()
        defer { stateLock.unlock() }
        guard let latestFrameBuffer, let latestFrameDimensions, lastFrameArrivalNs > 0 else { return nil }
        return (latestFrameBuffer, latestFrameDimensions, lastFrameArrivalNs)
    }

    /// Replays the most recent processed observation when ScreenCaptureKit
    /// suppresses an unchanged frame. This keeps consumers such as the live
    /// agent on a continuous clock without copying pixels through a slow path.
    func replayLatestFrame() {
        guard let (buffer, dimensions, _) = latestFrame() else { return }
        outputQueue.async { [weak self] in
            self?.onFrame?(buffer, dimensions, DispatchTime.now().uptimeNanoseconds)
        }
    }

    /// Seeds capture from a one-shot screenshot when a game/display stream is
    /// valid but has not emitted a fresh composited frame yet.
    @discardableResult
    func seedFrame(from image: CGImage) -> (CGImage, VideoDimensions)? {
        guard let (processed, dimensions) = processor.process(image),
              let preview = processor.previewImage(from: processed) else { return nil }
        let timestamp = DispatchTime.now().uptimeNanoseconds
        stateLock.withLock {
            lastFrameArrivalNs = timestamp
            latestFrameBuffer = processed
            latestFrameDimensions = dimensions
        }
        onFrame?(processed, dimensions, timestamp)
        onPreview?(preview, dimensions)
        return (preview, dimensions)
    }

    private func makeStreamConfiguration(sourceSize: CGSize) -> SCStreamConfiguration {
        let config = SCStreamConfiguration()
        let nativeScale: CGFloat = 2
        let requested = configuration.resolution.dimensions
        config.width = requested?.0 ?? min(4096, max(2, Int(sourceSize.width * nativeScale)))
        config.height = requested?.1 ?? min(2304, max(2, Int(sourceSize.height * nativeScale)))
        config.minimumFrameInterval = CMTime(value: 1, timescale: CMTimeScale(configuration.fps))
        config.queueDepth = 5
        config.pixelFormat = kCVPixelFormatType_32BGRA
        config.showsCursor = true
        config.capturesAudio = false
        return config
    }
}

extension CaptureEngine: SCStreamOutput, SCStreamDelegate {
    func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        guard type == .screen,
              sampleBuffer.isValid,
              let source = sampleBuffer.imageBuffer,
              let (processed, dimensions) = processor.process(source) else { return }

        let timestamp = DispatchTime.now().uptimeNanoseconds
        stateLock.lock()
        lastFrameArrivalNs = timestamp
        latestFrameBuffer = processed
        latestFrameDimensions = dimensions
        stateLock.unlock()
        onFrame?(processed, dimensions, timestamp)

        if timestamp - lastPreviewNs >= 66_000_000,
           let preview = processor.previewImage(from: processed) {
            lastPreviewNs = timestamp
            onPreview?(preview, dimensions)
        }
    }

    func stream(_ stream: SCStream, didStopWithError error: Error) {
        onStopped?(error)
    }
}
