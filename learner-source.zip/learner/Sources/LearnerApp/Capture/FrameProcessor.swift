import CoreImage
import CoreVideo
import Metal
import LearnerCore

final class FrameProcessor: @unchecked Sendable {
    private let lock = NSLock()
    private let context: CIContext
    private var configuration: VisionConfiguration
    private var pool: CVPixelBufferPool?
    private var poolDimensions = VideoDimensions(width: 0, height: 0)

    init(configuration: VisionConfiguration) {
        self.configuration = configuration
        if let device = MTLCreateSystemDefaultDevice() {
            context = CIContext(mtlDevice: device, options: [.cacheIntermediates: false])
        } else {
            context = CIContext(options: [.cacheIntermediates: false])
        }
    }

    func update(configuration: VisionConfiguration) {
        lock.lock()
        self.configuration = configuration
        lock.unlock()
    }

    func process(_ sourceBuffer: CVPixelBuffer) -> (CVPixelBuffer, VideoDimensions)? {
        lock.lock()
        let config = configuration
        lock.unlock()

        let sourceWidth = CVPixelBufferGetWidth(sourceBuffer)
        let sourceHeight = CVPixelBufferGetHeight(sourceBuffer)
        let crop = config.crop.clamped()
        guard crop.isMeaningful else { return nil }

        let requested = config.resolution.dimensions
        let outputWidth = even(max(2, requested?.0 ?? Int(Double(sourceWidth) * crop.width)))
        let outputHeight = even(max(2, requested?.1 ?? Int(Double(sourceHeight) * crop.height)))
        let dimensions = VideoDimensions(width: outputWidth, height: outputHeight)

        guard let destination = makeBuffer(dimensions: dimensions) else { return nil }

        let sourceImage = CIImage(cvPixelBuffer: sourceBuffer)
        let sourceCrop = CGRect(
            x: Double(sourceWidth) * crop.x,
            y: Double(sourceHeight) * (1 - crop.y - crop.height),
            width: Double(sourceWidth) * crop.width,
            height: Double(sourceHeight) * crop.height
        ).integral
        guard sourceCrop.width > 1, sourceCrop.height > 1 else { return nil }

        var image = sourceImage
            .cropped(to: sourceCrop)
            .transformed(by: CGAffineTransform(translationX: -sourceCrop.minX, y: -sourceCrop.minY))
        image = image.transformed(
            by: CGAffineTransform(
                scaleX: Double(outputWidth) / sourceCrop.width,
                y: Double(outputHeight) / sourceCrop.height
            )
        )

        for mask in config.masks {
            let rect = mask.rect.clamped()
            let maskRect = CGRect(
                x: rect.x * Double(outputWidth),
                y: (1 - rect.y - rect.height) * Double(outputHeight),
                width: rect.width * Double(outputWidth),
                height: rect.height * Double(outputHeight)
            ).integral
            let neutral = CIImage(color: CIColor(red: 0.055, green: 0.065, blue: 0.08, alpha: 1))
                .cropped(to: maskRect)
            image = neutral.composited(over: image)
        }

        let bounds = CGRect(x: 0, y: 0, width: outputWidth, height: outputHeight)
        context.render(image, to: destination, bounds: bounds, colorSpace: CGColorSpace(name: CGColorSpace.sRGB))
        return (destination, dimensions)
    }

    /// Converts a one-shot ScreenCaptureKit screenshot into the same processed
    /// pixel pipeline used by live stream frames. This is a startup fallback for
    /// games whose compositor does not immediately emit a new stream frame.
    func process(_ sourceImage: CGImage) -> (CVPixelBuffer, VideoDimensions)? {
        let width = sourceImage.width
        let height = sourceImage.height
        guard width > 1, height > 1 else { return nil }
        var sourceBuffer: CVPixelBuffer?
        let attributes: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: width,
            kCVPixelBufferHeightKey as String: height,
            kCVPixelBufferIOSurfacePropertiesKey as String: [:],
            kCVPixelBufferMetalCompatibilityKey as String: true,
        ]
        guard CVPixelBufferCreate(
            nil,
            width,
            height,
            kCVPixelFormatType_32BGRA,
            attributes as CFDictionary,
            &sourceBuffer
        ) == kCVReturnSuccess, let sourceBuffer else { return nil }
        let bounds = CGRect(x: 0, y: 0, width: width, height: height)
        context.render(
            CIImage(cgImage: sourceImage),
            to: sourceBuffer,
            bounds: bounds,
            colorSpace: CGColorSpace(name: CGColorSpace.sRGB)
        )
        return process(sourceBuffer)
    }

    func previewImage(from buffer: CVPixelBuffer) -> CGImage? {
        let image = CIImage(cvPixelBuffer: buffer)
        return context.createCGImage(image, from: image.extent)
    }

    private func makeBuffer(dimensions: VideoDimensions) -> CVPixelBuffer? {
        lock.lock()
        defer { lock.unlock() }
        if pool == nil || poolDimensions != dimensions {
            let attributes: [String: Any] = [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: dimensions.width,
                kCVPixelBufferHeightKey as String: dimensions.height,
                kCVPixelBufferIOSurfacePropertiesKey as String: [:],
                kCVPixelBufferMetalCompatibilityKey as String: true,
            ]
            var newPool: CVPixelBufferPool?
            let status = CVPixelBufferPoolCreate(nil, nil, attributes as CFDictionary, &newPool)
            guard status == kCVReturnSuccess else { return nil }
            pool = newPool
            poolDimensions = dimensions
        }
        var buffer: CVPixelBuffer?
        guard let pool, CVPixelBufferPoolCreatePixelBuffer(nil, pool, &buffer) == kCVReturnSuccess else { return nil }
        return buffer
    }

    private func even(_ value: Int) -> Int { value.isMultiple(of: 2) ? value : value - 1 }
}
