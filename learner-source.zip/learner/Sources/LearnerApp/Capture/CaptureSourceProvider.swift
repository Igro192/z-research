import AppKit
import ScreenCaptureKit
import LearnerCore

enum CaptureSourceProvider {
    static func availableSources() async throws -> [CaptureSourceDescriptor] {
        // Include windows on other macOS Spaces. Selecting Learner commonly moves focus
        // away from a fullscreen game, but that must not make the game disappear here.
        let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: false)
        var windowSources: [CaptureSourceDescriptor] = []
        var otherSources: [CaptureSourceDescriptor] = []
        let windowOrder = frontToBackWindowOrder()

        for window in content.windows {
            guard window.frame.width >= 120,
                  window.frame.height >= 80,
                  let app = window.owningApplication,
                  app.bundleIdentifier != Bundle.main.bundleIdentifier else { continue }
            let runningApplication = NSRunningApplication(processIdentifier: app.processID)
            let isNormalApplication = runningApplication?.activationPolicy == .regular
            let isThirdPartyAccessory = runningApplication?.activationPolicy == .accessory
                && !app.bundleIdentifier.hasPrefix("com.apple.")
            guard isNormalApplication || isThirdPartyAccessory,
                  !app.applicationName.localizedCaseInsensitiveContains("Backstop") else { continue }
            let title = (window.title ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            // Off-Space windows need a real title; this omits dormant helper panels
            // while keeping normal game and browser windows selectable.
            guard window.isOnScreen || !title.isEmpty else { continue }
            windowSources.append(
                CaptureSourceDescriptor(
                    kind: .window,
                    windowID: window.windowID,
                    ownerPID: app.processID,
                    applicationName: app.applicationName,
                    windowTitle: title.isEmpty ? "Untitled Window" : title,
                    bundleIdentifier: app.bundleIdentifier,
                    bounds: .init(
                        x: window.frame.origin.x,
                        y: window.frame.origin.y,
                        width: window.frame.width,
                        height: window.frame.height
                    )
                )
            )
        }

        // Apps such as Chromium expose untitled compositor/helper windows in
        // addition to their real user window. Keep an untitled window only when
        // it is the app's sole captureable choice (common for native games).
        let ownersWithNamedWindows = Set(windowSources.compactMap { source in
            source.windowTitle == "Untitled Window" ? nil : source.ownerPID
        })
        windowSources.removeAll { source in
            source.windowTitle == "Untitled Window"
                && source.ownerPID.map(ownersWithNamedWindows.contains) == true
        }

        for (index, display) in content.displays.enumerated() {
            let descriptor = CaptureSourceDescriptor(
                kind: .display,
                displayID: display.displayID,
                applicationName: "Display \(index + 1)",
                windowTitle: "\(display.width) × \(display.height)",
                bounds: .init(x: display.frame.origin.x, y: display.frame.origin.y, width: display.frame.width, height: display.frame.height)
            )
            otherSources.append(descriptor)
            var region = descriptor
            region.kind = .region
            region.applicationName = "Custom Region — Display \(index + 1)"
            region.windowTitle = "Draw a crop after selection"
            otherSources.append(region)
        }

        // Keep the visually frontmost, most recently used windows first. This
        // makes the first card the game that was behind Learner in the common
        // Dock/Command-Tab workflow, without depending on game-specific APIs.
        windowSources.sort { left, right in
            let leftRank = left.windowID.flatMap { windowOrder[$0] } ?? Int.max
            let rightRank = right.windowID.flatMap { windowOrder[$0] } ?? Int.max
            if leftRank != rightRank { return leftRank < rightRank }
            let leftArea = left.bounds.width * left.bounds.height
            let rightArea = right.bounds.width * right.bounds.height
            if leftArea != rightArea { return leftArea > rightArea }
            return left.displayName.localizedStandardCompare(right.displayName) == .orderedAscending
        }
        otherSources.sort { $0.displayName.localizedStandardCompare($1.displayName) == .orderedAscending }
        return windowSources + otherSources
    }

    static func thumbnail(for descriptor: CaptureSourceDescriptor, maximumSize: CGSize = CGSize(width: 420, height: 236)) async throws -> CGImage {
        let (filter, sourceSize) = try await resolve(descriptor)
        let scale = min(1, min(
            maximumSize.width / max(1, sourceSize.width),
            maximumSize.height / max(1, sourceSize.height)
        ))
        let configuration = SCStreamConfiguration()
        configuration.width = max(2, Int(sourceSize.width * scale))
        configuration.height = max(2, Int(sourceSize.height * scale))
        configuration.showsCursor = false
        configuration.capturesAudio = false
        return try await SCScreenshotManager.captureImage(
            contentFilter: filter,
            configuration: configuration
        )
    }

    static func resolve(_ descriptor: CaptureSourceDescriptor) async throws -> (SCContentFilter, CGSize) {
        let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: false)
        switch descriptor.kind {
        case .window:
            guard let id = descriptor.windowID,
                  let window = content.windows.first(where: { $0.windowID == id }) else {
                throw CaptureError.sourceUnavailable
            }
            return (SCContentFilter(desktopIndependentWindow: window), window.frame.size)
        case .display, .region:
            guard let id = descriptor.displayID,
                  let display = content.displays.first(where: { $0.displayID == id }) else {
                throw CaptureError.sourceUnavailable
            }
            let learnerApplications = content.applications.filter {
                $0.bundleIdentifier == Bundle.main.bundleIdentifier
            }
            return (
                SCContentFilter(display: display, excludingApplications: learnerApplications, exceptingWindows: []),
                CGSize(width: display.width, height: display.height)
            )
        }
    }

    private static func frontToBackWindowOrder() -> [UInt32: Int] {
        guard let information = CGWindowListCopyWindowInfo(
            [.optionOnScreenOnly, .excludeDesktopElements],
            CGWindowID(0)
        ) as? [[String: Any]] else { return [:] }
        var result: [UInt32: Int] = [:]
        for (index, entry) in information.enumerated() {
            guard let number = entry[kCGWindowNumber as String] as? NSNumber else { continue }
            result[number.uint32Value] = index
        }
        return result
    }
}

enum CaptureError: LocalizedError {
    case sourceUnavailable
    case processingFailed

    var errorDescription: String? {
        switch self {
        case .sourceUnavailable: "The selected window or display is no longer available."
        case .processingFailed: "Learner could not process a captured frame."
        }
    }
}
