import Foundation

public let learnerSchemaVersion = 1

public enum CaptureSourceKind: String, Codable, CaseIterable, Sendable {
    case window
    case display
    case region

    public var label: String {
        switch self {
        case .window: "Window"
        case .display: "Display"
        case .region: "Custom Region"
        }
    }
}

public struct CodableRect: Codable, Hashable, Sendable {
    public var x: Double
    public var y: Double
    public var width: Double
    public var height: Double

    public init(x: Double, y: Double, width: Double, height: Double) {
        self.x = x
        self.y = y
        self.width = width
        self.height = height
    }
}

public struct NormalizedRect: Codable, Hashable, Sendable {
    public var x: Double
    public var y: Double
    public var width: Double
    public var height: Double

    public init(x: Double = 0, y: Double = 0, width: Double = 1, height: Double = 1) {
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        clampInPlace()
    }

    public var maxX: Double { x + width }
    public var maxY: Double { y + height }
    public var isMeaningful: Bool { width >= 0.01 && height >= 0.01 }

    public mutating func clampInPlace() {
        x = min(max(x, 0), 1)
        y = min(max(y, 0), 1)
        width = min(max(width, 0), 1 - x)
        height = min(max(height, 0), 1 - y)
    }

    public func clamped() -> NormalizedRect {
        var copy = self
        copy.clampInPlace()
        return copy
    }
}

public struct CaptureSourceDescriptor: Codable, Hashable, Identifiable, Sendable {
    public var id: String { "\(kind.rawValue)-\(windowID ?? displayID ?? 0)" }
    public var kind: CaptureSourceKind
    public var displayID: UInt32?
    public var windowID: UInt32?
    public var ownerPID: Int32?
    public var applicationName: String
    public var windowTitle: String
    public var bundleIdentifier: String?
    public var bounds: CodableRect

    public init(
        kind: CaptureSourceKind,
        displayID: UInt32? = nil,
        windowID: UInt32? = nil,
        ownerPID: Int32? = nil,
        applicationName: String,
        windowTitle: String = "",
        bundleIdentifier: String? = nil,
        bounds: CodableRect
    ) {
        self.kind = kind
        self.displayID = displayID
        self.windowID = windowID
        self.ownerPID = ownerPID
        self.applicationName = applicationName
        self.windowTitle = windowTitle
        self.bundleIdentifier = bundleIdentifier
        self.bounds = bounds
    }

    public var displayName: String {
        if !windowTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return "\(applicationName) — \(windowTitle)"
        }
        return applicationName
    }
}

public enum CaptureResolution: String, Codable, CaseIterable, Sendable {
    case native
    case hd1080
    case hd720
    case compact

    public var label: String {
        switch self {
        case .native: "Native"
        case .hd1080: "1920 × 1080"
        case .hd720: "1280 × 720"
        case .compact: "960 × 540"
        }
    }

    public var dimensions: (Int, Int)? {
        switch self {
        case .native: nil
        case .hd1080: (1920, 1080)
        case .hd720: (1280, 720)
        case .compact: (960, 540)
        }
    }
}

public struct MaskRegion: Codable, Hashable, Identifiable, Sendable {
    public var id: UUID
    public var name: String
    public var rect: NormalizedRect

    public init(id: UUID = UUID(), name: String, rect: NormalizedRect) {
        self.id = id
        self.name = name
        self.rect = rect
    }
}

public struct ObservationRegion: Codable, Hashable, Identifiable, Sendable {
    public var id: UUID
    public var name: String
    public var rect: NormalizedRect
    public var exportSeparately: Bool

    public init(id: UUID = UUID(), name: String, rect: NormalizedRect, exportSeparately: Bool = false) {
        self.id = id
        self.name = name
        self.rect = rect
        self.exportSeparately = exportSeparately
    }
}

public struct VisionConfiguration: Codable, Hashable, Sendable {
    public var fps: Int
    public var resolution: CaptureResolution
    public var crop: NormalizedRect
    public var masks: [MaskRegion]
    public var regions: [ObservationRegion]

    public init(
        fps: Int = 30,
        resolution: CaptureResolution = .hd720,
        crop: NormalizedRect = .init(),
        masks: [MaskRegion] = [],
        regions: [ObservationRegion] = []
    ) {
        self.fps = min(max(fps, 1), 60)
        self.resolution = resolution
        self.crop = crop
        self.masks = masks
        self.regions = regions
    }
}

public struct VideoDimensions: Codable, Hashable, Sendable {
    public var width: Int
    public var height: Int

    public init(width: Int, height: Int) {
        self.width = width
        self.height = height
    }
}

public enum SessionStatus: String, Codable, Sendable {
    case recording
    case paused
    case complete
    case interrupted
    case failed
}

public enum ExperienceRole: String, Codable, CaseIterable, Sendable {
    case teach
    case practice
    case autopilot
    case correction
    case legacy
}

public struct SessionMetadata: Codable, Hashable, Identifiable, Sendable {
    public var schemaVersion: Int
    public var id: UUID
    public var name: String
    public var createdAt: Date
    public var updatedAt: Date
    public var target: CaptureSourceDescriptor
    public var vision: VisionConfiguration
    public var output: VideoDimensions
    public var durationNs: UInt64
    public var frameCount: Int
    public var actionCount: Int
    public var status: SessionStatus
    public var videoPath: String
    public var recoveredAfterCrash: Bool
    /// Optional so every V1 recording remains decodable without rewriting it.
    public var gameID: UUID?
    public var learningRole: ExperienceRole?

    public init(
        id: UUID = UUID(),
        name: String,
        createdAt: Date = Date(),
        target: CaptureSourceDescriptor,
        vision: VisionConfiguration,
        output: VideoDimensions,
        durationNs: UInt64 = 0,
        frameCount: Int = 0,
        actionCount: Int = 0,
        status: SessionStatus = .recording,
        videoPath: String = "video/observation.mp4",
        recoveredAfterCrash: Bool = false,
        gameID: UUID? = nil,
        learningRole: ExperienceRole? = nil
    ) {
        self.schemaVersion = learnerSchemaVersion
        self.id = id
        self.name = name
        self.createdAt = createdAt
        self.updatedAt = createdAt
        self.target = target
        self.vision = vision
        self.output = output
        self.durationNs = durationNs
        self.frameCount = frameCount
        self.actionCount = actionCount
        self.status = status
        self.videoPath = videoPath
        self.recoveredAfterCrash = recoveredAfterCrash
        self.gameID = gameID
        self.learningRole = learningRole
    }
}

public struct FrameRecord: Codable, Hashable, Sendable {
    public var frameIndex: Int
    public var timestampNs: UInt64
    public var videoPtsNs: UInt64

    public init(frameIndex: Int, timestampNs: UInt64, videoPtsNs: UInt64) {
        self.frameIndex = frameIndex
        self.timestampNs = timestampNs
        self.videoPtsNs = videoPtsNs
    }
}

public enum RecordedInputType: String, Codable, CaseIterable, Sendable {
    case keyDown
    case keyUp
    case modifiersChanged
    case mouseMove
    case mouseButtonDown
    case mouseButtonUp
    case scroll
}

public struct InputEventRecord: Codable, Hashable, Sendable {
    public var timestampNs: UInt64
    public var type: RecordedInputType
    public var keyCode: Int?
    public var key: String?
    public var isRepeat: Bool?
    public var heldKeys: [String]
    public var modifiers: [String]
    public var x: Double?
    public var y: Double?
    public var deltaX: Double?
    public var deltaY: Double?
    public var button: String?
    public var heldButtons: [String]
    public var scrollX: Double?
    public var scrollY: Double?

    public init(
        timestampNs: UInt64,
        type: RecordedInputType,
        keyCode: Int? = nil,
        key: String? = nil,
        isRepeat: Bool? = nil,
        heldKeys: [String] = [],
        modifiers: [String] = [],
        x: Double? = nil,
        y: Double? = nil,
        deltaX: Double? = nil,
        deltaY: Double? = nil,
        button: String? = nil,
        heldButtons: [String] = [],
        scrollX: Double? = nil,
        scrollY: Double? = nil
    ) {
        self.timestampNs = timestampNs
        self.type = type
        self.keyCode = keyCode
        self.key = key
        self.isRepeat = isRepeat
        self.heldKeys = heldKeys
        self.modifiers = modifiers
        self.x = x
        self.y = y
        self.deltaX = deltaX
        self.deltaY = deltaY
        self.button = button
        self.heldButtons = heldButtons
        self.scrollX = scrollX
        self.scrollY = scrollY
    }
}

public enum MarkerLabel: String, Codable, CaseIterable, Sendable {
    case good = "GOOD"
    case bad = "BAD"
    case important = "IMPORTANT"
    case ignore = "IGNORE"
}

public struct TimelineMarker: Codable, Hashable, Identifiable, Sendable {
    public var id: UUID
    public var timestampNs: UInt64
    public var endTimestampNs: UInt64?
    public var label: MarkerLabel
    public var note: String?

    public init(id: UUID = UUID(), timestampNs: UInt64, endTimestampNs: UInt64? = nil, label: MarkerLabel, note: String? = nil) {
        self.id = id
        self.timestampNs = timestampNs
        self.endTimestampNs = endTimestampNs
        self.label = label
        self.note = note
    }
}

public struct DatasetManifest: Codable, Hashable, Identifiable, Sendable {
    public var schemaVersion: Int
    public var id: UUID
    public var name: String
    public var createdAt: Date
    public var sessionIDs: [UUID]

    public init(id: UUID = UUID(), name: String, createdAt: Date = Date(), sessionIDs: [UUID]) {
        self.schemaVersion = learnerSchemaVersion
        self.id = id
        self.name = name
        self.createdAt = createdAt
        self.sessionIDs = sessionIDs
    }
}

/// The user-facing unit of learning. Datasets and model files remain internal
/// implementation details and are migrated into a project without deletion.
public struct GameProject: Codable, Hashable, Identifiable, Sendable {
    public var schemaVersion: Int
    public var id: UUID
    public var name: String
    public var createdAt: Date
    public var updatedAt: Date
    public var sessionIDs: [UUID]
    public var legacyDatasetIDs: [UUID]
    public var preferredTarget: CaptureSourceDescriptor?

    public init(
        id: UUID = UUID(),
        name: String,
        createdAt: Date = Date(),
        updatedAt: Date = Date(),
        sessionIDs: [UUID] = [],
        legacyDatasetIDs: [UUID] = [],
        preferredTarget: CaptureSourceDescriptor? = nil
    ) {
        self.schemaVersion = 2
        self.id = id
        self.name = name
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.sessionIDs = sessionIDs
        self.legacyDatasetIDs = legacyDatasetIDs
        self.preferredTarget = preferredTarget
    }
}

public struct DiscoveredState: Codable, Hashable, Identifiable, Sendable {
    public var id: Int
    public var observations: Int
    public var firstSeenSeconds: Double
    public var lastSeenSeconds: Double
    public var progressEstimate: Double?

    public init(id: Int, observations: Int, firstSeenSeconds: Double, lastSeenSeconds: Double, progressEstimate: Double? = nil) {
        self.id = id
        self.observations = observations
        self.firstSeenSeconds = firstSeenSeconds
        self.lastSeenSeconds = lastSeenSeconds
        self.progressEstimate = progressEstimate
    }
}

public struct DiscoveredSkill: Codable, Hashable, Identifiable, Sendable {
    public var id: String
    public var actionSequence: [String]
    public var occurrences: Int
    public var averageDurationSeconds: Double
    /// Optional for forward-compatible decoding of understanding files created
    /// before behavior confidence was measured.
    public var confidence: Double?
    public var relatedStateIDs: [Int]
    public var successfulUses: Int?
    public var failedUses: Int?
    public var dependencies: [String]

    public init(
        id: String,
        actionSequence: [String],
        occurrences: Int,
        averageDurationSeconds: Double,
        confidence: Double? = nil,
        relatedStateIDs: [Int] = [],
        successfulUses: Int? = nil,
        failedUses: Int? = nil,
        dependencies: [String] = []
    ) {
        self.id = id
        self.actionSequence = actionSequence
        self.occurrences = occurrences
        self.averageDurationSeconds = averageDurationSeconds
        self.confidence = confidence.map { min(max($0, 0), 1) }
        self.relatedStateIDs = relatedStateIDs
        self.successfulUses = successfulUses
        self.failedUses = failedUses
        self.dependencies = dependencies
    }
}

public struct LearnedTransition: Codable, Hashable, Identifiable, Sendable {
    public var id: String { "\(fromState)-\(skillID)-\(toState)" }
    public var fromState: Int
    public var skillID: String
    public var toState: Int
    public var observations: Int
    public var averageProgressDelta: Double

    public init(fromState: Int, skillID: String, toState: Int, observations: Int, averageProgressDelta: Double) {
        self.fromState = fromState
        self.skillID = skillID
        self.toState = toState
        self.observations = observations
        self.averageProgressDelta = averageProgressDelta
    }
}

public enum LearningEventKind: String, Codable, CaseIterable, Sendable {
    case newVisualState
    case majorVisualChange
    case inactivity
    case probableReset
    case humanCorrection
    case actionSequence
}

public struct LearningEvent: Codable, Hashable, Identifiable, Sendable {
    public var id: UUID
    public var kind: LearningEventKind
    public var timestampSeconds: Double
    public var detail: String

    public init(id: UUID = UUID(), kind: LearningEventKind, timestampSeconds: Double, detail: String) {
        self.id = id
        self.kind = kind
        self.timestampSeconds = timestampSeconds
        self.detail = detail
    }
}

/// Persisted output from real post-session discovery. Empty arrays mean the
/// subsystem has not discovered anything yet; the UI never invents counts.
public struct ProjectKnowledge: Codable, Hashable, Sendable {
    public var schemaVersion: Int
    public var updatedAt: Date
    public var processedSessionIDs: [UUID]
    public var states: [DiscoveredState]
    public var skills: [DiscoveredSkill]
    public var transitions: [LearnedTransition]
    public var recentEvents: [LearningEvent]
    public var correctionCount: Int

    public init(
        updatedAt: Date = Date(),
        processedSessionIDs: [UUID] = [],
        states: [DiscoveredState] = [],
        skills: [DiscoveredSkill] = [],
        transitions: [LearnedTransition] = [],
        recentEvents: [LearningEvent] = [],
        correctionCount: Int = 0
    ) {
        self.schemaVersion = 1
        self.updatedAt = updatedAt
        self.processedSessionIDs = processedSessionIDs
        self.states = states
        self.skills = skills
        self.transitions = transitions
        self.recentEvents = recentEvents
        self.correctionCount = correctionCount
    }
}

public struct CorrectionRecord: Codable, Hashable, Identifiable, Sendable {
    public var id: UUID
    public var createdAt: Date
    public var sessionID: UUID?
    public var timestampNs: UInt64
    public var agentConfidence: Double
    public var proposedControls: [String]
    public var humanAction: InputEventRecord

    public init(
        id: UUID = UUID(),
        createdAt: Date = Date(),
        sessionID: UUID? = nil,
        timestampNs: UInt64,
        agentConfidence: Double,
        proposedControls: [String],
        humanAction: InputEventRecord
    ) {
        self.id = id
        self.createdAt = createdAt
        self.sessionID = sessionID
        self.timestampNs = timestampNs
        self.agentConfidence = agentConfidence
        self.proposedControls = proposedControls
        self.humanAction = humanAction
    }
}

public struct SessionSummary: Identifiable, Hashable, Sendable {
    public let metadata: SessionMetadata
    public let directoryURL: URL
    public let sizeBytes: Int64

    public var id: UUID { metadata.id }

    public init(metadata: SessionMetadata, directoryURL: URL, sizeBytes: Int64) {
        self.metadata = metadata
        self.directoryURL = directoryURL
        self.sizeBytes = sizeBytes
    }
}
