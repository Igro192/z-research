import Foundation

public struct TrainingSampleIndex: Codable, Hashable, Sendable {
    public let sessionID: UUID
    public let frameIndex: Int
    public let nextFrameIndex: Int
    public let timestampNs: UInt64
    public let nextTimestampNs: UInt64
    public let actionRange: Range<Int>

    public init(
        sessionID: UUID,
        frameIndex: Int,
        nextFrameIndex: Int,
        timestampNs: UInt64,
        nextTimestampNs: UInt64,
        actionRange: Range<Int>
    ) {
        self.sessionID = sessionID
        self.frameIndex = frameIndex
        self.nextFrameIndex = nextFrameIndex
        self.timestampNs = timestampNs
        self.nextTimestampNs = nextTimestampNs
        self.actionRange = actionRange
    }
}

public enum SampleIndexBuilder {
    /// Builds causal transitions: actions after frame N and at or before frame N+1
    /// are paired with observation N -> observation N+1.
    public static func build(
        sessionID: UUID,
        frames: [FrameRecord],
        actions: [InputEventRecord]
    ) -> [TrainingSampleIndex] {
        guard frames.count > 1 else { return [] }
        let orderedFrames = frames.sorted { $0.timestampNs < $1.timestampNs }
        let orderedActions = actions.enumerated().sorted { $0.element.timestampNs < $1.element.timestampNs }
        var lower = 0
        var result: [TrainingSampleIndex] = []
        result.reserveCapacity(orderedFrames.count - 1)

        for index in 0..<(orderedFrames.count - 1) {
            let current = orderedFrames[index]
            let next = orderedFrames[index + 1]
            while lower < orderedActions.count && orderedActions[lower].element.timestampNs <= current.timestampNs {
                lower += 1
            }
            var upper = lower
            while upper < orderedActions.count && orderedActions[upper].element.timestampNs <= next.timestampNs {
                upper += 1
            }
            result.append(
                TrainingSampleIndex(
                    sessionID: sessionID,
                    frameIndex: current.frameIndex,
                    nextFrameIndex: next.frameIndex,
                    timestampNs: current.timestampNs,
                    nextTimestampNs: next.timestampNs,
                    actionRange: lower..<upper
                )
            )
            lower = upper
        }
        return result
    }
}

/// Extension point for future structured browser observations. Pixel capture never depends on it.
public protocol BrowserAdapter: Sendable {
    func observation(at timestampNs: UInt64) async throws -> BrowserObservation?
}

public struct BrowserObservation: Codable, Sendable {
    public var url: String?
    public var title: String?
    public var visibleText: String?

    public init(url: String? = nil, title: String? = nil, visibleText: String? = nil) {
        self.url = url
        self.title = title
        self.visibleText = visibleText
    }
}

public protocol ControllerAdapter: Sendable {
    func apply(action: InputEventRecord) async throws
}

// Architectural seams only. V1 deliberately ships no implementations.
public protocol BehaviorCloningTrainer: Sendable {}
public protocol AgentController: Sendable {}
public protocol RLTrainer: Sendable {}
public protocol VisionEncoder: Sendable {}
public protocol SkillMemory: Sendable {}
