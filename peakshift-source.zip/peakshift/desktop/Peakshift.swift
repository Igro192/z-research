import AppKit
import WebKit
import Network

// A self-contained WebKit game with a loopback-only asset server. The stable
// origin preserves local records across launches; no Node or network is needed.
final class GameServer {
    private let queue = DispatchQueue(label: "com.peakshift.assets")
    private let root: URL
    private var listener: NWListener?
    init(root: URL) { self.root = root.standardizedFileURL }

    func start(ready: @escaping (Result<URL, Error>) -> Void) throws {
        let parameters = NWParameters.tcp
        parameters.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: 48737)
        let listener = try NWListener(using: parameters)
        self.listener = listener
        listener.stateUpdateHandler = { state in
            switch state {
            case .ready: DispatchQueue.main.async { ready(.success(URL(string: "http://127.0.0.1:48737/")!)) }
            case .failed(let error): DispatchQueue.main.async { ready(.failure(error)) }
            default: break
            }
        }
        listener.newConnectionHandler = { [weak self] connection in
            guard let self = self else { connection.cancel(); return }
            connection.start(queue: self.queue)
            self.receive(connection, accumulated: Data())
        }
        listener.start(queue: queue)
    }

    private func receive(_ connection: NWConnection, accumulated: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 16384) { [weak self] data, _, complete, error in
            guard let self = self else { connection.cancel(); return }
            var request = accumulated
            if let data = data { request.append(data) }
            if request.count > 16384 || error != nil { connection.cancel(); return }
            if let text = String(data: request, encoding: .utf8), text.contains("\r\n\r\n") {
                self.respond(connection, request: text)
            } else if complete { connection.cancel() }
            else { self.receive(connection, accumulated: request) }
        }
    }

    private func respond(_ connection: NWConnection, request: String) {
        let first = request.components(separatedBy: "\r\n")[0].split(separator: " ")
        guard first.count == 3, first[0] == "GET" || first[0] == "HEAD" else {
            send(connection, status: "405 Method Not Allowed", type: "text/plain", body: Data()); return
        }
        let path = String(first[1]).components(separatedBy: "?")[0].removingPercentEncoding ?? ""
        let relative = path == "/" ? "index.html" : String(path.drop(while: { $0 == "/" }))
        let file = root.appendingPathComponent(relative).standardizedFileURL.resolvingSymlinksInPath()
        guard file.path.hasPrefix(root.path + "/"), let data = try? Data(contentsOf: file) else {
            send(connection, status: "404 Not Found", type: "text/plain", body: Data("Not found".utf8)); return
        }
        let types = ["html":"text/html; charset=utf-8", "js":"text/javascript; charset=utf-8", "css":"text/css", "wasm":"application/wasm", "json":"application/json", "png":"image/png", "svg":"image/svg+xml", "ico":"image/x-icon", "woff2":"font/woff2"]
        send(connection, status: "200 OK", type: types[file.pathExtension] ?? "application/octet-stream", body: data, head: first[0] == "HEAD")
    }

    private func send(_ connection: NWConnection, status: String, type: String, body: Data, head: Bool = false) {
        var response = Data("HTTP/1.1 \(status)\r\nContent-Type: \(type)\r\nContent-Length: \(body.count)\r\nCache-Control: no-cache\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n".utf8)
        if !head { response.append(body) }
        connection.send(content: response, completion: .contentProcessed { _ in connection.cancel() })
    }
    func stop() { listener?.cancel() }
}

final class GameWebView: WKWebView {
    // Unhandled game keys must not reach AppKit's default alert sound.
    override func doCommand(by selector: Selector) {}
}

final class GameApp: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKDownloadDelegate, WKScriptMessageHandler {
    private var window: NSWindow!
    private var webView: WKWebView!
    private var server: GameServer!
    private var gameURL: URL?
    private var renderRestarts = 0
    private let publicURL = URL(string: "https://peakshift-mountain-playground.igrothegreat.chatgpt.site")!

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        buildMenu()
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.userContentController.add(self, name: "gameError")
        config.userContentController.addUserScript(WKUserScript(source: "window.addEventListener('error', e => window.webkit.messageHandlers.gameError.postMessage(e.message || 'A game resource failed to load')); window.addEventListener('unhandledrejection', e => window.webkit.messageHandlers.gameError.postMessage(String(e.reason)));", injectionTime: .atDocumentStart, forMainFrameOnly: true))
        webView = GameWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.allowsBackForwardNavigationGestures = false
        webView.setValue(false, forKey: "drawsBackground")
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1280, height: 800), styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false)
        window.title = "PEAKSHIFT"
        window.isRestorable = false
        window.minSize = NSSize(width: 850, height: 570)
        window.collectionBehavior.insert(.fullScreenPrimary)
        window.backgroundColor = NSColor(calibratedRed: 0.05, green: 0.12, blue: 0.16, alpha: 1)
        let content = NSView(frame: NSRect(x: 0, y: 0, width: 1280, height: 800))
        webView.translatesAutoresizingMaskIntoConstraints = false
        content.addSubview(webView)
        NSLayoutConstraint.activate([webView.leadingAnchor.constraint(equalTo: content.leadingAnchor), webView.trailingAnchor.constraint(equalTo: content.trailingAnchor), webView.topAnchor.constraint(equalTo: content.topAnchor), webView.bottomAnchor.constraint(equalTo: content.bottomAnchor)])
        window.contentView = content
        window.center()
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        window.makeFirstResponder(webView)
        server = GameServer(root: Bundle.main.resourceURL!.appendingPathComponent("Game"))
        do {
            try server.start { [weak self] result in
                switch result {
                case .success(let url): self?.gameURL = url; self?.webView.load(URLRequest(url: url))
                case .failure(let error): self?.showError(error)
                }
            }
        } catch { showError(error) }
    }

    private func buildMenu() {
        let menu = NSMenu()
        let appItem = NSMenuItem(); menu.addItem(appItem)
        let appMenu = NSMenu(); appItem.submenu = appMenu
        appMenu.addItem(withTitle: "About PEAKSHIFT", action: #selector(about), keyEquivalent: "")
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "Hide PEAKSHIFT", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        appMenu.addItem(withTitle: "Quit PEAKSHIFT", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        let gameItem = NSMenuItem(); gameItem.title = "Game"; menu.addItem(gameItem)
        let gameMenu = NSMenu(title: "Game"); gameItem.submenu = gameMenu
        gameMenu.addItem(withTitle: "Reload Game", action: #selector(reload), keyEquivalent: "r")
        let fullscreen = gameMenu.addItem(withTitle: "Toggle Full Screen", action: #selector(fullScreen), keyEquivalent: "f")
        fullscreen.keyEquivalentModifierMask = [.command, .control]
        gameMenu.addItem(.separator())
        gameMenu.addItem(withTitle: "Open Public Browser Version", action: #selector(openBrowser), keyEquivalent: "b")
        gameMenu.addItem(withTitle: "Controls", action: #selector(controls), keyEquivalent: "?")
        NSApp.mainMenu = menu
    }
    @objc private func reload() { webView.reload(); window.makeFirstResponder(webView) }
    @objc private func fullScreen() { window.toggleFullScreen(nil) }
    @objc private func openBrowser() { NSWorkspace.shared.open(publicURL) }
    @objc private func about() { NSApp.orderFrontStandardAboutPanel(options: [.applicationName: "PEAKSHIFT", .applicationVersion: "3.7", .credits: NSAttributedString(string: "Snowboard the mountains.\nSeventeen distinct courses. Physical tricks. Your own line.\nIncludes the game for offline play.")]) }
    @objc private func controls() {
        let alert = NSAlert(); alert.messageText = "Find your line"
        alert.informativeText = "A / D: carve left / right\nW / S: tuck / brake\nHold Space, release: charge and pop\nWASD in the air: spins and flips\nZ / X: corks\nQ / E: nose / tail presses\nR: restart • Escape: pause\nControl–Command–F: full screen"
        alert.beginSheetModal(for: window)
    }
    private func showError(_ error: Error) {
        let alert = NSAlert(); alert.messageText = "PEAKSHIFT couldn’t start"
        alert.informativeText = "The local game server could not start. Quit another copy if it is running, then reopen PEAKSHIFT.\n\n\(error.localizedDescription)"
        alert.addButton(withTitle: "Open Browser Version"); alert.addButton(withTitle: "Quit")
        alert.beginSheetModal(for: window) { result in
            if result == .alertFirstButtonReturn { self.openBrowser() }
            NSApp.terminate(nil)
        }
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.shouldPerformDownload { decisionHandler(.download); return }
        if let url = navigationAction.request.url, url.scheme != "blob", url.host != "127.0.0.1" {
            NSWorkspace.shared.open(url); decisionHandler(.cancel)
        } else { decisionHandler(.allow) }
    }
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) { download.delegate = self }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { showError(error) }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        guard renderRestarts < 2, let url = gameURL else {
            let alert = NSAlert(); alert.messageText = "The game renderer stopped"
            alert.informativeText = "Reload from the Game menu to try again, or open the public browser version."
            alert.beginSheetModal(for: window); return
        }
        renderRestarts += 1
        webView.load(URLRequest(url: url))
    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        let alert = NSAlert(); alert.messageText = "The game couldn’t load"
        alert.informativeText = String(describing: message.body)
        alert.beginSheetModal(for: window)
    }
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let panel = NSSavePanel(); panel.nameFieldStringValue = suggestedFilename
        panel.beginSheetModal(for: window) { result in completionHandler(result == .OK ? panel.url : nil) }
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
    func applicationWillTerminate(_ notification: Notification) { server?.stop() }
}

let application = NSApplication.shared
let delegate = GameApp()
application.delegate = delegate
application.run()
