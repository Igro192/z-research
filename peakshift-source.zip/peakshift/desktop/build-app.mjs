import {cpSync,mkdirSync,writeFileSync,existsSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const source=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const destination=resolve(process.argv[2]||resolve(source,'../PEAKSHIFT.app'));
if(!existsSync(resolve(source,'dist/index.html')))throw Error('Run npm run build first');
if(existsSync(destination))throw Error(`Destination exists: ${destination}. Choose an empty path.`);
const contents=resolve(destination,'Contents'),resources=resolve(contents,'Resources'),macos=resolve(contents,'MacOS');
mkdirSync(resources,{recursive:true});mkdirSync(macos,{recursive:true});
cpSync(resolve(source,'dist'),resolve(resources,'Game'),{recursive:true});
const iconset=resolve(source,'desktop/Peakshift.iconset');mkdirSync(iconset,{recursive:true});
for(const size of[16,32,128,256,512])for(const scale of[1,2]){
 execFileSync('/usr/bin/sips',['-z',String(size*scale),String(size*scale),resolve(source,'desktop/icon.png'),'--out',resolve(iconset,`icon_${size}x${size}${scale===2?'@2x':''}.png`)],{stdio:'ignore'});
}
execFileSync('/usr/bin/iconutil',['-c','icns',iconset,'-o',resolve(resources,'Peakshift.icns')]);
writeFileSync(resolve(contents,'Info.plist'),`<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>PEAKSHIFT</string>
<key>CFBundleDisplayName</key><string>PEAKSHIFT</string>
<key>CFBundleIdentifier</key><string>com.peakshift.snowboard</string>
<key>CFBundleExecutable</key><string>PEAKSHIFT</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>3.7.0</string>
<key>CFBundleVersion</key><string>37</string>
<key>CFBundleIconFile</key><string>Peakshift</string>
<key>LSMinimumSystemVersion</key><string>13.0</string>
<key>LSApplicationCategoryType</key><string>public.app-category.sports-games</string>
<key>NSHighResolutionCapable</key><true/>
<key>NSAppTransportSecurity</key><dict><key>NSAllowsLocalNetworking</key><true/></dict>
</dict></plist>`);
execFileSync('/usr/bin/xcrun',['swiftc','-O','-target','arm64-apple-macos13.0','-framework','AppKit','-framework','WebKit','-framework','Network',resolve(source,'desktop/Peakshift.swift'),'-o',resolve(macos,'PEAKSHIFT')],{stdio:'inherit'});
// File-provider folders can stamp Finder metadata on a newly created .app.
try{execFileSync('/usr/bin/xattr',['-d','com.apple.FinderInfo',destination],{stdio:'ignore'});}catch{}
execFileSync('/usr/bin/codesign',['--force','--sign','-','--identifier','com.peakshift.snowboard',destination],{stdio:'inherit'});
console.log(`Built ${destination}`);
