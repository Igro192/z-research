import {beforeAll,it,expect} from 'vitest';
import * as THREE from 'three';
import {initPhysics,SnowboardPhysics,type TerrainWorldLike} from '../src/game/physics';
import {ActiveRider} from '../src/game/active-rider';
import {createRider,poseRider} from '../src/game/rider';
import {neutral,plane,advance} from './helpers';
beforeAll(initPhysics);
function hill():TerrainWorldLike{
 const height=(x:number,z:number)=>-z*.12+3*Math.exp(-(x*x+(z-25)**2)/144),normal=(x:number,z:number)=>new THREE.Vector3(height(x-.1,z)-height(x+.1,z),.2,height(x,z-.1)-height(x,z+.1)).normalize();
 const vertices:number[]=[],indices:number[]=[];
 for(let j=0;j<=100;j++)for(let i=0;i<=100;i++){const x=i-50,z=j-25;vertices.push(x,height(x,z),z);}
 for(let j=0;j<100;j++)for(let i=0;i<100;i++){const a=j*101+i;indices.push(a,a+101,a+1,a+1,a+101,a+102);}
 return{height,normal,objects:[],obstacles:[],collisionMesh:()=>({vertices:new Float32Array(vertices),indices:new Uint32Array(indices)})};
}
it.each([0,Math.PI/2,-Math.PI/2,Math.PI])('rides a gentle natural hill from heading %s without a scripted bail',heading=>{
 const w=hill(),p=new SnowboardPhysics(w),x=-16*Math.sin(heading),z=25-16*Math.cos(heading);p.reset(x,z,false,heading);
 const n=w.normal(x,z),v=new THREE.Vector3(Math.sin(heading)*12,0,Math.cos(heading)*12);v.y=-(v.x*n.x+v.z*n.z)/n.y;p.board.setLinvel(v,true);p.sync();
 const r=new ActiveRider(p);p.onEvent=e=>{if(e.type==='crash')r.release();};let travelled=0;
 try{for(let i=0;i<300;i++){const before=p.position.clone();p.update(neutral,1/120);travelled+=before.distanceTo(p.position);expect(p.position.y-w.height(p.position.x,p.position.z)).toBeGreaterThan(-.12);}
  expect(p.crashed).toBe(false);expect(travelled).toBeGreaterThan(10);expect(p.dynamics.bodies.len()).toBe(12);
 }finally{r.dispose();p.dispose();}
});
it('allows a new air trick during the previous landing recovery window',()=>{
 const p=new SnowboardPhysics(plane()),r=new ActiveRider(p);p.launchSpeed(14);
 try{
  advance(p,.4);p.landingRecovery=.8;r.jump(new THREE.Vector3(0,5,0));p.grounded=false;
  advance(p,.2,{pitch:-1});expect(p.flipRotation).toBeLessThan(-.2);
 }finally{r.dispose();p.dispose();}
});
it('keeps Method knees forward and clear of the back throughout its blend',()=>{
 const p=new SnowboardPhysics(plane(0)),reference=createRider('snowboard');p.position.y=5;p.grounded=false;p.airtime=.6;
 try{
  for(let i=0;i<100;i++){
   poseRider(reference,p,{...neutral,grab:true,grabStyle:'Method'},1/120);const a=reference.userData.parts;
   for(const knee of [a.leftKnee,a.rightKnee]){
    const world=knee.getWorldPosition(new THREE.Vector3()),local=a.pelvis.worldToLocal(world.clone());
    expect(local.z).toBeGreaterThan(0);
    const back=new THREE.Line3(a.torso.localToWorld(new THREE.Vector3(0,.08,-.18)),a.torso.localToWorld(new THREE.Vector3(0,.48,-.18)));
    expect(back.closestPointToPoint(world,true,new THREE.Vector3()).distanceTo(world)).toBeGreaterThan(.24);
   }
  }
  expect(reference.userData.pose.grabContact).toBe(true);
 }finally{p.dispose();}
});
it('keeps the physically simulated Method knees clear of the chest and uncrossed',()=>{
 const p=new SnowboardPhysics(plane()),r=new ActiveRider(p);p.launchSpeed(14);let samples=0;
 try{
  advance(p,1.1,{jump:true});
  for(let i=0;i<180;i++){
   p.update({...neutral,grab:i<120,grabStyle:'Method'},1/120);
   if(r.grip.joint){samples++;const j=r.ragdoll.poses(),spine=new THREE.Line3(j.hip.clone().lerp(j.chest,.35),j.chest);
    for(const knee of [j.lk,j.rk])expect(spine.closestPointToPoint(knee,true,new THREE.Vector3()).distanceTo(knee)).toBeGreaterThan(.2);
    expect(j.lk.clone().sub(j.rk).dot(new THREE.Vector3(0,0,1).applyQuaternion(p.orientation))).toBeGreaterThan(.1);
   }
  }
  expect(samples).toBeGreaterThan(45);advance(p,1);expect(p.crashed).toBe(false);
 }finally{r.dispose();p.dispose();}
});
