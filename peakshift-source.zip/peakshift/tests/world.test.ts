import { describe, it, expect } from 'vitest';
import * as THREE from 'three';
import { MountainWorld, MAPS } from '../src/game/world';

describe('mountain height field and world lifecycle', () => {
  it('loads all 17 mountain presets with finite spawns, clear first routes and downhill gradients', () => {
    const scene = new THREE.Scene();
    expect(new Set(MAPS.map(map => map.id)).size).toBe(17);
    for (const map of MAPS) {
      const world = new MountainWorld(scene, map);
      expect(map.vertical).toBe(Math.round(map.slope*1800));
      expect(world.height(0, 0)).toBeGreaterThan(400);
      expect(world.height(0, 0)).toBeLessThan(450);
      expect(world.height(0, 1200)).toBeLessThan(world.height(0, 0)-200);
      for (let z=0;z<=1800;z+=30) {
        expect(Number.isFinite(world.height(0,z))).toBe(true);
        expect(world.normal(0,z).length()).toBeCloseTo(1,5);
      }
      expect(world.obstacles.filter(o => Math.abs(o.x)<20 && o.z<300 && o.z>0)).toHaveLength(0);
      expect(world.objects.every(o=>o.id.startsWith('course37-'+map.id+'-'))).toBe(true);
      expect(world.group.children.length).toBeGreaterThan(2);
      world.update(new THREE.Vector3(0,world.height(0,1100),1100),1/60);
      world.dispose();
      expect(scene.children).toHaveLength(0);
    }
  },60000);

  it('releases every attached geometry and the snow texture when switching worlds', () => {
    const world=new MountainWorld(new THREE.Scene(),MAPS[0]);
    const geometries=new Set<THREE.BufferGeometry>();
    const textures=new Set<THREE.Texture>();
    world.group.traverse(obj=>{
      if(!(obj instanceof THREE.Mesh || obj instanceof THREE.Points || obj instanceof THREE.Line))return;
      geometries.add(obj.geometry);
      for(const material of Array.isArray(obj.material)?obj.material:[obj.material]) {
        for(const value of Object.values(material))if(value instanceof THREE.Texture)textures.add(value);
      }
    });
    let disposedGeometry=0,disposedTexture=0;
    geometries.forEach(g=>g.addEventListener('dispose',()=>disposedGeometry++));
    textures.forEach(t=>t.addEventListener('dispose',()=>disposedTexture++));
    expect(textures.size).toBeGreaterThan(0);
    world.dispose();
    expect(disposedGeometry).toBe(geometries.size);
    expect(disposedTexture).toBe(textures.size);
  });
  it('samples constructed jump surfaces and terrain edits using the same field', () => {
    const world=new MountainWorld(new THREE.Scene(),MAPS[0]);
    world.setObjects([]);
    const original=world.height(0,81);
    world.setObjects([{id:'test-ramp',type:'ramp',x:0,z:75,rotation:0,scale:1}]);
    expect(world.height(0,81)).toBeGreaterThan(original+2);
    const rampHeight=world.height(0,81);
    world.setEdits([{x:0,z:81,radius:10,amount:4,mode:'raise'}]);
    expect(world.height(0,81)).toBeCloseTo(rampHeight+4);
    world.setEdits([{x:0,z:81,radius:10,amount:4,mode:'lower'}]);
    expect(world.height(0,81)).toBeCloseTo(rampHeight-4);
    world.setEdits([{x:0,z:81,radius:10,amount:0,mode:'flatten',target:200}]);
    world.setObjects([]);
    expect(world.height(0,81)).toBe(200);
    world.dispose();
  });
  it('reproduces seeded terrain and scenery', () => {
    const a=new MountainWorld(new THREE.Scene(),MAPS[0]);
    const b=new MountainWorld(new THREE.Scene(),MAPS[0]);
    for (const [x,z] of [[0,0],[25,500],[-170,1200],[270,1810]]) {
      expect(a.height(x,z)).toBe(b.height(x,z));
      expect(a.normal(x,z).equals(b.normal(x,z))).toBe(true);
    }
    expect(a.obstacles).toEqual(b.obstacles);
    a.dispose();b.dispose();
  });
  it('keeps rendered chunk vertices on the shared collision surface after streaming', () => {
    const world=new MountainWorld(new THREE.Scene(),MAPS[0]);
    world.update(new THREE.Vector3(100,200,780),1/60);
    let samples=0;
    world.group.traverse(obj=>{
      if(!(obj instanceof THREE.Mesh) || !obj.name.startsWith('terrain-chunk-'))return;
      const p=obj.geometry.getAttribute('position');
      for(let i=0;i<p.count;i+=53) {
        expect(p.getY(i)).toBeCloseTo(world.groundHeight(p.getX(i),p.getZ(i)),3);
        samples++;
      }
    });
    expect(samples).toBeGreaterThan(100);
    world.dispose();
  });
});
