import {beforeAll,it,expect} from 'vitest';
import * as THREE from 'three';
import {initPhysics,SnowboardPhysics,landingIntercept} from '../src/game/physics';
import {ActiveRider} from '../src/game/active-rider';
import {plane,neutral,advance} from './helpers';
beforeAll(initPhysics);
it('predicts a ballistic contact against the track ahead',()=>{
 const t=landingIntercept(plane(0),new THREE.Vector3(0,2.055,0),new THREE.Vector3(0,-4,12));
 expect(t).toBeCloseTo((Math.sqrt(16+2*9.81*2)-4)/9.81,4);
 expect(landingIntercept(plane(0),new THREE.Vector3(0,20,0),new THREE.Vector3(0,4,12))).toBe(Infinity);
});
it.each([['turn',-1],['turn',1],['pitch',-1],['pitch',1],['roll',-1],['roll',1]] as const)('recovers a slightly off landing with a late held %s input (%s)',(key,direction)=>{
 const p=new SnowboardPhysics(plane()),r=new ActiveRider(p);p.launchSpeed(14);let landed=0,assist=0,held=false;
 p.onEvent=e=>{if(e.type==='land')landed++;if(e.type==='crash')r.release();};
 try{
  advance(p,1.1,{jump:true});
  for(let i=0;i<360;i++){if(!p.grounded&&landingIntercept(p.world,p.position,r.linearVelocity())<.1)held=true;p.update({...neutral,...(held?{[key]:direction}:{})},1/120);if(!p.grounded&&landed===0)expect(p.landingAssist).toBe(0);assist=Math.max(assist,p.landingAssist);}
  expect(assist).toBe(1);expect(p.crashed).toBe(false);expect(p.grounded).toBe(true);expect(landed).toBe(1);
  expect(new THREE.Vector3(0,1,0).applyQuaternion(p.orientation).dot(p.surfaceNormal)).toBeGreaterThan(.8);
 }finally{r.dispose();p.dispose();}
});
it('preserves requested rotation away from the touchdown window',()=>{
 const p=new SnowboardPhysics(plane()),r=new ActiveRider(p);p.launchSpeed(14);
 try{advance(p,1.1,{jump:true});advance(p,.6,{pitch:-1});expect(p.landingAssist).toBe(0);expect(p.flipRotation).toBeLessThan(-2);}
 finally{r.dispose();p.dispose();}
});

it('does not turn an airborne board upright automatically',()=>{
 const p=new SnowboardPhysics(plane(0));
 try{p.board.setTranslation({x:0,y:8,z:0},true);const q=new THREE.Quaternion().setFromEuler(new THREE.Euler(1.1,.7,.5));p.sync();p.grounded=false;advance(p,.05);p.board.setRotation(q,true);p.board.setAngvel({x:0,y:0,z:0},true);p.sync();advance(p,.2);expect(p.orientation.angleTo(q)).toBeLessThan(.001);expect(p.landingAssist).toBe(0);}
 finally{p.dispose();}
});
