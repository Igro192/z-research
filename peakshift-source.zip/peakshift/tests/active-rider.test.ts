import {beforeAll,describe,it,expect} from 'vitest';
import * as THREE from 'three';
import {initPhysics,SnowboardPhysics,RAPIER,type InputState} from '../src/game/physics';
import {ActiveRider} from '../src/game/active-rider';
import {createRider} from '../src/game/rider';
import {GRAB_NAMES} from '../src/game/tricks';
import {plane,bump,neutral,advance} from './helpers';

beforeAll(initPhysics);
function setup(slope=.22,speed=14){
 const physics=new SnowboardPhysics(plane(slope));physics.launchSpeed(speed);
 const rider=new ActiveRider(physics);
 physics.onEvent=e=>{if(e.type==='crash')rider.release();};
 return{physics,rider,dispose:()=>{rider.dispose();physics.dispose();}};
}
const velocity=(body:RAPIER.RigidBody)=>new THREE.Vector3().copy(body.linvel());

describe('continuously articulated snowboard rider',()=>{
 it('rides on twelve dynamic bodies with an 80 kg total mass and attached boots',()=>{
  const{physics:p,rider,dispose}=setup(),visible=createRider('snowboard');
  try{
   const bodies=[p.board,...rider.ragdoll.bodies];
   expect(bodies.reduce((mass,b)=>mass+b.mass(),0)).toBeCloseTo(80,3);
   expect(bodies.every(b=>b.isDynamic())).toBe(true);
   advance(p,3);rider.render(visible);
   expect(p.crashed).toBe(false);expect(p.speed).toBeGreaterThan(17);
   expect(p.dynamics.bodies.len()).toBe(12);expect(rider.ragdoll.joints).toHaveLength(12);
   const a=visible.userData.parts;
   for(const [side,boot]of [[1,a.leftAnkle],[-1,a.rightAnkle]]as const){
    expect(boot.getWorldPosition(new THREE.Vector3()).distanceTo(a.board.localToWorld(new THREE.Vector3(0,.245,side*.3)))).toBeLessThan(.035);
   }
  }finally{dispose();}
 });

 it.each([[-1,1],[1,-1]])('keeps A/D steering direction with the live skeleton (%s)',(turn,direction)=>{
  const{physics:p,dispose}=setup();
  try{advance(p,.9,{turn});expect(Math.sign(p.position.x)).toBe(direction);expect(p.crashed).toBe(false);}
  finally{dispose();}
 });

 it('distributes an assembly torque without adding a net translation force',()=>{
  const{physics:p,rider,dispose}=setup();
  try{
   const bodies=[p.board,...rider.ragdoll.bodies],centre=new THREE.Vector3(),mass=bodies.reduce((sum,b)=>sum+b.mass(),0);
   for(const b of bodies)centre.addScaledVector(new THREE.Vector3().copy(b.worldCom()),b.mass()/mass);
   const wanted=new THREE.Vector3(90,40,-60);rider.addTorque(wanted);
   const force=new THREE.Vector3(),torque=new THREE.Vector3();
   for(const b of bodies){const f=new THREE.Vector3().copy(b.userForce());force.add(f);torque.add(new THREE.Vector3().copy(b.userTorque())).add(new THREE.Vector3().crossVectors(new THREE.Vector3().copy(b.worldCom()).sub(centre),f));}
   expect(force.length()).toBeLessThan(.0001);expect(torque.distanceTo(wanted)).toBeLessThan(.001);
  }finally{dispose();}
 });

 it('a jump adds the same velocity to each body without artificial joint stretch',()=>{
  const{physics:p,rider,dispose}=setup();
  try{
   const bodies=[p.board,...rider.ragdoll.bodies],before=bodies.map(velocity),delta=new THREE.Vector3(.2,4,.1);
   rider.jump(delta);
   bodies.forEach((body,i)=>expect(velocity(body).sub(before[i]).distanceTo(delta)).toBeLessThan(.00001));
  }finally{dispose();}
 });

 it('holding Space longer produces a higher articulated jump',()=>{
  const heights:number[]=[];
  for(const charge of [.15,1.1]){
   const{physics:p,dispose}=setup(0,9.5);
   try{advance(p,charge,{jump:true});expect(p.grounded).toBe(true);const base=p.position.y;let peak=0;
    for(let i=0;i<180;i++){p.update(neutral,1/120);peak=Math.max(peak,p.position.y-base);}
    heights.push(peak);expect(p.crashed).toBe(false);
   }finally{dispose();}
  }
  expect(heights[1]).toBeGreaterThan(heights[0]*2);
 });

 it.each(GRAB_NAMES)('%s reaches the physical board and scores only sustained contact',style=>{
  const{physics:p,rider,dispose}=setup(),visible=createRider('snowboard');let contact=0;
  try{
   for(let i=0;i<330;i++){
    const t=i/60,input:InputState={...neutral,jump:t<1.1,grab:t>1.2&&t<2.4,grabStyle:style,grabContact:visible.userData.pose?.grabContact===true};
    p.update(input,1/60);rider.render(visible);
    if(visible.userData.pose.grabContact)contact+=1/60;
   }
   expect(contact).toBeGreaterThan(.5);expect(p.lastTrick).toContain(style);
   expect(p.score).toBeGreaterThan(200);expect(p.crashed).toBe(false);expect(p.grounded).toBe(true);
  }finally{dispose();}
 });

 it.each(GRAB_NAMES)('prepares to land %s even when its grab key stays held',style=>{
  const{physics:p,rider,dispose}=setup(),visible=createRider('snowboard');let landed='';
  p.onEvent=e=>{if(e.type==='land'&&!landed)landed=e.text||'';if(e.type==='crash')rider.release();};
  try{
   for(let i=0;i<270;i++){
    const t=i/60,input={...neutral,jump:t<1.1,grab:t>1.2,grabStyle:style,grabContact:visible.userData.pose?.grabContact===true};
    p.update(input,1/60);rider.render(visible);
   }
   expect(landed).toContain(style);expect(p.crashed).toBe(false);expect(p.grounded).toBe(true);
   expect(visible.userData.pose.grabContact).toBe(false);
  }finally{dispose();}
 });

 it.each([['Wildcat',{pitch:-1},1.1],['Cork',{roll:1},1.35]]as const)('physically rotates the torso and board for a landed %s',(name,input,duration)=>{
  const{physics:p,rider,dispose}=setup();let inverted=false;const landed:string[]=[];
  p.onEvent=e=>{if(e.type==='land')landed.push(e.text||'');if(e.type==='crash')rider.release();};
  try{
   advance(p,1.1,{jump:true});
   for(let i=0;i<duration*120;i++){
    p.update({...neutral,...input},1/120);
    if(new THREE.Vector3(0,1,0).applyQuaternion(new THREE.Quaternion().copy(rider.ragdoll.bodies[1].rotation())).y<-.4)inverted=true;
   }
   expect(inverted).toBe(true);advance(p,2.5);
   expect(landed.some(label=>label.includes(name))).toBe(true);expect(p.crashed).toBe(false);expect(p.grounded).toBe(true);
  }finally{dispose();}
 });

 it('lands a physical 180 and continues riding switch',()=>{
  const{physics:p,dispose}=setup();
  try{advance(p,1.1,{jump:true});advance(p,.58,{turn:1});advance(p,2.2);expect(p.crashed).toBe(false);expect(p.switch).toBe(true);expect(p.lastTrick).toMatch(/side 180/);}
  finally{dispose();}
 });

 it('a torso obstacle can cause a bail while the board clears underneath',()=>{
  const{physics:p,rider,dispose}=setup(0,12);let reason='';
  p.onEvent=e=>{if(e.type==='crash'){reason=e.text||'';rider.release();}};
  p.dynamics.createCollider(RAPIER.ColliderDesc.cuboid(2,.3,.18).setTranslation(0,1.4,8));
  try{advance(p,1.5);expect(p.crashed).toBe(true);expect(reason).toContain('BODY IMPACT');expect(p.position.z).toBeGreaterThan(6);}
  finally{dispose();}
 });

 it.each([12,24])('a sharp snow bump at %s transfers rotation into the live rider',at=>{
  const p=new SnowboardPhysics(bump(at,3,.25));p.launchSpeed(28);const rider=new ActiveRider(p);let peakAngular=0,peakHeight=0;
  p.onEvent=e=>{if(e.type==='crash')rider.release();};
  try{
   for(let i=0;i<720&&!p.crashed;i++){p.update(neutral,1/120);peakAngular=Math.max(peakAngular,p.angularVelocity.length());peakHeight=Math.max(peakHeight,p.position.y-p.world.height(p.position.x,p.position.z));}
   // Contact may launch, deflect or topple the rider; a bump is not a scripted bail.
   expect(peakAngular).toBeGreaterThan(4);expect(peakHeight).toBeGreaterThan(.4);expect(p.dynamics.bodies.len()).toBe(12);
   advance(p,2);for(const b of rider.ragdoll.bodies)expect(velocity(b).length()).toBeLessThan(90);
  }finally{rider.dispose();p.dispose();}
 });

 it('a bail releases the existing bodies without a model swap or momentum reset',()=>{
  const{physics:p,rider,dispose}=setup();
  try{
   advance(p,.7);const bodies=[p.board,...rider.ragdoll.bodies],handles=bodies.map(b=>b.handle),positions=bodies.map(b=>new THREE.Vector3().copy(b.translation())),velocities=bodies.map(velocity);
   p.bail('Test');expect(rider.release()).toBe(rider.ragdoll);
   expect([p.board,...rider.ragdoll.bodies].map(b=>b.handle)).toEqual(handles);
   bodies.forEach((b,i)=>{expect(velocity(b).distanceTo(velocities[i])).toBe(0);expect(new THREE.Vector3().copy(b.translation()).distanceTo(positions[i])).toBe(0);});
   advance(p,3);expect(p.dynamics.bodies.len()).toBe(12);
   for(const body of bodies){expect(velocity(body).length()).toBeLessThan(35);expect(new THREE.Vector3().copy(body.translation()).toArray().every(Number.isFinite)).toBe(true);}
  }finally{dispose();}
 });
});
