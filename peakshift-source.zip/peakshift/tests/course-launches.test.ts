import {beforeAll,it,expect} from 'vitest';
import * as THREE from 'three';
import {MountainWorld,MAPS} from '../src/game/world';
import {initPhysics,SnowboardPhysics} from '../src/game/physics';
import {ActiveRider} from '../src/game/active-rider';
import {neutral} from './helpers';
beforeAll(initPhysics);
it.each(['tabletop','hip','step-up'])('%s launches the articulated rider from actual snow contact without a pop button',type=>{
 const w=new MountainWorld(new THREE.Scene(),{...MAPS[0],slope:.18,vertical:324});w.setObjects([{id:'test',type,x:0,z:80,scale:1.2,rotation:0}]);
 const p=new SnowboardPhysics(w);p.launchSpeed(32);const r=new ActiveRider(p);let peak=0,landed=false,crashes=0;
 p.onEvent=e=>{if(e.type==='land'&&p.position.z>85)landed=true;if(e.type==='crash'){crashes++;r.release();}};
 try{
  for(let i=0;i<8*120&&!landed;i++){p.update(neutral,1/120);if(!p.grounded&&p.position.z>60)peak=Math.max(peak,p.position.y-w.groundHeight(p.position.x,p.position.z));}
  expect(peak).toBeGreaterThan(1);expect(landed).toBe(true);expect(p.score).toBeGreaterThan(0);expect(crashes).toBe(0);
 }finally{r.dispose();p.dispose();w.dispose();}
},15000);
