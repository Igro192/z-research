import {beforeAll,describe,it,expect} from 'vitest';
import * as THREE from 'three';
import {initPhysics,SnowboardPhysics} from '../src/game/physics';
import {createRider,poseRider} from '../src/game/rider';
import {keyboardInput,AirInputGate} from '../src/game/input';
import {plane,advance,neutral} from './helpers';
beforeAll(initPhysics);
describe('snowboard controls and articulated stance',()=>{
 it('has one snowboard and no skis or poles',()=>{const r=createRider('snowboard');expect(r.getObjectByName('snowboard')).toBeTruthy();expect(r.getObjectByName('left-ski')).toBeUndefined();expect(r.getObjectByName('right-ski')).toBeUndefined();expect(r.userData.parts.leftPole).toBeUndefined();expect(r.userData.parts.board.children.filter((c:THREE.Object3D)=>c instanceof THREE.Mesh).length).toBeGreaterThan(2);});
 it.each(['riding','charge','carve','air','grab'] as const)('keeps both boots on the same board through %s',state=>{const p=new SnowboardPhysics(plane()),r=createRider('snowboard');p.launchSpeed(14);const input={...neutral,jump:state==='charge',turn:state==='carve'?.5:0,grab:state==='grab',grabStyle:'Indy'};advance(p,.4,input);if(state==='air'||state==='grab'){p.board.setTranslation({x:p.position.x,y:p.position.y+5,z:p.position.z},true);p.grounded=false;p.airtime=.5;p.sync();}for(let i=0;i<20;i++)poseRider(r,p,input,1/60);const a=r.userData.parts;for(const[side,boot]of[[1,a.leftAnkle],[-1,a.rightAnkle]] as const)expect(boot.getWorldPosition(new THREE.Vector3()).distanceTo(a.board.localToWorld(new THREE.Vector3(0,.245,side*.3)))).toBeLessThan(.006);p.dispose();});
 it('turns the torso into spins and tucks the knees for a flip',()=>{const p=new SnowboardPhysics(plane()),r=createRider('snowboard');p.grounded=false;p.flipProgress=.5;p.spinWindup=.8;for(let i=0;i<20;i++)poseRider(r,p,{...neutral,pitch:-1},1/60);expect(r.userData.parts.pelvis.position.y).toBeLessThan(.75);expect(Math.abs(r.userData.parts.torso.rotation.y)).toBeGreaterThan(.05);p.dispose();});
 it('keeps ground presses and disables the retired air grabs',()=>{expect(keyboardInput(new Set(['ShiftLeft'])).grab).toBe(false);expect(keyboardInput(new Set(['KeyQ'])).grab).toBe(false);expect(keyboardInput(new Set(['KeyE'])).grab).toBe(false);expect(keyboardInput(new Set(['KeyE'])).press).toBe(1);expect(keyboardInput(new Set(['KeyA','KeyD'])).turn).toBe(0);});
 it('accepts held and freshly pressed WASD on the first airborne frame',()=>{
  const g=new AirInputGate();
  for(const [key,axis,value]of [['KeyW','airPitch',1],['KeyS','airPitch',-1],['KeyA','airTurn',-1],['KeyD','airTurn',1]]as const){
   const raw=keyboardInput(new Set([key]));g.read(raw,true,.5);expect(g.read(raw,false)[axis]).toBe(value);g.read(neutral,false);expect(g.read(raw,false)[axis]).toBe(value);g.reset();
  }
 });
});
