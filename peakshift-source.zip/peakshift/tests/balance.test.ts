import {beforeAll,describe,it,expect} from 'vitest';
import * as THREE from 'three';
import {initPhysics,SnowboardPhysics} from '../src/game/physics';
import {ActiveRider} from '../src/game/active-rider';
import {createRider,poseRider} from '../src/game/rider';
import {GRAB_NAMES} from '../src/game/tricks';
import {plane,neutral,advance} from './helpers';
beforeAll(initPhysics);
describe('anatomical stance and finite balance recovery',()=>{
 it.each(['riding','loading','carving',...GRAB_NAMES])('keeps hip, knee and boot order uncrossed in %s',style=>{
  const p=new SnowboardPhysics(plane()),r=createRider('snowboard');
  try{
   p.charge=style==='loading'?.8:0;p.edgeAngle=style==='carving'?.3:0;
   if(GRAB_NAMES.includes(style as typeof GRAB_NAMES[number])){p.board.setTranslation({x:0,y:5,z:0},true);p.sync();p.grounded=false;p.airtime=.5;}
   for(let i=0;i<40;i++)poseRider(r,p,{...neutral,grab:!p.grounded,grabStyle:style},1/60);
   const a=r.userData.parts,z=(node:THREE.Object3D)=>a.board.worldToLocal(node.getWorldPosition(new THREE.Vector3())).z;
   expect(z(a.leftAnkle)).toBeGreaterThan(z(a.rightAnkle)+.55);
   expect(z(a.leftLeg)).toBeGreaterThan(z(a.rightLeg)+.25);
   expect(z(a.leftKnee)).toBeGreaterThan(z(a.rightKnee)+.1);
  }finally{p.dispose();}
 });
 it.each([-1,1])('recovers a lateral torso shove (%s) through the existing joints',direction=>{
  const p=new SnowboardPhysics(plane(0));p.launchSpeed(9.5);const rider=new ActiveRider(p);
  p.onEvent=e=>{if(e.type==='crash')rider.release();};
  try{
   advance(p,1);const torso=rider.ragdoll.bodies[1],baselineEffort=p.balanceEffort;
   torso.applyImpulse({x:direction*24,y:0,z:0},true);
   let peakEffort=0,peakLean=0;
   for(let i=0;i<300;i++){
    p.update(neutral,1/120);peakEffort=Math.max(peakEffort,p.balanceEffort);peakLean=Math.max(peakLean,p.balanceTilt.length());
    const j=rider.ragdoll.poses(),forward=new THREE.Vector3(0,0,1).applyQuaternion(p.orientation);
    expect(j.lk.clone().sub(j.rk).dot(forward)).toBeGreaterThan(.12);
    expect(p.balanceOffset.length()).toBeLessThan(.29);expect(p.balanceTilt.length()).toBeLessThan(.32);
   }
   expect(peakEffort).toBeGreaterThan(baselineEffort+.04);expect(peakLean).toBeGreaterThan(.01);
   expect(p.crashed).toBe(false);expect(p.grounded).toBe(true);
   expect(new THREE.Vector3(0,1,0).applyQuaternion(new THREE.Quaternion().copy(torso.rotation())).y).toBeGreaterThan(.85);
   expect(p.dynamics.bodies.len()).toBe(12);expect(p.dynamics.impulseJoints.len()).toBe(12);
  }finally{rider.dispose();p.dispose();}
 });
 it('fades upright corrections in flight and leaves a bail passive',()=>{
  const p=new SnowboardPhysics(plane()),rider=new ActiveRider(p);
  try{
   advance(p,.8);advance(p,1.1,{jump:true});advance(p,.3,{pitch:-1});
   expect(p.grounded).toBe(false);expect(p.balanceTilt.length()).toBeLessThan(.01);
   p.bail('Test');rider.release();const before=p.balanceTilt.clone();advance(p,.2);
   expect(p.balanceTilt.equals(before)).toBe(true);expect(p.crashed).toBe(true);
  }finally{rider.dispose();p.dispose();}
 });
});
