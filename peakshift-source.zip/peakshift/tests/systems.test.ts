import { afterEach, describe, expect, it, vi } from 'vitest';
import { EditorHistory, loadLocal, MountainNetwork, ReplayRecorder, saveLocal, validateMountainConfig, validatePark, type ReplayFrame } from '../src/game/systems';
// The relay is intentionally plain Node ESM, separate from the browser build.
// @ts-expect-error The server module has no browser TypeScript declarations.
import { createPeakshiftServer } from '../server/index.mjs';
// @ts-expect-error ws is a server runtime dependency, without browser declarations.
import WebSocket from 'ws';

const park = () => ({
  version: 1, mapId: 'alpine-crown',
  objects: [{ id: 'jump-1', type: 'ramp', x: 10, z: 20, rotation: 0.4, scale: 1 }],
  edits: [{ x: 10, z: 20, radius: 12, amount: 3, mode: 'raise' }],
});
const frame = (x: number, heading = 0): ReplayFrame => ({
  t: 0, x, y: 100, z: x * 2, heading, pitch: 0, roll: 0, spin: x / 10, speed: 12,
  grounded: x === 0,
});

afterEach(() => vi.unstubAllGlobals());

describe('shared mountain configuration', () => {
  const mountain = () => ({ id: 'seed-42', seed: 42, name: 'Fresh tracks', region: 'Uncharted territory', tagline: 'Your mountain.', difficulty: 'ALL RIDERS', slope: 0.24, roughness: 1.2, forest: 0.5, vertical: 432, snow: 'powder', sky: '#5995c1', accent: '#d4fb48', fog: '#bed8e5', night: false });
  it('accepts a complete bounded seed configuration, sanitizes text and drops unknown fields', () => {
    const value = { ...mountain(), name: '<Fresh>\ntracks', execute: 'never execute', assetUrl: 'https://untrusted.example/asset' };
    const result = validateMountainConfig(value);
    expect(result).toEqual({ ...mountain(), name: 'Freshtracks' });
    expect(result).not.toHaveProperty('execute');
    expect(result).not.toHaveProperty('assetUrl');
    expect(validateMountainConfig({ ...mountain(), night: undefined })).not.toHaveProperty('night');
  });
  it('rejects non-finite, oversized, non-integer and incompatible configurations', () => {
    for (const key of ['seed', 'slope', 'roughness', 'forest', 'vertical']) {
      for (const value of [NaN, Infinity, -Infinity, '1']) {
        expect(() => validateMountainConfig({ ...mountain(), [key]: value })).toThrow();
      }
    }
    for (const invalid of [{ id: 'alpine' }, { seed: -1 }, { seed: 4294967296 }, { seed: 1.5 }, { slope: 0.41 }, { slope: 0.11 }, { roughness: 2.6 }, { forest: 1.3 }, { snow: 'lava' }, { sky: 'url(script)' }, { fog: '#fff' }, { night: 'true' }, { name: 'x'.repeat(65) }, { region: '<>\n' }]) {
      expect(() => validateMountainConfig({ ...mountain(), ...invalid })).toThrow();
    }
  });
});

describe('park imports', () => {
  it('accepts bounded park data and strips undeclared payload fields', () => {
    const data = park();
    Object.assign(data.objects[0], { script: 'do not execute', y: 500 });
    const result = validatePark(data);
    expect(result).toEqual(park());
    expect(result.objects[0]).not.toHaveProperty('script');
    data.objects[0].x = 500;
    expect(result.objects[0].x).toBe(10);
  });
  it('rejects unknown versions, object kinds, NaN, Infinity and duplicate IDs', () => {
    expect(() => validatePark({ ...park(), version: 2 })).toThrow(/version/);
    for (const value of [NaN, Infinity, -Infinity, 10001]) {
      const data = park(); data.objects[0].x = value;
      expect(() => validatePark(data)).toThrow(/finite/);
    }
    const kind = park(); kind.objects[0].type = 'javascript';
    expect(() => validatePark(kind)).toThrow(/Unknown/);
    const duplicate = park(); duplicate.objects.push({ ...duplicate.objects[0] });
    expect(() => validatePark(duplicate)).toThrow(/Duplicate/);
  });
  it('enforces brush and object budgets without silently truncating data', () => {
    expect(() => validatePark({ ...park(), objects: Array(301).fill(park().objects[0]) })).toThrow(/300/);
    expect(() => validatePark({ ...park(), edits: Array(101).fill(park().edits[0]) })).toThrow(/100/);
    const bad = park(); bad.edits[0].radius = 5000;
    expect(() => validatePark(bad)).toThrow(/radius/);
    expect(() => validatePark({ ...park(), edits: [{ ...park().edits[0], mode: 'execute' }] })).toThrow(/brush/);
  });
});

describe('editor history', () => {
  it('supports undo, redo and branching after undo', () => {
    const history = new EditorHistory({ objects: [1] });
    history.commit({ objects: [1, 2] }); history.commit({ objects: [1, 2, 3] });
    expect(history.undo().objects).toEqual([1, 2]);
    expect(history.canRedo).toBe(true);
    expect(history.redo().objects).toEqual([1, 2, 3]);
    history.undo(); history.commit({ objects: [4] });
    expect(history.canRedo).toBe(false);
    expect(history.undo().objects).toEqual([1, 2]);
  });
  it('keeps snapshots independent from editing and reading', () => {
    const initial = { objects: [1] };
    const history = new EditorHistory(initial); initial.objects.push(2);
    const selected = history.current; selected.objects.push(3);
    expect(history.current.objects).toEqual([1]);
    expect(history.undo()).toEqual({ objects: [1] });
    expect(history.canUndo).toBe(false);
  });
});

describe('recorded transforms', () => {
  it('records a fixed cadence, interpolates spatially and wraps headings', () => {
    const replay = new ReplayRecorder();
    replay.record(frame(0, Math.PI - 0.1), 0.016);
    replay.record(frame(0.1), 0.016);
    expect(replay.frames).toHaveLength(1);
    replay.record(frame(10, -Math.PI + 0.1), 0.084);
    expect(replay.duration).toBeCloseTo(0.1);
    const sampled = replay.sample(0.05)!;
    expect(sampled.x).toBeCloseTo(5);
    expect(sampled.z).toBeCloseTo(10);
    expect(Math.abs(sampled.heading)).toBeCloseTo(Math.PI);
    expect(replay.sample(-4)?.x).toBe(0);
    expect(replay.sample(400)?.x).toBe(10);
  });
  it('roundtrips without re-running physics and rejects corrupt recordings atomically', () => {
    const replay = new ReplayRecorder(); replay.record(frame(0), 0); replay.record(frame(10), 0.1);
    const saved = replay.export();
    const loaded = new ReplayRecorder(); loaded.import(saved);
    expect(loaded.sample(0.075)?.x).toBeCloseTo(7.5);
    expect(loaded.recording).toBe(false);
    const invalid = JSON.parse(saved); invalid.frames[1].t = 0;
    expect(() => loaded.import(JSON.stringify(invalid))).toThrow(/timestamps/);
    expect(loaded.export()).toBe(saved);
    invalid.frames[1].x = '10';
    expect(() => loaded.import(JSON.stringify(invalid))).toThrow(/finite/);
    loaded.clear(); expect(loaded.duration).toBe(0); expect(loaded.sample(0)).toBeNull();
    expect(loaded.recording).toBe(true);
  });
  it('preserves pose inputs and trick text while sampling animation state from the nearest frame', () => {
    const replay = new ReplayRecorder();
    replay.record({ ...frame(0), grab: false, grabStyle: 'Mute', turn: -0.4, tuck: true, crashed: false, charge: 0.8, lastTrick: 'Find your line' }, 0);
    replay.record({ ...frame(10), grab: true, grabStyle: 'Japan', turn: 0.7, tuck: false, crashed: true, charge: 0, lastTrick: '360 <Japan>\nGrab' }, 0.1);
    const loaded = new ReplayRecorder(); loaded.import(replay.export());
    expect(loaded.sample(0.02)?.x).toBeCloseTo(2);
    expect(loaded.sample(0.02)).toMatchObject({ grab: false, grabStyle: 'Mute', turn: -0.4, tuck: true, crashed: false, charge: 0.8 });
    expect(loaded.sample(0.08)?.x).toBeCloseTo(8);
    expect(loaded.sample(0.08)).toMatchObject({ grab: true, grabStyle: 'Japan', turn: 0.7, tuck: false, crashed: true, charge: 0, lastTrick: '360 JapanGrab' });
    const legacy = new ReplayRecorder(); legacy.import(JSON.stringify({ version: 1, frames: [frame(0)] }));
    expect(legacy.sample(0)).not.toHaveProperty('grab');
  });
  it('validates optional replay pose values and strips unrecognized fields', () => {
    const replay = new ReplayRecorder();
    for (const extra of [{ turn: Infinity }, { turn: 2 }, { charge: -1 }, { grab: 'yes' }, { grabStyle: {} }]) {
      expect(() => replay.import(JSON.stringify({ version: 1, frames: [{ ...frame(0), ...extra }] }))).toThrow();
    }
    replay.import(JSON.stringify({ version: 1, frames: [{ ...frame(0), script: 'never execute', grabStyle: 'Tail' }] }));
    expect(replay.frames[0]).not.toHaveProperty('script');
    expect(replay.frames[0].grabStyle).toBe('Tail');
  });
});

describe('local persistence', () => {
  it('roundtrips JSON and tolerates restricted or full storage', () => {
    const storage = new Map<string, string>();
    vi.stubGlobal('localStorage', {
      getItem: (key: string) => storage.get(key) ?? null,
      setItem: (key: string, value: string) => storage.set(key, value),
    });
    expect(saveLocal('settings', { volume: 0.4 })).toBe(true);
    expect(loadLocal('settings', { volume: 1 })).toEqual({ volume: 0.4 });
    storage.set('peakshift:settings', '{broken');
    expect(loadLocal('settings', { volume: 1 })).toEqual({ volume: 1 });
    vi.stubGlobal('localStorage', { getItem: () => { throw new Error('SecurityError'); }, setItem: () => { throw new Error('QuotaExceededError'); } });
    expect(saveLocal('settings', {})).toBe(false);
    expect(loadLocal('settings', { volume: 1 })).toEqual({ volume: 1 });
  });
});

type TestSocket = {
  send: (data: string) => void; close: () => void; terminate: () => void;
  on: (event: string, listener: (...args: any[]) => void) => void;
  off: (event: string, listener: (...args: any[]) => void) => void;
};
const waitMessage = (socket: TestSocket, predicate: (message: any) => boolean, timeout = 2500): Promise<any> => new Promise((resolve, reject) => {
  const timer = setTimeout(() => { socket.off('message', handle); reject(new Error('Expected server message was not received.')); }, timeout);
  const handle = (raw: { toString: () => string }) => {
    const value = JSON.parse(raw.toString());
    if (predicate(value)) { clearTimeout(timer); socket.off('message', handle); resolve(value); }
  };
  socket.on('message', handle);
});
const openSocket = (url: string): Promise<TestSocket> => new Promise((resolve, reject) => {
  const socket = new WebSocket(url);
  socket.on('open', () => resolve(socket)); socket.on('error', reject);
});

describe('real multiplayer relay', () => {
  it('connects the browser client API to actual peers and clears them on disconnect', async () => {
    vi.stubGlobal('WebSocket', WebSocket);
    vi.stubGlobal('requestAnimationFrame', (callback: () => void) => setTimeout(callback, 16));
    vi.stubGlobal('cancelAnimationFrame', (id: number) => clearTimeout(id));
    const server = await createPeakshiftServer({ port: 0, log: null });
    const one = new MountainNetwork(), two = new MountainNetwork();
    try {
      const endpoint = `ws://127.0.0.1:${server.port}/ws`;
      await one.connect(endpoint, 'One', '', 'alpine-crown');
      await two.connect(endpoint, 'Two', one.room, 'alpine-crown');
      expect(one.connected).toBe(true); expect(two.connected).toBe(true);
      one.send({ ...frame(42), sport: 'ski', color: '#00ffaa' });
      await expect.poll(() => [...two.players.values()][0]?.x, { timeout: 2000 }).toBeCloseTo(42);
      expect([...two.players.values()][0]?.name).toBe('One');
      one.disconnect();
      await expect.poll(() => two.players.size, { timeout: 2000 }).toBe(0);
      expect(one.players.size).toBe(0); expect(one.connected).toBe(false);
    } finally { one.disconnect(); two.disconnect(); await server.close(); }
  });
  it('settles an interrupted connection instead of leaving a pending promise', async () => {
    vi.stubGlobal('WebSocket', class { close() {} });
    vi.stubGlobal('cancelAnimationFrame', () => {});
    const network = new MountainNetwork();
    const pending = network.connect('ws://127.0.0.1:8787', 'Guest');
    const rejected = expect(pending).rejects.toThrow(/cancelled/);
    network.disconnect(); await rejected;
    expect(network.status).toMatch(/Offline/);
  });
  it('connects two real clients, syncs positions on the room map, discards totals, and handles leaving', async () => {
    const server = await createPeakshiftServer({ port: 0, log: null });
    const sockets: TestSocket[] = [];
    try {
      const one = await openSocket(`ws://127.0.0.1:${server.port}/ws`); sockets.push(one);
      const welcomeOne = waitMessage(one, message => message.type === 'welcome');
      one.send(JSON.stringify({ type: 'join', name: 'First', mapId: 'alpine-crown' }));
      const first = await welcomeOne;
      expect(first.room).toMatch(/^[A-Z2-9]{6}$/);
      expect(first.players).toHaveLength(0);
      const two = await openSocket(`ws://127.0.0.1:${server.port}/ws`); sockets.push(two);
      const welcomeTwo = waitMessage(two, message => message.type === 'welcome');
      two.send(JSON.stringify({ type: 'join', name: 'Second', room: first.room, mapId: 'different-map' }));
      const second = await welcomeTwo;
      expect(second.mapId).toBe('alpine-crown');
      expect(second.players).toHaveLength(1);
      const snapshot = waitMessage(two, message => message.type === 'snapshot' && message.players.some((player: any) => player.id === first.id && player.x === 50));
      one.send(JSON.stringify({ type: 'state', state: { x: 50, y: 180, z: 320, heading: 0.2, pitch: 1, roll: 0, spin: 6.28, sport: 'snowboard', color: '#ff6611', trick: '360 melon', score: 99999999, total: 99999999 } }));
      const received = await snapshot;
      const remote = received.players.find((player: any) => player.id === first.id);
      expect(remote).toMatchObject({ x: 50, z: 320, sport: 'snowboard', trick: '360 melon' });
      expect(remote).not.toHaveProperty('total'); expect(remote).not.toHaveProperty('score');
      const left = waitMessage(two, message => message.type === 'leave' && message.id === first.id);
      one.close(); await left;
    } finally {
      for (const socket of sockets) socket.terminate();
      await server.close();
    }
  });
  it('rejects unknown rooms rather than fabricating peers', async () => {
    const server = await createPeakshiftServer({ port: 0, log: null });
    let socket: TestSocket | undefined;
    try {
      socket = await openSocket(`ws://127.0.0.1:${server.port}`);
      const failure = waitMessage(socket, message => message.type === 'error');
      socket.send(JSON.stringify({ type: 'join', room: 'ABCDEF', name: 'Guest', mapId: 'alpine-crown' }));
      expect((await failure).message).toMatch(/not found/);
      expect(server.rooms.size).toBe(0);
    } finally { socket?.terminate(); await server.close(); }
  });
});
