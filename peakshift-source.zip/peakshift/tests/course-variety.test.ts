import {describe,it,expect} from 'vitest';
import * as THREE from 'three';
import {MAPS,MountainWorld} from '../src/game/world';
import {COURSES,courseCenter,courseObjects,SNOW_FEATURES,snowFeatureHeight} from '../src/game/courses';
import {validatePark} from '../src/game/systems';
describe('individual mountain courses',()=>{
 it('authors a different route, terrain profile, feature arrangement and section sequence for every map',()=>{
  const routes=new Set(),layouts=new Set(),labels=new Set(),terrain=new Set(),sections=new Set();
  for(const m of MAPS){const p=COURSES[m.id];expect(p).toBeTruthy();routes.add(JSON.stringify(p.line));labels.add(p.label);sections.add(p.sections.join('/'));terrain.add([p.width,p.bank,p.roller,p.wave,p.terrace].join('/'));
   const objects=courseObjects(m.id);expect(objects.length).toBeGreaterThan(5);layouts.add(JSON.stringify(objects.map(o=>[o.type,o.x,o.z,o.scale])));
   expect(validatePark({version:1,mapId:m.id,objects,edits:[]}).objects).toHaveLength(objects.length);
   expect(courseCenter(m.id,0)).toBe(0);expect(courseCenter(m.id,1780)).toBe(0);
  }
  for(const unique of [routes,layouts,labels,terrain,sections])expect(unique.size).toBe(17);
 });
 it('keeps dedicated courses focused instead of scattering identical park objects across every mountain',()=>{
  expect(courseObjects('velocity').some(o=>SNOW_FEATURES.has(o.type)||o.type==='ramp')).toBe(false);
  expect(courseObjects('pipe-lab').filter(o=>o.type.includes('rail')||o.type==='tube')).toHaveLength(12);
  expect(courseObjects('hokkaido').filter(o=>o.type==='pillow').length).toBeGreaterThan(10);
  expect(courseObjects('bigair').filter(o=>o.type==='tabletop')).toHaveLength(5);
  expect(courseObjects('canyon').filter(o=>o.type==='banked-turn')).toHaveLength(11);
  expect(courseObjects('megapark').some(o=>o.x<-20)).toBe(true);expect(courseObjects('megapark').some(o=>o.x>20)).toBe(true);
 });
 it.each([...SNOW_FEATURES])('bakes the new %s feature into the same mesh used by snow contact',type=>{
  const w=new MountainWorld(new THREE.Scene(),MAPS[0]);
  try{
   w.setObjects([]);const before=w.height(6,210);
   w.setObjects([{id:'feature',type,x:6,z:210,scale:1,rotation:.6}]);
   let peak=0;
   for(let x=-15;x<25;x+=3)for(let z=190;z<240;z+=3){peak=Math.max(peak,w.height(x,z)-before);expect(Number.isFinite(w.height(x,z))).toBe(true);}
   expect(peak).toBeGreaterThan(1);
   const data=w.collisionMesh();for(let i=0;i<data.vertices.length;i+=15003){const x=data.vertices[i],y=data.vertices[i+1],z=data.vertices[i+2];expect(y).toBeCloseTo(w.groundHeight(x,z),3);}
   expect(Number.isFinite(snowFeatureHeight(type,4,7,1))).toBe(true);
  }finally{w.dispose();}
 });
});
