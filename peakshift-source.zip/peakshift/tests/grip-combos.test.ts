import {beforeAll,it,expect} from 'vitest';
import * as THREE from 'three';
import {initPhysics,SnowboardPhysics,type InputState} from '../src/game/physics';
import {ActiveRider} from '../src/game/active-rider';
import {createRider} from '../src/game/rider';
import {GRAB_NAMES,grabDefinition} from '../src/game/tricks';
import {plane,neutral,advance} from './helpers';

beforeAll(initPhysics);
function setup(){
 const p=new SnowboardPhysics(plane());p.launchSpeed(14);const rider=new ActiveRider(p),visible=createRider('snowboard');
 p.onEvent=e=>{if(e.type==='crash')rider.release();};
 return{p,rider,visible,dispose:()=>{rider.dispose();p.dispose();visible.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();for(const m of Array.isArray(o.material)?o.material:[o.material])m.dispose();}});}};
}

it('cannot attach a hand to a board that it has not reached',()=>{
 const{p,rider,dispose}=setup();
 try{rider.grip.update('Indy');expect(rider.grip.joint).toBeUndefined();expect(p.dynamics.impulseJoints.len()).toBe(12);}
 finally{dispose();}
});

it.each(GRAB_NAMES)('%s adds one physical wrist-to-board grip and releases it before landing',style=>{
 const{p,rider,visible,dispose}=setup();let held=0;
 try{
  for(let i=0;i<240;i++){
   const t=i/60,input={...neutral,jump:t<1.1,grab:t>1.2&&t<2.4,grabStyle:style,grabContact:visible.userData.pose?.grabContact===true};
   p.update(input,1/60);rider.render(visible);
   expect(p.dynamics.bodies.len()).toBe(12);expect(p.dynamics.impulseJoints.len()).toBeLessThanOrEqual(13);
   if(rider.grip.joint){
    held+=1/60;expect(rider.grip.style).toBe(style);expect(p.dynamics.impulseJoints.len()).toBe(13);
    expect(rider.grip.joint.body1().handle).toBe(rider.ragdoll.bodies[grabDefinition(style).hand==='rear'?10:8].handle);
    expect(rider.grip.joint.body2().handle).toBe(p.board.handle);
   }
  }
  expect(held).toBeGreaterThan(.5);expect(rider.grip.joint).toBeUndefined();expect(p.dynamics.impulseJoints.len()).toBe(12);expect(p.crashed).toBe(false);
 }finally{dispose();}
});

it.each(['release','bail'])('%s removes the grip without changing any body momentum',action=>{
 const{p,rider,dispose}=setup();
 try{
  advance(p,1.1,{jump:true});
  for(let i=0;i<120&&!rider.grip.joint;i++)p.update({...neutral,grab:true,grabStyle:'Indy'},1/120);
  expect(rider.grip.joint).toBeDefined();
  const bodies=[p.board,...rider.ragdoll.bodies],velocities=bodies.map(b=>new THREE.Vector3().copy(b.linvel())),positions=bodies.map(b=>new THREE.Vector3().copy(b.translation()));
  if(action==='bail')p.bail('Test');else rider.grip.release();
  expect(rider.grip.joint).toBeUndefined();expect(p.dynamics.impulseJoints.len()).toBe(12);
  bodies.forEach((b,i)=>{expect(new THREE.Vector3().copy(b.linvel()).distanceTo(velocities[i])).toBe(0);expect(new THREE.Vector3().copy(b.translation()).distanceTo(positions[i])).toBe(0);});
 }finally{dispose();}
});

it('lets go under a strong wrist impact instead of rigidly dragging the board',()=>{
 const{p,rider,dispose}=setup();
 try{
  advance(p,1.1,{jump:true});
  for(let i=0;i<120&&!rider.grip.joint;i++)p.update({...neutral,grab:true,grabStyle:'Indy'},1/120);
  expect(rider.grip.joint).toBeDefined();
  rider.ragdoll.bodies[10].applyImpulse({x:50,y:0,z:0},true);let released=false;
  for(let i=0;i<18;i++){
   p.update({...neutral,grab:true,grabStyle:'Indy'},1/120);
   if(!rider.grip.joint){released=true;break;}
  }
  expect(released).toBe(true);expect(p.crashed).toBe(false);expect(p.dynamics.impulseJoints.len()).toBe(12);
 }finally{dispose();}
});

it.each([
 ['Wildcat · Indy','Indy',{pitch:-1},2.15],
 ['Backside 360 · Mute','Mute',{turn:1},2.2],
 ['Backside 180 · Method','Method',{turn:1},1.8],
 ['Cork · Melon','Melon',{roll:1},2.55],
]as const)('lands the combined trick %s with a real grip',(label,style,rotation,end)=>{
 const{p,rider,visible,dispose}=setup(),landed:string[]=[];let contact=0;
 p.onEvent=e=>{if(e.type==='land')landed.push(e.text||'');if(e.type==='crash')rider.release();};
 try{
  for(let i=0;i<330;i++){
   const t=i/60,input:InputState={...neutral,...(t>1.2&&t<end?rotation:{}),jump:t<1.1,grab:t>1.2&&t<2.4,grabStyle:style,grabContact:visible.userData.pose?.grabContact===true};
   p.update(input,1/60);rider.render(visible);if(visible.userData.pose.grabContact)contact+=1/60;
   for(const b of rider.ragdoll.bodies)expect(new THREE.Vector3().copy(b.linvel()).length()).toBeLessThan(40);
  }
  expect(contact).toBeGreaterThan(.5);expect(landed).toEqual([label]);expect(p.crashed).toBe(false);expect(p.grounded).toBe(true);
 }finally{dispose();}
});

it('links two physical grips without adding overlapping constraints',()=>{
 const{p,rider,visible,dispose}=setup(),landed:string[]=[];
 p.onEvent=e=>{if(e.type==='land')landed.push(e.text||'');if(e.type==='crash')rider.release();};
 try{
  for(let i=0;i<270;i++){
   const t=i/60,style=t<1.85?'Indy':'Melon';
   p.update({...neutral,jump:t<1.1,grab:t>1.2&&t<2.4,grabStyle:style,grabContact:visible.userData.pose?.grabContact===true&&visible.userData.pose?.grabStyle===style},1/60);rider.render(visible);
   expect(p.dynamics.impulseJoints.len()).toBeLessThanOrEqual(13);
  }
  expect(landed).toContain('Indy → Melon');expect(p.crashed).toBe(false);
 }finally{dispose();}
});
