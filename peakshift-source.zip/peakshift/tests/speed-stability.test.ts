import {beforeAll,it,expect} from 'vitest';
import * as THREE from 'three';
import {initPhysics,SnowboardPhysics} from '../src/game/physics';
import {ActiveRider} from '../src/game/active-rider';
import {plane,neutral} from './helpers';
beforeAll(initPhysics);
it('keeps the board and chest quiet while coasting above 100 km/h',()=>{
 const p=new SnowboardPhysics(plane(.38));p.launchSpeed(32);const r=new ActiveRider(p);let sum=0,samples=0,peak=0,chestSum=0,crashes=0;
 p.onEvent=e=>{if(e.type==='crash'){crashes++;r.release();}};
 try{
  for(let i=0;i<120*20;i++){
   p.update({...neutral,tuck:i<120*4||i>120*10&&i<120*14},1/120);
   if(i<120*4)continue;
   const up=new THREE.Vector3(0,1,0).applyQuaternion(p.orientation),angle=up.angleTo(p.world.normal(p.position.x,p.position.z));
   const chest=new THREE.Vector3().copy(r.ragdoll.bodies[1].angvel()).sub(new THREE.Vector3().copy(p.board.angvel()));
   sum+=angle*angle;peak=Math.max(peak,angle);chestSum+=chest.lengthSq();samples++;
  }
  expect(Math.sqrt(sum/samples)).toBeLessThan(.03);expect(peak).toBeLessThan(.08);
  expect(Math.sqrt(chestSum/samples)).toBeLessThan(.5);expect(p.speed*3.6).toBeGreaterThan(100);expect(crashes).toBe(0);
 }finally{r.dispose();p.dispose();}
},15000);
