import {beforeAll,describe,it,expect} from 'vitest';
import * as THREE from 'three';
import {initPhysics,SnowboardPhysics,RAPIER} from '../src/game/physics';
import {ActiveRider} from '../src/game/active-rider';
import {MountainWorld,MAPS} from '../src/game/world';
import {buildRailPath,railMesh,railMagnet,closestRailPoint} from '../src/game/rails';
import {neutral,plane,advance} from './helpers';
beforeAll(initPhysics);
describe('curved physical pipes and gentle capture',()=>{
 it('renders and collides against the exact same curved, downhill tube triangles',()=>{
  const w=new MountainWorld(new THREE.Scene(),MAPS[0]);
  w.setObjects([{id:'curve',type:'curved-rail',x:0,z:150,rotation:.25,scale:2}]);
  const p=new SnowboardPhysics(w);
  try{
   const path=p.rails[0],rendered=w.group.getObjectByName('pipe-curve') as THREE.Mesh,data=railMesh(path);
   expect(Array.from(rendered.geometry.getAttribute('position').array)).toEqual(Array.from(data.vertices));
   expect(Array.from(rendered.geometry.index!.array)).toEqual(Array.from(data.indices));
   expect(path.points[0].y-path.points[32].y).toBeGreaterThan(1);
   expect(Math.abs(closestRailPoint(path,path.points[0]).heading-closestRailPoint(path,path.points[32]).heading)).toBeGreaterThan(.4);
   advance(p,.01);w.group.updateMatrixWorld(true);
   for(const i of [4,13,22,29]){
    const start=path.points[i].clone().add(new THREE.Vector3(0,3,0)),down=new THREE.Vector3(0,-1,0);
    const visible=new THREE.Raycaster(start,down).intersectObject(rendered)[0];
    const physical=p.dynamics.castRay(new RAPIER.Ray(start,down),4,true)!;
    expect(visible).toBeDefined();expect(physical.timeOfImpact).toBeCloseTo(visible.distance,3);
   }
  }finally{p.dispose();w.dispose();}
 });
 it('captures only nearby boards at pipe height and lets steering pull away',()=>{
  const path=buildRailPath({id:'tube',type:'tube',x:0,z:0,rotation:0,scale:1},()=>0),velocity=new THREE.Vector3(0,-1,10);
  const assist=railMagnet(path,new THREE.Vector3(.6,1.7,0),velocity,false,0)!;
  expect(assist.force.x).toBeLessThan(0);expect(Math.abs(assist.force.y)).toBe(0);expect(assist.force.length()).toBeLessThanOrEqual(500);
  expect(railMagnet(path,new THREE.Vector3(.6,.055,0),velocity,false,0)).toBeUndefined();
  expect(railMagnet(path,new THREE.Vector3(2,1.7,0),velocity,false,0)).toBeUndefined();
  expect(railMagnet(path,new THREE.Vector3(.6,4,0),velocity,false,0)).toBeUndefined();
  expect(railMagnet(path,new THREE.Vector3(.6,1.7,0),velocity,false,1)!.force.length()).toBe(0);
 });
 it('physically catches a near miss without teleporting or lifting the assembly',()=>{
  const run=(assistance:boolean)=>{
   const w=plane(0);w.objects=[{id:'tube',type:'tube',x:0,z:15,rotation:0,scale:2}];
   const p=new SnowboardPhysics(w);p.reset(.6,7);p.board.setTranslation({x:.6,y:3.6,z:7},true);p.board.setLinvel({x:0,y:-1,z:8},true);p.sync();p.grounded=false;p.assistance=assistance;
   const rider=new ActiveRider(p);let railTime=0,maxStep=0,old=p.position.clone();
   p.onEvent=e=>{if(e.type==='crash')rider.release();};
   try{for(let i=0;i<180;i++){p.update(neutral,1/120);if(p.railId)railTime+=1/120;maxStep=Math.max(maxStep,old.distanceTo(p.position));old.copy(p.position);}return{railTime,maxStep,x:p.position.x,crashed:p.crashed};}
   finally{rider.dispose();p.dispose();}
  };
  const helped=run(true),unassisted=run(false);
  expect(helped.railTime).toBeGreaterThan(.35);expect(helped.railTime).toBeGreaterThan(unassisted.railTime+.2);expect(helped.maxStep).toBeLessThan(.25);expect(helped.crashed).toBe(false);
 });
 it.each(['curved-rail','rainbow-rail'])('follows the actual %s path with the live skeleton',type=>{
  const w=plane(.08);w.objects=[{id:'curve',type,x:0,z:20,rotation:0,scale:3}];
  const p=new SnowboardPhysics(w),path=p.rails[0],at=path.points[3],hit=closestRailPoint(path,at);
  p.reset(at.x,at.z,false,hit.heading);p.board.setTranslation(at.clone().addScaledVector(hit.normal,path.radius+.08),true);p.board.setLinvel(hit.tangent.clone().multiplyScalar(9),true);p.sync();
  const rider=new ActiveRider(p);let contact=0,maxDistance=0;p.onEvent=e=>{if(e.type==='crash')rider.release();};
  try{
   for(let i=0;i<240;i++){
    p.update(neutral,1/120);
    if(p.railId){contact+=1/120;maxDistance=Math.max(maxDistance,closestRailPoint(path,p.position).distance);}
   }
   expect(contact).toBeGreaterThan(1);expect(maxDistance).toBeLessThan(.9);expect(p.crashed).toBe(false);expect(p.position.z).toBeGreaterThan(at.z+8);
  }finally{rider.dispose();p.dispose();}
 });
 it('pops free of a pipe without the magnet pulling the jump back',()=>{
  const w=plane(0);w.objects=[{id:'tube',type:'tube',x:0,z:20,rotation:0,scale:3}];
  const p=new SnowboardPhysics(w);p.reset(0,15);p.board.setTranslation({x:0,y:4.49,z:15},true);p.board.setLinvel({x:0,y:0,z:8},true);p.sync();
  const rider=new ActiveRider(p);
  try{advance(p,.25);expect(p.railId).toBe('tube');advance(p,.25,{jump:true});const before=p.position.y;advance(p,.15);expect(p.railId).toBeNull();expect(p.grounded).toBe(false);expect(p.position.y).toBeGreaterThan(before+.25);}
  finally{rider.dispose();p.dispose();}
 });
 it('adds reachable centre pipes and five physically different practice layouts',()=>{
  for(const map of MAPS.filter(m=>m.layout||m.id==='alpine')){
   const w=new MountainWorld(new THREE.Scene(),map);
   try{
    if(!map.layout)expect(w.objects.every(o=>!o.id.startsWith('centre-pipe-'))).toBe(true);
    if(map.layout==='pipes')expect(w.objects.filter(o=>o.type==='tube'||o.type.includes('rail'))).toHaveLength(12);
    if(map.layout==='big-jumps')expect(w.objects.filter(o=>['hip','tabletop'].includes(o.type)&&o.scale>1.5)).toHaveLength(6);
    if(map.layout==='flips')expect(w.objects.filter(o=>o.type==='ramp'||o.type==='tabletop')).toHaveLength(8);
    if(map.layout==='speed')expect(w.normal(0,400).z).toBeGreaterThan(.25);
    if(map.layout==='side-hits')expect(w.objects.filter(o=>o.type!=='volcano')).toHaveLength(16);
   }finally{w.dispose();}
  }
 },15000);
});
