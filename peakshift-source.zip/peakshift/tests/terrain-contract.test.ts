import {describe,it,expect} from 'vitest';
import * as THREE from 'three';
import {MountainWorld,MAPS,atLiftFinish} from '../src/game/world';
import {TrackSurface} from '../src/game/surface';
const neutral={turn:0,tuck:false,brake:false,jump:false,grab:false,pitch:0,roll:0};
describe('one mesh for the visible track and snow contact',()=>{
 it('matches arbitrary triangle interiors across the dense-to-wide grid transition',()=>{
  const surface=new TrackSurface((x,z)=>10+Math.sin(x*.07)*4+Math.cos(z*.03)*3);const g=surface.geometry(0,surface.columns-1,100,220,()=>new THREE.Color('white')),m=new THREE.Mesh(g,new THREE.MeshBasicMaterial()),ray=new THREE.Raycaster();m.updateMatrixWorld(true);
  for(let i=0;i<150;i++){const x=-690+(i*127.31%1380),z=-80+(i*19.79%320);ray.set(new THREE.Vector3(x,80,z),new THREE.Vector3(0,-1,0));const hit=ray.intersectObject(m)[0];expect(hit).toBeTruthy();expect(Math.abs(hit.point.y-surface.height(x,z))).toBeLessThan(.00001);}g.dispose();
 });
 it('matches rendered ramps, side walls, rotated features and edited landings',()=>{
  const w=new MountainWorld(new THREE.Scene(),MAPS[0]);w.setObjects([{id:'jump',type:'ramp',x:4,z:135,rotation:.37,scale:1.1},{id:'pipe',type:'halfpipe',x:-25,z:240,rotation:-.2,scale:1},{id:'box',type:'box',x:20,z:300,rotation:.2,scale:1}]);w.setEdits([{x:0,z:175,radius:35,amount:3,mode:'raise'}]);w.group.updateMatrixWorld(true);const ray=new THREE.Raycaster(),meshes=[w.group.children[0],w.group.children[2]];
  for(let i=0;i<170;i++){const x=-40+(i*17.71%75),z=110+(i*23.23%215);ray.set(new THREE.Vector3(x,600,z),new THREE.Vector3(0,-1,0));const hit=ray.intersectObjects(meshes,true)[0];expect(hit).toBeTruthy();expect(Math.abs(hit.point.y-w.height(x,z)),`${x},${z}`).toBeLessThan(.03);}w.dispose();
 });
});
