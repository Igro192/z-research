import {beforeAll,describe,expect,it} from 'vitest';
import * as THREE from 'three';
import {initPhysics,SnowboardPhysics} from '../src/game/physics';
import {ActiveRider} from '../src/game/active-rider';
import {AirInputGate,keyboardInput} from '../src/game/input';
import {plane,neutral,advance} from './helpers';
beforeAll(initPhysics);
const vec=(v:{x:number;y:number;z:number})=>new THREE.Vector3().copy(v);
describe('firm catches and continuous held controls',()=>{
 it.each([['KeyW',1],['KeyS',-1]]as const)('%s held while riding starts its flip during the takeoff frame',(key,sign)=>{
  const p=new SnowboardPhysics(plane(0)),r=new ActiveRider(p),gate=new AirInputGate(),keys=new Set([key,'Space']);p.launchSpeed(12);
  try{
   for(let i=0;i<66;i++)p.update(gate.read(keyboardInput(keys),p.grounded),1/60);
   keys.delete('Space');
   p.update(gate.read(keyboardInput(keys),p.grounded),1/60);
   expect(p.grounded).toBe(false);expect(p.flipRotation*sign).toBeGreaterThan(.001);
   for(let i=0;i<48;i++)p.update(gate.read(keyboardInput(keys),p.grounded),1/60);
   expect(p.flipRotation*sign).toBeGreaterThan(1.8);expect(p.crashed).toBe(false);
   expect(keys.has(key)).toBe(true);
  }finally{r.dispose();p.dispose();}
 });
 it.each([2,5,8])('absorbs a %sm board-first drop without folding the knees into a bail',height=>{
  const p=new SnowboardPhysics(plane(0)),r=new ActiveRider(p);p.launchSpeed(12);let crashes=0,minHip=Infinity,maxBend=0;
  p.onEvent=e=>{if(e.type==='crash'){crashes++;r.release();}};
  try{
   advance(p,.8);
   for(const b of [p.board,...r.ragdoll.bodies])b.setTranslation(vec(b.translation()).add(new THREE.Vector3(0,height,0)),true);
   p.sync();
   for(let i=0;i<480;i++){
    p.update(neutral,1/120);
    if(p.landingRecovery>0){
     const j=r.ragdoll.poses(),up=new THREE.Vector3(0,1,0).applyQuaternion(p.orientation);minHip=Math.min(minHip,j.hip.clone().sub(p.position).dot(up));
     for(const [a,b,c]of [[j.lh,j.lk,j.la],[j.rh,j.rk,j.ra]])maxBend=Math.max(maxBend,Math.PI-a.clone().sub(b).angleTo(c.clone().sub(b)));
    }
   }
   expect(crashes).toBe(0);expect(p.crashed).toBe(false);expect(p.grounded).toBe(true);
   expect(minHip).toBeGreaterThan(.36);expect(maxBend).toBeLessThan(height>=5?2.35:2.8);
   expect(new THREE.Vector3(0,1,0).applyQuaternion(p.orientation).y).toBeGreaterThan(.9);
  }finally{r.dispose();p.dispose();}
 });
 it('uses actual native forearm-to-torso collision while tumbling',()=>{
  const p=new SnowboardPhysics(plane(0)),r=new ActiveRider(p);let impulse=0;
  try{
   for(const b of [p.board,...r.ragdoll.bodies]){b.setTranslation(vec(b.translation()).add(new THREE.Vector3(0,6,0)),true);b.setLinvel({x:0,y:0,z:0},true);}
   p.sync();p.bail('Collision test');r.release();
   const torso=r.ragdoll.bodies[1],arm=r.ragdoll.bodies[8];
   arm.setTranslation(vec(torso.translation()).add(new THREE.Vector3(.2,0,0)),true);arm.setRotation(torso.rotation(),true);
   for(let i=0;i<30;i++){
    p.update(neutral,1/480);
    p.dynamics.contactPair(torso.collider(0),arm.collider(0),m=>{for(let c=0;c<m.numContacts();c++)impulse+=m.contactImpulse(c);});
    for(const b of r.ragdoll.bodies)expect(vec(b.linvel()).length()).toBeLessThan(90);
   }
   expect(impulse).toBeGreaterThan(.01);expect(p.crashed).toBe(true);expect(p.dynamics.bodies.len()).toBe(12);
   expect(arm.collider(0).collisionGroups()).toBe(0x00020007);
  }finally{r.dispose();p.dispose();}
 });
});
it.each([0,.22,.38])('coasts and releases repeated tucks without falling backwards on slope %s',slope=>{
 const p=new SnowboardPhysics(plane(slope));p.launchSpeed();const r=new ActiveRider(p);let crashes=0;
 p.onEvent=e=>{if(e.type==='crash'){crashes++;r.release();}};
 try{
  for(let i=0;i<120*24;i++){
   p.update({...neutral,tuck:i<360||i>1200&&i<1560},1/120);
   expect(new THREE.Vector3(0,1,0).applyQuaternion(p.orientation).dot(p.world.normal(p.position.x,p.position.z))).toBeGreaterThan(.4);
  }
  expect(crashes).toBe(0);expect(p.crashed).toBe(false);expect(p.position.z).toBeGreaterThan(120);
 }finally{r.dispose();p.dispose();}
},15000);
