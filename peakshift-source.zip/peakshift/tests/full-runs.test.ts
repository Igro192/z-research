import {beforeAll,it,expect} from 'vitest';
import * as THREE from 'three';
import {MountainWorld,MAPS,atLiftFinish} from '../src/game/world';
import {initPhysics,SnowboardPhysics,recoveryPoint} from '../src/game/physics';
import {ActiveRider} from '../src/game/active-rider';
import {SnowRagdoll,shouldGetUp} from '../src/game/fall';
import {neutral} from './helpers';
beforeAll(initPhysics);
it.each(MAPS)('$id reaches the gondola with bounded contact, flight and ragdoll motion',async map=>{
 const w=new MountainWorld(new THREE.Scene(),map),p=new SnowboardPhysics(w);
 p.launchSpeed();
 let rider=new ActiveRider(p),fall:SnowRagdoll|undefined,finished=false,maxAir=0;
 p.onEvent=e=>{if(e.type==='crash')fall=rider.release();if(e.type==='save')fall=undefined;};
 try{
  for(let i=0;i<180*120;i++){
   if(i%600===0)await new Promise(resolve=>setTimeout(resolve,0));
   // Steer along the winding centre route, as a rider would, through the finish.
   const target=Math.atan2((w.center(p.position.z+20)-p.position.x)*.22,25)+(p.switch?Math.PI:0),error=Math.atan2(Math.sin(target-p.heading),Math.cos(target-p.heading));
   p.update({...neutral,jump:i>240&&i<372,turn:THREE.MathUtils.clamp(-error*2,-1,1),airTurn:0,airPitch:0},1/120);
   expect(p.position.toArray().every(Number.isFinite)).toBe(true);
   expect(p.speed).toBeLessThan(65);
   expect(p.dynamics.bodies.len()).toBe(12);
   for(const b of rider.ragdoll.bodies){
    expect(new THREE.Vector3().copy(b.linvel()).length()).toBeLessThan(90);
    const centre=b.translation();expect(centre.y-w.groundHeight(centre.x,centre.z)).toBeGreaterThan(-.2);
   }
   expect(p.position.y-w.groundHeight(p.position.x,p.position.z)).toBeGreaterThan(-.2);
   if(!p.crashed){maxAir=Math.max(maxAir,p.airtime);expect(p.position.y-w.groundHeight(p.position.x,p.position.z)).toBeGreaterThan(-.12);}
   if(fall){
    fall.update(1/120);
    for(const b of fall.bodies){expect(new THREE.Vector3().copy(b.linvel()).length()).toBeLessThan(90);}
    const settled=fall.bodies.reduce((sum,b)=>sum+new THREE.Vector3().copy(b.linvel()).length(),0)/fall.bodies.length;
    if(shouldGetUp(fall.elapsed,p.fallSupportedFor,settled,false)){const hip=fall.poses().hip,score=p.score,safe=recoveryPoint(w,hip.x,hip.z);rider.dispose();fall=undefined;p.reset(safe.x,safe.z,true);p.launchSpeed();rider=new ActiveRider(p);expect(p.score).toBe(score);}
   }
   if(!p.crashed&&p.grounded&&atLiftFinish(p.position.x,p.position.z)){finished=true;break;}
  }
  expect(finished).toBe(true);expect(maxAir).toBeLessThan(6);if(!['speed','pipes','side-hits'].includes(map.layout||''))expect(p.score).toBeGreaterThan(0);
 }finally{rider.dispose();p.dispose();w.dispose();}
},60000);
