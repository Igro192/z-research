import {beforeAll,describe,expect,it} from 'vitest';
import * as THREE from 'three';
import {initPhysics,SnowboardPhysics,terrainFrame} from '../src/game/physics';
import {ActiveRider} from '../src/game/active-rider';
import {shouldGetUp} from '../src/game/fall';
import {advance,neutral,plane} from './helpers';
beforeAll(initPhysics);
const vec=(v:{x:number;y:number;z:number})=>new THREE.Vector3().copy(v);
function falling(heading=0,tilt=0,height=.55){
 const p=new SnowboardPhysics(plane(0));p.reset(0,0,false,heading);
 p.board.setRotation(terrainFrame(new THREE.Vector3(0,1,0),heading).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,0,1),tilt)),true);p.sync();
 const r=new ActiveRider(p),bodies=[p.board,...r.ragdoll.bodies];
 for(const b of bodies){b.setTranslation(vec(b.translation()).add(new THREE.Vector3(0,height,0)),true);b.setLinvel({x:0,y:-2,z:10},true);}
 p.sync();p.score=750;p.bail('Air tumble');r.release();
 return{p,r,bodies,dispose:()=>{r.dispose();p.dispose();}};
}
describe('recoverable physical tumbles',()=>{
 it.each([[0,0],[Math.PI,0],[.25,.3]])('catches a rideable board-first landing heading %s tilt %s without replacing or teleporting bodies',(heading,tilt)=>{
  const {p,r,bodies,dispose}=falling(heading,tilt),handles=bodies.map(b=>b.handle);let saves=0;
  const resume=r.resume.bind(r);
  r.resume=input=>{
   const positions=bodies.map(b=>vec(b.translation())),velocities=bodies.map(b=>vec(b.linvel())),rotations=bodies.map(b=>new THREE.Quaternion().copy(b.rotation())),omegas=bodies.map(b=>vec(b.angvel()));
   resume(input);
   bodies.forEach((b,i)=>{expect(vec(b.translation()).distanceTo(positions[i])).toBe(0);expect(vec(b.linvel()).distanceTo(velocities[i])).toBe(0);expect(new THREE.Quaternion().copy(b.rotation()).toArray()).toEqual(rotations[i].toArray());expect(vec(b.angvel()).distanceTo(omegas[i])).toBe(0);});
  };
  p.onEvent=e=>{if(e.type==='save'){saves++;expect(p.grounded).toBe(true);}};
  try{
   advance(p,.08);expect(p.crashed).toBe(true);expect(p.grounded).toBe(false);expect(saves).toBe(0);
   for(let i=0;i<120&&p.crashed;i++)p.update(neutral,1/120);
   expect(saves).toBe(1);expect(p.crashed).toBe(false);expect(p.score).toBe(750);expect(p.lastPoints).toBe(0);
   expect(bodies.map(b=>b.handle)).toEqual(handles);expect(p.dynamics.impulseJoints.len()).toBe(12);expect(p.switch).toBe(heading===Math.PI);
   const z=p.position.z;advance(p,2);expect(p.crashed).toBe(false);expect(p.position.z).toBeGreaterThan(z+10);
   for(const b of bodies)expect(vec(b.linvel()).length()).toBeLessThan(35);
   advance(p,.5,{turn:1});expect(p.steering).toBeGreaterThan(.8);
  }finally{dispose();}
 });
 it('keeps a head-first landing passive instead of powering an impossible stance',()=>{
  const {p,r,dispose}=falling(0,Math.PI,3);let saves=0;p.onEvent=e=>{if(e.type==='save')saves++;};
  try{advance(p,1.4);expect(saves).toBe(0);expect(p.crashed).toBe(true);expect(p.fallSupportedFor).toBeGreaterThan(0);expect(r.canResume(new THREE.Vector3(0,1,0))).toBe(false);}
  finally{dispose();}
 });
 it('does not choose an airborne upright rotation, and still accepts deliberate air input',()=>{
  const {p,dispose}=falling(0,.6,40);
  try{
   const start=p.orientation.clone();advance(p,.12);
   expect(p.crashed).toBe(true);expect(p.fallSupportedFor).toBe(0);expect(start.angleTo(p.orientation)).toBeLessThan(.15);
   const omega=p.riderDynamics!.angularVelocity().y;advance(p,.25,{airTurn:1});
   expect(p.riderDynamics!.angularVelocity().y).toBeLessThan(omega-.2);expect(p.crashed).toBe(true);
  }finally{dispose();}
 });
 it('can catch repeatedly without accumulating bodies or constraints',()=>{
  const {p,r,bodies,dispose}=falling();let saves=0;p.onEvent=e=>{if(e.type==='save')saves++;if(e.type==='crash')r.release();};
  try{
   advance(p,1);expect(p.crashed).toBe(false);
   for(let i=0;i<4;i++){
    advance(p,2);expect(p.grounded).toBe(true);
    p.bail('Wobble');for(let frame=0;frame<240&&p.crashed;frame++)p.update(neutral,1/120);expect(p.crashed).toBe(false);
    expect(p.dynamics.bodies.len()).toBe(12);expect(p.dynamics.impulseJoints.len()).toBe(12);
    for(const b of bodies)expect(vec(b.linvel()).length()).toBeLessThan(35);

   }
   expect(saves).toBe(5);expect(p.score).toBe(750);
  }finally{dispose();}
 },15000);
 it('never gets up just because an airborne tumble has lasted a long time',()=>{
  expect(shouldGetUp(20,0,0,false)).toBe(false);expect(shouldGetUp(20,0,1,true)).toBe(false);
  expect(shouldGetUp(8,.05,10,false)).toBe(false);expect(shouldGetUp(1,.002,10,true)).toBe(true);expect(shouldGetUp(1,.2,10,true)).toBe(true);
  expect(shouldGetUp(3,.5,1,false)).toBe(true);expect(shouldGetUp(7,.5,10,false)).toBe(true);
 });
});
