import{beforeAll,describe,it,expect}from'vitest';
import*as THREE from'three';
import{initPhysics,SnowboardPhysics}from'../src/game/physics';
import{createRider,poseRider}from'../src/game/rider';
import{GRAB_NAMES,grabDefinition,BOARD_LENGTH}from'../src/game/tricks';
import{keyboardInput}from'../src/game/input';
import{plane,neutral,advance}from'./helpers';
beforeAll(initPhysics);
describe('reference-based snowboard grabs',()=>{
 it.each(GRAB_NAMES)('%s touches the correct board target with an unstretched arm and attached feet',style=>{
  const p=new SnowboardPhysics(plane()),r=createRider('snowboard');p.position.y+=5;p.grounded=false;p.airtime=.6;
  for(let i=0;i<90;i++)poseRider(r,p,{...neutral,grab:true,grabStyle:style},1/120);
  const def=grabDefinition(style),a=r.userData.parts,elbow=def.hand==='rear'?a.rightElbow:a.leftElbow,shoulder=elbow.parent,hand=elbow.localToWorld(new THREE.Vector3(0,-.35,.014)),target=a.board.localToWorld(new THREE.Vector3(...def.target));
  expect(hand.distanceTo(target)).toBeLessThan(.04);expect(r.userData.pose.grabContact).toBe(true);
  expect(shoulder.getWorldPosition(new THREE.Vector3()).distanceTo(elbow.getWorldPosition(new THREE.Vector3()))).toBeCloseTo(.33,4);
  expect(elbow.getWorldPosition(new THREE.Vector3()).distanceTo(hand)).toBeCloseTo(Math.hypot(.35,.014),4);
  for(const[side,boot]of[[1,a.leftAnkle],[-1,a.rightAnkle]]as const)expect(boot.getWorldPosition(new THREE.Vector3()).distanceTo(a.board.localToWorld(new THREE.Vector3(0,.245,side*.3)))).toBeLessThan(.006);
  expect(a.head.getWorldPosition(new THREE.Vector3()).y-p.position.y).toBeGreaterThan(.45);p.dispose();
 });
 it('uses a proportionate adult twin-tip deck with rounded tips',()=>{const r=createRider('snowboard'),a=r.userData.parts,box=new THREE.Box3().setFromObject(a.board);expect(box.max.z-box.min.z).toBeCloseTo(BOARD_LENGTH,2);expect(BOARD_LENGTH).toBeLessThan(1.7);});
 it('ignores the retired grab buttons while retaining cork controls',()=>{for(const key of ['ShiftLeft','ShiftRight','KeyQ','KeyE',...Array.from({length:8},(_,i)=>'Digit'+(i+1))]){const input=keyboardInput(new Set([key]));expect(input.grab).toBe(false);expect(input.grabStyle).toBeUndefined();}expect(keyboardInput(new Set(['KeyZ'])).roll).toBe(-1);});
 it('does not score a held grab when the rendered hand has not made contact',()=>{const p=new SnowboardPhysics(plane());p.launchSpeed(14);advance(p,1.1,{jump:true});advance(p,1,{grab:true,grabStyle:'Mute',grabContact:false});advance(p,2);expect(p.lastTrick).not.toContain('Mute');p.dispose();});
 it('recognizes two sustained hand contacts in a single air',()=>{const p=new SnowboardPhysics(plane()),events:string[]=[];p.onEvent=e=>{if(e.type==='land')events.push(e.text||'');};p.launchSpeed(14);advance(p,1.1,{jump:true});advance(p,.6,{grab:true,grabStyle:'Indy',grabContact:true});advance(p,.6,{grab:true,grabStyle:'Stalefish',grabContact:true});advance(p,2);expect(events.some(e=>e.includes('Indy → Stalefish'))).toBe(true);expect(p.crashed).toBe(false);p.dispose();});
 it('conserves angular momentum when folding and opening the rider mass distribution',()=>{const p=new SnowboardPhysics(plane(0));p.board.setAngvel({x:0,y:3,z:0},true);p.setRiderTuck(.9);expect(p.board.mass()).toBeCloseTo(80,3);expect(p.board.angvel().y).toBeGreaterThan(5);p.setRiderTuck(0);expect(p.board.angvel().y).toBeCloseTo(3,4);p.dispose();});
 it('removes a grab pose cleanly after releasing the button',()=>{const p=new SnowboardPhysics(plane()),r=createRider('snowboard');p.grounded=false;p.airtime=.5;for(let i=0;i<60;i++)poseRider(r,p,{...neutral,grab:true,grabStyle:'Nose'},1/120);for(let i=0;i<90;i++)poseRider(r,p,neutral,1/120);expect(r.userData.pose.grabContact).toBe(false);expect(r.userData.parts.pelvis.position.y).toBeGreaterThan(.75);expect(Math.abs(r.userData.parts.leftElbow.rotation.y)).toBeLessThan(.01);p.dispose();});
});
