import {beforeAll,it,expect} from 'vitest';
import * as THREE from 'three';
import {initPhysics,SnowboardPhysics,type TerrainWorldLike} from '../src/game/physics';
import {ActiveRider} from '../src/game/active-rider';
import {neutral} from './helpers';
beforeAll(initPhysics);
function bowl():TerrainWorldLike{
 const height=(x:number,z:number)=>x*x*.045-z*.12,normal=(x:number,_z:number)=>new THREE.Vector3(-x*.09,1,.12).normalize();
 const vertices:number[]=[],indices:number[]=[],nx=160,nz=320;
 for(let j=0;j<=nz;j++)for(let i=0;i<=nx;i++){const x=-40+i*.5,z=-40+j*2;vertices.push(x,height(x,z),z);}
 for(let j=0;j<nz;j++)for(let i=0;i<nx;i++){const a=j*(nx+1)+i;indices.push(a,a+nx+1,a+1,a+1,a+nx+1,a+nx+2);}
 return{height,normal,objects:[],obstacles:[],collisionMesh:()=>({vertices:new Float32Array(vertices),indices:new Uint32Array(indices)})};
}
it.each([-.9,.9,-1.2,1.2])('rides up a side bank and returns under momentum and gravity at heading %s',heading=>{
 const w=bowl(),p=new SnowboardPhysics(w);p.reset(0,20,false,heading);p.board.setLinvel({x:Math.sin(heading)*19,y:-Math.cos(heading)*19*.12,z:Math.cos(heading)*19},true);p.sync();
 const r=new ActiveRider(p);let peak=0,crashes=0,returned=false;
 p.onEvent=e=>{if(e.type==='crash'){crashes++;r.release();}};
 try{
  for(let i=0;i<840;i++){
   p.update(neutral,1/120);const bank=Math.abs(p.position.x);peak=Math.max(peak,bank);if(peak>4&&bank<peak-2)returned=true;
   expect(p.position.y-w.height(p.position.x,p.position.z)).toBeGreaterThan(-.12);
   for(const b of r.ragdoll.bodies)expect(new THREE.Vector3().copy(b.linvel()).length()).toBeLessThan(90);
  }
  expect(peak).toBeGreaterThan(4);expect(returned).toBe(true);expect(crashes).toBe(0);expect(p.crashed).toBe(false);
 }finally{r.dispose();p.dispose();}
},15000);
it('draws the snowboard at its real physical orientation during a tumble',()=>{
 const p=new SnowboardPhysics(bowl()),r=new ActiveRider(p);
 try{
  p.bail('Render test');r.release();p.update(neutral,.1);r.render(r.reference);
  expect(r.reference.userData.parts.board.getWorldQuaternion(new THREE.Quaternion()).angleTo(p.orientation.clone().normalize())).toBeLessThan(.001);
  expect(p.board.collider(0).collisionGroups()).toBe(0x00040003);
  expect(r.ragdoll.joints[4].contactsEnabled()).toBe(true);expect(r.ragdoll.joints[7].contactsEnabled()).toBe(true);
 }finally{r.dispose();p.dispose();}
});
