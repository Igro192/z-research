# Peakshift

Original snowboarding game source and tests. Generated builds and bundled assets are excluded.

## Run

npm install; npm run dev

This is a source snapshot from Z. Research. No license is granted for third-party content or trademarks.
