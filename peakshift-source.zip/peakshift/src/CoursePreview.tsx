import React from 'react';
import {courseCenter,courseObjects,courseProfile,SNOW_FEATURES} from './game/courses';
import type {MapConfig} from './game/world';
/** Preview is drawn from the route and features used by the playable course. */
export function CoursePreview({map}:{map:MapConfig}){
 const profile=courseProfile(map.id),x=(v:number)=>100+v*.9,y=(z:number)=>8+z/1780*112;
 const route=Array.from({length:64},(_,i)=>{const z=i/63*1780;return`${i?'L':'M'}${x(courseCenter(map.id,z)).toFixed(1)},${y(z).toFixed(1)}`;}).join(' ');
 return <svg className="course-preview" viewBox="0 0 200 130" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
  <defs><linearGradient id={'course-'+map.id} x2="1" y2="1"><stop stopColor={map.sky}/><stop offset="1" stopColor={map.fog}/></linearGradient></defs>
  <rect width="200" height="130" fill={'url(#course-'+map.id+')'}/>
  {[0,1,2,3].map(i=><path key={i} d={`M${10+i*18},-10 Q${100-i*25},45 ${5+i*14},80 T${35+i*15},150 M${190-i*18},-10 Q${100+i*25},45 ${195-i*14},80 T${165-i*15},150`} fill="none" stroke="#e6f3f7" strokeOpacity={.13+i*.05} strokeWidth="2"/>)}
  <path d={route} fill="none" stroke="#173e4e" strokeOpacity=".23" strokeWidth={profile.width*.84+11}/>
  <path d={route} fill="none" stroke={map.night?'#b9d1e0':'#edf6f7'} strokeWidth={profile.width*.84}/>
  <path d={route} fill="none" stroke={map.accent} strokeWidth="1.4" strokeDasharray="2 3"/>
  {courseObjects(map.id).filter(o=>SNOW_FEATURES.has(o.type)||o.type.includes('rail')||o.type==='tube'||o.type==='box'||o.type==='halfpipe'||o.type.includes('ramp')).map(o=>{
   const px=x(o.x),py=y(o.z);
   return o.type.includes('rail')||o.type==='tube'||o.type==='box'?<rect key={o.id} x={px-1.5} y={py-3} width="3" height="6" rx="1" fill={map.accent}/>:<path key={o.id} d={o.type==='halfpipe'?`M${px-5},${py-3}q5,8 10,0`:`M${px-4},${py+2}l4,-5 4,5`} fill="none" stroke="#376b7a" strokeWidth="1.3"/>;
  })}
 </svg>;
}
