import * as THREE from 'three';
import {RAPIER,type SnowboardPhysics} from './physics';
export const FALL_JOINTS=['hip','chest','head','lh','rh','lk','rk','la','ra','ls','rs','le','re','lw','rw','lf','lb','rf','rb'] as const;
type Joint=typeof FALL_JOINTS[number];type Poses=Record<Joint,THREE.Vector3>;
const UP=new THREE.Vector3(0,1,0),DOWN=new THREE.Vector3(0,-1,0);
const point=(o:THREE.Object3D,x=0,y=0,z=0)=>o.localToWorld(new THREE.Vector3(x,y,z));
function capture(r:THREE.Group):Poses{const a=r.userData.parts;r.updateMatrixWorld(true);return{hip:point(a.pelvis),chest:point(a.torso,0,.46),head:point(a.head,0,.1),lh:point(a.leftLeg),rh:point(a.rightLeg),lk:point(a.leftKnee),rk:point(a.rightKnee),la:point(a.leftAnkle),ra:point(a.rightAnkle),ls:point(a.leftArm),rs:point(a.rightArm),le:point(a.leftElbow),re:point(a.rightElbow),lw:point(a.leftElbow,0,-.35),rw:point(a.rightElbow,0,-.35),lf:point(a.board,0,0,.78),lb:point(a.board,0,0,-.78),rf:point(a.board,0,0,.78),rb:point(a.board,0,0,-.78)};}
const position=(b:RAPIER.RigidBody)=>new THREE.Vector3().copy(b.translation());
const rotation=(b:RAPIER.RigidBody)=>new THREE.Quaternion().copy(b.rotation());
const local=(b:RAPIER.RigidBody,p:THREE.Vector3)=>p.clone().sub(position(b)).applyQuaternion(rotation(b).invert());
/** Eleven independent rider bodies, collision capsules and jointed boots on the physical board. */
export class SnowRagdoll{
 readonly frames:{node:THREE.Object3D;offset:THREE.Quaternion;body:RAPIER.RigidBody}[]=[];readonly bodies:RAPIER.RigidBody[]=[];readonly joints:RAPIER.ImpulseJoint[]=[];elapsed=0;
 private anchors=new Map<Joint,{body:RAPIER.RigidBody;local:THREE.Vector3}>();
 constructor(rider:THREE.Group,readonly physics:SnowboardPhysics){
  const p=capture(rider),world=physics.dynamics,velocity=physics.velocity.clone(),omega=physics.angularVelocity.clone(),centre=physics.position.clone().add(new THREE.Vector3(0,.55,0).applyQuaternion(physics.orientation));
  physics.board.setLinvel(velocity.clone().add(new THREE.Vector3().crossVectors(omega,physics.position.clone().sub(centre))),true);
  const add=(from:THREE.Vector3,to:THREE.Vector3,radius:number,mass:number,axis?:THREE.Vector3)=>{
   const up=to.clone().sub(from).normalize(),right=(axis||new THREE.Vector3(0,0,1).applyQuaternion(physics.orientation)).clone().addScaledVector(up,-(axis||new THREE.Vector3(0,0,1).applyQuaternion(physics.orientation)).dot(up)).normalize();
   if(right.lengthSq()<.1)right.set(1,0,0);const q=new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(right,up,new THREE.Vector3().crossVectors(right,up).normalize())),mid=from.clone().add(to).multiplyScalar(.5),v=velocity.clone().add(new THREE.Vector3().crossVectors(omega,mid.clone().sub(centre)));
   const body=world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(mid.x,mid.y,mid.z).setRotation(q).setLinvel(v.x,v.y,v.z).setAngvel(omega).setCcdEnabled(true).setSoftCcdPrediction(.3).setLinearDamping(.12).setAngularDamping(.4).setAdditionalSolverIterations(8));
   world.createCollider(RAPIER.ColliderDesc.capsule(Math.max(.01,from.distanceTo(to)/2-radius),radius).setMass(mass).setFriction(.35).setRestitution(.03),body);this.bodies.push(body);return body;
  };
  const anchor=(name:Joint,body:RAPIER.RigidBody)=>this.anchors.set(name,{body,local:local(body,p[name])});
  const joint=(a:RAPIER.RigidBody,b:RAPIER.RigidBody,at:THREE.Vector3,hinge=false,limits?:[number,number])=>{const data=hinge?RAPIER.JointData.revolute(local(a,at),local(b,at),{x:1,y:0,z:0}):RAPIER.JointData.spherical(local(a,at),local(b,at));const j=world.createImpulseJoint(data,a,b,true);j.setContactsEnabled(false);if(hinge)(j as RAPIER.RevoluteImpulseJoint).setLimits(...(limits||[-2.6,2.6]));this.joints.push(j);};
  const hip=add(p.hip.clone().add(new THREE.Vector3(0,-.1,0)),p.hip.clone().add(new THREE.Vector3(0,.1,0)),.16,12),torso=add(p.hip.clone().lerp(p.chest,.2),p.chest,.18,28),head=add(p.head.clone().add(new THREE.Vector3(0,-.02,0)),p.head.clone().add(new THREE.Vector3(0,.02,0)),.145,5);
  anchor('hip',hip);anchor('chest',torso);anchor('head',head);joint(hip,torso,p.hip.clone().lerp(p.chest,.2));joint(torso,head,p.head.clone().lerp(p.chest,.3));
  for(const names of [['lh','lk','la'],['rh','rk','ra'],['ls','le','lw'],['rs','re','rw']] as [Joint,Joint,Joint][]){
   const [top,middle,end]=names,leg=top==='lh'||top==='rh',u=p[middle].clone().sub(p[top]).normalize(),v=p[end].clone().sub(p[middle]).normalize(),axis=new THREE.Vector3().crossVectors(u,v).normalize();if(axis.lengthSq()<.1)axis.set(0,0,1).applyQuaternion(physics.orientation);
   const upper=add(p[top],p[middle],leg?.085:.07,leg?6:3,axis),lower=add(p[middle],p[end],leg?.07:.06,leg?4:2,axis);anchor(top,upper);anchor(middle,lower);anchor(end,lower);joint(leg?hip:torso,upper,p[top]);joint(upper,lower,p[middle],true,[-.15,2.8]);if(leg)joint(lower,physics.board,p[end]);
  }
  for(const name of ['lf','lb','rf','rb'] as Joint[])anchor(name,physics.board);
  const a=rider.userData.parts,nodes=[a.pelvis,a.torso,a.head,a.leftLeg,a.leftKnee,a.rightLeg,a.rightKnee,a.leftArm,a.leftElbow,a.rightArm,a.rightElbow] as THREE.Object3D[];this.bodies.forEach((body,i)=>this.frames.push({body,node:nodes[i],offset:nodes[i].getWorldQuaternion(new THREE.Quaternion()).invert().multiply(rotation(body))}));
 }
 update(dt:number){this.elapsed+=dt;}
 poses():Poses{return Object.fromEntries(FALL_JOINTS.map(name=>{const a=this.anchors.get(name)!;return[name,a.local.clone().applyQuaternion(rotation(a.body)).add(position(a.body))];})) as Poses;}
 snapshot(){const p=this.poses();return FALL_JOINTS.flatMap(n=>p[n].toArray());}
 render(r:THREE.Group){const q=this.frames.slice(0,3).map(f=>rotation(f.body).multiply(f.offset.clone().invert()));applyPose(r,this.poses(),{hip:q[0],torso:q[1],head:q[2],board:this.physics.orientation.clone()});}
 dispose(){for(const b of this.bodies)if(b.isValid())this.physics.dynamics.removeRigidBody(b);this.bodies.length=0;this.joints.length=0;}
}
function applyPose(rider:THREE.Group,j:Poses,orientations?:{hip:THREE.Quaternion;torso:THREE.Quaternion;head:THREE.Quaternion;board?:THREE.Quaternion}){
 const a=rider.userData.parts;rider.position.set(0,0,0);rider.quaternion.identity();a.equipment.position.set(0,0,0);a.equipment.quaternion.identity();
 const up=j.chest.clone().sub(j.hip).normalize(),right=j.rh.clone().sub(j.lh).normalize(),forward=new THREE.Vector3().crossVectors(right,up).normalize();right.crossVectors(up,forward).normalize();a.pelvis.position.copy(j.hip);a.pelvis.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(right,up,forward));a.torso.position.set(0,.08,0);a.torso.quaternion.identity();rider.updateMatrixWorld(true);a.head.position.copy(a.torso.worldToLocal(j.head.clone().addScaledVector(up,-.1)));a.head.quaternion.identity();
 if(orientations){
  a.pelvis.quaternion.copy(orientations.hip);rider.updateMatrixWorld(true);
  const torsoUp=UP.clone().applyQuaternion(orientations.torso);a.torso.position.copy(a.pelvis.worldToLocal(j.chest.clone().addScaledVector(torsoUp,-.46)));a.torso.quaternion.copy(a.pelvis.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(orientations.torso));rider.updateMatrixWorld(true);
  a.head.position.copy(a.torso.worldToLocal(j.head.clone().addScaledVector(UP.clone().applyQuaternion(orientations.head),-.1)));a.head.quaternion.copy(a.torso.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(orientations.head));rider.updateMatrixWorld(true);
 }
 const bone=(upper:THREE.Group,lower:THREE.Group,ankle:THREE.Group|undefined,from:THREE.Vector3,knee:THREE.Vector3,to:THREE.Vector3)=>{const parent=upper.parent!;parent.updateWorldMatrix(true,false);upper.position.copy(parent.worldToLocal(from.clone()));upper.quaternion.copy(parent.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(new THREE.Quaternion().setFromUnitVectors(DOWN,knee.clone().sub(from).normalize())));upper.updateWorldMatrix(false,true);lower.position.copy(upper.worldToLocal(knee.clone()));lower.quaternion.copy(upper.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(new THREE.Quaternion().setFromUnitVectors(DOWN,to.clone().sub(knee).normalize())));lower.updateWorldMatrix(false,true);if(ankle)ankle.position.copy(lower.worldToLocal(to.clone()));};
 bone(a.leftLeg,a.leftKnee,a.leftAnkle,j.lh,j.lk,j.la);bone(a.rightLeg,a.rightKnee,a.rightAnkle,j.rh,j.rk,j.ra);bone(a.leftArm,a.leftElbow,undefined,j.ls,j.le,j.lw);bone(a.rightArm,a.rightElbow,undefined,j.rs,j.re,j.rw);
 const c=j.lf.clone().add(j.lb).multiplyScalar(.5),f=j.lf.clone().sub(j.lb).normalize(),n=j.la.clone().add(j.ra).multiplyScalar(.5).sub(c);n.addScaledVector(f,-n.dot(f)).normalize();const side=new THREE.Vector3().crossVectors(n,f).normalize(),q=new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(side,n,f));if(orientations?.board)q.copy(orientations.board);a.board.position.copy(c);a.board.quaternion.copy(q);rider.updateMatrixWorld(true);
 for(const [ankle,side]of [[a.leftAnkle,1],[a.rightAnkle,-1]] as const)ankle.quaternion.copy(ankle.parent.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(q).multiply(new THREE.Quaternion().setFromAxisAngle(UP,Math.PI/2-side*.2)));
 rider.userData.pose={state:'tumbling'};rider.updateMatrixWorld(true);
}
export function renderFallSnapshot(rider:THREE.Group,values:number[]){applyPose(rider,Object.fromEntries(FALL_JOINTS.map((n,i)=>[n,new THREE.Vector3(values[i*3],values[i*3+1],values[i*3+2])])) as Poses);}

/** Getting up needs sustained physical support; a long airborne tumble never resets. */
export function shouldGetUp(elapsed:number,supportedFor:number,speed:number,requested:boolean){
 return supportedFor>0&&elapsed>.6&&requested||supportedFor>.4&&(elapsed>1.5&&speed<2||elapsed>3.5);
}
