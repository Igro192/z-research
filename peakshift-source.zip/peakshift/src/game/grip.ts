import * as THREE from 'three';
import {RAPIER,type SnowboardPhysics} from './physics';
import type {SnowRagdoll} from './fall';
import {GRAB_NAMES,grabDefinition,type GrabStyle} from './tricks';

/** A finite, breakable hand-to-deck grip; reaching alone never attaches it. */
export class BoardGrip{
 style?:GrabStyle;
 joint?:RAPIER.ImpulseJoint;
 private hand?:RAPIER.RigidBody;
 private anchor=new THREE.Vector3();
 private target=new THREE.Vector3();
 private reach(){
  if(!this.hand)return Infinity;
  const wrist=this.anchor.clone().applyQuaternion(new THREE.Quaternion().copy(this.hand.rotation())).add(this.hand.translation());
  const board=this.target.clone().applyQuaternion(this.physics.orientation).add(this.physics.position);
  return wrist.distanceTo(board);
 }
 constructor(private physics:SnowboardPhysics,private rider:SnowRagdoll){}
 update(style?:string){
  const next=GRAB_NAMES.includes(style as GrabStyle)?style as GrabStyle:undefined;
  if(next!==this.style)this.release();
  if(!next)return;
  if(this.joint){if(this.reach()>.18)this.release();return;}
  const def=grabDefinition(next),poses=this.rider.poses(),wrist=def.hand==='rear'?poses.rw:poses.lw;
  const point=new THREE.Vector3(...def.target).applyQuaternion(this.physics.orientation).add(this.physics.position);
  if(wrist.distanceTo(point)>.07)return;
  this.hand=this.rider.bodies[def.hand==='rear'?10:8];
  this.anchor.copy(wrist).sub(this.hand.translation()).applyQuaternion(new THREE.Quaternion().copy(this.hand.rotation()).invert());
  this.target.set(def.target[0],def.target[1],def.target[2]);
  const data=RAPIER.JointData.spring(.018,1800,45,this.anchor,this.target);
  this.joint=this.physics.dynamics.createImpulseJoint(data,this.hand,this.physics.board,true);
  this.joint.setContactsEnabled(false);this.style=next;
 }
 release(){
  if(this.joint?.isValid())this.physics.dynamics.removeImpulseJoint(this.joint,true);
  this.joint=undefined;this.style=undefined;this.hand=undefined;
 }
}
