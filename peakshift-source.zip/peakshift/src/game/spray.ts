import * as THREE from 'three';
import type {SnowboardPhysics,InputState} from './physics';

/** A fixed pool of cosmetic snow grains emitted by actual sliding/contact load. */
export class SnowSpray{
 readonly points:THREE.Points;
 private readonly count=420;
 private readonly positions=new Float32Array(this.count*3);
 private readonly velocity=new Float32Array(this.count*3);
 private readonly life=new Float32Array(this.count);
 private readonly sizes=new Float32Array(this.count);
 private index=0;private emission=0;private seed=71829;private grounded=true;
 constructor(scene:THREE.Scene){
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(this.positions,3).setUsage(THREE.DynamicDrawUsage));g.setAttribute('life',new THREE.BufferAttribute(this.life,1).setUsage(THREE.DynamicDrawUsage));g.setAttribute('grainSize',new THREE.BufferAttribute(this.sizes,1));
  const m=new THREE.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{pixelHeight:{value:800},snowColor:{value:new THREE.Color('#eaf2f6')}},vertexShader:`attribute float life;attribute float grainSize;uniform float pixelHeight;varying float opacity;void main(){vec4 p=modelViewMatrix*vec4(position,1.);gl_Position=projectionMatrix*p;gl_PointSize=life>0.?min(25.,grainSize*pixelHeight/max(1.,-p.z)):0.;opacity=life;}`,fragmentShader:`uniform vec3 snowColor;varying float opacity;void main(){vec2 uv=gl_PointCoord*2.-1.;float r=dot(uv,uv);if(r>1.||opacity<=0.)discard;gl_FragColor=vec4(snowColor,exp(-r*4.)*min(1.,opacity*3.)*.6);}`});
  this.points=new THREE.Points(g,m);this.points.frustumCulled=false;scene.add(this.points);
 }
 private random(){this.seed=(Math.imul(this.seed,1664525)+1013904223)>>>0;return this.seed/4294967296;}
 private emit(p:SnowboardPhysics,impact=false){
  const i=this.index++%this.count,k=i*3,n=p.surfaceNormal,side=new THREE.Vector3(1,0,0).applyQuaternion(p.orientation),edge=Math.sign(p.edgeAngle)||((this.index%2)*2-1),v=p.velocity,origin=p.position.clone().addScaledVector(side,edge*.13);
  const strength=impact?2.5:Math.min(3,.3+Math.abs(p.lateralSlip)*.23+Math.abs(p.edgeAngle)*p.speed*.15),spread=(.4+this.random())*strength;
  this.positions.set([origin.x,origin.y+.02,origin.z],k);
  this.velocity.set([side.x*edge*spread+v.x*.08+(this.random()-.5),n.y*(.5+this.random()*strength)+Math.max(0,v.y*.05),side.z*edge*spread+v.z*.08+(this.random()-.5)],k);
  this.life[i]=.35+this.random()*.5;this.sizes[i]=.035+this.random()*.11;
 }
 update(p:SnowboardPhysics,input:InputState,dt:number,pixelHeight:number){
  dt=Math.min(.05,dt);(this.points.material as THREE.ShaderMaterial).uniforms.pixelHeight.value=pixelHeight;
  if(p.grounded&&!p.crashed&&p.speed>3){
   const powder=p.world.map?.snow==='powder'?1.7:.6,rate=powder*(Math.abs(p.lateralSlip)*13+Math.abs(p.edgeAngle)*p.speed*5+(input.brake?p.speed*5:p.speed*.5));
   this.emission+=Math.min(260,rate)*dt;while(this.emission>=1){this.emit(p);this.emission--;}
   if(!this.grounded&&p.landingImpact>3)for(let i=0;i<Math.min(48,p.landingImpact*3);i++)this.emit(p,true);
  }
  this.grounded=p.grounded;
  for(let i=0;i<this.count;i++)if(this.life[i]>0){const k=i*3;this.life[i]-=dt;this.velocity[k]*=1-dt*1.7;this.velocity[k+2]*=1-dt*1.7;this.velocity[k+1]-=9.81*dt;for(let j=0;j<3;j++)this.positions[k+j]+=this.velocity[k+j]*dt;if(this.positions[k+1]<(p.world.groundHeight?.(this.positions[k],this.positions[k+2])??p.world.height(this.positions[k],this.positions[k+2])))this.life[i]=0;}
  for(const key of ['position','life','grainSize'])(this.points.geometry.getAttribute(key) as THREE.BufferAttribute).needsUpdate=true;
 }
 clear(){this.life.fill(0);this.emission=0;(this.points.geometry.getAttribute('life') as THREE.BufferAttribute).needsUpdate=true;}
 dispose(){this.points.removeFromParent();this.points.geometry.dispose();(this.points.material as THREE.Material).dispose();}
}
