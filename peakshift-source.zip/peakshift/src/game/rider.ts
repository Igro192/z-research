import * as THREE from 'three';
import type { InputState, SnowboardPhysics, Sport } from './physics';
import {BOARD_LENGTH,BOARD_WIDTH,grabDefinition} from './tricks';
import {garmentGeometry,goggleGeometry} from './garment';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';

type Parts = {
  pelvis: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftElbow: THREE.Group;
  rightElbow: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftKnee: THREE.Group;
  rightKnee: THREE.Group;
  equipment: THREE.Group;
  board:THREE.Group;bindingFrame:THREE.Group;leftAnkle:THREE.Group;rightAnkle:THREE.Group;
};

function mesh(geometry: THREE.BufferGeometry, material: THREE.Material, parent: THREE.Object3D, x = 0, y = 0, z = 0): THREE.Mesh {
  const object = new THREE.Mesh(geometry, material);
  object.position.set(x, y, z);
  object.castShadow = true;
  object.receiveShadow = true;
  parent.add(object);
  return object;
}

/** A curved, bevel-like deck silhouette made from cross-sections, without textures. */
function deckGeometry(length: number, width: number): THREE.BufferGeometry {
  const vertices: number[] = [], indices: number[] = [];
  const segments = 18;
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    const end = Math.abs(t * 2 - 1);
    const tip = Math.max(0, (end - 0.72) / 0.28);
    const halfWidth = width * .5 * (.9+.1*end*end)*Math.sqrt(Math.max(.03,1-tip*tip));
    const lift = Math.pow(tip, 2) * 0.12;
    const z = (t - 0.5) * length;
    vertices.push(-halfWidth, lift, z, halfWidth, lift, z, -halfWidth, lift - 0.045, z, halfWidth, lift - 0.045, z);
    if (i < segments) {
      const a = i * 4, b = a + 4;
      indices.push(a, b, a + 1, a + 1, b, b + 1);
      indices.push(a + 2, a + 3, b + 2, a + 3, b + 3, b + 2);
      indices.push(a, a + 2, b, b, a + 2, b + 2);
      indices.push(a + 1, b + 1, a + 3, a + 3, b + 1, b + 3);
    }
  }
  indices.push(0, 1, 2, 1, 3, 2);
  const a = segments * 4;
  indices.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

export function createRider(sport: Sport, color = '#ff632b'): THREE.Group {
  const rider = new THREE.Group();
  rider.name = `${sport}-rider`;
  const fabric = new THREE.MeshStandardMaterial({ color, roughness: 0.92 });
  const darkFabric = new THREE.MeshStandardMaterial({ color: '#263744', roughness: 0.96 });
  const panel = new THREE.MeshStandardMaterial({ color: new THREE.Color(color).multiplyScalar(0.72), roughness: 0.85 });
  const black = new THREE.MeshStandardMaterial({ color: '#101c25', roughness: 0.6 });
  const bootMaterial = new THREE.MeshStandardMaterial({ color: '#263d4b', roughness: 0.64 });
  const helmetMaterial = new THREE.MeshStandardMaterial({ color: '#f3eee2', roughness: 0.48 });
  const lens = new THREE.MeshStandardMaterial({ color: '#72d6e9', metalness: 0.78, roughness: 0.18 });
  const silver = new THREE.MeshStandardMaterial({ color: '#a5b8c3', metalness: 0.75, roughness: 0.3 });
  const coral = new THREE.MeshStandardMaterial({ color: '#ff7449', roughness: 0.5 });
  const deckMaterial = new THREE.MeshStandardMaterial({ color: '#f6cc64', metalness: 0.18, roughness: 0.48, side: THREE.DoubleSide });
  const equipment = new THREE.Group();
  equipment.name = 'equipment';
  rider.add(equipment);
  const pelvis = new THREE.Group();
  pelvis.name = 'hips';
  pelvis.position.y = 0.95;
  rider.add(pelvis);
  mesh(garmentGeometry([[-.13,.2,.145],[-.07,.235,.17],[.04,.24,.175],[.1,.215,.16]]),darkFabric,pelvis);
  const torso = new THREE.Group();
  torso.name = 'jacket';
  torso.position.y = 0.08;
  pelvis.add(torso);
  mesh(garmentGeometry([[0,.24,.17],[.08,.255,.18],[.25,.245,.175],[.4,.255,.17],[.47,.255,.155],[.54,.195,.12],[.58,.12,.095]]),fabric,torso);
  // Shoulder yoke, zipper, chest pocket and jacket hem remain readable at distance.
  mesh(new THREE.BoxGeometry(0.012, 0.43, 0.008), helmetMaterial, torso, 0, 0.28, 0.181);
  mesh(new THREE.BoxGeometry(0.1, 0.115, 0.012), panel, torso, -0.13, 0.35, 0.15);
  mesh(new THREE.CylinderGeometry(.24,.245,.045,16),panel,torso,0,.025,0).scale.z=.77;
  // Compact avalanche backpack and bright compression straps.
  mesh(new RoundedBoxGeometry(0.28,0.38,0.13,3,.035), darkFabric, torso, 0, 0.3, -0.22);
  mesh(new THREE.BoxGeometry(0.024, 0.34, 0.018), coral, torso, -0.075, 0.3, -0.292);
  mesh(new THREE.BoxGeometry(0.024, 0.34, 0.018), coral, torso, 0.075, 0.3, -0.292);

  const head = new THREE.Group();
  head.name = 'helmet';
  head.position.set(0, 0.65, 0.015);
  torso.add(head);
  mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.1, 8), black, head, 0, -0.055, 0);
  mesh(new THREE.SphereGeometry(0.16, 16, 12), helmetMaterial, head, 0, 0.1, 0).scale.set(1, 1.05, 1.05);
  const strap=mesh(new THREE.TorusGeometry(.159,.015,6,32),black,head,0,.085,0);strap.rotation.x=Math.PI/2;
  mesh(goggleGeometry(.18,.2,.087),black,head,0,.085,.012);
  mesh(goggleGeometry(.168,.204,.065),lens,head,0,.085,.016);
  mesh(new THREE.BoxGeometry(0.11, 0.08, 0.11), black, head, 0, -0.002, 0.105);
  for (const x of [-0.07, 0, 0.07]) mesh(new THREE.BoxGeometry(0.022, 0.014, 0.08), darkFabric, head, x, 0.258, -0.015);

  function arm(side: number) {
    const shoulder = new THREE.Group();
    shoulder.name = side < 0 ? 'left-shoulder' : 'right-shoulder';
    shoulder.position.set(side * 0.25, 0.45, 0);
    torso.add(shoulder);
    mesh(garmentGeometry([[-.33,.071,.074],[-.24,.085,.078],[-.1,.098,.09],[.015,.085,.08]]),fabric,shoulder);
    const elbow = new THREE.Group();
    elbow.name = side < 0 ? 'left-elbow' : 'right-elbow';
    elbow.position.y = -0.33;
    shoulder.add(elbow);
    mesh(garmentGeometry([[-.31,.066,.068],[-.2,.075,.071],[-.07,.078,.074],[.015,.073,.071]]),fabric,elbow);
    mesh(new THREE.CylinderGeometry(0.078, 0.076, 0.055, 8), black, elbow, 0, -0.3, 0);
    mesh(new THREE.SphereGeometry(1,12,8),black,elbow,0,-.35,.014).scale.set(.06,.085,.045);
    mesh(new THREE.SphereGeometry(.024,10,8),black,elbow,-side*.051,-.327,.032).scale.set(1,1.25,.8);
    return { shoulder, elbow };
  }
  function leg(side: number) {
    const thigh=new THREE.Group();thigh.name=side<0?'left-hip':'right-hip';thigh.position.set(side*.16,-.04,0);pelvis.add(thigh);
    mesh(garmentGeometry([[-.42,.092,.095],[-.31,.102,.101],[-.14,.12,.11],[.015,.115,.105]]),darkFabric,thigh);
    const knee=new THREE.Group();knee.name=side<0?'left-knee':'right-knee';knee.position.y=-.42;thigh.add(knee);
    mesh(garmentGeometry([[-.43,.083,.083],[-.32,.088,.092],[-.14,.093,.1],[.012,.093,.092]]),darkFabric,knee);
    mesh(new THREE.SphereGeometry(.09,12,8),darkFabric,knee,0,0,0).scale.set(1,.9,1);
    const ankle=new THREE.Group();ankle.name=side<0?'left-boot':'right-boot';ankle.position.y=-.43;knee.add(ankle);
    mesh(new RoundedBoxGeometry(.17,.19,.25,3,.035),bootMaterial,ankle,0,-.035,.035);
    mesh(new RoundedBoxGeometry(.18,.05,.33,3,.015),black,ankle,0,-.14,.065);
    for(const y of [-.005,-.08])mesh(new THREE.BoxGeometry(.18,.024,.025),silver,ankle,0,y,.165);
    return {thigh,knee,ankle};
  }
  const leftArm=arm(-1),rightArm=arm(1),leftLeg=leg(-1),rightLeg=leg(1);
  const board=new THREE.Group(),bindingFrame=new THREE.Group();board.name='snowboard';bindingFrame.name='binding-frame';equipment.add(board);board.add(bindingFrame);
  mesh(deckGeometry(BOARD_LENGTH,BOARD_WIDTH),deckMaterial,board,0,0,0);
  for(const z of [-.3,.3]){const binding=mesh(new THREE.BoxGeometry(.29,.08,.17),black,board,0,.06,z);binding.rotation.y=z>0?-.26:.2;mesh(new THREE.BoxGeometry(.035,.16,.19),coral,board,-.14,.14,z);}
  pelvis.rotation.y=Math.PI/2;leftLeg.thigh.position.x=-.16;rightLeg.thigh.position.x=.16;
  const parts: Parts = {
    pelvis, torso, head, leftArm: leftArm.shoulder, rightArm: rightArm.shoulder,
    leftElbow: leftArm.elbow, rightElbow: rightArm.elbow, leftLeg: leftLeg.thigh,
    rightLeg: rightLeg.thigh, leftKnee: leftLeg.knee, rightKnee: rightLeg.knee,
    equipment,board,bindingFrame,leftAnkle:leftLeg.ankle,rightAnkle:rightLeg.ankle,
  };
  rider.userData.parts = parts;
  rider.userData.sport = sport;
  rider.userData.animationTime = 0;
  rider.updateMatrixWorld(true);
  // Pelvis faces +X: anatomical left is +Z, the regular leading binding.
  for(const [side,leg,knee,ankle,deck]of [[1,parts.leftLeg,parts.leftKnee,parts.leftAnkle,board],[-1,parts.rightLeg,parts.rightKnee,parts.rightAnkle,board]] as const){
    const target=deck.localToWorld(new THREE.Vector3(0,.245,side*.3));
    solveLimb(leg,knee,target,.42,.43,new THREE.Vector3(-side*.18,0,1));
    rider.updateMatrixWorld(true);ankle.quaternion.copy(knee.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(deck.getWorldQuaternion(new THREE.Quaternion())));
  }
  return rider;
}

const DOWN=new THREE.Vector3(0,-1,0),UP=new THREE.Vector3(0,1,0);

/** Two-bone inverse kinematics keeps boots constrained to independent bindings. */
function solveLimb(upper:THREE.Group,lower:THREE.Group,targetWorld:THREE.Vector3,l1:number,l2:number,pole:THREE.Vector3){
 const parent=upper.parent!;parent.updateWorldMatrix(true,false);
 const target=parent.worldToLocal(targetWorld.clone()),delta=target.sub(upper.position),distance=THREE.MathUtils.clamp(delta.length(),.08,l1+l2-.001),direction=delta.normalize();
 const bend=pole.clone().addScaledVector(direction,-pole.dot(direction)).normalize();
 const along=(l1*l1-l2*l2+distance*distance)/(2*distance),height=Math.sqrt(Math.max(0,l1*l1-along*along));
 const toKnee=direction.clone().multiplyScalar(along).addScaledVector(bend,height),toAnkle=direction.clone().multiplyScalar(distance).sub(toKnee);
 upper.quaternion.setFromUnitVectors(DOWN,toKnee.normalize());lower.position.set(0,-l1,0);
 const lowerDirection=new THREE.Quaternion().setFromUnitVectors(DOWN,toAnkle.normalize());
 lower.quaternion.copy(upper.quaternion).invert().multiply(lowerDirection);
}

/** Terrain frame utility for board orientation. */
export function surfaceOrientation(normal:THREE.Vector3,heading:number):THREE.Quaternion{
 const forward=new THREE.Vector3(Math.sin(heading),0,Math.cos(heading));forward.addScaledVector(normal,-forward.dot(normal)).normalize();
 const right=new THREE.Vector3().crossVectors(normal,forward).normalize();
 return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(right,normal,forward));
}
export function poseRider(group:THREE.Group,physics:SnowboardPhysics,input:InputState,dt:number){
 const p=group.userData.parts as Parts;
 if(group.userData.pose?.state==='tumbling'){group.userData.grabBlend=0;
  p.pelvis.position.set(0,.92,0);p.pelvis.rotation.set(0,Math.PI/2,0);p.torso.position.set(0,.08,0);p.head.position.set(0,.65,.015);p.head.rotation.set(0,0,0);
  p.leftLeg.position.set(-.16,-.04,0);p.rightLeg.position.set(.16,-.04,0);p.leftAnkle.position.set(0,-.43,0);p.rightAnkle.position.set(0,-.43,0);p.leftArm.position.set(-.25,.45,0);p.rightArm.position.set(.25,.45,0);p.leftElbow.position.set(0,-.33,0);p.rightElbow.position.set(0,-.33,0);
 }
 group.position.copy(physics.position);group.quaternion.copy(physics.orientation);p.board.position.set(0,0,0);p.board.quaternion.identity();animateRider(group,physics,input,dt);
}

/** Side-on stance, independent limbs and fixed boots on a dynamically simulated board. */
export function animateRider(group:THREE.Group,physics:SnowboardPhysics,input:InputState,dt:number){
 const p=group.userData.parts as Parts,time=(group.userData.animationTime||0)+dt;group.userData.animationTime=time;
 const air=!physics.grounded,clearance=physics.position.y-physics.world.height(physics.position.x,physics.position.z),catching=physics.touchdownPrep>.12,grab=air&&input.grab&&physics.airtime>.08&&clearance>.65&&!catching,coil=air?Math.sin(Math.PI*physics.flipProgress):0;
 const blend=THREE.MathUtils.damp(group.userData.grabBlend||0,grab?1:0,14,dt);group.userData.grabBlend=blend;
 const def=grabDefinition(input.grabStyle),crouch=THREE.MathUtils.clamp((physics.grounded?.2+physics.charge*.8+(input.tuck?.45:0):THREE.MathUtils.lerp(.2+coil*.65,.28,physics.touchdownPrep))+physics.compression*(physics.grounded&&physics.landingImpact>9?.4:.65),0,1.1),edge=physics.edgeAngle*(physics.switch?-1:1),windup=physics.spinWindup;
 const smooth=(o:THREE.Object3D,axis:'x'|'y'|'z',target:number)=>o.rotation[axis]=THREE.MathUtils.damp(o.rotation[axis],target,16,dt);
 const hip=new THREE.Vector3(THREE.MathUtils.lerp(-edge*.23,def.hipX,blend),THREE.MathUtils.lerp(.92-crouch*.31,def.hipY,blend),THREE.MathUtils.lerp(-(input.press||0)*.1,def.hipZ,blend));
 hip.add(physics.balanceOffset);p.pelvis.position.lerp(hip,1-Math.exp(-dt*18));
 p.pelvis.quaternion.setFromEuler(new THREE.Euler(physics.balanceTilt.x,0,physics.balanceTilt.z)).multiply(new THREE.Quaternion().setFromAxisAngle(UP,Math.PI/2));
 smooth(p.torso,'x',THREE.MathUtils.lerp(.15+crouch*.45,def.lean,blend));smooth(p.torso,'y',THREE.MathUtils.lerp((physics.switch?.43:-.3)+windup*.65,def.twist,blend));smooth(p.torso,'z',-edge*.2);
 smooth(p.head,'x',THREE.MathUtils.lerp(-crouch*.35,-def.lean*.7,blend));smooth(p.head,'y',physics.switch?.7:-.7);
 group.updateMatrixWorld(true);
 // Bring the body toward a reachable hand target; never stretch an arm to fake a grab.
 const hand=def.hand==='rear'?p.rightArm:p.leftArm,elbow=def.hand==='rear'?p.rightElbow:p.leftElbow;
 const grabTarget=p.board.localToWorld(new THREE.Vector3(...def.target));
 if(grab){for(let i=0;i<3;i++){const toward=grabTarget.clone().sub(hand.getWorldPosition(new THREE.Vector3())),distance=toward.length();if(distance<.66)break;const correction=toward.multiplyScalar(Math.min(.12,(distance-.66))/distance).applyQuaternion(group.quaternion.clone().invert());p.pelvis.position.addScaledVector(correction,blend);p.pelvis.position.y=Math.max(.32,p.pelvis.position.y);group.updateMatrixWorld(true);}}
 for(let iteration=0;iteration<4;iteration++){
  const correction=new THREE.Vector3();let count=0;
  for(const [side,leg]of [[1,p.leftLeg],[-1,p.rightLeg]] as const){const toward=p.board.localToWorld(new THREE.Vector3(0,.245,side*.3)).sub(leg.getWorldPosition(new THREE.Vector3())),d=toward.length();if(d>.835){correction.addScaledVector(toward,(d-.835)/d);count++;}}
  if(!count)break;p.pelvis.position.add(correction.multiplyScalar(1/count).applyQuaternion(group.quaternion.clone().invert()));group.updateMatrixWorld(true);
 }
 for(const [side,leg,knee,ankle]of [[1,p.leftLeg,p.leftKnee,p.leftAnkle],[-1,p.rightLeg,p.rightKnee,p.rightAnkle]] as const){
  const target=p.board.localToWorld(new THREE.Vector3(0,.245,side*.3));solveLimb(leg,knee,target,.42,.43,new THREE.Vector3(-side*.18,blend*(input.grabStyle==='Japan'?.6:.15),1));group.updateMatrixWorld(true);
  ankle.quaternion.copy(knee.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(p.board.getWorldQuaternion(new THREE.Quaternion())).multiply(new THREE.Quaternion().setFromAxisAngle(UP,Math.PI/2-side*.2)));
 }
 const spread=air?1.05:.45+Math.abs(edge)*.5+physics.balanceEffort*.65;
 smooth(p.leftArm,'z',-spread);smooth(p.rightArm,'z',spread);smooth(p.leftArm,'x',-.2-crouch*.5+windup*.65);smooth(p.rightArm,'x',-.2-crouch*.5-windup*.65);smooth(p.leftElbow,'x',-.65-crouch*.4);smooth(p.rightElbow,'x',-.65-crouch*.4);for(const arm of [p.leftArm,p.rightArm,p.leftElbow,p.rightElbow])smooth(arm,'y',0);for(const elbow of [p.leftElbow,p.rightElbow])smooth(elbow,'z',0);
 let grabContact=false;
 if(grab){
  const free=def.hand==='rear'?p.leftArm:p.rightArm;smooth(free,'z',(def.hand==='rear'?-1:1)*1.65);smooth(free,'x',-.45);
  group.updateMatrixWorld(true);const resting=elbow.localToWorld(new THREE.Vector3(0,-.35,0));
  solveLimb(hand,elbow,resting.lerp(grabTarget,blend),.33,.35,new THREE.Vector3(def.hand==='rear'?1:-1,0,.3));group.updateMatrixWorld(true);
  grabContact=elbow.localToWorld(new THREE.Vector3(0,-.35,.014)).distanceTo(grabTarget)<.055;
 }
 group.userData.pose={state:air?(grab?'grab':'air'):physics.railId?'rail':physics.charge>.02?'loading':physics.compression>.15?'absorbing':input.press?'butter':input.brake?'braking':Math.abs(edge)>.03?(edge>0?'toe-edge':'heel-edge'):'riding',compression:physics.compression,edge,grabContact,grabStyle:grab?input.grabStyle:undefined,grabTarget:grab?grabTarget.toArray():undefined};group.updateMatrixWorld(true);
}
