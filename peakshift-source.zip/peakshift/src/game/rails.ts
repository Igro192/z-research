import * as THREE from 'three';

export type RailObject={id:string;type:string;x:number;z:number;rotation:number;scale:number};
export type RailPath={object:RailObject;points:THREE.Vector3[];radius:number;minX:number;maxX:number;minZ:number;maxZ:number};
export const isPipeRail=(type:string)=>['rail','tube','curved-rail','rainbow-rail'].includes(type);

/** One sampled centreline and tube surface are used by rendering and Rapier. */
export function buildRailPath(object:RailObject,ground:(x:number,z:number)=>number):RailPath{
 const s=object.scale,c=Math.cos(object.rotation),sin=Math.sin(object.rotation),points:THREE.Vector3[]=[];
 for(let i=0;i<=32;i++){
  const u=i/32,t=u-.5,z=t*9*s;
  const x=object.type==='curved-rail'?-.7*s*4*t*t:0;
  const wx=object.x+x*c+z*sin,wz=object.z-x*sin+z*c;
  const arch=object.type==='rainbow-rail'?.55*s*Math.sin(Math.PI*u):0;
  points.push(new THREE.Vector3(wx,ground(wx,wz)+1.25*s+arch,wz));
 }
 const radius=(object.type==='tube'?.22:object.type==='rail'?.14:.18)*s;
 return{object,points,radius,minX:Math.min(...points.map(p=>p.x)),maxX:Math.max(...points.map(p=>p.x)),minZ:Math.min(...points.map(p=>p.z)),maxZ:Math.max(...points.map(p=>p.z))};
}

export function railMesh(path:RailPath){
 const vertices:number[]=[],indices:number[]=[],sides=12,up=new THREE.Vector3(0,1,0);
 path.points.forEach((p,i)=>{
  const tangent=path.points[Math.min(i+1,32)].clone().sub(path.points[Math.max(i-1,0)]).normalize();
  const side=new THREE.Vector3().crossVectors(up,tangent).normalize(),normal=new THREE.Vector3().crossVectors(tangent,side).normalize();
  for(let j=0;j<sides;j++){const a=j/sides*Math.PI*2,v=p.clone().addScaledVector(normal,Math.cos(a)*path.radius).addScaledVector(side,Math.sin(a)*path.radius);vertices.push(v.x,v.y,v.z);}
  if(i<32)for(let j=0;j<sides;j++){const a=i*sides+j,b=i*sides+(j+1)%sides;indices.push(a,a+sides,b,b,a+sides,b+sides);}
 });
 for(let j=1;j<sides-1;j++){indices.push(0,j,j+1);const end=32*sides;indices.push(end,end+j+1,end+j);}
 return{vertices:new Float32Array(vertices),indices:new Uint32Array(indices)};
}

export function closestRailPoint(path:RailPath,position:THREE.Vector3){
 let distance=Infinity,point=new THREE.Vector3(),tangent=new THREE.Vector3(),index=0;
 for(let i=0;i<path.points.length-1;i++){
  const a=path.points[i],b=path.points[i+1],dx=b.x-a.x,dz=b.z-a.z;
  const t=THREE.MathUtils.clamp(((position.x-a.x)*dx+(position.z-a.z)*dz)/(dx*dx+dz*dz),0,1);
  const p=a.clone().lerp(b,t),d=Math.hypot(position.x-p.x,position.z-p.z);
  if(d<distance){distance=d;point=p;tangent=b.clone().sub(a).normalize();index=i;}
 }
 const normal=new THREE.Vector3(0,1,0).addScaledVector(tangent,-tangent.y).normalize();
 return{point,tangent,normal,distance,index,heading:Math.atan2(tangent.x,tangent.z)};
}

/** A bounded lateral spring helps catch a near miss; it never lifts or snaps a rider. */
export function railMagnet(path:RailPath,position:THREE.Vector3,velocity:THREE.Vector3,attached:boolean,steer:number){
 const hit=closestRailPoint(path,position),gap=position.y-hit.point.y-path.radius-.04;
 const direction=hit.tangent.clone().setY(0).normalize(),side=new THREE.Vector3(direction.z,0,-direction.x);
 const along=velocity.dot(direction),lateral=position.clone().sub(hit.point).dot(side);
 if(hit.distance>(attached?1.15:1)||gap<(attached?-path.radius-.18:-.18)||gap>(attached?.45:1.25)||Math.abs(along)<2||Math.abs(along)<velocity.clone().setY(0).length()*.5)return;
 const influence=1-THREE.MathUtils.smoothstep(Math.abs(steer),.15,.85);
 const magnitude=THREE.MathUtils.clamp(-lateral*(attached?3500:1400)-velocity.dot(side)*(attached?750:180),attached?-1600:-500,attached?1600:500)*influence;
 return{force:side.multiplyScalar(magnitude),...hit};
}
