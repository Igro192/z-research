import * as THREE from 'three';

/** A single immutable mesh supplies both rendered vertices and triangle contact. */
export class TrackSurface {
 readonly xs:Float32Array;
 readonly heights:Float32Array;
 readonly minZ=-384;readonly stepZ=3;readonly rows=801;
 readonly columns:number;
 constructor(sample:(x:number,z:number)=>number){
  const xs:number[]=[];
  for(let x=-720;x< -96;x+=12)xs.push(x);
  for(let x=-96;x<96;x+=3)xs.push(x);
  for(let x=96;x<=720;x+=12)xs.push(x);
  this.xs=new Float32Array(xs);this.columns=xs.length;this.heights=new Float32Array(this.columns*this.rows);
  for(let j=0;j<this.rows;j++)for(let i=0;i<this.columns;i++)this.heights[j*this.columns+i]=sample(xs[i],this.minZ+j*this.stepZ);
 }
 collisionMesh(){const vertices=new Float32Array(this.columns*this.rows*3),indices=new Uint32Array((this.columns-1)*(this.rows-1)*6);for(let j=0;j<this.rows;j++)for(let i=0;i<this.columns;i++){const k=j*this.columns+i;vertices.set([this.xs[i],this.heights[k],this.minZ+j*this.stepZ],k*3);}let k=0;for(let j=0;j<this.rows-1;j++)for(let i=0;i<this.columns-1;i++){const a=j*this.columns+i;indices.set([a,a+this.columns,a+1,a+1,a+this.columns,a+this.columns+1],k);k+=6;}return{vertices,indices};}
 private column(x:number){let lo=0,hi=this.columns-1;while(hi-lo>1){const mid=(lo+hi)>>1;if(this.xs[mid]<=x)lo=mid;else hi=mid;}return Math.min(this.columns-2,lo);}
 height(x:number,z:number){
  const i=this.column(x),j=THREE.MathUtils.clamp(Math.floor((z-this.minZ)/this.stepZ),0,this.rows-2),u=THREE.MathUtils.clamp((x-this.xs[i])/(this.xs[i+1]-this.xs[i]),0,1),v=THREE.MathUtils.clamp((z-this.minZ-j*this.stepZ)/this.stepZ,0,1),k=j*this.columns+i;
  const a=this.heights[k],b=this.heights[k+1],c=this.heights[k+this.columns],d=this.heights[k+this.columns+1];
  return u+v<=1?a+(b-a)*u+(c-a)*v:d+(c-d)*(1-u)+(b-d)*(1-v);
 }
 geometry(i0:number,i1:number,j0:number,j1:number,color:(x:number,z:number,h:number)=>THREE.Color){
  const nx=i1-i0,nz=j1-j0,count=(nx+1)*(nz+1),positions=new Float32Array(count*3),normals=new Float32Array(count*3),colors=new Float32Array(count*3),uv=new Float32Array(count*2),indices:number[]=[];
  for(let j=0;j<=nz;j++)for(let i=0;i<=nx;i++){
   const ix=i0+i,iz=j0+j,k=iz*this.columns+ix,p=(j*(nx+1)+i)*3,x=this.xs[ix],z=this.minZ+iz*this.stepZ,h=this.heights[k];
   positions.set([x,h,z],p);const left=Math.max(0,ix-1),right=Math.min(this.columns-1,ix+1),back=Math.max(0,iz-1),front=Math.min(this.rows-1,iz+1);
   const n=new THREE.Vector3(-(this.heights[iz*this.columns+right]-this.heights[iz*this.columns+left])/(this.xs[right]-this.xs[left]),1,-(this.heights[front*this.columns+ix]-this.heights[back*this.columns+ix])/((front-back)*this.stepZ)).normalize();normals.set(n.toArray(),p);const c=color(x,z,h);colors.set(c.toArray(),p);uv.set([x*.125,z*.125],p/3*2);
  }
  for(let j=0;j<nz;j++)for(let i=0;i<nx;i++){const a=j*(nx+1)+i,b=a+1,c=a+nx+1,d=c+1;indices.push(a,c,b,b,c,d);}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(positions,3));g.setAttribute('normal',new THREE.BufferAttribute(normals,3));g.setAttribute('color',new THREE.BufferAttribute(colors,3));g.setAttribute('uv',new THREE.BufferAttribute(uv,2));g.setIndex(indices);g.computeBoundingSphere();return g;
 }
}
