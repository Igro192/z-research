import type {ParkObject} from './world';
export const COURSE_EDITION='37';
export type CourseProfile={label:string;terrain:string;line:number[];width:number;bank:number;roller:number;wave:number;terrace:number;sections:[string,string,string,string];};
/** Authored routes and terrain signatures, independent of scenery random seeds. */
export const COURSES:Record<string,CourseProfile>={
 alpine:{label:'Alpine carving circuit',terrain:'Open bowls · sweeping turns · mellow hips',line:[0,2,24,12,-27,-15,22,30,-18,-8,0,0],width:35,bank:6,roller:.6,wave:135,terrace:2,sections:['THE CROWN','WIDE OPEN BOWLS','S CURVE','CHALET HIPS']},
 hokkaido:{label:'Powder pillow glades',terrain:'Narrow tree lines · pillow fields · natural lips',line:[0,-5,-18,-26,9,22,6,-25,-12,10,0,0],width:20,bank:3,roller:1.5,wave:100,terrace:3,sections:['CEDAR GLADE','PILLOW GARDEN','BAMBOO BENDS','LAST LIGHT']},
 frostwood:{label:'Forest pump track',terrain:'Linked rollers · log slides · wooded transfers',line:[0,9,18,-12,-20,14,22,-16,-24,8,0,0],width:26,bank:5,roller:1,wave:72,terrace:1,sections:['TIMBER FLOW','LOG LINE','TRANSFER GROVE','PUMP EXIT']},
 glacier:{label:'Ice spine expedition',terrain:'Blue ice spines · huge bowls · split ridges',line:[0,-3,9,27,12,-24,-8,25,5,-17,0,0],width:29,bank:13,roller:.5,wave:170,terrace:6,sections:['BLUE ICE','THE DIVIDE','GLACIER BOWL','SPINE ESCAPE']},
 neon:{label:'Floodlit street park',terrain:'Rail plaza · stair-style boxes · glowing transfers',line:[0,0,-8,-8,12,12,-12,-12,8,0,0,0],width:38,bank:1.5,roller:.1,wave:140,terrace:.5,sections:['AFTER HOURS','THE PLAZA','NEON TRANSFERS','LAST CALL']},
 stormpeak:{label:'Wind-carved freeride',terrain:'Wind lips · rolling couloirs · storm shelters',line:[0,5,24,32,3,-27,-30,7,27,10,0,0],width:33,bank:9,roller:2.1,wave:125,terrace:4,sections:['WHITE ROOM','WIND LIPS','STORM GULLY','SHELTER RUN']},
 sunset:{label:'Golden surf bowls',terrain:'Long surf banks · hips · ridge-to-bowl transfers',line:[0,8,30,17,-18,-32,-6,25,29,-9,0,0],width:44,bank:10,roller:.4,wave:200,terrace:3,sections:['GOLDEN RIDGE','SUNSET SURF','THE AMPHITHEATRE','LAST LAP']},
 bigair:{label:'Stadium slopestyle',terrain:'Four competition tables · stadium walls · finish jump',line:[0,0,0,0,6,6,-6,-6,0,0,0,0],width:48,bank:2,roller:0,wave:200,terrace:0,sections:['THE IN-RUN','STADIUM TABLES','THE TRANSFER','FINAL SEND']},
 megapark:{label:'Three-line progression',terrain:'Choose rail, jump or pipe lanes · long combos',line:[0,0,8,8,-8,-8,8,8,-8,0,0,0],width:53,bank:3,roller:.25,wave:95,terrace:1,sections:['CHOOSE A LINE','RAIL / AIR / PIPE','COMBO DISTRICT','VICTORY LAP']},
 canyon:{label:'Winding canyon walls',terrain:'Tight gorge · bank-to-bank rides · rock windows',line:[0,-7,-27,-9,25,33,4,-29,-20,15,0,0],width:21,bank:15,roller:.6,wave:155,terrace:3,sections:['THE NARROWS','ROCK WINDOW','CANYON SURF','GORGE EXIT']},
 aurora:{label:'Frozen lake playground',terrain:'Open snowfields · snow volcanoes · gentle waves',line:[0,7,15,21,12,-5,-21,-13,8,18,0,0],width:57,bank:2,roller:.65,wave:210,terrace:1,sections:['POLAR FIELD','FROZEN WAVES','CRATER GARDEN','AURORA HOME']},
 fjord:{label:'Coastal terrace traverse',terrain:'Stepped ridges · coastal hips · fishing village',line:[0,-9,-25,-29,-14,12,29,23,5,-15,0,0],width:26,bank:7,roller:.4,wave:175,terrace:7,sections:['SEA RIDGE','COASTAL TERRACES','VILLAGE TRANSFER','HARBOUR RUN']},
 'pipe-lab':{label:'Curved pipe circuit',terrain:'Twelve different pipe approaches · halfpipe returns',line:[0,3,10,10,-10,-10,10,10,-10,-5,0,0],width:37,bank:2,roller:0,wave:120,terrace:0,sections:['FIRST CONTACT','BEND THE LINE','RAINBOW DISTRICT','PIPE FINALE']},
 'air-academy':{label:'Mega transfer range',terrain:'Six giant takeoffs · broad landing decks · alternate line',line:[0,0,0,10,10,-10,-10,10,10,0,0,0],width:54,bank:2,roller:0,wave:220,terrace:1,sections:['SKYLINE IN-RUN','MEGA TRANSFERS','HIGH ALTITUDE','ONE LAST FLIGHT']},
 'flip-school':{label:'Flip progression line',terrain:'Eight measured pops · quiet approaches · wide runouts',line:[0,0,3,3,-3,-3,3,3,-3,0,0,0],width:31,bank:1,roller:0,wave:160,terrace:0,sections:['LOAD AND POP','OPEN AND LAND','LINK YOUR FLIPS','GRADUATION']},
 velocity:{label:'High-speed glacier chute',terrain:'Clean speed lane · long-radius turns · optional side hits',line:[0,0,3,7,10,7,0,-7,-10,-4,0,0],width:45,bank:4,roller:0,wave:260,terrace:0,sections:['THE ACCELERATOR','TERMINAL VELOCITY','THE LONG TURN','BRAKE ZONE']},
 'side-hits':{label:'Bank-to-bank snow surf',terrain:'Alternating wall banks · hips · spines · side launches',line:[0,5,16,5,-16,-5,16,5,-16,-5,0,0],width:34,bank:11,roller:1.1,wave:92,terrace:1,sections:['PICK A WALL','HIP CITY','BANK TO BANK','BOUNCE HOME']},
};
const smooth=(a:number,b:number,v:number)=>{const t=Math.max(0,Math.min(1,(v-a)/(b-a)));return t*t*(3-2*t);};
export function courseProfile(id:string){return COURSES[id]||COURSES.alpine;}
export function courseCenter(id:string,z:number){if(z<=0||z>=1780)return 0;const p=courseProfile(id),u=Math.max(0,Math.min(10.999,z/180)),i=Math.floor(u),t=smooth(0,1,u-i);return (p.line[i]*(1-t)+p.line[i+1]*t)*(1-smooth(1620,1780,z));}
export function courseHeading(id:string,z:number){return Math.atan2(courseCenter(id,z+3)-courseCenter(id,z-3),6);}
export function courseObjects(id:string):ParkObject[]{
 const out:ParkObject[]=[],add=(type:string,z:number,offset=0,scale=1,rotation=0)=>out.push({id:`course37-${id}-${out.length}`,type,x:courseCenter(id,z)+offset,z,scale,rotation:courseHeading(id,z)+rotation});
 const series=(type:string,zs:number[],offset=0,scale=1)=>zs.forEach(z=>add(type,z,offset,scale));
 switch(id){
 case 'alpine':
  series('hip',[150,520,1060,1500],-19,.9);series('banked-turn',[300,730,1250],20,1.1);series('tabletop',[420,960,1570],0,.75);series('cabin',[610,1320],-70,.7);break;
 case 'hokkaido':
  for(let i=0;i<22;i++){const z=100+i*68;add(i%4===0?'hip':'pillow',z,(i%2?1:-1)*(i%3?10:22),.65+(i%3)*.22);}
  series('snowbank',[380,890,1370],0,.9);series('gate',[550,1250],0,.9);break;
 case 'frostwood':
  for(let i=0;i<12;i++){const z=120+i*127;add(i%3===0?'spine':'hip',z,i%2?9:-9,.75);if(i%3===1)add('tube',z+45,-17,1.35);}
  series('banked-turn',[440,1010],22,1.1);break;
 case 'glacier':
  series('spine',[160,490,850,1250,1550],0,1.5);series('banked-turn',[320,700,1080,1450],-24,1.7);series('step-up',[570,1130],18,1.2);break;
 case 'neon':
  for(let i=0;i<10;i++){const z=105+i*151;add(i%3===0?'box':i%3===1?'curved-rail':'rainbow-rail',z,(i%3-1)*15,1.6);add('ride-on-ramp',z-18,(i%3-1)*15,1.3);add('light',z+20,i%2?31:-31,1.2);}
  series('tabletop',[350,820,1320],20,.85);series('cabin',[420,980],-64,1.1);break;
 case 'stormpeak':
  for(let i=0;i<15;i++)add(i%3===0?'spine':i%3===1?'pillow':'hip',125+i*103,(i%2?1:-1)*(9+i%4*5),.9+i%3*.25);
  series('cabin',[470,1210],-67,.65);break;
 case 'sunset':
  series('halfpipe',[210,620,1040,1450],0,1.6);series('hip',[390,840,1240,1610],22,1.2);series('volcano',[740,1350],-31,1.3);break;
 case 'bigair':
  [140,490,870,1270,1570].forEach((z,i)=>{add('tabletop',z,0,1.25+i%2*.25);add('gate',z-55,0,2.1);});
  series('light',[250,650,1040,1440],-58,1.8);series('cabin',[650,1040],66,1.3);break;
 case 'megapark':
  for(let i=0;i<8;i++){const z=110+i*193;add(i%2?'tabletop':'step-up',z,0,1);add(i%2?'curved-rail':'box',z+25,-26,1.5);add('ride-on-ramp',z+6,-26,1.2);if(i%2===0)add('halfpipe',z+65,30,1.15);}
  break;
 case 'canyon':
  for(let i=0;i<11;i++){const z=140+i*138;add('banked-turn',z,(i%2?1:-1)*18,1.3, i%2?0:Math.PI);if(i%3===1)add('spine',z+60,0,1.1);}
  series('hip',[410,1000,1530],-14,.9);break;
 case 'aurora':
  series('volcano',[180,620,1070,1510],0,1.4);series('pillow',[350,830,1280],-26,1.4);series('snowbank',[450,960,1430],29,1.3);break;
 case 'fjord':
  series('step-up',[140,560,1010,1480],0,1);series('hip',[340,790,1260],-18,1.3);series('banked-turn',[440,880,1350],22,1.2);series('cabin',[620,1190],-57,.9);break;
 case 'pipe-lab':
  for(let i=0;i<12;i++){const z=80+i*137,offset=i%3===0?0:i%2?8:-8;add(i%3===0?'tube':i%3===1?'curved-rail':'rainbow-rail',z,offset,1.6+i%2*.25);add('ride-on-ramp',z-18,offset,1.4);if(i%4===3)add('halfpipe',z+60,24,1);}
  break;
 case 'air-academy':
  [100,375,655,935,1220,1510].forEach((z,i)=>{add(i%2?'hip':'tabletop',z,0,1.65+i%3*.2);add('small-ramp',z+95,31,.8);add('gate',z-62,0,2.1);});break;
 case 'flip-school':
  [85,290,495,700,905,1110,1315,1520].forEach((z,i)=>{add(i%2?'tabletop':'ramp',z,0,.65+i*.045);add('sign',z-42,19,1);});break;
 case 'velocity':
  series('snowbank',[350,810,1270],37,1.2);series('gate',[210,510,850,1210,1540],0,2.3);break;
 case 'side-hits':
  for(let i=0;i<16;i++){const z=95+i*99,side=i%2?1:-1;add(['hip','banked-turn','spine','pillow'][i%4],z,side*(18+i%3*4),1.05,side*.45);}
  series('volcano',[540,1170],0,.9);break;
 }
 return out;
}
export const SNOW_FEATURES=new Set(['tabletop','hip','step-up','pillow','spine','banked-turn','volcano']);
/** Smooth, bidirectionally rideable profiles, baked into the shared terrain mesh. */
export function snowFeatureHeight(type:string,x:number,z:number,scale:number){
 x/=scale;z/=scale;const edge=(w:number)=>1-smooth(w*.65,w,Math.abs(x)),ends=(length:number)=>1-smooth(length*.65,length,Math.abs(z));
 if(type==='pillow')return 3.1*scale*Math.exp(-(x*x/45+z*z/90));
 if(type==='spine')return 5*scale*Math.exp(-x*x/30)*ends(27);
 if(type==='banked-turn')return 7*scale*smooth(-7,11,x)*ends(42)*(1-smooth(15,28,x));
 if(type==='volcano'){const r=Math.hypot(x,z);return 4*scale*Math.exp(-(((r-9)/4)**2));}
 if(type==='hip')z+=x*.45;
 if(type==='step-up'){
  if(z< -26||z>70)return 0;
  const rise=z<=0?4.8*((z+26)/26)**2:z<12?4.8-2.8*smooth(0,12,z):z<28?2+5.1*smooth(12,28,z):z<38?7.1:7.1*(1-smooth(38,70,z));
  return scale*rise*edge(15);
 }
 if(z< -28||z>64)return 0;
 const profile=z<=0?((z+28)/28)**2:z<18?1:1-smooth(18,64,z);
 return (type==='hip'?7:6.2)*scale*profile*edge(type==='hip'?13:15)*(type==='hip'?.8+.2*Math.max(-1,Math.min(1,x/13)):1);
}
