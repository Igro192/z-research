import * as THREE from 'three';
import {TrackSurface} from './surface';
import {courseProfile,courseCenter,courseObjects,SNOW_FEATURES,snowFeatureHeight} from './courses';
import {buildRailPath,railMesh,isPipeRail} from './rails';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export interface MapConfig {
  id: string; name: string; region: string; tagline: string; difficulty: string;
  layout?:'pipes'|'big-jumps'|'flips'|'speed'|'side-hits';
  vertical: number; seed: number; snow: 'groomed' | 'powder' | 'ice';
  sky: string; accent: string; fog: string; slope: number; forest: number; roughness: number; night?: boolean;
}
export type ParkObject = { id: string; type: string; x: number; z: number; rotation: number; scale: number };
export type TerrainEdit = { x: number; z: number; radius: number; amount: number; mode: 'raise' | 'lower' | 'flatten' | 'smooth'; target?: number };
export const FINISH_Z=1780;
export const LIFT_BASE={x:-38,z:1835};
export const COURSE_GATES=[240,520,800,1080,1400,FINISH_Z].map((z,i)=>({x:i===5?0:Math.sin((i+1)*.8)*18,z}));
export function atLiftFinish(x:number,z:number){return z>=FINISH_Z&&Math.abs(x)<105;}

export const MAPS: MapConfig[] = [
  { id:'alpine', name:'Alpine Crown', region:'THE EUROPEAN ALPS', tagline:'Your mountain. Your line.', difficulty:'ALL RIDERS', vertical:423, seed:41, snow:'groomed', sky:'#5995c1', accent:'#d4fb48', fog:'#bed8e5', slope:.235, forest:.65, roughness:1 },
  { id:'hokkaido', name:'Hokkaido Powder', region:'NORTHERN JAPAN', tagline:'Get lost in the white room.', difficulty:'INTERMEDIATE', vertical:378, seed:217, snow:'powder', sky:'#7b99ad', accent:'#ff997c', fog:'#c9dbe2', slope:.21, forest:1.2, roughness:.65 },
  { id:'frostwood', name:'Frostwood Freestyle', region:'PACIFIC NORTHWEST', tagline:'Find your flow between the trees.', difficulty:'ALL RIDERS', vertical:405, seed:84, snow:'groomed', sky:'#649db4', accent:'#9df8cf', fog:'#c6e1e4', slope:.225, forest:1, roughness:.75 },
  { id:'glacier', name:'Glacier Divide', region:'HIGH ALPINE', tagline:'Big mountain. Bigger commitment.', difficulty:'EXPERT', vertical:630, seed:396, snow:'ice', sky:'#376997', accent:'#8eeaff', fog:'#a5d2e5', slope:.35, forest:.05, roughness:1.8 },
  { id:'neon', name:'Neon Afterdark', region:'THE NIGHT SESSION', tagline:'The mountain never clocks out.', difficulty:'INTERMEDIATE', vertical:396, seed:615, snow:'groomed', sky:'#10182f', accent:'#d896ff', fog:'#262d49', slope:.22, forest:.4, roughness:.6, night:true },
  { id:'stormpeak', name:'Stormpeak', region:'NORTH CASCADES', tagline:'Ride into the weather.', difficulty:'EXPERT', vertical:522, seed:910, snow:'powder', sky:'#667b8b', accent:'#f1ad62', fog:'#a6bac4', slope:.29, forest:.5, roughness:1.5 },
  { id:'sunset', name:'Sunset Ridge', region:'THE DOLOMITES', tagline:'One more run. Always.', difficulty:'ALL RIDERS', vertical:396, seed:132, snow:'groomed', sky:'#bb8d90', accent:'#ffd08d', fog:'#ebc7b9', slope:.22, forest:.55, roughness:.85 },
  { id:'bigair', name:'Big Air Kingdom', region:'FREESTYLE ARENA', tagline:'A little less gravity.', difficulty:'INTERMEDIATE', vertical:432, seed:754, snow:'groomed', sky:'#4e9ac8', accent:'#ffc868', fog:'#baddf0', slope:.24, forest:.24, roughness:.45 },
  { id:'megapark', name:'Megapark XL', region:'THE PROGRESSION PARK', tagline:'Build a line worth repeating.', difficulty:'ADVANCED', vertical:360, seed:533, snow:'groomed', sky:'#6fa4ba', accent:'#ff89af', fog:'#c8e1ea', slope:.2, forest:.4, roughness:.4 },
  { id:'canyon', name:'Backcountry Canyon', region:'UNTAMED WILDERNESS', tagline:'No ropes. No boundaries.', difficulty:'EXPERT', vertical:558, seed:962, snow:'powder', sky:'#7291a4', accent:'#e2c6a0', fog:'#bdcbd3', slope:.31, forest:.35, roughness:2 },
  { id:'aurora', name:'Aurora Basin', region:'ARCTIC CIRCLE', tagline:'Chase a different kind of light.', difficulty:'ALL RIDERS', vertical:387, seed:333, snow:'powder', sky:'#102b39', accent:'#91efd3', fog:'#32616e', slope:.215, forest:.6, roughness:.8, night:true },
  { id:'fjord', name:'Fjordline', region:'COASTAL NORWAY', tagline:'From summit to sea.', difficulty:'ADVANCED', vertical:522, seed:107, snow:'ice', sky:'#6d91a6', accent:'#b5d9fc', fog:'#c1d4dd', slope:.29, forest:.25, roughness:1.65 },
  {id:'pipe-lab',name:'Pipe Playground',region:'RAIL PRACTICE',tagline:'Catch a pipe. Follow its curve.',difficulty:'PRACTICE',layout:'pipes',vertical:324,seed:1421,snow:'groomed',sky:'#78b4cf',accent:'#87f1d0',fog:'#d4e8ed',slope:.18,forest:.2,roughness:.35},
  {id:'air-academy',name:'Skyline Big Air',region:'BIG JUMP PRACTICE',tagline:'Long approaches. Huge, open landings.',difficulty:'BIG AIR',layout:'big-jumps',vertical:504,seed:1529,snow:'groomed',sky:'#498cc1',accent:'#ffd47a',fog:'#c5e1ef',slope:.28,forest:.12,roughness:.3},
  {id:'flip-school',name:'Flip School',region:'FRONTFLIP & BACKFLIP PRACTICE',tagline:'Pop. Tuck. Open. Ride away.',difficulty:'PRACTICE',layout:'flips',vertical:414,seed:1663,snow:'groomed',sky:'#779fc5',accent:'#ffab9c',fog:'#d2e3ec',slope:.23,forest:.3,roughness:.35},
  {id:'velocity',name:'Velocity Pass',region:'SUPER SPEED',tagline:'A long, steep ribbon of fast snow.',difficulty:'SPEED',layout:'speed',vertical:684,seed:1783,snow:'ice',sky:'#426e9a',accent:'#a0efff',fog:'#bbd5e5',slope:.38,forest:.08,roughness:.45},
  {id:'side-hits',name:'Bank & Bounce',region:'NATURAL HIT PLAYGROUND',tagline:'Every bank is another takeoff.',difficulty:'ALL RIDERS',layout:'side-hits',vertical:432,seed:1907,snow:'powder',sky:'#a1a9c3',accent:'#ead299',fog:'#e1dce6',slope:.24,forest:.4,roughness:.65},
];

const smooth = (a:number,b:number,x:number) => { const t=THREE.MathUtils.clamp((x-a)/(b-a),0,1); return t*t*(3-2*t); };
function hash(x:number,z:number,seed:number) { const n=Math.sin(x*127.1+z*311.7+seed*19.19)*43758.5453123; return n-Math.floor(n); }
function noise(x:number,z:number,seed:number) {
  const ix=Math.floor(x), iz=Math.floor(z), tx=x-ix, tz=z-iz;
  const u=tx*tx*(3-2*tx), v=tz*tz*(3-2*tz);
  return THREE.MathUtils.lerp(THREE.MathUtils.lerp(hash(ix,iz,seed),hash(ix+1,iz,seed),u),THREE.MathUtils.lerp(hash(ix,iz+1,seed),hash(ix+1,iz+1,seed),u),v);
}
function rng(seed:number) { let n=seed>>>0; return ()=> { n=(1664525*n+1013904223)>>>0; return n/4294967296; }; }
function isRamp(type:string) { return type.includes('ramp') || type==='kicker' || type==='quarterpipe' || type==='snowbank'; }
const isRail=isPipeRail;

/** One deterministic height field powers collision, editing, scenery and every terrain LOD. */
export class MountainWorld {
  group = new THREE.Group();
  readonly bounds={minX:-650,maxX:650,minZ:-350,maxZ:1900};
  map: MapConfig;
  objects: ParkObject[] = [];
  edits: TerrainEdit[] = [];
  obstacles: {x:number;z:number;radius:number}[] = [];
  private scene: THREE.Scene;
  private terrain = new THREE.Group();
  private props = new THREE.Group();
  private scenery = new THREE.Group();
  private surface!:TrackSurface;
  private readonly surfaceTiles:THREE.Mesh[]=[];
  private snowfall?:THREE.Points;
  private snowOffsets?:Float32Array;
  private elapsed=0;
  private previousPlayer=new THREE.Vector3();
  private snowMaterial: THREE.MeshStandardMaterial;
  private darkMaterial: THREE.MeshStandardMaterial;
  private accentMaterial: THREE.MeshStandardMaterial;
  private treeGeometry:THREE.BufferGeometry;
  private treeSnowGeometry:THREE.BufferGeometry;
  private trunkGeometry:THREE.BufferGeometry;
  private resourceMaterials=new Set<THREE.Material>();
  private propMaterials=new Set<THREE.Material>();
  private requestedWeather=true;
  private trees?:THREE.InstancedMesh;
  private treeSnow?:THREE.InstancedMesh;
  private trunks?:THREE.InstancedMesh;
  private treeLocations:{x:number;z:number;s:number;angle:number}[]=[];
  private rockLocations:{x:number;z:number;s:number;angle:number}[]=[];
  private rocks?:THREE.InstancedMesh;

  constructor(scene:THREE.Scene,map:MapConfig) {
    this.scene=scene; this.map={...map}; this.group.name='Mountain '+map.name;
    const snowNormals=this.makeSnowNormalTexture();
    this.snowMaterial=this.material({color:map.night?'#b8cad8':'#edf5f6',roughness:.84,metalness:.025,vertexColors:true,normalMap:snowNormals,normalScale:new THREE.Vector2(.1,.1)});
    this.snowMaterial.onBeforeCompile=shader=>{
      shader.uniforms.courseLine={value:courseProfile(map.id).line};shader.uniforms.courseWidth={value:courseProfile(map.id).width};shader.uniforms.courseGrooming={value:map.snow==='groomed'?1:.15};
      shader.vertexShader='varying vec3 snowWorld;\n'+shader.vertexShader;
      shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nsnowWorld=(modelMatrix*vec4(position,1.0)).xyz;');
      shader.fragmentShader='varying vec3 snowWorld; uniform float courseLine[12]; uniform float courseWidth; uniform float courseGrooming;\n'+shader.fragmentShader;
      shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
        float u=clamp(snowWorld.z/180.0,0.0,10.999); int i=int(floor(u)); float t=smoothstep(0.0,1.0,fract(u));
        float center=mix(courseLine[i],courseLine[i+1],t)*(1.0-smoothstep(1620.0,1780.0,snowWorld.z));
        float route=1.0-smoothstep(courseWidth*.8,courseWidth,abs(snowWorld.x-center));
        float ribs=.5+.5*sin(snowWorld.x*31.416);
        float detail=(1.0-smoothstep(10.0,35.0,distance(cameraPosition,snowWorld)))*(1.0-smoothstep(.4,1.0,fwidth(snowWorld.x*31.416)));
        diffuseColor.rgb*=1.0-courseGrooming*route*detail*.07*ribs;`);
    };
    this.darkMaterial=this.material({color:'#293d49',roughness:.7});
    this.accentMaterial=this.material({color:map.accent,roughness:.5,emissive:map.accent,emissiveIntensity:map.night?.65:.05});
    [this.treeGeometry,this.treeSnowGeometry,this.trunkGeometry]=this.makeTreeGeometry();
    this.group.add(this.terrain,this.scenery,this.props);
    scene.add(this.group);
    this.buildCelestial(); this.buildPanorama(); this.makeDefaultPark(); this.buildTerrain(); this.buildForest(); this.buildLandmarks(); this.batchStaticScenery(); this.rebuildProps(); this.buildWeather();
    this.update(new THREE.Vector3(0,this.height(0,0),0),0);
  }
  private material(params:THREE.MeshStandardMaterialParameters) { const m=new THREE.MeshStandardMaterial(params); this.resourceMaterials.add(m); return m; }
  private makeSnowNormalTexture() {
    const size=128,heights=new Float32Array(size*size),data=new Uint8Array(size*size*4);
    for(let y=0;y<size;y++)for(let x=0;x<size;x++)heights[y*size+x]=hash(x,y,827)*.07+Math.sin(x*Math.PI/2)*.35;
    for(let y=0;y<size;y++)for(let x=0;x<size;x++) {
      const dx=heights[y*size+(x+1)%size]-heights[y*size+(x+size-1)%size];
      const dy=heights[((y+1)%size)*size+x]-heights[((y+size-1)%size)*size+x];
      const n=new THREE.Vector3(-dx,-dy,1.7).normalize(),i=(y*size+x)*4;
      data[i]=(n.x*.5+.5)*255;data[i+1]=(n.y*.5+.5)*255;data[i+2]=(n.z*.5+.5)*255;data[i+3]=255;
    }
    const texture=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);
    texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.magFilter=THREE.LinearFilter;texture.minFilter=THREE.LinearMipmapLinearFilter;texture.generateMipmaps=true;texture.needsUpdate=true;return texture;
  }
  private disposeMaterial(material:THREE.Material) {
    for(const value of Object.values(material))if(value instanceof THREE.Texture)value.dispose();
    material.dispose();
  }

  center(z:number) { return courseCenter(this.map.id,z); }
  private baseHeight(x:number,z:number) {
    const {seed,roughness,slope,id}=this.map;
    const cx=this.center(z), d=Math.abs(x-cx), shoulder=smooth(45,270,d);
    const n=noise(x*.006,z*.006,seed), detail=noise(x*.022,z*.022,seed+12);
    const broad=430-z*slope;
    const profile=courseProfile(id),width=profile.width;
    const run=profile.terrace*Math.sin(z*.012+Math.sin(z*.003))+.35*Math.sin(z*.021+seed*.1);
    const bowl=.00025*(x-cx)*(x-cx);
    const flow=smooth(25,100,z)*(1-smooth(1630,1780,z));
    const rollers=flow*profile.roller*Math.exp(-(((x-cx)/(width*1.5))**2))*(Math.sin(z*Math.PI*2/profile.wave)+.25*Math.sin(z*.067));
    const banks=flow*smooth(width*.55,width+14,d)*(1-smooth(width+35,width+90,d))*profile.bank*(.8+.2*Math.sin(z*.013+x*.01)**2);
    const ridge=shoulder*(32+115*n+28*detail)*roughness;
    let land=broad+run+bowl+ridge+rollers+banks;
    if(id==='canyon') land+=smooth(72,270,d)*(100+95*Math.sin(z*.009)**2);
    if(id==='glacier') land+=shoulder*Math.max(0,Math.sin(x*.014+z*.006))*92;
    if(id==='fjord') land+=smooth(150,380,d)*Math.max(0,Math.sin(z*.006))*140;
    if(id==='hokkaido') land+=shoulder*9*Math.sin(x*.022+z*.008);
    // Ease the final descent into a broad, level gondola forecourt.
    const baseBlend=smooth(1650,1800,z)*(1-smooth(95,155,Math.abs(x)));
    return THREE.MathUtils.lerp(land,430-1800*slope,baseBlend);
  }
  private editedHeight(x:number,z:number) {
    let h=this.baseHeight(x,z);
    for(const edit of this.edits) {
      const d=Math.hypot(x-edit.x,z-edit.z); if(d>=edit.radius) continue;
      const w=1-smooth(0,edit.radius,d);
      if(edit.mode==='raise') h+=edit.amount*w;
      else if(edit.mode==='lower') h-=edit.amount*w;
      else if(edit.mode==='flatten') h=THREE.MathUtils.lerp(h,edit.target??this.baseHeight(edit.x,edit.z),w);
      else {
        const r=edit.radius*.3;
        const avg=(this.baseHeight(x-r,z)+this.baseHeight(x+r,z)+this.baseHeight(x,z-r)+this.baseHeight(x,z+r))*.25;
        h=THREE.MathUtils.lerp(h,avg,w);
      }
    }
    return h;
  }
  private local(o:ParkObject,x:number,z:number) {
    const dx=x-o.x,dz=z-o.z,c=Math.cos(o.rotation),s=Math.sin(o.rotation);
    return {x:dx*c-dz*s,z:dx*s+dz*c};
  }
  /** Compatibility accessor: all snow contact uses the actual resident triangles. */
  groundHeight(x:number,z:number){return this.surface.height(x,z);}
  railBaseHeight(x:number,z:number){return this.editedHeight(x,z);}
  private rampHeight(o:ParkObject,x:number,z:number){
    const p=this.local(o,x,z),scale=Math.max(.25,o.scale),width=18*scale;
    if(o.type==='ride-on-ramp'){
      if(Math.abs(p.x)>2.1*scale||p.z< -7*scale||p.z>3*scale)return 0;
      const edge=1-smooth(1.3*scale,2.1*scale,Math.abs(p.x));
      return 1.43*scale*edge*(p.z<0?smooth(-7*scale,0,p.z):1-smooth(0,3*scale,p.z));
    }
    if(Math.abs(p.x)>width*.5||p.z< -18*scale||p.z>32*scale)return 0;
    const edge=1-smooth(width*.3,width*.5,Math.abs(p.x));
    const profile=p.z<=12*scale?((p.z+18*scale)/(30*scale))**2:1-smooth(12*scale,32*scale,p.z);
    return (o.type==='snowbank'?3:6.5)*scale*profile*edge;
  }
  private snowSample(x:number,z:number){
    const base=this.editedHeight(x,z);let rise=0;
    for(const o of this.objects){
      const radius=SNOW_FEATURES.has(o.type)?80:60;if(Math.abs(x-o.x)>radius*o.scale||Math.abs(z-o.z)>radius*o.scale)continue;
      if(SNOW_FEATURES.has(o.type)){const p=this.local(o,x,z);rise=Math.max(rise,snowFeatureHeight(o.type,p.x,p.z,o.scale));}
      else if(isRamp(o.type))rise=Math.max(rise,this.rampHeight(o,x,z));
      else if(o.type==='halfpipe'){const p=this.local(o,x,z);if(Math.abs(p.x)<13*o.scale&&Math.abs(p.z)<38*o.scale){const side=smooth(3*o.scale,13*o.scale,Math.abs(p.x)),end=1-smooth(27*o.scale,38*o.scale,Math.abs(p.z));rise=Math.max(rise,side*side*7*o.scale*end);}}
    }
    return base+rise;
  }
  collisionMesh(){return this.surface.collisionMesh();}
  height(x:number,z:number){
    let h=this.surface.height(x,z);
    for(const o of this.objects)if(o.type==='box'&&Math.abs(x-o.x)<6*o.scale&&Math.abs(z-o.z)<6*o.scale){const p=this.local(o,x,z);if(Math.abs(p.x)<1.8*o.scale&&Math.abs(p.z)<4.5*o.scale)h=Math.max(h,this.surface.height(o.x,o.z)+1.1*o.scale);}
    return h;
  }
  normal(x:number,z:number){const e=.35;return new THREE.Vector3(this.height(x-e,z)-this.height(x+e,z),2*e,this.height(x,z-e)-this.height(x,z+e)).normalize();}
  section(z:number){return z>=1650?'GONDOLA RUNOUT':courseProfile(this.map.id).sections[z<420?0:z<900?1:z<1330?2:3];}
  nextFeature(x:number,z:number){const o=this.objects.filter(o=>(isRamp(o.type)||SNOW_FEATURES.has(o.type)||isRail(o.type)||o.type==='box')&&o.z>z+6&&Math.abs(o.x-x)<23).sort((a,b)=>a.z-b.z)[0];return o?{name:SNOW_FEATURES.has(o.type)?o.type.replaceAll('-',' '):isRamp(o.type)?'Kicker':o.type==='box'?'Box slide':'Rail',distance:Math.round(o.z-z)}:{name:'Lift base',distance:Math.max(0,Math.round(FINISH_Z-z))};}
  private makeDefaultPark() {
    this.objects=courseObjects(this.map.id);
    for(let i=0;i<this.objects.length;i++)if(this.objects[i].type==='ride-on-ramp'){
      const rail=this.objects[i-1];if(!rail||!isRail(rail.type))continue;
      const point=buildRailPath(rail,()=>0).points[0];
      Object.assign(this.objects[i],{x:point.x,z:point.z,rotation:rail.rotation+(rail.type==='curved-rail'?.3:0),scale:rail.scale});
    }
  }
  private trackColor(x:number,z:number,h:number){
    const d=Math.abs(x-this.center(z)),route=1-smooth(courseProfile(this.map.id).width*.8,courseProfile(this.map.id).width,d),edge=smooth(50,240,d),grain=noise(x*.06,z*.06,this.map.seed+4);
    const color=new THREE.Color(this.map.night?'#a6c9d9':'#e9f2f5');
    color.lerp(new THREE.Color(this.map.night?'#477788':'#9fbece'),edge*.35+(1-route)*.14);
    if(route>0)color.lerp(new THREE.Color(this.map.night?'#80b1bd':'#a6c7d8'),route*.7);
    color.multiplyScalar(.94+grain*.07);
    const rise=h-this.editedHeight(x,z);
    if(rise>.7&&d<65)color.lerp(new THREE.Color('#8cb8cb'),Math.min(.4,rise*.07));
    // The subtle blue groomed stripe and actual jump shapes share these mesh vertices.
    return color;
  }
  private buildTerrain(){
    for(const m of this.surfaceTiles)m.geometry.dispose();this.surfaceTiles.length=0;this.terrain.clear();
    this.surface=new TrackSurface((x,z)=>this.snowSample(x,z));
    const boundaries=[0,52,84,116,this.surface.columns-1];
    for(let j=0;j<this.surface.rows-1;j+=64)for(let stripe=0;stripe<4;stripe++){
      const geometry=this.surface.geometry(boundaries[stripe],boundaries[stripe+1],j,Math.min(j+64,this.surface.rows-1),(x,z,h)=>this.trackColor(x,z,h));
      const tile=new THREE.Mesh(geometry,this.snowMaterial);tile.name='terrain-chunk-'+stripe+','+j;tile.receiveShadow=true;this.surfaceTiles.push(tile);this.terrain.add(tile);
    }
  }
  private makeTreeGeometry():[THREE.BufferGeometry,THREE.BufferGeometry,THREE.BufferGeometry] {
    const random=rng(713),greenPositions:number[]=[],snowPositions:number[]=[],greenIndices:number[]=[],snowIndices:number[]=[];
    // Each crown is a network of drooping boughs, with uneven snow resting on their upper faces.
    // The disconnected tips and staggered heights avoid the bands of a stacked-cone fir.
    for(let tier=0;tier<6;tier++) {
      const y=1.25+tier*1.2+(random()-.5)*.32,radius=2.65*(1-tier*.16),branches=6-(tier>3?1:0);
      for(let branch=0;branch<branches;branch++) {
        const angle=branch/branches*Math.PI*2+tier*.61+(random()-.5)*.24,length=radius*(.78+random()*.38),width=length*(.24+random()*.1),drop=.12+random()*.28;
        const dx=Math.cos(angle),dz=Math.sin(angle),tx=-dz,tz=dx,by=y+(random()-.5)*.42;
        const point=(distance:number,across:number,height:number)=>[dx*distance+tx*across,by+height,dz*distance+tz*across];
        const points=[point(.05,0,.67),point(length*.36,width,.08),point(length,0,-drop),point(length*.36,-width,.03),point(length*.21,0,-.37)];
        const offset=greenPositions.length/3;points.forEach(p=>greenPositions.push(...p));
        for(const triangle of [[0,1,2],[0,2,3],[1,4,2],[3,2,4],[0,4,1],[0,3,4]])greenIndices.push(...triangle.map(i=>i+offset));
        if(random()>.16) {
          const snowOffset=snowPositions.length/3;
          [point(.13,0,.69),point(length*.4,width*.79,.16),point(length*.9,0,-drop+.11),point(length*.38,-width*.77,.15),point(length*.38,0,.52)].forEach(p=>snowPositions.push(...p));
          for(const triangle of [[0,1,4],[1,2,4],[2,3,4],[3,0,4]])snowIndices.push(...triangle.map(i=>i+snowOffset));
        }
      }
    }
    const geometry=(positions:number[],indices:number[])=>{const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setIndex(indices);g.computeVertexNormals();return g;};
    const green=geometry(greenPositions,greenIndices),snow=geometry(snowPositions,snowIndices);
    const leader=new THREE.ConeGeometry(.37,1.8,7,2);leader.translate(.03,8.25,0);
    const evergreen=mergeGeometries([green,leader.deleteAttribute('uv')])!;green.dispose();leader.dispose();
    const trunk=new THREE.CylinderGeometry(.1,.23,8,7);trunk.translate(0,4,0);
    return [evergreen,snow,trunk];
  }
  private buildForest() {
    const random=rng(this.map.seed*77), count=Math.floor(1100*this.map.forest), mat=new THREE.Matrix4(), q=new THREE.Quaternion(), v=new THREE.Vector3();
    for(let i=0;i<count*3&&this.treeLocations.length<count;i++) {
      const z=-150+random()*2250,x=(random()-.5)*1040,d=Math.abs(x-this.center(z));
      if(d<courseProfile(this.map.id).width+8+noise(z*.012,0,this.map.seed)*12 || z<300&&Math.abs(x)<25 || (Math.abs(x-LIFT_BASE.x)<15) || (z>1630&&Math.abs(x)<155)) continue;
      this.treeLocations.push({x,z,s:.74+random()*.95,angle:random()*Math.PI*2});
    }
    const n=this.treeLocations.length;
    this.trees=new THREE.InstancedMesh(this.treeGeometry,this.material({color:'#ffffff',roughness:1}),n);
    this.treeSnow=new THREE.InstancedMesh(this.treeSnowGeometry,this.material({color:this.map.night?'#9bb5ce':'#e6eff1',roughness:.94}),n);
    this.trunks=new THREE.InstancedMesh(this.trunkGeometry,this.material({color:'#59493e',roughness:1}),n);
    this.trees.castShadow=true;this.treeSnow.castShadow=true;this.treeSnow.receiveShadow=true;
    const greenColor=new THREE.Color(),snowColor=new THREE.Color();
    this.treeLocations.forEach((p,i)=>{
      q.setFromAxisAngle(new THREE.Vector3(0,1,0),p.angle);v.set(p.x,this.height(p.x,p.z)-.12,p.z);mat.compose(v,q,new THREE.Vector3(p.s,p.s,p.s));
      this.trees!.setMatrixAt(i,mat);this.treeSnow!.setMatrixAt(i,mat);this.trunks!.setMatrixAt(i,mat);
      greenColor.setHSL(.37,.2,.2+random()*.09);snowColor.setRGB(.82+random()*.12,.9+random()*.08,.96+random()*.04);
      this.trees!.setColorAt(i,greenColor);this.treeSnow!.setColorAt(i,snowColor);
      if(Math.abs(p.x-this.center(p.z))<230) this.obstacles.push({x:p.x,z:p.z,radius:.5*p.s});
    });
    this.scenery.add(this.trees,this.treeSnow,this.trunks);
    const rockN=Math.floor(70+this.map.roughness*45),rockGeo=new THREE.DodecahedronGeometry(1,0);
    this.rocks=new THREE.InstancedMesh(rockGeo,this.material({color:'#7b8a91',roughness:1,flatShading:true}),rockN);
    this.rocks.castShadow=true;this.rocks.receiveShadow=true;
    for(let i=0;i<rockN;i++) {
      const z=random()*2150,x=(random()>.5?1:-1)*(z>1630?165+random()*350:75+random()*440),s=2.3+random()*6,angle=random()*6.28;
      this.rockLocations.push({x,z,s,angle});v.set(x,this.height(x,z)+s*.18,z);q.setFromEuler(new THREE.Euler(random(),angle,random()));mat.compose(v,q,new THREE.Vector3(s*1.1,s*.7,s));this.rocks.setMatrixAt(i,mat);
      if(Math.abs(x-this.center(z))<230) this.obstacles.push({x,z,radius:s*.65});
    }this.scenery.add(this.rocks);
  }
  private mesh(geometry:THREE.BufferGeometry,material:THREE.Material,parent:THREE.Group,x=0,y=0,z=0) {
    const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;
  }
  private buildCelestial() {
    if(this.map.night) {
      const random=rng(this.map.seed),positions=new Float32Array(1300*3);
      for(let i=0;i<1300;i++) {const theta=random()*Math.PI*2,phi=Math.acos(random()*.85);positions[i*3]=Math.cos(theta)*Math.sin(phi)*3800;positions[i*3+1]=Math.cos(phi)*3800;positions[i*3+2]=Math.sin(theta)*Math.sin(phi)*3800;}
      const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(positions,3));const mat=new THREE.PointsMaterial({color:'#dcecff',size:2.5,sizeAttenuation:false,fog:false,transparent:true,opacity:.65});this.resourceMaterials.add(mat);const stars=new THREE.Points(geo,mat);this.group.add(stars);
    }
    if(this.map.id==='aurora') {
      for(let ribbon=0;ribbon<3;ribbon++) {
        const pos:number[]=[],colors:number[]=[],index:number[]=[];
        for(let i=0;i<=90;i++) {const x=-2200+i*49,z=1700+Math.sin(i*.042+ribbon)*420,y=900+Math.sin(i*.066+ribbon)*190;
          pos.push(x,y,z,x,y+240+Math.sin(i*.21)*70,z);
          const c=new THREE.Color(ribbon===1?'#79c6d6':'#60e5b0');colors.push(c.r,c.g,c.b,.18,.35,.4);
          if(i<90) {const a=i*2;index.push(a,a+1,a+2,a+1,a+3,a+2);}
        }
        const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geo.setIndex(index);const mat=new THREE.MeshBasicMaterial({vertexColors:true,transparent:true,opacity:.22,side:THREE.DoubleSide,depthWrite:false,fog:false});this.resourceMaterials.add(mat);this.group.add(new THREE.Mesh(geo,mat));
      }
    }
  }
  private buildPanorama() {
    const material=this.material({color:'#e2ecf2',vertexColors:true,roughness:.96,flatShading:false,side:THREE.DoubleSide});
    const random=rng(this.map.seed*13);
    const geometry=(positions:number[],colors:number[],indices:number[])=>{
      const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geo.setIndex(indices);geo.computeVertexNormals();return geo;
    };
    // Continuous radial height fields form far ranges, with a wandering crest and eroded gullies.
    for(let ring=0;ring<2;ring++) {
      const verts:number[]=[],colors:number[]=[],indices:number[]=[],segments=320,rows=32,radius=ring?3700:2050;
      const phase=random()*6.28;
      for(let j=0;j<=rows;j++)for(let i=0;i<=segments;i++) {
        const angle=i/segments*Math.PI*2,c=Math.cos(angle),sn=Math.sin(angle),t=j/rows;
        const ridge=.43+.1*Math.sin(angle*7+phase)+.045*Math.sin(angle*19-phase);
        const spread=t<ridge?ridge:1-ridge,profile=Math.max(0,1-Math.abs(t-ridge)/spread);
        const crest=510+240*noise(c*2.4,sn*2.4,this.map.seed+ring)+170*Math.sin(angle*9+phase)**2+120*Math.sin(angle*23-phase)**2;
        const erosion=(noise(c*13+t*4,sn*13+t*4,this.map.seed+22)-.5)*105;
        const ravine=Math.abs(Math.sin(angle*51+t*7+phase))*26;
        const h=-210+crest*Math.pow(profile,.82)+(erosion-ravine)*profile+(ring?130:0),rad=radius+t*1000;
        verts.push(sn*rad,h,c*rad+650);
        const exposed=smooth(.1,.8,Math.abs(Math.sin(angle*31+t*8+phase)))*smooth(.35,.85,profile)*(t>ridge?1:.34);
        const color=new THREE.Color(this.map.night?'#8da9bf':'#e6edf3');color.lerp(new THREE.Color('#6e8495'),exposed*.55);
        color.lerp(new THREE.Color('#f5f7f8'),Math.max(0,(h-470)/1000));colors.push(color.r,color.g,color.b);
      }
      for(let j=0;j<rows;j++)for(let i=0;i<segments;i++){const a=j*(segments+1)+i,b=a+1,c=a+segments+1,d=c+1;indices.push(a,c,b,b,c,d);}
      const mountain=new THREE.Mesh(geometry(verts,colors,indices),material);this.scenery.add(mountain);
    }
    // Continue the valley beyond the rideable mesh so its far edge never cuts into the sky.
    {
      const verts:number[]=[],colors:number[]=[],indices:number[]=[],nx=72,nz=40;
      for(let j=0;j<=nz;j++)for(let i=0;i<=nx;i++){
        const t=j/nz,z=2016+t*1500,x=(i/nx-.5)*1440*(1+t*1.3),blend=smooth(0,1,t),floor=-210+Math.abs(x/720)**2*40;
        verts.push(x,THREE.MathUtils.lerp(this.baseHeight(x,2016),floor,blend),z);
        const c=new THREE.Color(this.map.night?'#9db9cf':'#dce8ee');colors.push(c.r,c.g,c.b);
      }
      for(let j=0;j<nz;j++)for(let i=0;i<nx;i++){const a=j*(nx+1)+i;indices.push(a,a+nx+1,a+1,a+1,a+nx+1,a+nx+2);}
      this.scenery.add(new THREE.Mesh(geometry(verts,colors,indices),material));
    }
    // Nearby buttresses are long fractured ridges, never isolated geometric cones.
    for(const side of [-1,1]) {
      const verts:number[]=[],colors:number[]=[],indices:number[]=[],nx=48,nz=130,seed=this.map.seed+side*27;
      for(let j=0;j<=nz;j++)for(let i=0;i<=nx;i++) {
        const z=-400+j/nz*3300,x=side*(560+i/nx*1140),distance=Math.abs(x);
        const crest=880+100*Math.sin(z*.0024+seed)+65*Math.sin(z*.0065+seed*.13);
        const width=420+80*Math.sin(z*.0031),profile=Math.exp(-Math.pow(Math.abs(distance-crest)/width,1.65));
        const boundary=smooth(560,760,distance)*(1-smooth(1400,1700,distance));
        const peak=245+150*noise(z*.003,0,seed)+90*Math.abs(Math.sin(z*.008+seed));
        const gully=Math.abs(Math.sin(z*.024+distance*.009+seed))*22+Math.abs(Math.sin(z*.047-distance*.015))*10;
        const fracture=(noise(x*.018,z*.018,seed)-.5)*32;
        const rise=(peak*profile-gully+fracture)*boundary;
        const h=this.baseHeight(x,z)-32+rise;
        verts.push(x,h,z);
        const rocky=smooth(.22,.83,Math.abs(Math.sin(z*.016+distance*.006+seed)))*smooth(30,160,rise);
        const color=new THREE.Color(this.map.night?'#9db9cf':'#e1eaf0');color.lerp(new THREE.Color('#718392'),rocky*.65);colors.push(color.r,color.g,color.b);
      }
      for(let j=0;j<nz;j++)for(let i=0;i<nx;i++){const a=j*(nx+1)+i,b=a+1,c=a+nx+1,d=c+1;if(side>0)indices.push(a,c,b,b,c,d);else indices.push(a,b,c,b,d,c);}
      const ridge=new THREE.Mesh(geometry(verts,colors,indices),material);ridge.receiveShadow=true;this.scenery.add(ridge);
    }
  }
  private cabin(x:number,z:number,scale=1,parent=this.scenery) {
    const group=new THREE.Group();group.position.set(x,this.height(x,z),z);group.scale.setScalar(scale);parent.add(group);
    const wood=this.material({color:this.map.id==='hokkaido'?'#5b4440':'#776053',roughness:1}),roof=this.material({color:'#dce9ee',roughness:.94}),window=this.material({color:'#ffd49a',emissive:'#ffb64b',emissiveIntensity:this.map.night?1.7:.5,roughness:.25});
    const foundationDepth=Math.max(.7,...[-1,1].flatMap(sx=>[-1,1].map(sz=>(group.position.y-this.height(x+sx*7*scale,z+sz*5.5*scale))/scale+1)));
    const foundation=this.material({color:'#697371',roughness:1});this.mesh(new THREE.BoxGeometry(14,foundationDepth,11),foundation,group,0,-foundationDepth*.5,0);
    this.mesh(new THREE.BoxGeometry(14,8,11),wood,group,0,4,0);
    const rg=new THREE.BufferGeometry();rg.setAttribute('position',new THREE.Float32BufferAttribute([-8,0,-6,8,0,-6,0,5,-6,-8,0,6,8,0,6,0,5,6],3));rg.setIndex([0,1,2,3,5,4,0,3,1,1,3,4,0,2,3,2,5,3,1,4,2,2,4,5]);rg.computeVertexNormals();this.mesh(rg,roof,group,0,8,0);
    for(let i=-1;i<=1;i++)this.mesh(new THREE.BoxGeometry(2.2,2,.06),window,group,i*3.7,4.5,-5.53);
    this.mesh(new THREE.BoxGeometry(2.5,4,.15),this.darkMaterial,group,0,2,-5.6);
    this.mesh(new THREE.BoxGeometry(1.4,4,1.4),wood,group,4,12,2);
    return group;
  }
  private gate(x:number,z:number,width=23,label='PEAKSHIFT',parent=this.scenery) {
    const group=new THREE.Group();group.position.set(x,this.height(x,z),z);parent.add(group);
    for(const side of [-1,1]) this.mesh(new THREE.CylinderGeometry(.18,.22,5.5,8),this.darkMaterial,group,side*width*.5,2.75,0);
    this.mesh(new THREE.BoxGeometry(width,1.5,.38),this.accentMaterial,group,0,5.5,0);
    const canvas=typeof document!=='undefined'?document.createElement('canvas'):undefined;
    if(canvas) {canvas.width=512;canvas.height=96;const ctx=canvas.getContext('2d');if(ctx){ctx.fillStyle=this.map.accent;ctx.fillRect(0,0,512,96);ctx.fillStyle='#18262d';ctx.font='bold 54px Arial';ctx.textAlign='center';ctx.fillText(label,256,68);const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;const mat=new THREE.MeshBasicMaterial({map:tex,side:THREE.DoubleSide});this.resourceMaterials.add(mat);const sign=new THREE.Mesh(new THREE.PlaneGeometry(width,.98),mat);sign.position.set(0,5.5,-.21);sign.rotation.y=Math.PI;group.add(sign);}}
    return group;
  }
  private buildCourseLandmarks(){
    const id=this.map.id,profile=courseProfile(id),ice=this.material({color:id==='glacier'?'#71b6ce':'#8c9a9f',roughness:id==='glacier'?.42:.94,metalness:id==='glacier'?.12:0,flatShading:id!=='glacier'});
    if(['glacier','canyon','stormpeak'].includes(id)){
      for(let i=0;i<18;i++){
        const z=100+i*87,side=i%2?1:-1,x=this.center(z)+side*(profile.width+18+i%3*8),size=5+i%4*2;
        const rock=this.mesh(new THREE.DodecahedronGeometry(size,1),ice,this.scenery,x,this.height(x,z)+size*.5,z);rock.scale.set(.8,1.7+i%3*.3,1.6);rock.rotation.y=i*.8;
      }
    }
    if(id==='canyon')for(const z of [570,1190]){
      const radius=profile.width+9,arch=this.mesh(new THREE.TorusGeometry(radius,3,8,36,Math.PI),ice,this.scenery,this.center(z),this.height(this.center(z),z)+3,z);arch.name='canyon-rock-window';
    }
    if(['bigair','megapark','air-academy','flip-school','pipe-lab'].includes(id)){
      for(const z of [280,680,1090,1490])for(const side of [-1,1]){
        const x=this.center(z)+side*(profile.width+12),group=new THREE.Group();group.position.set(x,this.height(x,z),z);this.scenery.add(group);
        if(id==='bigair')for(let row=0;row<4;row++)this.mesh(new THREE.BoxGeometry(9+row*2,1.4,24),this.darkMaterial,group,side*row*2,row*1.5,0);
        this.mesh(new THREE.BoxGeometry(1,9,1),this.darkMaterial,group,0,4.5,0);
        this.mesh(new THREE.BoxGeometry(5,3,.3),this.accentMaterial,group,0,8,0);
      }
    }
    if(id==='neon')for(const z of [170,650,1150,1570]){
      const group=new THREE.Group();group.position.set(this.center(z),this.height(this.center(z),z),z);this.scenery.add(group);
      const glow=this.material({color:this.map.accent,emissive:this.map.accent,emissiveIntensity:1.2});
      for(const side of [-1,1])this.mesh(new THREE.BoxGeometry(.6,13,.6),glow,group,side*29,6.5,0);
      this.mesh(new THREE.BoxGeometry(58,.6,.6),glow,group,0,13,0);
    }
    if(id==='hokkaido')for(const z of [450,990,1480]){
      const red=this.material({color:'#a94338',roughness:.85}),group=new THREE.Group();group.position.set(this.center(z)+profile.width+7,this.height(this.center(z)+profile.width+7,z),z);this.scenery.add(group);
      for(const side of [-1,1])this.mesh(new THREE.CylinderGeometry(.25,.35,6,8),red,group,side*3,3,0);
      this.mesh(new THREE.BoxGeometry(9,.6,1.1),red,group,0,6,0);
    }
    if(id==='frostwood')for(const z of [250,710,1210]){
      const x=this.center(z)-profile.width-12,log=this.mesh(new THREE.CylinderGeometry(1.6,2.1,28,10),this.material({color:'#635547',roughness:1}),this.scenery,x,this.height(x,z)+2,z);log.rotation.z=Math.PI/2;
    }
    if(id==='sunset')for(const z of [330,870,1390])this.cabin(this.center(z)-profile.width-20,z,.85);
    if(id==='fjord')for(let i=0;i<8;i++){const z=700+i*31;this.cabin(this.center(z)-65-i%2*15,z,.6+i%3*.1);}
  }
  private buildLandmarks() {
    this.gate(0,-16,25,'DROP IN');this.gate(0,FINISH_Z,210,'FINISH · LIFT BASE');
    this.gate(0,1690,42,'LIFT BASE ↓');
    for(const [i,z]of [420,900,1330].entries())this.gate(this.center(z),z,(courseProfile(this.map.id).width+8)*2,courseProfile(this.map.id).sections[i+1]);
    for(let i=0;i<48;i++) {
      const z=25+i*35,c=this.center(z);
      for(const side of [-1,1]) {const x=c+side*(courseProfile(this.map.id).width+4),y=this.height(x,z);this.mesh(new THREE.CylinderGeometry(.07,.09,2.5,5),this.darkMaterial,this.scenery,x,y+1.25,z);const flag=this.mesh(new THREE.PlaneGeometry(1.2,.7),this.accentMaterial,this.scenery,x+side*.6,y+2.05,z);flag.material.side=THREE.DoubleSide;}
    }
    if(this.map.forest>.1) {
      this.cabin(-123,190,1.3);this.cabin(142,620,1.15);
      if(this.map.id==='alpine'||this.map.id==='sunset') for(let i=0;i<5;i++)this.cabin(-155-i*19,880+i*25,.75+(i%2)*.25);
    }
    this.buildCourseLandmarks();this.buildLift();
    if(this.map.id==='hokkaido') {
      const red=this.material({color:'#bc4b40',roughness:.8}),x=83,z=265,y=this.height(x,z);
      for(const side of [-1,1])this.mesh(new THREE.CylinderGeometry(.35,.48,8,8),red,this.scenery,x+side*5.5,y+4,z);
      this.mesh(new THREE.BoxGeometry(15,.9,1.4),red,this.scenery,x,y+8,z);this.mesh(new THREE.BoxGeometry(12,.6,1.1),this.darkMaterial,this.scenery,x,y+6.3,z);
    }
    if(this.map.id==='aurora'||this.map.id==='glacier') {
      const lake=this.mesh(new THREE.CircleGeometry(95,64),this.material({color:'#81aebb',roughness:.17,metalness:.3,transparent:true,opacity:.8}),this.scenery,240,this.height(240,1450)-5,1450);lake.rotation.x=-Math.PI/2;
    }
    if(this.map.id==='fjord') {
      const water=this.mesh(new THREE.PlaneGeometry(3700,4200),this.material({color:'#38677b',roughness:.25,metalness:.35}),this.scenery,0,-310,2500);water.rotation.x=-Math.PI/2;
      this.cabin(190,1030,1.4);
      for(let i=0;i<14;i++) {const x=160+i*8,z=1050,y=this.height(x,z)+4;this.mesh(new THREE.BoxGeometry(8,1.1,7),this.darkMaterial,this.scenery,x,y,z);for(const side of [-1,1])this.mesh(new THREE.BoxGeometry(8,.4,.3),this.accentMaterial,this.scenery,x,y+2,z+side*3.2);}
    }
    if(this.map.night) {
      for(let i=0;i<18;i++) {const z=i*100,x=(i%2?-1:1)*39,y=this.height(x,z);this.mesh(new THREE.CylinderGeometry(.14,.19,9,8),this.darkMaterial,this.scenery,x,y+4.5,z);this.mesh(new THREE.BoxGeometry(3,.4,1.2),this.material({color:'#e4f5ff',emissive:i%2?this.map.accent:'#9bdfff',emissiveIntensity:2}),this.scenery,x,y+9,z);if(i<8){const light=new THREE.PointLight(i%2?this.map.accent:'#b8e2ff',9,75,1);light.position.set(x,y+8,z);this.scenery.add(light);}}
    }
  }
  private buildLift() {
    const cablePoints:THREE.Vector3[]=[],lineX=LIFT_BASE.x;
    for(let i=0;i<=12;i++) {
      const z=-55+i*(LIFT_BASE.z+55)/12,y=this.height(lineX,z)+18;
      this.mesh(new THREE.CylinderGeometry(.4,.65,18,8),this.darkMaterial,this.scenery,lineX,y-9,z);
      this.mesh(new THREE.BoxGeometry(9,.5,1.3),this.darkMaterial,this.scenery,lineX,y,z);
      if(i<12)for(let j=0;j<10;j++) {const zz=z+j*(LIFT_BASE.z+55)/120,yy=this.height(lineX,zz)+18-Math.sin(j/10*Math.PI)*2;cablePoints.push(new THREE.Vector3(lineX-3,yy,zz));}
    }
    const cableGeo=new THREE.BufferGeometry().setFromPoints(cablePoints),cableMat=new THREE.LineBasicMaterial({color:'#475964'});this.resourceMaterials.add(cableMat);this.scenery.add(new THREE.Line(cableGeo,cableMat));
    for(let i=0;i<24;i++) {
      const z=-30+i*76,y=this.height(lineX,z)+14;
      this.mesh(new THREE.CylinderGeometry(.06,.06,3.5,5),this.darkMaterial,this.scenery,lineX-3,y+1.7,z);
      this.mesh(new THREE.BoxGeometry(3.5,.2,1.7),this.darkMaterial,this.scenery,lineX-3,y,z);
      this.mesh(new THREE.BoxGeometry(3.5,1.6,.16),this.darkMaterial,this.scenery,lineX-3,y+.8,z+.7);
    }
    const z=LIFT_BASE.z,y=this.height(lineX,z),glass=this.material({color:'#82b6c7',metalness:.25,roughness:.2});
    const terminal=new THREE.Group();terminal.name='Gondola base station';terminal.position.set(lineX,y,z);this.scenery.add(terminal);
    for(const side of [-1,1])this.mesh(new THREE.BoxGeometry(1.2,12,18),this.darkMaterial,terminal,side*10,6,0);
    this.mesh(new THREE.BoxGeometry(25,2.2,24),this.accentMaterial,terminal,0,13,0);
    this.mesh(new THREE.BoxGeometry(22,.7,23),this.snowMaterial,terminal,0,14.5,0);
    this.mesh(new THREE.BoxGeometry(19,4,1),glass,terminal,0,8.5,9);
    this.mesh(new THREE.CylinderGeometry(6,6,.8,24),this.darkMaterial,terminal,-3,12,0);
    for(const offset of [-4,4]){
      this.mesh(new THREE.BoxGeometry(3.6,2.4,2.8),this.accentMaterial,terminal,offset,4,-3);
      this.mesh(new THREE.BoxGeometry(3.3,1.2,2.9),glass,terminal,offset,4.3,-3);
      this.mesh(new THREE.CylinderGeometry(.09,.09,6,6),this.darkMaterial,terminal,offset,8,-3);
    }
    this.gate(lineX,z-14,20,'GONDOLA · SUMMIT ↑');this.cabin(31,z+2,1.65);
    // Lime side markers funnel the run into the unobstructed finish and station plaza.
    for(let i=0;i<11;i++)for(const side of [-1,1]){
      const zz=1660+i*15,x=side*(65-i*2.2),yy=this.height(x,zz);
      this.mesh(new THREE.CylinderGeometry(.1,.12,2.6,6),this.accentMaterial,this.scenery,x,yy+1.3,zz);
    }
  }
  private batchStaticScenery() {
    // Scenery is stationary: share material draws across lift furniture, flags and gates.
    // Trees and rocks remain instanced, and each terrain chunk keeps independent culling.
    this.scenery.updateMatrixWorld(true);
    const batches=new Map<string,THREE.Mesh[]>();
    this.scenery.traverse(obj=>{
      if(!(obj instanceof THREE.Mesh)||obj instanceof THREE.InstancedMesh||Array.isArray(obj.material)||obj.material.transparent)return;
      const key=obj.material.uuid+','+obj.castShadow+','+obj.receiveShadow;
      const list=batches.get(key)||[];list.push(obj);batches.set(key,list);
    });
    for(const meshes of batches.values()) {
      if(meshes.length<4)continue;
      const geometries=meshes.map(mesh=>mesh.geometry.clone().applyMatrix4(mesh.matrixWorld));
      // Material users can have different optional attributes; merge compatible layouts only.
      const layouts=new Map<string,{mesh:THREE.Mesh;geometry:THREE.BufferGeometry}[]>();
      geometries.forEach((geometry,i)=>{const key=Object.keys(geometry.attributes).sort().join(',')+','+Boolean(geometry.index);const list=layouts.get(key)||[];list.push({mesh:meshes[i],geometry});layouts.set(key,list);});
      for(const entries of layouts.values()) {
        if(entries.length<4){entries.forEach(e=>e.geometry.dispose());continue;}
        const merged=mergeGeometries(entries.map(e=>e.geometry));
        if(merged){const first=entries[0].mesh,m=new THREE.Mesh(merged,first.material);m.castShadow=first.castShadow;m.receiveShadow=first.receiveShadow;m.name='batched-scenery';this.scenery.add(m);entries.forEach(({mesh})=>{mesh.removeFromParent();mesh.geometry.dispose();});}
        entries.forEach(e=>e.geometry.dispose());
      }
    }
  }
  private clearGroup(group:THREE.Group) {
    group.traverse(obj=>{if(obj instanceof THREE.Mesh||obj instanceof THREE.Line||obj instanceof THREE.Points)obj.geometry?.dispose();});group.clear();
  }
  private rebuildProps() {
    this.clearGroup(this.props);
    for(const material of this.propMaterials){this.disposeMaterial(material);this.resourceMaterials.delete(material);}this.propMaterials.clear();
    const beforeMaterials=new Set(this.resourceMaterials);
    const railMat=this.material({color:this.map.night?this.map.accent:'#70868d',roughness:.32,metalness:.65,emissive:this.map.accent,emissiveIntensity:this.map.night?.45:0});
    for(const o of this.objects) {
      const at=(x:number,z:number)=>({x:o.x+x*Math.cos(o.rotation)+z*Math.sin(o.rotation),z:o.z-x*Math.sin(o.rotation)+z*Math.cos(o.rotation)});
      if(isRamp(o.type)||SNOW_FEATURES.has(o.type)) {
        if(o.type==='ride-on-ramp'||['pillow','spine','volcano','banked-turn'].includes(o.type))continue;
        const scale=o.scale;
        for(const side of [-1,1]){const {x,z}=at(side*9.7*scale,11*scale);this.mesh(new THREE.CylinderGeometry(.07,.07,1.8,5),this.accentMaterial,this.props,x,this.height(x,z)+.9,z);}
        for(const offset of SNOW_FEATURES.has(o.type)?[0,61]:[11,29]){
          const vertices:number[]=[],indices:number[]=[];
          for(let i=0;i<=16;i++)for(const dz of [-.22,.22]){const {x,z}=at((i/16-.5)*13*scale,offset*scale+dz);vertices.push(x,this.height(x,z)+.025,z);}
          for(let i=0;i<16;i++){const k=i*2;indices.push(k,k+1,k+2,k+1,k+3,k+2);}
          const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));g.setIndex(indices);g.computeVertexNormals();
          const mat=this.material({color:offset===11||offset===0?'#4bbed1':'#f8a55d',roughness:.9,side:THREE.DoubleSide});this.props.add(new THREE.Mesh(g,mat));
        }
      } else if(isRail(o.type)||o.type==='box') {
        if(o.type==='box') {
          const group=new THREE.Group();group.position.set(o.x,this.surface.height(o.x,o.z),o.z);group.rotation.y=o.rotation;group.scale.setScalar(o.scale);this.props.add(group);
          this.mesh(new THREE.BoxGeometry(3.6,1.1,9),this.darkMaterial,group,0,.55,0);this.mesh(new THREE.BoxGeometry(3.65,.12,9.05),railMat,group,0,1.1,0);
        }else{
          const path=buildRailPath(o,(x,z)=>this.railBaseHeight(x,z)),data=railMesh(path),geometry=new THREE.BufferGeometry();
          geometry.setAttribute('position',new THREE.BufferAttribute(data.vertices,3));geometry.setIndex(new THREE.BufferAttribute(data.indices,1));geometry.computeVertexNormals();
          const pipe=this.mesh(geometry,railMat,this.props);pipe.name='pipe-'+o.id;
          for(const i of [3,16,29]){const p=path.points[i],base=this.groundHeight(p.x,p.z),height=Math.max(.1,p.y-base);this.mesh(new THREE.CylinderGeometry(.07*o.scale,.09*o.scale,height,6),this.darkMaterial,this.props,p.x,base+height*.5,p.z);}
        }
      } else if(o.type==='halfpipe') {
        for(const side of [-1,1]){const {x,z}=at(side*12*o.scale,0);this.mesh(new THREE.CylinderGeometry(.08,.08,2.2,5),this.accentMaterial,this.props,x,this.height(x,z)+1.1,z);}
      } else if(o.type==='tree') {
        const group=new THREE.Group();group.position.set(o.x,this.height(o.x,o.z),o.z);group.scale.setScalar(o.scale);group.rotation.y=o.rotation;this.props.add(group);this.mesh(this.treeGeometry.clone(),this.trees?.material as THREE.Material||this.darkMaterial,group);this.mesh(this.treeSnowGeometry.clone(),this.treeSnow?.material as THREE.Material||this.snowMaterial,group);this.mesh(this.trunkGeometry.clone(),this.darkMaterial,group);
      } else if(o.type==='rock') {const rock=this.mesh(new THREE.DodecahedronGeometry(2.3*o.scale,0),this.darkMaterial,this.props,o.x,this.height(o.x,o.z)+o.scale,o.z);rock.rotation.y=o.rotation;}
      else if(o.type==='cabin'||o.type==='building')this.cabin(o.x,o.z,o.scale,this.props);
      else if(o.type==='light') {const y=this.height(o.x,o.z),s=o.scale;this.mesh(new THREE.CylinderGeometry(.12*s,.17*s,8*s,8),this.darkMaterial,this.props,o.x,y+4*s,o.z);const glow=this.material({color:'#edfbff',emissive:this.map.night?this.map.accent:'#fff1ca',emissiveIntensity:2});this.mesh(new THREE.BoxGeometry(2.5*s,.3*s,1.2*s),glow,this.props,o.x,y+8*s,o.z);const light=new THREE.PointLight(this.map.night?this.map.accent:'#fff3da',10*s,55*s,1);light.position.set(o.x,y+7.5*s,o.z);this.props.add(light);}
      else if(o.type==='gate'||o.type==='checkpoint'||o.type==='finish')this.gate(o.x,o.z,20*o.scale,o.type.toUpperCase(),this.props);
      else if(o.type==='fence'||o.type==='wallride') {const group=new THREE.Group();group.position.set(o.x,this.height(o.x,o.z),o.z);group.rotation.y=o.rotation;this.props.add(group);for(const y of [1,2])this.mesh(new THREE.BoxGeometry(10*o.scale,.22,.25),this.darkMaterial,group,0,y*o.scale,0);for(const x of [-5,0,5])this.mesh(new THREE.BoxGeometry(.25,2.6*o.scale,.25),this.darkMaterial,group,x*o.scale,1.3*o.scale,0);}
      else {const y=this.height(o.x,o.z);this.mesh(new THREE.CylinderGeometry(.11,.11,3.5*o.scale,6),this.darkMaterial,this.props,o.x,y+1.75*o.scale,o.z);this.mesh(new THREE.BoxGeometry(2.5*o.scale,1.2*o.scale,.2),this.accentMaterial,this.props,o.x,y+3.1*o.scale,o.z);}
    }
    for(const material of this.resourceMaterials)if(!beforeMaterials.has(material))this.propMaterials.add(material);
    this.rebuildObstacles();
  }
  private rebuildObstacles() {
    this.obstacles=[];
    for(const p of this.treeLocations)if(Math.abs(p.x-this.center(p.z))<230)this.obstacles.push({x:p.x,z:p.z,radius:.5*p.s});
    for(const p of this.rockLocations)if(Math.abs(p.x-this.center(p.z))<230)this.obstacles.push({x:p.x,z:p.z,radius:p.s*.65});
    for(const o of this.objects) {
      if(o.type==='tree'||o.type==='rock'||o.type==='cabin'||o.type==='wallride'||o.type==='light')this.obstacles.push({x:o.x,z:o.z,radius:o.type==='cabin'?6*o.scale:o.type==='rock'?1.8*o.scale:.5*o.scale});
      if(o.type==='fence')for(let i=-5;i<=5;i++)this.obstacles.push({x:o.x+i*o.scale*Math.cos(o.rotation),z:o.z-i*o.scale*Math.sin(o.rotation),radius:.5*o.scale});
      if(['gate','checkpoint','finish'].includes(o.type))for(const side of [-1,1])this.obstacles.push({x:o.x+side*10*o.scale,z:o.z,radius:.3*o.scale});
    }
  }
  private buildWeather() {
    const n=this.map.id==='stormpeak'?1000:this.map.id==='hokkaido'?500:this.map.snow==='powder'?250:90;
    const random=rng(this.map.seed+90);this.snowOffsets=new Float32Array(n*3);
    for(let i=0;i<n;i++) {this.snowOffsets[i*3]=(random()-.5)*180;this.snowOffsets[i*3+1]=random()*85;this.snowOffsets[i*3+2]=(random()-.5)*180;}
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(this.snowOffsets.slice(),3));const material=new THREE.PointsMaterial({color:'#f1f8ff',size:this.map.id==='stormpeak'?.14:.1,transparent:true,opacity:this.map.id==='stormpeak'?.6:.58,depthWrite:false});this.resourceMaterials.add(material);this.snowfall=new THREE.Points(geo,material);this.snowfall.frustumCulled=false;this.group.add(this.snowfall);
  }
  update(player:THREE.Vector3,dt:number) {
    this.elapsed+=dt;this.previousPlayer.copy(player);
    if(this.snowfall&&this.snowOffsets&&this.requestedWeather) {
      const a=this.snowfall.geometry.getAttribute('position') as THREE.BufferAttribute,n=this.snowOffsets.length/3,wind=this.map.id==='stormpeak'?12:1.5;
      for(let i=0;i<n;i++) {const ox=this.snowOffsets[i*3],oy=this.snowOffsets[i*3+1],oz=this.snowOffsets[i*3+2];a.setXYZ(i,player.x+((ox+this.elapsed*wind+270)%180)-90,player.y+((oy-this.elapsed*(2+i%3)+85000)%85)-5,player.z+oz);}
      a.needsUpdate=true;
    }
  }
  setWeather(enabled:boolean) {this.requestedWeather=enabled;if(this.snowfall)this.snowfall.visible=enabled;}
  setObjects(objects:ParkObject[]) {
    this.objects=objects.map(o=>({...o,scale:THREE.MathUtils.clamp(o.scale,.25,5)}));this.buildTerrain();this.rebuildProps();
  }
  pickSurface(raycaster:THREE.Raycaster){return raycaster.intersectObjects(this.surfaceTiles,false)[0]?.point;}
  setPark(objects:ParkObject[],edits:TerrainEdit[]){
    this.objects=objects.map(o=>({...o}));this.setEdits(edits);
  }
  setEdits(edits:TerrainEdit[]) {
    this.edits=edits.map(e=>({...e}));this.buildTerrain();this.rebuildProps();
    // Keep trees attached to edited terrain, using the same instance geometry.
    const matrix=new THREE.Matrix4(),q=new THREE.Quaternion(),pos=new THREE.Vector3(),scale=new THREE.Vector3();
    this.treeLocations.forEach((p,i)=> {q.setFromAxisAngle(new THREE.Vector3(0,1,0),p.angle);pos.set(p.x,this.height(p.x,p.z)-.12,p.z);scale.setScalar(p.s);matrix.compose(pos,q,scale);this.trees?.setMatrixAt(i,matrix);this.treeSnow?.setMatrixAt(i,matrix);this.trunks?.setMatrixAt(i,matrix);});
    for(const mesh of [this.trees,this.treeSnow,this.trunks])if(mesh)mesh.instanceMatrix.needsUpdate=true;

  }
  dispose() {
    this.scene.remove(this.group);
    const geometries=new Set<THREE.BufferGeometry>();
    this.group.traverse(obj=>{if(obj instanceof THREE.Mesh||obj instanceof THREE.Points||obj instanceof THREE.Line)geometries.add(obj.geometry);});
    geometries.add(this.treeGeometry);geometries.add(this.treeSnowGeometry);geometries.add(this.trunkGeometry);geometries.forEach(g=>g.dispose());
    this.resourceMaterials.forEach(m=>this.disposeMaterial(m));this.resourceMaterials.clear();this.group.clear();
  }
}
