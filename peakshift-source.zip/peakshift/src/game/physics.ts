import * as THREE from 'three';
import RAPIER from '@dimforge/rapier3d-compat';
import {BOARD_LENGTH,BOARD_WIDTH} from './tricks';
import {buildRailPath,railMesh,closestRailPoint,railMagnet,isPipeRail,type RailPath,type RailObject} from './rails';
export {RAPIER};
let initialized:Promise<void>|undefined;
export function initPhysics(){return initialized??=RAPIER.init();}
export type Sport='snowboard';
export type InputState={turn:number;tuck:boolean;brake:boolean;jump:boolean;grab:boolean;pitch:number;roll:number;grabStyle?:string;grabContact?:boolean;airTurn?:number;airPitch?:number;press?:number};
export interface TerrainWorldLike{height(x:number,z:number):number;groundHeight?(x:number,z:number):number;railBaseHeight?(x:number,z:number):number;normal(x:number,z:number):THREE.Vector3;objects:{id:string;type:string;x:number;z:number;rotation:number;scale:number}[];obstacles:{x:number;z:number;radius:number}[];map?:{snow?:string};collisionMesh?():{vertices:Float32Array;indices:Uint32Array};}
export interface RiderDynamics{beforeStep(input:InputState,dt:number):void;afterStep():void;isRiderCollider(collider:RAPIER.Collider):boolean;addTorque(torque:THREE.Vector3):void;addForce(force:THREE.Vector3):void;jump(deltaVelocity:THREE.Vector3):void;angularVelocity():THREE.Vector3;linearVelocity():THREE.Vector3;hasSupport():boolean;canResume(normal:THREE.Vector3):boolean;resume(input:InputState):void;stop():void;}
export const GRAVITY=9.81,FULL_JUMP_CHARGE_SECONDS=1.05,MAX_LAUNCH_SPEED=8.2;
/** Ballistic intercept against the actual track ahead, including uphill landings. */
export function landingIntercept(world:TerrainWorldLike,position:THREE.Vector3,velocity:THREE.Vector3){
 let t=.3;
 for(let i=0;i<3;i++){
  const height=world.height(position.x+velocity.x*t,position.z+velocity.z*t)+.055;
  const gap=position.y-height,discriminant=velocity.y*velocity.y+2*GRAVITY*gap;
  if(discriminant<0)return Infinity;
  t=(velocity.y+Math.sqrt(discriminant))/GRAVITY;
  if(t<0||t>.8)return Infinity;
 }
 const n=world.normal(position.x+velocity.x*t,position.z+velocity.z*t);
 return velocity.clone().add(new THREE.Vector3(0,-GRAVITY*t,0)).dot(n)<-.5?t:Infinity;
}
const STEP=1/480,UP=new THREE.Vector3(0,1,0),IDENTITY={x:0,y:0,z:0,w:1};
const clamp=THREE.MathUtils.clamp,wrap=(v:number)=>Math.atan2(Math.sin(v),Math.cos(v));
export function terrainFrame(n:THREE.Vector3,heading:number){const f=new THREE.Vector3(Math.sin(heading),0,Math.cos(heading));f.addScaledVector(n,-f.dot(n)).normalize();return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3().crossVectors(n,f).normalize(),n,f));}
function fallbackMesh(w:TerrainWorldLike){const vertices:number[]=[],indices:number[]=[],nx=40,nz=520;for(let j=0;j<=nz;j++)for(let i=0;i<=nx;i++){const x=-80+i*4,z=-80+j*4;vertices.push(x,w.height(x,z),z);}for(let j=0;j<nz;j++)for(let i=0;i<nx;i++){const a=j*(nx+1)+i;indices.push(a,a+nx+1,a+1,a+1,a+nx+1,a+nx+2);}return{vertices:new Float32Array(vertices),indices:new Uint32Array(indices)};}
/** Dynamic rigid board. Terrain contact, angular momentum and impacts are solved by Rapier. */
export class SnowboardPhysics{
 readonly dynamics:RAPIER.World;readonly board:RAPIER.RigidBody;readonly collider:RAPIER.Collider;readonly terrain:RAPIER.Collider;
 readonly balanceOffset=new THREE.Vector3();readonly balanceTilt=new THREE.Vector3();balanceEffort=0;readonly position=new THREE.Vector3();readonly velocity=new THREE.Vector3();readonly orientation=new THREE.Quaternion();readonly angularVelocity=new THREE.Vector3();readonly surfaceNormal=new THREE.Vector3(0,1,0);
 heading=0;pitch=0;roll=0;spin=0;speed=0;grounded=true;crashed=false;charge=0;airtime=0;score=0;combo=1;lastTrick='Find your line';lastPoints=0;compression=0;landingImpact=0;edgeAngle=0;steering=0;lateralSlip=0;flipProgress=0;flipDirection=0;spinWindup=0;spinRotation=0;flipRotation=0;corkRotation=0;railId:string|null=null;railBalance=0;switch=false;airSwitch=false;fallTime=0;fallSupportedFor=0;contactLoad=0;butterTime=0;tuckAmount=0;
 readonly sport:Sport='snowboard';assistance=true;landingAssist=0;landingRecovery=0;touchdownPrep=0;riderDynamics?:RiderDynamics;
 onEvent?:(e:{type:string;text?:string;points?:number})=>void;
 private supportTargetNormal=new THREE.Vector3(0,1,0);private fallNoContact=0;private contactNormal?:THREE.Vector3;private airHeading=0;private catchTime=0;private edgeDangerTime=0;private targetHeading=0;private accumulator=0;private previousJump=false;private time=0;private lastLanding=-100;private noContact=0;private jumpCooldown=0;private airActive=false;private peakAir=0;private grabTime=0;private grabName='Indy';private grabDurations=new Map<string,number>();private lastAirTurn=0;private spinAge=1;private expectedForce=new THREE.Vector3();private solidColliders=new Set<number>();private railColliders=new Map<number,RailObject>();readonly rails:RailPath[]=[];private railHeading=0;private railTime=0;private railGap=0;private railName='50–50';
 constructor(public readonly world:TerrainWorldLike){
  this.dynamics=new RAPIER.World({x:0,y:-GRAVITY,z:0});this.dynamics.timestep=STEP;this.dynamics.integrationParameters.numSolverIterations=8;this.dynamics.integrationParameters.maxCcdSubsteps=4;
  const mesh=world.collisionMesh?.()??fallbackMesh(world);this.terrain=this.dynamics.createCollider(RAPIER.ColliderDesc.trimesh(mesh.vertices,mesh.indices,RAPIER.TriMeshFlags.FIX_INTERNAL_EDGES).setFriction(.03).setRestitution(0));
  for(const o of world.obstacles){const h=world.height(o.x,o.z),c=this.dynamics.createCollider(RAPIER.ColliderDesc.cylinder(2,Math.max(.25,o.radius)).setTranslation(o.x,h+2,o.z).setFriction(.3));this.solidColliders.add(c.handle);}
  for(const o of world.objects){
   if(isPipeRail(o.type)){
    const path=buildRailPath(o,(x,z)=>world.railBaseHeight?.(x,z)??world.groundHeight?.(x,z)??world.height(x,z)),mesh=railMesh(path);
    const c=this.dynamics.createCollider(RAPIER.ColliderDesc.trimesh(mesh.vertices,mesh.indices,RAPIER.TriMeshFlags.FIX_INTERNAL_EDGES).setFriction(.025).setRestitution(0));
    this.rails.push(path);this.solidColliders.add(c.handle);this.railColliders.set(c.handle,o);
   }else if(o.type==='box'){
    const y=(world.groundHeight?.(o.x,o.z)??world.height(o.x,o.z))+.58*o.scale;
    const c=this.dynamics.createCollider(RAPIER.ColliderDesc.cuboid(1.8*o.scale,.58*o.scale,4.5*o.scale).setTranslation(o.x,y,o.z).setRotation(new THREE.Quaternion().setFromAxisAngle(UP,o.rotation)).setFriction(.04));this.solidColliders.add(c.handle);this.railColliders.set(c.handle,o);
   }
  }
  const desc=RAPIER.RigidBodyDesc.dynamic().setCcdEnabled(true).setSoftCcdPrediction(.6).setCanSleep(false).setLinearDamping(.015).setAngularDamping(.5).setAdditionalSolverIterations(4).setAdditionalMassProperties(80,{x:0,y:.55,z:0},{x:35,y:18,z:28},IDENTITY);
  this.board=this.dynamics.createRigidBody(desc);
  const points:number[]=[];for(const z of [-BOARD_LENGTH/2,-.67,-.55,0,.55,.67,BOARD_LENGTH/2])for(const side of [-1,1])for(const y of [-.035,.015]){const tip=Math.max(0,(Math.abs(z)-.57)/.22),x=side*BOARD_WIDTH*.5*(.9+.1*(Math.abs(z)/.79)**2)*Math.sqrt(Math.max(.03,1-tip*tip));points.push(x,y+tip*tip*.12,z);}
  this.collider=this.dynamics.createCollider(RAPIER.ColliderDesc.convexHull(new Float32Array(points))!.setDensity(0).setFriction(.045).setRestitution(.02).setContactSkin(.005),this.board);this.reset();
 }
 reset(x=0,z=0,preserveScore=false,heading=0){this.contactNormal=undefined;this.fallNoContact=0;this.landingAssist=this.landingRecovery=this.touchdownPrep=0;this.balanceOffset.set(0,0,0);this.balanceTilt.set(0,0,0);this.balanceEffort=0;const score=this.score;this.position.set(x,this.world.height(x,z)+.055,z);this.supportTargetNormal.copy(this.world.normal(x,z));this.orientation.copy(terrainFrame(this.supportTargetNormal,heading));this.board.setTranslation(this.position,true);this.board.setRotation(this.orientation,true);this.board.setLinvel({x:0,y:0,z:0},true);this.board.setAngvel({x:0,y:0,z:0},true);this.board.setAdditionalMassProperties(80,{x:0,y:.55,z:0},{x:35,y:18,z:28},IDENTITY,true);this.board.resetForces(true);this.board.resetTorques(true);this.crashed=false;this.grounded=true;this.heading=this.targetHeading=this.airHeading=heading;this.pitch=this.roll=this.spin=this.charge=this.speed=this.airtime=this.fallTime=this.spinRotation=this.flipRotation=this.corkRotation=this.compression=this.contactLoad=this.butterTime=0;this.switch=this.airSwitch=false;this.catchTime=this.fallSupportedFor=this.edgeDangerTime=this.noContact=this.jumpCooldown=this.accumulator=0;this.airActive=this.previousJump=false;this.tuckAmount=0;this.grabDurations.clear();this.score=preserveScore?score:0;this.combo=1;this.lastPoints=0;this.lastTrick='Find your line';this.railId=null;this.railTime=this.railGap=0;this.velocity.set(0,0,0);this.sync();}
 launchSpeed(speed=9.5){const n=this.world.normal(this.position.x,this.position.z),v=new THREE.Vector3(0,0,speed);v.y=-n.z*speed/Math.max(.2,n.y);this.board.setLinvel(v,true);this.sync();}
 update(input:InputState,dt:number){if(!Number.isFinite(dt)||dt<=0)return;this.accumulator+=Math.min(.1,dt);while(this.accumulator+1e-9>=STEP){this.step(input);this.accumulator-=STEP;}}
 /** Approximate the rider's folded mass distribution, preserving angular momentum. */
 setRiderTuck(amount:number){
  if(this.riderDynamics)return;amount=clamp(Number.isFinite(amount)?amount:0,0,1);if(this.crashed||Math.abs(amount-this.tuckAmount)<.00001)return;
  const inertia=(t:number)=>new THREE.Vector3(35*(1-.42*t),18*(1-.5*t),28*(1-.45*t)),old=inertia(this.tuckAmount),next=inertia(amount),q=new THREE.Quaternion().copy(this.board.rotation());
  const omega=new THREE.Vector3().copy(this.board.angvel()).applyQuaternion(q.clone().invert()).multiply(old).divide(next).applyQuaternion(q);
  this.board.setAdditionalMassProperties(80,{x:0,y:.55,z:0},next,IDENTITY,true);this.board.recomputeMassPropertiesFromColliders();this.board.setAngvel(omega,true);this.angularVelocity.copy(omega);this.tuckAmount=amount;
 }
 private torqueTo(target:THREE.Quaternion,strength:number,damping:number,maximum:number){const error=target.clone().multiply(this.orientation.clone().invert());if(error.w<0)error.set(-error.x,-error.y,-error.z,-error.w);const vector=new THREE.Vector3(error.x,error.y,error.z).multiplyScalar(2*strength).addScaledVector(this.riderDynamics?.angularVelocity()??this.angularVelocity,-damping);vector.clampLength(0,maximum);if(this.riderDynamics)this.riderDynamics.addTorque(vector);else this.board.addTorque(vector,true);}
 private step(input:InputState){
  this.time+=STEP;this.jumpCooldown=Math.max(0,this.jumpCooldown-STEP);this.landingRecovery=Math.max(0,this.landingRecovery-STEP);const released=this.previousJump&&!input.jump;this.previousJump=input.jump;
  const intercept=!this.grounded&&this.airtime>.15&&this.assistance?landingIntercept(this.world,this.position,this.riderDynamics?.linearVelocity()??this.velocity):Infinity;
  this.touchdownPrep=this.assistance?1-THREE.MathUtils.smoothstep(intercept,.14,.32):0;
  this.landingAssist=this.assistance&&this.landingRecovery>0?1:0;
  this.board.resetForces(true);this.board.resetTorques(true);const previousVelocity=this.velocity.clone(),loadVelocity=this.riderDynamics?.linearVelocity()??previousVelocity;this.expectedForce.set(0,0,0);this.riderDynamics?.beforeStep(input,STEP);
  if(this.crashed){this.stepTumble(input);return;}
  this.setRiderTuck(THREE.MathUtils.damp(this.tuckAmount,!this.grounded&&input.grab&&input.grabContact!==false?.9:0,10,STEP));
  const activeRail=this.railId?this.rails.find(r=>r.object.id===this.railId):undefined;
  const railPoint=activeRail?closestRailPoint(activeRail,this.position):undefined;
  if(railPoint){this.targetHeading+=wrap(railPoint.heading-this.railHeading);this.railHeading=railPoint.heading;}
  const n=railPoint?.normal??(this.grounded?this.contactNormal:undefined)??this.world.normal(this.position.x,this.position.z);this.surfaceNormal.copy(n);const movement=new THREE.Vector3(this.velocity.x,0,this.velocity.z),travel=this.riderDynamics?.linearVelocity()??this.velocity,motionHeading=this.grounded?(movement.length()>1?Math.atan2(movement.x,movement.z):this.heading):(Math.hypot(travel.x,travel.z)>2?Math.atan2(travel.x,travel.z):this.airHeading);
  const alignment=Math.cos(this.heading-motionHeading);if(Math.abs(alignment)>.25)this.switch=alignment<0;
  if(this.grounded){
   this.steering=THREE.MathUtils.damp(this.steering,input.turn,12,STEP);this.edgeAngle=THREE.MathUtils.damp(this.edgeAngle,this.steering*Math.min(.42,this.speed*.018),10,STEP);
   const desiredRate=-this.steering*1.45/(1+this.speed*.022);
   this.targetHeading+=desiredRate*STEP;
   const bank=THREE.MathUtils.smoothstep(1-n.y,.06,.35);
   if(bank>0&&Math.abs(input.turn)<.05&&this.speed>2){const flow=motionHeading+(Math.cos(this.heading-motionHeading)<0?Math.PI:0);this.targetHeading+=clamp(wrap(flow-this.targetHeading),-STEP*1.6,STEP*1.6)*bank;}
   if(this.railId||this.supportTargetNormal.dot(n)<.88)this.supportTargetNormal.copy(n);else this.supportTargetNormal.lerp(n,1-Math.exp(-STEP*(this.speed>18?22:50))).normalize();
   const stability=THREE.MathUtils.smoothstep(this.speed,18,34);
   const target=terrainFrame(this.supportTargetNormal,this.targetHeading).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,0,1),this.edgeAngle*(this.switch?-1:1))).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1,0,0),(input.press||0)*.12));
   this.torqueTo(target,this.railId?2200:this.landingRecovery>0?1700:1600+bank*900,this.railId?380:this.landingRecovery>0?230:280+bank*120+stability*180,this.railId?1800:this.landingRecovery>0?1200:1200+bank*700+stability*200);
   const f=new THREE.Vector3(Math.sin(this.heading),0,Math.cos(this.heading)),side=new THREE.Vector3(f.z,0,-f.x).projectOnPlane(n).normalize(),lateral=travel.dot(side),snow=this.world.map?.snow;
   this.lateralSlip=lateral;const grip=(snow==='ice'?4:snow==='powder'?7:11)*(1-bank*.8*(1-Math.abs(this.steering)));
   const lateralForce=side.multiplyScalar(this.railId?0:clamp(-lateral*80*grip,-900,900)),force=new THREE.Vector3();
   const downhill=new THREE.Vector3(0,0,80*GRAVITY*Math.max(0,n.z)*n.y*2.1).projectOnPlane(n);
   if(!this.railId&&!input.brake&&n.y>.55){const drive=new THREE.Vector3(0,0,1).addScaledVector(n,-n.z).normalize();downhill.addScaledVector(drive,80*6.5*Math.max(0,1-this.speed/7));}
   const drag=(input.tuck?.0016:.0055)*(snow==='powder'?1.5:1),friction=snow==='powder'?.45:.08,deceleration=friction+(input.brake?12+this.speed*.32:0);
   if(this.speed>.2){movement.normalize();force.addScaledVector(movement,-80*deceleration);downhill.addScaledVector(movement,-80*drag*this.speed*this.speed);}downhill.add(lateralForce);
   this.expectedForce.copy(force).add(downhill);this.board.addForce(force,true);if(this.riderDynamics)this.riderDynamics.addForce(downhill);else this.board.addForce(downhill,true);
   this.charge=input.jump?Math.min(1,this.charge+STEP/FULL_JUMP_CHARGE_SECONDS):this.charge;
   if(released&&this.jumpCooldown<=0){const vy=Math.min(MAX_LAUNCH_SPEED,Math.max(-1,this.velocity.y)+3.2+this.charge*3.8);if(this.riderDynamics)this.riderDynamics.jump(new THREE.Vector3(0,vy-this.velocity.y,0));else this.board.applyImpulse({x:0,y:80*(vy-this.velocity.y),z:0},true);this.charge=0;this.jumpCooldown=.22;this.landingRecovery=0;this.startAir();}
   if(input.press&&this.speed>4){this.butterTime+=STEP;if(this.butterTime>.7&&this.time-this.lastLanding>.8)this.award((this.switch?'Switch ':'')+(input.press>0?'Tail press':'Nose press'),80);}
   else this.butterTime=0;
  }else{
   const turn=input.airTurn??input.turn,pitch=input.airPitch??input.pitch;
   if(Math.sign(turn)!==Math.sign(this.lastAirTurn)&&Math.abs(turn)>.15)this.spinAge=0;this.spinAge+=STEP;this.lastAirTurn=turn;this.spinWindup=turn*Math.max(0,1-this.spinAge/.18);
   const right=new THREE.Vector3(Math.cos(motionHeading),0,-Math.sin(motionHeading));
   const recoveryInput=this.landingRecovery>0&&this.airtime<.08&&this.peakAir<.3?0:1;
   const desired=right.multiplyScalar(pitch*7*recoveryInput).add(new THREE.Vector3(0,-turn*7*recoveryInput*(1-Math.abs(this.spinWindup)*.5),0));
   if(input.roll)desired.add(new THREE.Vector3(Math.sin(motionHeading),0,Math.cos(motionHeading)).multiplyScalar(input.roll*5*recoveryInput));
   // Air rotations remain player-driven. The assist never chooses an airborne
   // orientation or cancels a held trick key; recovery begins at snow contact.
   const braking=Math.abs(pitch)+Math.abs(turn)+Math.abs(input.roll)<.1;
   const motor=desired.sub(this.riderDynamics?.angularVelocity()??this.angularVelocity).multiplyScalar(braking?320:110);motor.clampLength(0,braking?1600:800);if(this.riderDynamics)this.riderDynamics.addTorque(motor);else this.board.addTorque(motor,true);
   const rotation=this.riderDynamics?.angularVelocity()??this.angularVelocity;this.spinRotation+=rotation.y*STEP;this.flipRotation+=rotation.dot(new THREE.Vector3(Math.cos(motionHeading),0,-Math.sin(motionHeading)))*STEP;this.corkRotation+=rotation.dot(new THREE.Vector3(Math.sin(motionHeading),0,Math.cos(motionHeading)))*STEP;this.spin=this.spinRotation;this.flipProgress=Math.abs(this.flipRotation)/(Math.PI*2)%1;this.flipDirection=Math.sign(pitch);
   if(input.grab&&input.grabContact!==false&&this.airtime>.12){this.grabTime+=STEP;this.grabName=input.grabStyle||'Indy';this.grabDurations.set(this.grabName,(this.grabDurations.get(this.grabName)||0)+STEP);}
  }
  if(this.assistance&&this.jumpCooldown<=0&&UP.clone().applyQuaternion(this.orientation).y>.45){
   let best:ReturnType<typeof railMagnet>;
   for(const rail of this.rails){
    if(this.position.x<rail.minX-1.1||this.position.x>rail.maxX+1.1||this.position.z<rail.minZ-1.1||this.position.z>rail.maxZ+1.1)continue;
    const assist=railMagnet(rail,this.position,this.velocity,this.railId===rail.object.id,input.turn);
    if(assist&&(!best||assist.distance<best.distance))best=assist;
   }
   if(best){this.expectedForce.add(best.force);if(this.riderDynamics)this.riderDynamics.addForce(best.force);else this.board.addForce(best.force,true);}
  }
  this.dynamics.step();this.sync();this.riderDynamics?.afterStep();if(this.crashed)return;
  const {touching,solidHit,railContact,supportNormal}=this.boardContact();this.contactNormal=supportNormal;if(supportNormal)this.surfaceNormal.copy(supportNormal);
  if(railContact){if(this.railId!==railContact.id){this.railTime=0;const path=this.rails.find(r=>r.object.id===railContact!.id);this.railHeading=path?closestRailPoint(path,this.position).heading:railContact.rotation;this.targetHeading=this.heading;this.onEvent?.({type:'rail',text:'ON THE RAIL'});}this.railId=railContact.id;this.railGap=0;this.railTime+=STEP;this.railName=Math.abs(Math.cos(this.heading-this.railHeading))>.7?'50–50':'Boardslide';}
  else if(this.railId){this.railGap+=STEP;if(this.railGap>.08){if(this.railTime>.18)this.award((this.switch?'Switch ':'')+this.railName,Math.round(100+this.railTime*160));this.railId=null;this.railTime=0;}}
  this.contactLoad=touching?Math.max(0,((this.riderDynamics?.linearVelocity()??this.velocity.clone()).sub(loadVelocity).dot(n)+GRAVITY*n.y*STEP-this.expectedForce.dot(n)/80*STEP)/(GRAVITY*STEP)):0;const compression=clamp((this.contactLoad-1)*.1,0,.75);this.compression=THREE.MathUtils.damp(this.compression,compression,compression>this.compression?20:3,STEP);
  this.noContact=touching?0:this.noContact+STEP;this.grounded=(this.noContact<.035||!!this.railId&&this.railGap<.08)&&this.jumpCooldown<=0;
  if(!this.grounded&&this.noContact>.035&&!this.airActive)this.startAir();
  if(this.airActive){this.peakAir=Math.max(this.peakAir,this.position.y-this.world.height(this.position.x,this.position.z));this.airtime+=STEP;if(this.grounded&&this.airtime>.1){this.landingImpact=Math.max(0,-loadVelocity.dot(n));this.land(motionHeading);}}
  const up=UP.clone().applyQuaternion(this.orientation),tilt=up.dot(n),angular=(this.riderDynamics?.angularVelocity()??this.angularVelocity).length(),hitDelta=this.velocity.clone().sub(previousVelocity).length();
  // A light deck can deflect for a few substeps while the knees absorb a seam.
  // Allow that physical recovery; sustained overturning or an obstacle still bails.
  const recovery=this.assistance&&this.landingRecovery>0;
  const unsafe=touching&&this.speed>2&&(tilt<(recovery?.12:.28)||angular>(recovery?12:10)&&tilt<.5);
  this.edgeDangerTime=unsafe?this.edgeDangerTime+STEP:Math.max(0,this.edgeDangerTime-STEP*2);
  if((touching&&tilt<-.3&&this.speed>2)||(solidHit>0&&hitDelta>2)||this.edgeDangerTime>(recovery?.4:.3))this.bail('EDGE CAUGHT');
 }
 /** Read native contacts in both riding and tumbling states. */
 private boardContact(){
  let touching=false,solidHit=0,railContact:RailObject|undefined,supportNormal:THREE.Vector3|undefined;
  this.dynamics.contactPairsWith(this.collider,other=>{
   if(this.riderDynamics?.isRiderCollider(other))return;
   this.dynamics.contactPair(this.collider,other,m=>{
    const rail=this.railColliders.get(other.handle),path=rail&&this.rails.find(r=>r.object.id===rail.id);
    const normal=new THREE.Vector3().copy(m.normal());if(normal.y<0)normal.negate();
    const top=rail&&(path?this.position.y>closestRailPoint(path,this.position).point.y+.03&&UP.clone().applyQuaternion(this.orientation).y>.4:normal.y>.65);
    for(let i=0;i<m.numContacts();i++)if(m.contactDist(i)<.035){
     touching=true;if(top)railContact=rail;else if(this.solidColliders.has(other.handle))solidHit++;
     if(normal.y>.05&&(other.handle===this.terrain.handle||top))supportNormal=normal;
    }
   });
  });
  return{touching,solidHit,railContact,supportNormal};
 }
 private stepTumble(input:InputState){
  this.fallTime+=STEP;
  // A loose rider can still use deliberate air input to try to save the landing.
  // Neutral input adds no braking or upright target to the passive fall.
  const turn=input.airTurn??input.turn,pitch=input.airPitch??input.pitch;
  if(!this.grounded&&this.riderDynamics&&Math.abs(turn)+Math.abs(pitch)+Math.abs(input.roll)>.1){
   const travel=this.riderDynamics.linearVelocity(),heading=Math.hypot(travel.x,travel.z)>2?Math.atan2(travel.x,travel.z):this.airHeading,desired=new THREE.Vector3(Math.cos(heading)*pitch*5,-turn*5,-Math.sin(heading)*pitch*5);
   desired.add(new THREE.Vector3(Math.sin(heading),0,Math.cos(heading)).multiplyScalar(input.roll*4));
   this.riderDynamics.addTorque(desired.sub(this.riderDynamics.angularVelocity()).multiplyScalar(65).clampLength(0,450));
  }
  this.dynamics.step();this.sync();
  const contact=this.boardContact();this.grounded=!!contact.supportNormal;
  const supported=contact.touching||this.riderDynamics?.hasSupport();
  this.fallNoContact=supported?0:this.fallNoContact+STEP;
  if(supported)this.fallSupportedFor+=STEP;else if(this.fallNoContact>.08)this.fallSupportedFor=0;
  const n=contact.supportNormal;
  const possible=!!n&&UP.clone().applyQuaternion(this.orientation).dot(n)>.45&&this.riderDynamics?.canResume(n);
  this.catchTime=possible?this.catchTime+STEP:0;
  if(this.catchTime<.035||!n||!this.riderDynamics)return;
  // Same bodies, joints, positions and momenta. Only the control state changes.
  this.crashed=false;this.catchTime=this.fallTime=this.fallSupportedFor=this.edgeDangerTime=this.noContact=0;
  this.charge=0;this.previousJump=input.jump;this.jumpCooldown=.18;this.airActive=false;this.airtime=this.peakAir=0;
  this.grabDurations.clear();this.grabTime=this.spinRotation=this.flipRotation=this.corkRotation=0;
  this.surfaceNormal.copy(n);this.contactNormal=n.clone();this.landingRecovery=.9;this.landingAssist=1;
  const forward=new THREE.Vector3(0,0,1).applyQuaternion(this.orientation),heading=Math.atan2(forward.x,forward.z),motion=Math.atan2(this.velocity.x,this.velocity.z);
  this.heading=heading;this.switch=Math.cos(heading-motion)<0;
  this.targetHeading=contact.railContact?heading:motion+(this.switch?Math.PI:0);
  this.lastTrick='Saved it';this.lastPoints=0;
  this.riderDynamics.resume(input);this.onEvent?.({type:'save',text:'SAVED IT · KEEP RIDING'});
 }
 private startAir(){if(this.airActive)return;this.grounded=false;this.airActive=true;const travel=this.riderDynamics?.linearVelocity()??this.velocity;this.airHeading=Math.hypot(travel.x,travel.z)>2?Math.atan2(travel.x,travel.z):this.heading+(this.switch?Math.PI:0);this.airtime=0;this.peakAir=0;this.airSwitch=this.switch;this.spinRotation=this.flipRotation=this.corkRotation=0;this.grabTime=0;this.grabDurations.clear();this.spinAge=1;this.onEvent?.({type:'air',text:'SEND IT'});}
 private land(motionHeading:number){
  const n=this.surfaceNormal,up=UP.clone().applyQuaternion(this.orientation),tilt=up.dot(n);this.airActive=false;
  if(tilt<(this.assistance?.18:.25)||this.landingImpact>(this.assistance?28:22)){this.bail('HEAVY LANDING');return;}
  if(this.assistance){this.landingRecovery=.9;const forward=new THREE.Vector3(0,0,1).applyQuaternion(this.orientation),actualHeading=Math.atan2(forward.x,forward.z);this.heading=actualHeading;const aligned=motionHeading+(Math.cos(actualHeading-motionHeading)<0?Math.PI:0);this.targetHeading=this.railId?actualHeading:aligned;if(!this.riderDynamics)this.board.setAngvel(this.angularVelocity.multiplyScalar(.3),true);}
  if(this.airtime<.2||this.peakAir<.45||(this.time-this.lastLanding<.9&&this.peakAir<1.2))return;
  const halfTurns=Math.floor((Math.abs(this.spinRotation)+.3)/Math.PI),flips=Math.floor((Math.abs(this.flipRotation)+.35)/(Math.PI*2)),corks=Math.floor((Math.abs(this.corkRotation)+.35)/(Math.PI*2)),parts:string[]=[];
  const grabs=[...this.grabDurations].filter(([,duration])=>duration>.12).map(([name])=>name);
  if(this.airSwitch)parts.push('Switch');if(halfTurns)parts.push((this.spinRotation*(this.airSwitch?-1:1)>0?'Frontside ':'Backside ')+halfTurns*180);if(flips)parts.push((['','Double ','Triple ','Quad '][flips-1]??flips+'x ')+(this.flipRotation<0?'Wildcat':'Tamedog'));if(corks)parts.push((['','Double ','Triple ','Quad '][corks-1]??corks+'x ')+'Cork');if(grabs.length)parts.push(grabs.join(' → '));if(!halfTurns&&!flips&&!corks&&!grabs.length)parts.push('Straight air');
  this.award(parts.join(' · '),Math.round(50+this.airtime*45+halfTurns*160+flips*450+corks*450+Math.min(2,this.grabTime)*150+Math.max(0,grabs.length-1)*80));
 }
 private award(text:string,points:number){this.combo=this.time-this.lastLanding<6?Math.min(5,this.combo+.25):1;this.lastLanding=this.time;this.lastTrick=text;this.lastPoints=Math.round(points*this.combo);this.score+=this.lastPoints;this.onEvent?.({type:'land',text,points:this.lastPoints});}
 bail(reason:string){if(this.crashed)return;this.crashed=true;this.charge=0;this.catchTime=this.fallTime=this.fallSupportedFor=this.fallNoContact=0;this.grounded=false;this.railId=null;this.railTime=0;this.lastTrick='Tumbling';this.lastPoints=0;this.combo=1;if(!this.riderDynamics)this.board.setAdditionalMassProperties(5,{x:0,y:0,z:0},{x:1.4,y:1.5,z:.1},IDENTITY,true);this.onEvent?.({type:'crash',text:reason+' · LAND BOARD FIRST TO SAVE IT'});}
 sync(){this.position.copy(this.board.translation());this.velocity.copy(this.board.linvel());this.orientation.copy(this.board.rotation());this.angularVelocity.copy(this.board.angvel());this.speed=Math.hypot(this.velocity.x,this.velocity.z);const f=new THREE.Vector3(0,0,1).applyQuaternion(this.orientation);if(this.grounded&&!this.crashed)this.heading=Math.atan2(f.x,f.z);const e=new THREE.Euler().setFromQuaternion(this.orientation,'YXZ');this.pitch=e.x;this.roll=e.z;}
 stop(){this.riderDynamics?.stop();this.board.setLinvel({x:0,y:0,z:0},true);this.board.setAngvel({x:0,y:0,z:0},true);this.velocity.set(0,0,0);this.speed=0;}
 dispose(){this.dynamics.free();}
}

/** Recover on nearby rideable snow rather than inside the uphill face of a kicker. */
export function recoveryPoint(world:TerrainWorldLike,x:number,z:number){x=clamp(x,-640,640);z=clamp(z,-50,1770);for(let offset=0;offset<=60;offset+=3){const candidate=Math.min(1770,z+offset),n=world.normal(x,candidate);if(n.y>.8&&n.z>.025&&!world.obstacles.some(o=>Math.hypot(o.x-x,o.z-candidate)<o.radius+1.5))return{x,z:candidate};}return{x,z};}
