import type { MapConfig, ParkObject, TerrainEdit } from './world';

/** Small, failure-tolerant browser saves. Storage failures never stop a run. */
export function saveLocal<T>(key: string, value: T): boolean {
  try {
    localStorage.setItem(`peakshift:${key}`, JSON.stringify(value));
    return true;
  } catch { return false; }
}

export function loadLocal<T>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(`peakshift:${key}`);
    return value === null ? fallback : JSON.parse(value) as T;
  } catch { return fallback; }
}

const copy = <T>(value: T): T => typeof structuredClone === 'function'
  ? structuredClone(value) : JSON.parse(JSON.stringify(value)) as T;

/** Immutable snapshots keep editor previews from mutating the undo stack. */
export class EditorHistory<T> {
  private past: T[] = [];
  private future: T[] = [];
  private value: T;
  constructor(initial: T) { this.value = copy(initial); }
  get current(): T { return copy(this.value); }
  get canUndo(): boolean { return this.past.length > 0; }
  get canRedo(): boolean { return this.future.length > 0; }
  commit(value: T): void {
    this.past.push(copy(this.value));
    if (this.past.length > 80) this.past.shift();
    this.value = copy(value);
    this.future.length = 0;
  }
  undo(): T {
    if (this.past.length) {
      this.future.push(copy(this.value));
      this.value = this.past.pop()!;
    }
    return this.current;
  }
  redo(): T {
    if (this.future.length) {
      this.past.push(copy(this.value));
      this.value = this.future.pop()!;
    }
    return this.current;
  }
}

const objectTypes = new Set([
  'tabletop','hip','step-up','pillow','spine','banked-turn','volcano',
  'ramp', 'kicker', 'rail', 'box', 'halfpipe', 'tree', 'rock', 'fence',
  'cabin', 'light', 'checkpoint', 'gate', 'spawn', 'finish', 'sign', 'snowbank',
  'small-ramp', 'medium-ramp', 'large-ramp', 'huge-ramp', 'curved-rail',
  'rainbow-rail', 'tube', 'ride-on-ramp', 'wallride', 'quarterpipe',
]);
function record(value: unknown, label: string): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(`${label} must be an object.`);
  return value as Record<string, unknown>;
}
function number(value: unknown, min: number, max: number, label: string): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max)
    throw new Error(`${label} must be finite and between ${min} and ${max}.`);
  return value;
}
function identifier(value: unknown, label: string): string {
  if (typeof value !== 'string' || !/^[a-zA-Z0-9_-]{1,80}$/.test(value)) throw new Error(`${label} is invalid.`);
  return value;
}

/** Full seed configurations are shareable data, never executable scene definitions. */
export function validateMountainConfig(data: unknown): MapConfig {
  const input = record(data, 'Mountain');
  const id = identifier(input.id, 'Mountain ID');
  if (!/^seed-[a-zA-Z0-9_-]+$/.test(id)) throw new Error('Imported mountain IDs must start with seed-.');
  const seed = number(input.seed, 0, 4294967295, 'Mountain seed');
  if (!Number.isInteger(seed)) throw new Error('Mountain seed must be an integer.');
  const text = (value: unknown, limit: number, label: string): string => {
    if (typeof value !== 'string' || !value.length || value.length > limit) throw new Error(`${label} is invalid.`);
    const cleaned = value.replace(/[\u0000-\u001f\u007f<>]/g, '').trim();
    if (!cleaned) throw new Error(`${label} cannot be empty.`);
    return cleaned;
  };
  const color = (value: unknown, label: string): string => {
    if (typeof value !== 'string' || !/^#[a-fA-F0-9]{6}$/.test(value)) throw new Error(`${label} must be a six-digit hex color.`);
    return value;
  };
  if (typeof input.snow !== 'string' || !['groomed', 'powder', 'ice'].includes(input.snow)) throw new Error('Mountain snow type is invalid.');
  const mountain: MapConfig = {
    id, seed,
    name: text(input.name, 64, 'Mountain name'),
    region: text(input.region, 64, 'Mountain region'),
    tagline: text(input.tagline, 120, 'Mountain description'),
    difficulty: text(input.difficulty, 40, 'Mountain difficulty'),
    slope: number(input.slope, 0.12, 0.4, 'Mountain slope'),
    roughness: number(input.roughness, 0.2, 2.5, 'Mountain roughness'),
    forest: number(input.forest, 0, 1.2, 'Mountain forest density'),
    vertical: number(input.vertical, 0, 10000, 'Mountain vertical'),
    snow: input.snow as MapConfig['snow'],
    sky: color(input.sky, 'Mountain sky'),
    accent: color(input.accent, 'Mountain accent'),
    fog: color(input.fog, 'Mountain fog'),
  };
  if (input.night !== undefined) {
    if (typeof input.night !== 'boolean') throw new Error('Mountain night setting must be a boolean.');
    mountain.night = input.night;
  }
  return mountain;
}

/** Whitelist fields; imported JSON is data, never script or arbitrary scene content. */
export function validatePark(data: unknown): { version: 1; mapId: string; objects: ParkObject[]; edits: TerrainEdit[] } {
  const input = record(data, 'Park');
  if (input.version !== 1) throw new Error('Unsupported park version. Expected version 1.');
  const mapId = identifier(input.mapId, 'Mountain ID');
  if (!Array.isArray(input.objects) || input.objects.length > 300) throw new Error('A park can contain up to 300 objects.');
  if (!Array.isArray(input.edits) || input.edits.length > 100) throw new Error('A park can contain up to 100 terrain edits.');
  const ids = new Set<string>();
  const objects = input.objects.map((value, i): ParkObject => {
    const item = record(value, `Object ${i + 1}`);
    const id = identifier(item.id, `Object ${i + 1} ID`);
    if (ids.has(id)) throw new Error(`Duplicate object ID: ${id}.`);
    ids.add(id);
    if (typeof item.type !== 'string' || !objectTypes.has(item.type)) throw new Error(`Unknown park object: ${String(item.type)}.`);
    return {
      id, type: item.type,
      x: number(item.x, -10000, 10000, 'Object x'),
      z: number(item.z, -10000, 10000, 'Object z'),
      rotation: number(item.rotation, -Math.PI * 100, Math.PI * 100, 'Object rotation'),
      scale: number(item.scale, 0.25, 5, 'Object scale'),
    };
  });
  const edits = input.edits.map((value, i): TerrainEdit => {
    const item = record(value, `Terrain edit ${i + 1}`);
    if (typeof item.mode !== 'string' || !['raise', 'lower', 'flatten', 'smooth'].includes(item.mode)) throw new Error('Unknown terrain brush.');
    const edit: TerrainEdit = {
      x: number(item.x, -10000, 10000, 'Brush x'),
      z: number(item.z, -10000, 10000, 'Brush z'),
      radius: number(item.radius, 1, 100, 'Brush radius'),
      amount: number(item.amount, -50, 50, 'Brush strength'),
      mode: item.mode as TerrainEdit['mode'],
    };
    if (item.target !== undefined) edit.target = number(item.target, -10000, 10000, 'Brush target');
    return edit;
  });
  return { version: 1, mapId, objects, edits };
}

export type ReplayFrame = {
  t: number; x: number; y: number; z: number; heading: number; pitch: number;
  roll: number; spin: number; speed: number; grounded: boolean;
  grab?: boolean; grabStyle?: string; turn?: number; tuck?: boolean;
  crashed?: boolean; charge?: number; lastTrick?: string;compression?:number;edgeAngle?:number;steering?:number;flipProgress?:number;flipDirection?:number;spinWindup?:number;fallPose?:number[];
};
const frameFields = ['t', 'x', 'y', 'z', 'heading', 'pitch', 'roll', 'spin', 'speed'] as const;
function validateFrame(value: unknown): ReplayFrame {
  const input = record(value, 'Replay frame');
  const output = {} as ReplayFrame;
  for (const key of frameFields) output[key] = number(input[key], key === 't' || key === 'speed' ? 0 : -1000000, 1000000, `Replay ${key}`);
  if (typeof input.grounded !== 'boolean') throw new Error('Replay contact state is invalid.');
  output.grounded = input.grounded;
  for (const key of ['grab', 'tuck', 'crashed'] as const) {
    if (input[key] === undefined) continue;
    if (typeof input[key] !== 'boolean') throw new Error(`Replay ${key} must be a boolean.`);
    output[key] = input[key];
  }
  if (input.turn !== undefined) output.turn = number(input.turn, -1, 1, 'Replay turn');
  for(const key of ['compression','edgeAngle','steering','flipProgress','flipDirection','spinWindup'] as const)if(input[key]!==undefined)output[key]=number(input[key],key==='compression'||key==='flipProgress'?0:-1,1,'Replay '+key);
  if (input.charge !== undefined) output.charge = number(input.charge, 0, 1, 'Replay jump charge');
  for (const key of ['grabStyle', 'lastTrick'] as const) {
    if (input[key] === undefined) continue;
    if (typeof input[key] !== 'string' || input[key].length > 160) throw new Error(`Replay ${key} is invalid.`);
    output[key] = input[key].replace(/[\u0000-\u001f\u007f<>]/g, '').slice(0, 80);
  }
  if(input.fallPose!==undefined){if(!Array.isArray(input.fallPose)||input.fallPose.length!==57)throw new Error('Invalid recorded fall pose.');output.fallPose=input.fallPose.map(v=>number(v,-10000,10000,'Fall joint'));}
  return output;
}
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const angleLerp = (a: number, b: number, t: number) => a + Math.atan2(Math.sin(b - a), Math.cos(b - a)) * t;

/** Transform playback does not rerun physics. Records up to 20 minutes at 30 Hz. */
export class ReplayRecorder {
  frames: ReplayFrame[] = [];
  recording = true;
  private elapsed = 0;
  private interval = 0;
  get duration(): number { return this.frames.at(-1)?.t ?? 0; }
  record(frame: ReplayFrame, dt: number): void {
    if (!this.recording || !Number.isFinite(dt) || dt < 0) return;
    if (!this.frames.length) {
      this.frames.push(validateFrame({ ...frame, t: 0 }));
      this.elapsed = 0; this.interval = 0;
      return;
    }
    this.elapsed += dt;
    this.interval += dt;
    if (this.interval + 1e-8 < 1 / 30) return;
    this.interval %= 1 / 30;
    if (this.elapsed > 1200 || this.frames.length >= 36001) { this.recording = false; return; }
    const checked = validateFrame({ ...frame, t: this.elapsed });
    this.frames.push(checked);
  }
  sample(time: number): ReplayFrame | null {
    if (!this.frames.length || !Number.isFinite(time)) return null;
    if (time <= this.frames[0].t) return { ...this.frames[0] };
    if (time >= this.duration) return { ...this.frames[this.frames.length - 1] };
    let lo = 0, hi = this.frames.length - 1;
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1;
      if (this.frames[mid].t <= time) lo = mid; else hi = mid;
    }
    const a = this.frames[lo], b = this.frames[hi];
    const mix = (time - a.t) / (b.t - a.t);
    return {
      ...(mix < 0.5 ? a : b),
      t: time, x: lerp(a.x, b.x, mix), y: lerp(a.y, b.y, mix), z: lerp(a.z, b.z, mix),
      heading: angleLerp(a.heading, b.heading, mix),
      pitch: lerp(a.pitch, b.pitch, mix), roll: lerp(a.roll, b.roll, mix),
      spin: lerp(a.spin, b.spin, mix), speed: lerp(a.speed, b.speed, mix),
      grounded: mix < 0.5 ? a.grounded : b.grounded,
    };
  }
  clear(): void { this.frames = []; this.elapsed = 0; this.interval = 0; this.recording = true; }
  export(): string { return JSON.stringify({ version: 1, frames: this.frames }); }
  import(json: string): void {
    if (json.length > 14000000) throw new Error('Replay file is too large.');
    const data = record(JSON.parse(json), 'Replay');
    if (data.version !== 1 || !Array.isArray(data.frames) || data.frames.length > 36001) throw new Error('Invalid replay format.');
    const frames = data.frames.map(validateFrame);
    for (let i = 0; i < frames.length; i++) {
      if (frames[i].t > 1200 || (i && frames[i].t <= frames[i - 1].t)) throw new Error('Replay timestamps must be increasing and under 20 minutes.');
    }
    this.frames = frames; this.elapsed = this.duration; this.interval = 0; this.recording = false;
  }
}

/** Original procedural sound: wind, board contact, transient takeoffs and landings. */
export class MountainAudio {
  enabled = true;
  volume = 0.45;
  private context?: AudioContext;
  private master?: GainNode;
  private wind?: GainNode;
  private snow?: GainNode;
  private windFilter?: BiquadFilterNode;
  private snowFilter?: BiquadFilterNode;
  private source?: AudioBufferSourceNode;
  start(): void {
    if (this.context) { void this.context.resume().catch(() => {}); return; }
    try {
      const Audio = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Audio) return;
      const ctx = this.context = new Audio();
      this.master = ctx.createGain(); this.master.gain.value = this.enabled ? this.volume : 0;
      this.master.connect(ctx.destination);
      const noise = ctx.createBuffer(1, ctx.sampleRate * 3, ctx.sampleRate);
      const channel = noise.getChannelData(0);
      let brown = 0;
      for (let i = 0; i < channel.length; i++) { brown = (brown + (Math.random() * 2 - 1) * 0.06) / 1.02; channel[i] = brown * 3; }
      this.source = ctx.createBufferSource(); this.source.buffer = noise; this.source.loop = true;
      this.windFilter = ctx.createBiquadFilter(); this.windFilter.type = 'lowpass'; this.windFilter.frequency.value = 600;
      this.snowFilter = ctx.createBiquadFilter(); this.snowFilter.type = 'highpass'; this.snowFilter.frequency.value = 900;
      this.wind = ctx.createGain(); this.wind.gain.value = 0;
      this.snow = ctx.createGain(); this.snow.gain.value = 0;
      this.source.connect(this.windFilter); this.windFilter.connect(this.wind); this.wind.connect(this.master);
      this.source.connect(this.snowFilter); this.snowFilter.connect(this.snow); this.snow.connect(this.master);
      this.source.start();
      void ctx.resume().catch(() => {});
    } catch { this.context = undefined; }
  }
  update(speed: number, turn: number, grounded: boolean): void {
    const ctx = this.context;
    if (!ctx || !this.master || !this.wind || !this.snow) return;
    const velocity = Math.max(0, Math.min(1, (Number.isFinite(speed) ? speed : 0) / 42));
    const edge = Math.min(1, Math.abs(Number.isFinite(turn) ? turn : 0));
    this.master.gain.setTargetAtTime(this.enabled ? Math.min(1, Math.max(0, this.volume)) : 0, ctx.currentTime, 0.06);
    this.wind.gain.setTargetAtTime(0.018 + velocity * velocity * 0.32, ctx.currentTime, 0.15);
    this.snow.gain.setTargetAtTime(grounded ? velocity * (0.12 + edge * 0.48) : 0, ctx.currentTime, 0.07);
    this.windFilter?.frequency.setTargetAtTime(220 + velocity * 1250, ctx.currentTime, 0.12);
    this.snowFilter?.frequency.setTargetAtTime(650 + (1 - edge) * 1400, ctx.currentTime, 0.08);
  }
  event(type: string): void {
    const ctx = this.context;
    if (!ctx || !this.master || !this.enabled || ctx.state !== 'running') return;
    const oscillator = ctx.createOscillator(), gain = ctx.createGain();
    oscillator.type = type === 'crash' ? 'triangle' : 'sine';
    const now = ctx.currentTime;
    const frequency = type === 'jump' ? 220 : type === 'land' || type === 'landing' ? 110 : type === 'crash' ? 80 : type === 'rail' ? 680 : 520;
    oscillator.frequency.setValueAtTime(frequency, now);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(25, frequency * (type === 'jump' ? 1.8 : 0.35)), now + 0.18);
    gain.gain.setValueAtTime(0, now); gain.gain.linearRampToValueAtTime(0.12, now + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    oscillator.connect(gain); gain.connect(this.master);
    oscillator.start(now); oscillator.stop(now + 0.24);
    oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
  }
  dispose(): void {
    try { this.source?.stop(); this.source?.disconnect(); void this.context?.close().catch(() => {}); } catch { /* already stopped */ }
    this.context = undefined; this.source = undefined;
  }
}

export type RemotePlayer = {
  id: string; name: string; x: number; y: number; z: number; heading: number;
  pitch: number; roll: number; spin: number; sport: string; color: string; trick?: string;
};
type RemoteSnapshot = { time: number; player: RemotePlayer };

/** Guest rooms require the separate WebSocket server. No synthetic online riders. */
export class MountainNetwork {
  connected = false;
  room = '';
  mapId = '';
  players = new Map<string, RemotePlayer>();
  status = 'Offline · solo riding';
  onChange?: () => void;
  private socket?: WebSocket;
  private id = '';
  private lastSend = 0;
  private cancelConnect?: () => void;
  private buffers = new Map<string, RemoteSnapshot[]>();
  private animation = 0;
  connect(url: string, name: string, room = '', mapId = 'alpine-crown'): Promise<void> {
    this.disconnect();
    this.status = 'Connecting…'; this.onChange?.();
    return new Promise((resolve, reject) => {
      let socket: WebSocket;
      try {
        const endpoint = new URL(url);
        if (!['ws:', 'wss:'].includes(endpoint.protocol) || endpoint.username || endpoint.password) throw new Error('Use a ws:// or wss:// server address.');
        socket = this.socket = new WebSocket(endpoint.toString());
      } catch (error) { this.status = 'Invalid multiplayer endpoint'; this.onChange?.(); reject(error); return; }
      let settled = false;
      const fail = (message: string) => {
        if (this.socket !== socket) return;
        this.connected = false; this.status = message; this.onChange?.();
        if (!settled) { settled = true; reject(new Error(message)); }
      };
      const timeout = setTimeout(() => { fail('Server did not respond. Solo play is available.'); socket.close(); }, 8000);
      this.cancelConnect = () => {
        clearTimeout(timeout);
        if (!settled) { settled = true; reject(new Error('Connection cancelled.')); }
      };
      socket.onopen = () => socket.send(JSON.stringify({ type: 'join', name: name.trim().slice(0, 20) || 'Guest', room: room.trim().toUpperCase(), mapId }));
      socket.onmessage = event => {
        if (this.socket !== socket) return;
        try {
          const data = JSON.parse(String(event.data));
          if (data.type === 'welcome') {
            clearTimeout(timeout); this.id = data.id; this.room = data.room; this.mapId = data.mapId;
            this.connected = true; this.status = `Connected · ${this.room}`;
            for (const player of data.players ?? []) this.receive(player);
            this.animate(); this.onChange?.();
            if (!settled) { settled = true; this.cancelConnect = undefined; resolve(); }
          } else if (data.type === 'snapshot') {
            for (const player of data.players ?? []) this.receive(player);
          } else if (data.type === 'player') {
            this.receive(data.player); this.onChange?.();
          } else if (data.type === 'leave') {
            this.players.delete(data.id); this.buffers.delete(data.id); this.onChange?.();
          } else if (data.type === 'error') {
            clearTimeout(timeout); fail(String(data.message).slice(0, 160)); socket.close();
          }
        } catch { /* malformed remote messages do not affect solo gameplay */ }
      };
      socket.onerror = () => { clearTimeout(timeout); fail('Multiplayer server unavailable. Start the local room server.'); };
      socket.onclose = () => {
        clearTimeout(timeout);
        if (this.socket !== socket) return;
        this.players.clear(); this.buffers.clear(); cancelAnimationFrame(this.animation);
        fail(this.connected ? 'Disconnected · solo riding' : this.status);
      };
    });
  }
  private receive(input: RemotePlayer): void {
    if (!input || input.id === this.id || typeof input.id !== 'string' || typeof input.name !== 'string') return;
    if (!['x', 'y', 'z', 'heading', 'pitch', 'roll', 'spin'].every(k => Number.isFinite(input[k as keyof RemotePlayer]))) return;
    const player = { ...input };
    const snapshots = this.buffers.get(player.id) ?? [];
    snapshots.push({ time: performance.now(), player });
    if (snapshots.length > 8) snapshots.shift();
    this.buffers.set(player.id, snapshots);
    if (!this.players.has(player.id)) this.players.set(player.id, player);
  }
  private animate = (): void => {
    if (!this.connected) return;
    const target = performance.now() - 100;
    for (const [id, snapshots] of this.buffers) {
      while (snapshots.length > 2 && snapshots[1].time <= target) snapshots.shift();
      const a = snapshots[0], b = snapshots[1] ?? a;
      const mix = a === b ? 1 : Math.max(0, Math.min(1, (target - a.time) / (b.time - a.time)));
      const player = this.players.get(id)!;
      Object.assign(player, b.player, {
        x: lerp(a.player.x, b.player.x, mix), y: lerp(a.player.y, b.player.y, mix), z: lerp(a.player.z, b.player.z, mix),
        heading: angleLerp(a.player.heading, b.player.heading, mix),
        pitch: lerp(a.player.pitch, b.player.pitch, mix), roll: lerp(a.player.roll, b.player.roll, mix),
        spin: lerp(a.player.spin, b.player.spin, mix),
      });
    }
    this.animation = requestAnimationFrame(this.animate);
  };
  send(state: unknown): void {
    if (!this.connected || this.socket?.readyState !== WebSocket.OPEN || performance.now() - this.lastSend < 50) return;
    this.lastSend = performance.now();
    try { this.socket.send(JSON.stringify({ type: 'state', state })); } catch { /* disconnected between frames */ }
  }
  disconnect(): void {
    this.cancelConnect?.(); this.cancelConnect = undefined;
    const socket = this.socket; this.socket = undefined;
    if (socket) socket.close();
    this.connected = false; this.room = ''; this.id = ''; this.lastSend = 0;
    this.players.clear(); this.buffers.clear(); cancelAnimationFrame(this.animation);
    this.status = 'Offline · solo riding'; this.onChange?.();
  }
}
