import type { InputState } from './physics';

export const DEFAULT_BINDINGS:Record<string,string>={left:'KeyA',right:'KeyD',tuck:'KeyW',brake:'KeyS',jump:'Space',restart:'KeyR'};
export function keyboardInput(keys:Set<string>,bindings=DEFAULT_BINDINGS):InputState{
 const down=(action:string,arrow?:string)=>keys.has(bindings[action])||!!arrow&&keys.has(arrow);
 const tuck=down('tuck','ArrowUp'),brake=down('brake','ArrowDown');
 return {turn:Number(down('right','ArrowRight'))-Number(down('left','ArrowLeft')),tuck,brake,jump:down('jump'),grab:false,pitch:Number(tuck)-Number(brake),roll:Number(keys.has('KeyX'))-Number(keys.has('KeyZ')),press:Number(keys.has('KeyE'))-Number(keys.has('KeyQ'))};
}
/** Ground actions become air rotations immediately when the board leaves support. */
export class AirInputGate{
 reset(){}
 read(raw:InputState,_grounded:boolean,_dt=1/60):InputState{
  // Keep the held axes even when a render frame begins on snow. A pop or
  // natural takeoff can happen partway through that frame's fixed steps.
  return {...raw,airTurn:raw.turn,airPitch:raw.pitch};
 }
}
