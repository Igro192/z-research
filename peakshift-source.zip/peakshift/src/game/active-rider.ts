import * as THREE from 'three';
import {RAPIER,type SnowboardPhysics,type InputState,type RiderDynamics} from './physics';
import {createRider,poseRider} from './rider';
import {SnowRagdoll} from './fall';
import {grabDefinition} from './tricks';
import {BoardGrip} from './grip';

const ANGLES=[RAPIER.JointAxis.AngX,RAPIER.JointAxis.AngY,RAPIER.JointAxis.AngZ];
const qOf=(body:RAPIER.RigidBody)=>new THREE.Quaternion().copy(body.rotation());
const vOf=(body:RAPIER.RigidBody)=>new THREE.Vector3().copy(body.linvel());
function inertiaOf(body:RAPIER.RigidBody){
 const a=body.effectiveAngularInertia();
 return new THREE.Matrix3().set(a.m11,a.m12,a.m13,a.m21,a.m22,a.m23,a.m31,a.m32,a.m33);
}
type Muscle={
 joint:RAPIER.ImpulseJoint;frameB:THREE.Quaternion;hinge:boolean;
 a:RAPIER.RigidBody;b:RAPIER.RigidBody;ai:number;bi:number;
 stiffness:number;damping:number;limit:number;restBend:number;target:THREE.Quaternion;
};

/** The riding skeleton and the fallen skeleton are the same twelve dynamic bodies. */
export class ActiveRider implements RiderDynamics{
 readonly reference=createRider('snowboard');
 readonly ragdoll:SnowRagdoll;
 readonly grip:BoardGrip;
 readonly muscles:Muscle[]=[];
 private all:RAPIER.RigidBody[];
 private active=true;
 private frame=0;
 private inertia=new THREE.Matrix3();
 private inverse=new THREE.Matrix3();
 private centre=new THREE.Vector3();
 private mass=80;
 private offsets:THREE.Vector3[]=[];
 private previous:THREE.Vector3[]=[];
 private disposed=false;
 private unsupportedTime=0;
 private muscleRecovery=1;

 constructor(readonly physics:SnowboardPhysics){
  poseRider(this.reference,physics,{turn:0,tuck:false,brake:false,jump:false,grab:false,pitch:0,roll:0},1/60);
  physics.board.setAdditionalMassProperties(5,{x:0,y:0,z:0},{x:1.4,y:1.5,z:.5},{x:0,y:0,z:0,w:1},true);
  physics.board.recomputeMassPropertiesFromColliders();
  this.ragdoll=new SnowRagdoll(this.reference,physics);
  this.grip=new BoardGrip(physics,this.ragdoll);
  this.all=[physics.board,...this.ragdoll.bodies];
  // The deck collides with the rider in every state. Human self-contact is
  // enabled during tumbles, with native exclusions at overlapping joint anchors.
  for(const body of this.all){
   body.recomputeMassPropertiesFromColliders();
   body.collider(0).setCollisionGroups(body===physics.board?0x00040003:0x00020005);
  }
  for(const index of [4,7])this.ragdoll.joints[index].setContactsEnabled(true);
  this.addMuscle(1,2,1200,40,360);
  this.addMuscle(2,3,180,10,50);
  for(const [upper,lower]of [[4,5],[6,7]]){
   this.addMuscle(1,upper,1000,30,280);
   this.addMuscle(upper,lower,800,24,300);
   this.addMuscle(lower,0,480,38,180);
  }
  for(const [upper,lower]of [[8,9],[10,11]]){
   this.addMuscle(2,upper,360,14,130);
   this.addMuscle(upper,lower,280,10,90);
  }
  this.updateTargets();
  this.updateInertia();
  physics.riderDynamics=this;
 }

 private addMuscle(ai:number,bi:number,stiffness:number,damping:number,limit:number){
  let joint=this.ragdoll.joints[this.muscles.length];
  const a=this.all[ai],b=this.all[bi],frameB=qOf(b).invert().multiply(qOf(a));
  const hinge=joint.type()===RAPIER.JointType.Revolute;
  let restBend=0;
  joint.setFrameX2(frameB);
  if(hinge){
   const up=new THREE.Vector3(0,1,0),bend=Math.acos(THREE.MathUtils.clamp(up.clone().applyQuaternion(qOf(a)).dot(up.clone().applyQuaternion(qOf(b))),-1,1));
   (joint as RAPIER.RevoluteImpulseJoint).setLimits(-bend+.015,2.75-bend);
   restBend=bend;
  }else{
   // Rapier 0.21 can expose a framed spherical joint as GenericImpulseJoint.
   // This public typed facade addresses the same native joint, without a duplicate.
   joint=new RAPIER.SphericalImpulseJoint(this.physics.dynamics.impulseJoints.raw,this.physics.dynamics.bodies,joint.handle);
  }
  this.muscles.push({joint,frameB,hinge,a,b,ai,bi,stiffness,damping,limit,restBend,target:new THREE.Quaternion()});
 }

 isRiderCollider(collider:RAPIER.Collider){
  const parent=collider.parent();
  return !!parent&&this.all.some(body=>body.handle===parent.handle);
 }
 hasSupport(){
  let supported=false;
  for(const body of this.ragdoll.bodies)this.physics.dynamics.contactPairsWith(body.collider(0),other=>{
   if(this.isRiderCollider(other))return;
   this.physics.dynamics.contactPair(body.collider(0),other,m=>{for(let i=0;i<m.numContacts();i++)if(m.contactDist(i)<.035)supported=true;});
  });
  return supported;
 }

 private updateTargets(){
  const targets=[qOf(this.physics.board),...this.ragdoll.frames.map(f=>f.node.getWorldQuaternion(new THREE.Quaternion()).multiply(f.offset))];
  const a=this.reference.userData.parts;
  // Visual IK leaves arbitrary bone twist. Construct a common bend axis so
  // knee/elbow targets are feasible for the physical hinge on those bones.
  const limbs=[[a.leftLeg,a.leftKnee,a.leftAnkle,4],[a.rightLeg,a.rightKnee,a.rightAnkle,6],[a.leftArm,a.leftElbow,null,8],[a.rightArm,a.rightElbow,null,10]] as const;
  for(const [upper,lower,end,index]of limbs){
   const from=upper.getWorldPosition(new THREE.Vector3()),middle=lower.getWorldPosition(new THREE.Vector3());
   const to=end?end.getWorldPosition(new THREE.Vector3()):lower.localToWorld(new THREE.Vector3(0,-.35,0));
   const u=middle.clone().sub(from).normalize(),v=to.clone().sub(middle).normalize(),axis=new THREE.Vector3().crossVectors(u,v).normalize();
   if(axis.lengthSq()<.1)axis.set(0,0,1).applyQuaternion(this.physics.orientation);
   const frame=(up:THREE.Vector3)=>new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(axis,up,new THREE.Vector3().crossVectors(axis,up).normalize()));
   targets[index]=frame(u);targets[index+1]=frame(v);
  }
  for(const m of this.muscles)m.target.copy(targets[m.ai]).invert().multiply(targets[m.bi]).multiply(m.frameB);
 }

 private updateInertia(){
  this.mass=this.all.reduce((n,b)=>n+b.mass(),0);
  this.centre.set(0,0,0);
  for(const b of this.all)this.centre.addScaledVector(new THREE.Vector3().copy(b.worldCom()),b.mass()/this.mass);
  this.inertia.set(0,0,0,0,0,0,0,0,0);
  this.offsets=this.all.map(b=>new THREE.Vector3().copy(b.worldCom()).sub(this.centre));
  this.all.forEach((b,i)=>{
   const r=this.offsets[i],mass=b.mass(),I=inertiaOf(b);
   // Parallel-axis theorem: include the moving mass of every body segment.
   const point=new THREE.Matrix3().set(mass*(r.y*r.y+r.z*r.z),-mass*r.x*r.y,-mass*r.x*r.z,-mass*r.x*r.y,mass*(r.x*r.x+r.z*r.z),-mass*r.y*r.z,-mass*r.x*r.z,-mass*r.y*r.z,mass*(r.x*r.x+r.y*r.y));
   for(let j=0;j<9;j++)this.inertia.elements[j]+=I.elements[j]+point.elements[j];
  });
  this.inverse.copy(this.inertia).invert();
 }

 beforeStep(input:InputState,dt:number){
  for(const body of this.ragdoll.bodies){body.resetForces(true);body.resetTorques(true);}
  this.previous=this.all.map(vOf);
  if(this.physics.crashed&&this.active)this.release();
  this.updateInertia();
  if(!this.active){this.passiveLimits();return;}
  this.muscleRecovery=Math.min(1,this.muscleRecovery+dt/.45);
  if(this.physics.grounded){
   const inverse=this.physics.orientation.clone().invert();
   const local=this.centre.clone().sub(this.physics.position).applyQuaternion(inverse),speed=new THREE.Vector3();
   for(const body of this.all)speed.addScaledVector(vOf(body),body.mass()/this.mass);
   speed.sub(this.physics.velocity).applyQuaternion(inverse);
   const offset=new THREE.Vector3(THREE.MathUtils.clamp(-local.x*.8-speed.x*.14,-.22,.22),0,THREE.MathUtils.clamp(-local.z*.8-speed.z*.14,-.18,.18));
   this.physics.balanceOffset.lerp(offset,1-Math.exp(-dt*10));
   // Recover through finite joint muscles: move the hips over the support and
   // counter-lean against torso wobble. No body is teleported or locked upright.
   const up=new THREE.Vector3(0,1,0),gravity=up.clone().applyQuaternion(inverse);
   const expected=up.clone().applyQuaternion(this.reference.userData.parts.torso.getWorldQuaternion(new THREE.Quaternion()));
   const wobble=up.clone().applyQuaternion(qOf(this.all[2])).sub(expected).applyQuaternion(inverse);
   const omega=new THREE.Vector3().copy(this.all[2].angvel()).sub(new THREE.Vector3().copy(this.physics.board.angvel())).applyQuaternion(inverse);
   const tilt=new THREE.Vector3(THREE.MathUtils.clamp(Math.atan2(gravity.z,gravity.y)*.35-wobble.z*.3-omega.x*.035,-.22,.22),0,THREE.MathUtils.clamp(-Math.atan2(gravity.x,gravity.y)*.35+wobble.x*.3-omega.z*.035,-.22,.22));
   this.physics.balanceTilt.lerp(tilt,1-Math.exp(-dt*9));
   this.physics.balanceEffort=THREE.MathUtils.damp(this.physics.balanceEffort,Math.min(1,wobble.length()*2+speed.length()*.22+omega.length()*.08),10,dt);
  }else{
   this.physics.balanceOffset.multiplyScalar(Math.exp(-dt*8));
   this.physics.balanceTilt.multiplyScalar(Math.exp(-dt*10));
   this.physics.balanceEffort*=Math.exp(-dt*8);
  }
  if(this.frame++%8===0){poseRider(this.reference,this.physics,input,dt*8);this.updateTargets();}
  this.grip.update(input.grab&&this.reference.userData.pose?.state==='grab'?(input.grabStyle||'Indy'):undefined);
  this.legExtension();
  const stability=this.physics.grounded?THREE.MathUtils.smoothstep(this.physics.speed,18,34):0;
  for(const m of this.muscles){
   if(m.hinge){
    const j=m.joint as RAPIER.RevoluteImpulseJoint;
    const knee=m.ai===4||m.ai===6,catching=knee&&this.bracing(),brace=catching?1.5:1;
    if(knee)j.setLimits(-m.restBend+.015,(catching?2.2:2.75)-m.restBend);
    j.configureMotorModel(RAPIER.MotorModel.ForceBased);j.setMotorMaxForce(m.limit*brace*this.muscleRecovery);
    j.configureMotorPosition(2*Math.atan2(m.target.x,m.target.w),m.stiffness*brace*this.muscleRecovery,m.damping*(catching?1.8:1)*(1+stability*.6)*this.muscleRecovery);
   }else{
    const j=m.joint as RAPIER.SphericalImpulseJoint;
    // Aim the motor's frame with the full quaternion. Independent Euler targets
    // disagree at compound rotations and leave the glove far from the board.
    j.setFrameX2(m.frameB.clone().multiply(m.target.clone().invert()));
    for(const axis of ANGLES){
     j.configureMotorModel(axis,RAPIER.MotorModel.ForceBased);j.setMotorMaxForce(axis,m.limit*this.muscleRecovery);
     j.configureMotorPosition(axis,0,m.stiffness*this.muscleRecovery,m.damping*(1+stability*.6)*this.muscleRecovery);
    }
   }
  }
 }

 private bracing(){
  const p=this.physics,up=new THREE.Vector3(0,1,0).applyQuaternion(p.orientation);
  return up.dot(p.surfaceNormal)>.65&&(p.landingRecovery>0&&p.landingImpact>9||p.touchdownPrep>.15&&this.linearVelocity().dot(p.surfaceNormal)<-9);
 }
 private legExtension(){
  const hip=this.ragdoll.poses().hip,lever=hip.clone().sub(this.physics.board.worldCom());
  const relative=vOf(this.ragdoll.bodies[0]).sub(vOf(this.physics.board)).sub(new THREE.Vector3().crossVectors(new THREE.Vector3().copy(this.physics.board.angvel()),lever));
  // A finite axial muscle force supports the squat without teleporting the hips
  // or applying a lateral couple that can flip a light board at a terrain seam.
  const catching=this.bracing();
  const force=this.reference.userData.parts.pelvis.getWorldPosition(new THREE.Vector3()).sub(hip).multiplyScalar(catching?3200:this.physics.landingRecovery>0?1600:2400).addScaledVector(relative,catching?-380:-220).projectOnVector(lever).clampLength(0,catching?1200:this.physics.landingRecovery>0?700:900).multiplyScalar(this.muscleRecovery);
  this.ragdoll.bodies[0].addForce(force,true);
  this.physics.board.addForce(force.clone().negate(),true);
 }

 private passiveLimits(){
  for(const m of this.muscles){
   if(m.hinge)continue; // Knees and elbows retain their native anatomical limits.
   const j=m.joint as RAPIER.SphericalImpulseJoint;
   const relative=qOf(m.a).invert().multiply(qOf(m.b)).multiply(m.frameB);
   if(relative.w<0)relative.set(-relative.x,-relative.y,-relative.z,-relative.w);
   const angle=2*Math.acos(THREE.MathUtils.clamp(relative.w,-1,1));
   const limit=m.ai===1&&m.bi===2?.8:m.bi===3?1:m.bi===0?.6:m.ai===1?1.9:2.7;
   if(angle<=limit){for(const axis of ANGLES)j.setMotorMaxForce(axis,0);continue;}
   const target=new THREE.Quaternion().identity().slerp(relative,limit/angle);
   j.setFrameX2(m.frameB.clone().multiply(target.invert()));
   for(const axis of ANGLES){
    j.setMotorMaxForce(axis,m.bi===3?6:m.bi===0?35:15);
    j.configureMotorPosition(axis,0,35,4);
   }
  }
 }

 /** Apply a bounded assembly torque without accelerating just the light deck. */
 addTorque(torque:THREE.Vector3){
  const alpha=torque.clone().applyMatrix3(this.inverse);
  this.all.forEach((body,i)=>{
   body.addForce(new THREE.Vector3().crossVectors(alpha,this.offsets[i]).multiplyScalar(body.mass()),true);
   body.addTorque(alpha.clone().applyMatrix3(inertiaOf(body)),true);
  });
 }
 /** Apply the pipe guide evenly across the articulated mass. */
 addForce(force:THREE.Vector3){for(const body of this.all)body.addForce(force.clone().multiplyScalar(body.mass()/this.mass),true);}
 angularVelocity(){
  const momentum=new THREE.Vector3();
  this.all.forEach((body,i)=>{
   momentum.add(new THREE.Vector3().crossVectors(this.offsets[i],vOf(body).multiplyScalar(body.mass())));
   momentum.add(new THREE.Vector3().copy(body.angvel()).applyMatrix3(inertiaOf(body)));
  });
  return momentum.applyMatrix3(this.inverse);
 }
 linearVelocity(){
  const velocity=new THREE.Vector3();
  for(const body of this.all)velocity.addScaledVector(vOf(body),body.mass()/this.mass);
  return velocity;
 }
 jump(deltaVelocity:THREE.Vector3){for(const body of this.all)body.applyImpulse(deltaVelocity.clone().multiplyScalar(body.mass()),true);}

 afterStep(){
  if(!this.active||this.physics.crashed)return;
  let supportedOnBody=false;
  if(!this.physics.grounded&&this.physics.airtime>.6){
   for(const body of this.ragdoll.bodies)this.physics.dynamics.contactPairsWith(body.collider(0),other=>{
    if(this.isRiderCollider(other))return;
    this.physics.dynamics.contactPair(body.collider(0),other,m=>{for(let i=0;i<m.numContacts();i++)if(m.contactDist(i)<.035)supportedOnBody=true;});
   });
  }
  this.unsupportedTime=supportedOnBody?this.unsupportedTime+this.physics.dynamics.timestep:0;
  if(this.unsupportedTime>.3){this.physics.bail('LOST FOOTING');return;}
  for(let i=1;i<=3;i++){
   const body=this.all[i];
   if(vOf(body).sub(this.previous[i]).length()<2.5)continue;
   const collider=body.collider(0);
   this.physics.dynamics.contactPairsWith(collider,other=>{
    if(this.isRiderCollider(other))return;
    if(other.handle===this.physics.terrain.handle&&this.physics.assistance&&this.physics.landingRecovery>0&&vOf(body).sub(this.previous[i]).length()<8&&new THREE.Vector3(0,1,0).applyQuaternion(this.physics.orientation).dot(this.physics.surfaceNormal)>.25)return;
    this.physics.dynamics.contactPair(collider,other,manifold=>{
     // CCD stops a torso obstacle before penetration. Snow needs a closer body
     // contact so a foot-first landing doesn't count its transmitted impulse twice.
     const gap=other.handle===this.physics.terrain.handle?.035:.32;
     const approach=Math.abs(this.previous[i].dot(new THREE.Vector3().copy(manifold.normal()))),snow=other.handle===this.physics.terrain.handle;
     const tilt=new THREE.Vector3(0,1,0).applyQuaternion(this.physics.orientation).dot(this.physics.surfaceNormal);
     for(let c=0;c<manifold.numContacts();c++)if(manifold.contactDist(c)<gap&&(!snow&&approach>5||snow&&(approach>16||approach>9&&tilt<.5)))this.physics.bail('BODY IMPACT');
    });
   });
  }
 }
 render(rider:THREE.Group){
  this.ragdoll.render(rider);
  if(!this.active||this.physics.crashed)return;
  const pose={...this.reference.userData.pose},def=grabDefinition(pose.grabStyle),a=rider.userData.parts;
  const elbow=def.hand==='rear'?a.rightElbow:a.leftElbow,target=a.board.localToWorld(new THREE.Vector3(...def.target));
  pose.grabContact=this.grip.style===pose.grabStyle&&!!pose.grabStyle&&elbow.localToWorld(new THREE.Vector3(0,-.35,.014)).distanceTo(target)<.07;
  pose.gripHeld=!!this.grip.joint;
  rider.userData.pose=pose;
 }
 release(){
  if(!this.active)return this.ragdoll;
  this.grip.release();
  for(const m of this.muscles){
   if(m.hinge)(m.joint as RAPIER.RevoluteImpulseJoint).setMotorMaxForce(0);
   else{m.joint.setFrameX2(m.frameB);for(const axis of ANGLES)(m.joint as RAPIER.SphericalImpulseJoint).setMotorMaxForce(axis,0);}
  }
  this.active=false;this.ragdoll.elapsed=0;
  // Environment and body-to-body contacts remain native solver constraints.
  // Joint neighbours keep their contact exclusions at overlapping anchors.
  for(const body of this.all)body.collider(0).setCollisionGroups(body===this.physics.board?0x00040003:0x00020007);
  for(const index of [8,10])this.muscles[index].joint.setContactsEnabled(true);
  return this.ragdoll;
 }
 /** A board-first catch is possible only when the body is still above its support. */
 canResume(normal:THREE.Vector3){
  if(this.active||this.disposed)return false;
  const p=this.ragdoll.poses(),board=this.physics.position;
  const hip=p.hip.clone().sub(board),chest=p.chest.clone().sub(board),head=p.head.clone().sub(board);
  if(hip.dot(normal)<.28||chest.dot(normal)<.58||head.dot(normal)<.8||p.chest.clone().sub(p.hip).dot(normal)<.13)return false;
  if(hip.length()>1.3||hip.clone().addScaledVector(normal,-hip.dot(normal)).length()>.7||this.angularVelocity().length()>9)return false;
  let bodySupported=false;
  for(const body of this.ragdoll.bodies.slice(0,3))this.physics.dynamics.contactPairsWith(body.collider(0),other=>{
   if(this.isRiderCollider(other))return;
   this.physics.dynamics.contactPair(body.collider(0),other,m=>{for(let i=0;i<m.numContacts();i++)if(m.contactDist(i)<.035)bodySupported=true;});
  });
  return !bodySupported;
 }
 /** Re-engage finite muscles on the existing bodies; keep every pose and velocity. */
 resume(input:InputState){
  this.active=true;this.unsupportedTime=0;this.muscleRecovery=0;this.frame=0;
  for(const body of this.all)body.collider(0).setCollisionGroups(body===this.physics.board?0x00040003:0x00020005);
  for(const index of [8,10])this.muscles[index].joint.setContactsEnabled(false);
  this.physics.balanceOffset.set(0,0,0);this.physics.balanceTilt.set(0,0,0);
  poseRider(this.reference,this.physics,{...input,grab:false},1/60);this.updateTargets();
 }
 stop(){this.grip.release();for(const body of this.all){body.setLinvel({x:0,y:0,z:0},true);body.setAngvel({x:0,y:0,z:0},true);}}
 dispose(){
  if(this.disposed)return;
  this.disposed=true;
  this.grip.release();
  if(this.physics.riderDynamics===this)this.physics.riderDynamics=undefined;
  this.physics.balanceOffset.set(0,0,0);this.physics.balanceTilt.set(0,0,0);this.physics.balanceEffort=0;this.ragdoll.dispose();
  this.reference.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();for(const material of Array.isArray(o.material)?o.material:[o.material])material.dispose();}});
 }
}
