/** Board coordinates: +X toes, +Z the regular leading end. */
export const BOARD_LENGTH=1.58,BOARD_WIDTH=.29,BINDING_SPACING=.6;
export const GRABS={
 Indy:{hand:'rear',target:[.145,.025,0],lean:1.12,hipX:-.07,hipZ:.1,hipY:.43,twist:-.12},
 Mute:{hand:'lead',target:[.145,.025,0],lean:1.12,hipX:-.07,hipZ:-.1,hipY:.43,twist:.12},
 Melon:{hand:'lead',target:[-.145,.025,0],lean:-1.08,hipX:.06,hipZ:-.1,hipY:.43,twist:.18},
 Stalefish:{hand:'rear',target:[-.145,.025,0],lean:-1.08,hipX:.06,hipZ:.1,hipY:.43,twist:-.18},
 Method:{hand:'lead',target:[-.145,.025,0],lean:-1.04,hipX:.2,hipZ:-.12,hipY:.46,twist:.46},
 Nose:{hand:'lead',target:[0,.12,.73],lean:.85,hipX:-.05,hipZ:.28,hipY:.43,twist:-.3},
 Tail:{hand:'rear',target:[0,.12,-.73],lean:.85,hipX:-.05,hipZ:-.28,hipY:.43,twist:.3},
 Japan:{hand:'lead',target:[.145,.025,0],lean:1.15,hipX:-.06,hipZ:-.14,hipY:.39,twist:.48},
} as const;
export type GrabStyle=keyof typeof GRABS;
export const GRAB_NAMES=Object.keys(GRABS) as GrabStyle[];
export function grabDefinition(style?:string){return GRABS[style as GrabStyle]||GRABS.Indy;}
export function grabKey(keys:Set<string>):GrabStyle{
 for(let i=0;i<GRAB_NAMES.length;i++)if(keys.has('Digit'+(i+1)))return GRAB_NAMES[i];
 return keys.has('KeyQ')?'Melon':keys.has('KeyE')?'Method':'Indy';
}
