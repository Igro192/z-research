import * as THREE from 'three';
type Ring=readonly[y:number,width:number,depth:number];

/** A continuous tailored silhouette rather than overlapping cylinders and balls. */
export function garmentGeometry(profile:readonly Ring[],segments=18){
 const vertices:number[]=[],indices:number[]=[],uv:number[]=[];
 for(let ring=0;ring<profile.length;ring++)for(let i=0;i<segments;i++){
  const [y,width,depth]=profile[ring],angle=i/segments*Math.PI*2;
  vertices.push(Math.sin(angle)*width,y,Math.cos(angle)*depth);uv.push(i/segments,ring/(profile.length-1));
  if(ring<profile.length-1){const a=ring*segments+i,b=ring*segments+(i+1)%segments,c=a+segments,d=b+segments;indices.push(a,b,c,b,d,c);}
 }
 for(const ring of[0,profile.length-1]){
  const centre=vertices.length/3;vertices.push(0,profile[ring][0],0);uv.push(.5,ring?1:0);
  for(let i=0;i<segments;i++){const a=ring*segments+i,b=ring*segments+(i+1)%segments;indices.push(...(ring?[centre,a,b]:[centre,b,a]));}
 }
 const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geometry.setIndex(indices);geometry.computeVertexNormals();
 return geometry;
}

export function goggleGeometry(width:number,depth:number,height:number){
 const vertices:number[]=[],indices:number[]=[];
 for(let i=0;i<=20;i++){
  const angle=(i/20-.5)*2.1,x=Math.sin(angle)*width,z=Math.cos(angle)*depth;
  vertices.push(x,-height/2,z,x,height/2,z);
  if(i<20){const a=i*2;indices.push(a,a+2,a+1,a+1,a+2,a+3);}
 }
 const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geometry.setIndex(indices);geometry.computeVertexNormals();return geometry;
}
