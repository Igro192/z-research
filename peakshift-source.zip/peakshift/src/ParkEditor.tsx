import React,{useEffect,useRef,useState} from 'react';
import {Undo2,Redo2,Play,ArrowLeft,Copy,Trash2,Download,Upload,MousePointer2,Move,MountainSnow} from 'lucide-react';
import type {GameEngine} from './game/engine';
import {EditorHistory,saveLocal,validatePark} from './game/systems';
import type {ParkObject,MapConfig} from './game/world';
type Park=ReturnType<typeof validatePark>;
const FEATURES=[['tabletop','Tabletop'],['hip','Hip'],['step-up','Step-up'],['pillow','Pillow'],['spine','Spine'],['banked-turn','Bank'],['volcano','Volcano'],['kicker','Kicker'],['small-ramp','Small jump'],['large-ramp','Big jump'],['box','Box'],['rail','Rail'],['tube','Tube'],['curved-rail','Curved pipe'],['rainbow-rail','Rainbow pipe'],['ride-on-ramp','Pipe entry'],['halfpipe','Halfpipe'],['snowbank','Snowbank'],['tree','Pine'],['rock','Rock'],['light','Light'],['gate','Gate']] as const;
const uid=()=>`custom-${crypto.randomUUID?.()||Date.now().toString(36)+Math.random().toString(36).slice(2)}`;
export function ParkEditor({engine,map,onRide,onClose}:{engine:GameEngine;map:MapConfig;onRide:()=>void;onClose:()=>void}){
 const history=useRef(new EditorHistory<Park>({version:1,mapId:map.id,objects:engine.world.objects,edits:engine.world.edits}));
 const[park,setPark]=useState(history.current.current),[tool,setTool]=useState('kicker'),[scale,setScale]=useState(1),[rotation,setRotation]=useState(0),[radius,setRadius]=useState(12),[strength,setStrength]=useState(2),[selected,setSelected]=useState(''),[status,setStatus]=useState('Click the snow to place. Your park saves automatically.'),[section,setSection]=useState(120);
 const file=useRef<HTMLInputElement>(null),selectedObject=park.objects.find(o=>o.id===selected);
 const apply=(next:Park,commit=true)=>{
  try{const clean=validatePark(next);if(commit)history.current.commit(clean);engine.applyPark(clean.objects,clean.edits);setPark(clean);setStatus(saveLocal('park37-'+map.id,clean)?'Park saved on this device.':'Park ready. Export a copy to keep it.');}
  catch(e){setStatus(String(e instanceof Error?e.message:e));}
 };
 const remove=()=>{if(selected){apply({...park,objects:park.objects.filter(o=>o.id!==selected)});setSelected('');}};
 const undo=()=>{apply(history.current.undo(),false);setSelected('');};const redo=()=>{apply(history.current.redo(),false);setSelected('');};
 const duplicate=()=>{if(selectedObject){const item={...selectedObject,id:uid(),x:selectedObject.x+8,z:selectedObject.z+12};apply({...park,objects:[...park.objects,item]});setSelected(item.id);}};
 useEffect(()=>{
  engine.editorTool={type:tool,scale,rotation:rotation*Math.PI/180,radius};
  engine.onEditorPlace=point=>{
   const x=Math.round(point.x/2)*2,z=Math.round(point.z/2)*2;
   if(Math.abs(x)>400||z<0||z>1740){setStatus('Build between the summit and gondola, inside the mountain.');return;}
   if(tool==='select'){
    const nearest=park.objects.map(o=>({o,d:Math.hypot(o.x-x,o.z-z)})).sort((a,b)=>a.d-b.d)[0];
    if(nearest&&nearest.d<Math.max(12,nearest.o.scale*14)){setSelected(nearest.o.id);setScale(nearest.o.scale);setRotation(Math.round(nearest.o.rotation*180/Math.PI));setStatus('Selected. Move, duplicate, rotate, resize, or delete.');}else{setSelected('');setStatus('Click near a feature to select it.');}return;
   }
   if(tool==='move'){if(selected){apply({...park,objects:park.objects.map(o=>o.id===selected?{...o,x,z}:o)});}else setStatus('Select a feature first.');return;}
   if(['raise','lower','flatten','smooth'].includes(tool)){
    apply({...park,edits:[...park.edits,{x,z,radius,amount:strength,mode:tool as Park['edits'][number]['mode'],...(tool==='flatten'?{target:engine.world.height(x,z)}:{})}]});return;
   }
   const item:ParkObject={id:uid(),type:tool,x,z,scale,rotation:rotation*Math.PI/180};
   apply({...park,objects:[...park.objects,item]});setSelected(item.id);
  };
  engine.onEditorCommand=command=>{if(command==='undo')undo();if(command==='redo')redo();if(command==='delete')remove();};
  return()=>{engine.onEditorPlace=undefined;engine.onEditorCommand=undefined;};
 });
 const transform=()=>{if(selectedObject)apply({...park,objects:park.objects.map(o=>o.id===selected?{...o,scale,rotation:rotation*Math.PI/180}:o)});};
 const exportPark=()=>{const blob=new Blob([JSON.stringify(park,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`peakshift-${map.id}-park.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);setStatus('Park exported. Import it on another device to ride your line.');};
 return <section className="park-editor" aria-label="Snowpark editor">
  <div className="editor-top"><div><span className="eyebrow">YOUR MOUNTAIN. YOUR RULES.</span><h1>Park workshop</h1><p>{map.name}</p></div><button className="drop-button" onClick={onRide}>TEST THIS LINE <Play size={18}/></button><button className="text-button" onClick={onClose}><ArrowLeft size={16}/> Maps</button></div>
  <aside className="editor-panel"><div className="editor-history"><button onClick={undo} disabled={!history.current.canUndo} aria-label="Undo"><Undo2 size={18}/></button><button onClick={redo} disabled={!history.current.canRedo} aria-label="Redo"><Redo2 size={18}/></button><span>{park.objects.length} features · {park.edits.length} brushes</span></div>
   <div className="editor-select"><button className={tool==='select'?'chosen':''} onClick={()=>setTool('select')}><MousePointer2 size={15}/> Select</button><button className={tool==='move'?'chosen':''} onClick={()=>setTool('move')}><Move size={15}/> Move</button></div>
   <h2>BUILD YOUR LINE</h2><div className="editor-tools">{FEATURES.map(([id,name])=><button key={id} className={tool===id?'chosen':''} onClick={()=>{setTool(id);setScale(id==='small-ramp'?.5:id==='large-ramp'?1.5:1);}}>{name}</button>)}</div>
   <h2>SHAPE THE SNOW</h2><div className="editor-tools">{['raise','lower','flatten','smooth'].map(id=><button key={id} className={tool===id?'chosen':''} onClick={()=>setTool(id)}>{id}</button>)}</div>
   {['raise','lower','flatten','smooth'].includes(tool)?<><label>Brush radius <b>{radius} m</b><input aria-label="Brush radius" type="range" min="3" max="40" step="1" value={radius} onChange={e=>setRadius(+e.target.value)}/></label><label>Snow height <b>{strength} m</b><input aria-label="Brush strength" type="range" min=".5" max="8" step=".5" value={strength} onChange={e=>setStrength(+e.target.value)}/></label></>:<><label>Size <b>{scale.toFixed(2)}×</b><input aria-label="Feature size" type="range" min=".25" max="3" step=".25" value={scale} onChange={e=>setScale(+e.target.value)}/></label><label>Rotation <b>{rotation}°</b><input aria-label="Feature rotation" type="range" min="-180" max="180" step="15" value={rotation} onChange={e=>setRotation(+e.target.value)}/></label></>}
   {selectedObject&&<div className="editor-selection"><strong>{selectedObject.type.replaceAll('-',' ')} · {selectedObject.x}, {selectedObject.z} m</strong><button onClick={transform}>Apply size & rotation</button><div><button onClick={duplicate}><Copy size={14}/> Duplicate</button><button onClick={remove}><Trash2 size={14}/> Delete</button></div></div>}
   <div className="editor-files"><button onClick={exportPark}><Download size={15}/> Export</button><button onClick={()=>file.current?.click()}><Upload size={15}/> Import</button><input ref={file} type="file" accept=".json,application/json" hidden onChange={async e=>{try{const picked=e.target.files?.[0];if(!picked)return;if(picked.size>500000)throw Error('Choose a park JSON under 500 KB.');const next=validatePark(JSON.parse(await picked.text()));if(next.mapId!==map.id)throw Error('Open '+next.mapId+' before importing this park.');apply(next);setSelected('');}catch(error){setStatus(String(error instanceof Error?error.message:error));}e.target.value='';}}/></div>
   <p className="editor-status" role="status">{status}</p>
  </aside><div className="editor-route"><MountainSnow size={19}/><label>Explore the mountain <b>{section} m downhill</b><input aria-label="Editor downhill position" type="range" min="0" max="1740" step="20" value={section} onChange={e=>{const z=+e.target.value;setSection(z);engine.editorView.z=z;}}/></label><p>WASD pan · scroll to zoom · click to build<br/>⌘Z undo · ⇧⌘Z redo · Delete removes selection</p></div>
 </section>;
}
