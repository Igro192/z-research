import React,{useEffect,useRef,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {MountainSnow,ArrowUpRight,ArrowLeft,Play,Pause,RotateCcw,Volume2,VolumeX,Timer,Trophy,Check} from 'lucide-react';
import {GameEngine,type HUD} from './game/engine';
import {initPhysics} from './game/physics';
import {MAPS,type MapConfig} from './game/world';
import {courseProfile} from './game/courses';
import {CoursePreview} from './CoursePreview';
import {readRecord,recordTime} from './game/records';
import {ParkEditor} from './ParkEditor';
import './style.css';
const INITIAL:HUD={speed:0,score:0,elapsed:0,trick:'',points:0,air:false,charge:0,crashed:false,switch:false,edge:0,finished:false,section:'SUMMIT ROLLERS',feature:'Kicker',distance:75,progress:0,record:{time:null,points:0,runs:0},newTime:false,newPoints:false,fps:0,message:'',grab:''};
function App(){
 const mount=useRef<HTMLDivElement>(null),engine=useRef<GameEngine|null>(null);const[ready,setReady]=useState(false),[error,setError]=useState(''),[playing,setPlaying]=useState(false),[editing,setEditing]=useState(false),[paused,setPaused]=useState(false),[map,setMap]=useState(MAPS[0]),[sound,setSound]=useState(true),[hud,setHUD]=useState<HUD>(INITIAL);
 useEffect(()=>{let cancelled=false;initPhysics().then(()=>{if(cancelled||!mount.current)return;const g=new GameEngine(mount.current);engine.current=g;g.onHUD=setHUD;g.onPause=setPaused;setMap(g.world.map);setSound(g.sound);setReady(true);}).catch(e=>setError(String(e)));return()=>{cancelled=true;engine.current?.dispose();};},[]);
 const home=()=>{setEditing(false);engine.current?.home();setPlaying(false);setPaused(false);};
 const select=(m:MapConfig)=>{engine.current?.selectMap(m);setMap(m);};
 const start=()=>{engine.current?.start();setPlaying(true);setPaused(false);};
 return <div className="app"><div className="game-viewport" ref={mount}/><div className="vignette"/>
  <header className="topbar"><button className="brand" onClick={home} aria-label="Choose map"><MountainSnow size={26}/> PEAKSHIFT <small>SNOWBOARD</small></button><div className="top-right">{playing&&<button className="map-link" onClick={home}><ArrowLeft size={15}/> Maps</button>}<button className="sound" aria-label={sound?'Mute sound':'Enable sound'} onClick={()=>setSound(engine.current?.toggleSound()??true)}>{sound?<Volume2 size={19}/>:<VolumeX size={19}/>}</button></div></header>
  {!ready&&<div className="loading"><MountainSnow size={45}/><h1>PEAKSHIFT</h1><p>{error?'Could not start the physics engine.':'Building your mountain…'}</p>{error&&<small>{error}</small>}</div>}
  {ready&&!playing&&!editing&&<main className="map-menu"><div className="menu-heading"><div><span className="eyebrow">ONE BOARD. ANY LINE.</span><h1>Pick a mountain.</h1></div><p>Ride to the gondola.<br/>Beat your time. Break your score.</p></div>
   <div className="map-grid" aria-label="Choose a mountain">{[...MAPS.filter(m=>m.layout),...MAPS.filter(m=>!m.layout)].map((m,i)=>{const record=readRecord(m.id);return <button key={m.id} className={'map-card '+(m.id===map.id?'selected':'')} onClick={()=>select(m)} aria-pressed={m.id===map.id} aria-label={m.name}><div className="map-art" style={{'--sky':m.sky,'--accent':m.accent} as React.CSSProperties}><CoursePreview map={m}/><span>{String(i+1).padStart(2,'0')}</span><small>{m.layout?m.difficulty:m.snow}</small>{m.id===map.id&&<Check size={19}/>}</div><div className="map-copy"><h2>{m.name}</h2><p>{courseProfile(m.id).label}</p><div className="map-records"><span><Timer size={13}/>{recordTime(record.time)}</span><span><Trophy size={13}/>{record.points.toLocaleString()} pts</span></div></div></button>;})}</div>
   <div className="drop-row"><div><span className="eyebrow">YOUR NEXT LINE</span><strong>{map.name}</strong><small className="course-description">{courseProfile(map.id).terrain}</small></div><button className="editor-open" onClick={()=>{engine.current?.openEditor();setEditing(true);}}>BUILD A PARK</button><button className="drop-button" onClick={start}>DROP IN <ArrowUpRight size={25}/></button></div><p className="menu-controls"><b>A / D</b> edges <b>W / S</b> tuck / brake <b>Space</b> charge & pop <b>WASD</b> air tricks <b>Z / X</b> corks</p><small className="version">V3.7 · 17 DISTINCT COURSES · RECORDS SAVED IN THIS BROWSER</small>
  </main>}
  {editing&&engine.current&&<ParkEditor engine={engine.current} map={map} onClose={home} onRide={()=>{engine.current?.rideEditor();setEditing(false);setPlaying(true);setPaused(false);}}/>}
  {playing&&<><div className="run-top"><div><span>{map.name}</span><strong>{recordTime(hud.elapsed)}</strong><small>BEST {recordTime(hud.record.time)}</small></div><div className="run-points"><span>RUN POINTS</span><strong>{hud.score.toLocaleString()}</strong><small>BEST {hud.record.points.toLocaleString()} PTS</small></div></div>
   <div className="speed-hud"><strong>{hud.speed.toFixed(0)}</strong><span>KM/H</span><small>{hud.crashed?'TUMBLING':hud.air?'AIRBORNE':hud.switch?'SWITCH':'REGULAR'}{!hud.air&&!hud.crashed&&Math.abs(hud.edge)>.05?' · '+(hud.edge*(hud.switch?-1:1)>0?'HEEL EDGE':'TOE EDGE'):''}</small></div>
   <div className="route-guide"><span>{hud.section}</span><strong>{hud.feature}<small>{hud.distance} m</small></strong><i style={{width:100*hud.progress+'%'}}/></div>
   {hud.charge>0&&!hud.crashed&&<div className="charge"><span>LOAD THE POP</span><i><b style={{width:hud.charge*100+'%'}}/></i></div>}
   {hud.grab&&!hud.crashed&&<div className="grab-label">{hud.grab}</div>}
   {hud.message&&!hud.finished&&<div className={'message '+(hud.crashed?'bail':'')}>{hud.message}</div>}
   {hud.trick&&!hud.crashed&&<div className="trick"><span>STOMPED</span><strong>{hud.trick}</strong><b>+{hud.points}</b></div>}
   <div className="ride-controls"><span><kbd>A D</kbd> edge / spin</span><span><kbd>W S</kbd> tuck / flip</span><span><kbd>Space</kbd> pop / get up</span><span><kbd>Z X</kbd> cork</span><button onClick={()=>engine.current?.pause(true)}><Pause size={13}/> Pause</button></div>
   {hud.finished&&<div className="overlay"><section className="finish-card"><Trophy size={30}/><span>GONDOLA BASE REACHED</span><h2>That’s a line.</h2><div className="finish-records"><div><small>RUN TIME</small><strong>{recordTime(hud.elapsed)}</strong>{hud.newTime&&<b>NEW RECORD</b>}</div><div><small>RUN POINTS</small><strong>{hud.score.toLocaleString()}</strong>{hud.newPoints&&<b>NEW RECORD</b>}</div></div><button className="drop-button" onClick={start}>ANOTHER RUN <RotateCcw size={18}/></button><button className="text-button" onClick={home}>Choose a mountain <ArrowLeft size={16}/></button></section></div>}
  </>}
  {paused&&!hud.finished&&playing&&<div className="overlay"><section className="pause-card"><span>TAKE A BREATHER</span><h2>Your line can wait.</h2><p className="air-help">W / S flip · A / D spin · Z / X cork<br/>Hold Space, release to pop · Q / E presses</p><button className="drop-button" onClick={()=>engine.current?.pause(false)}>KEEP RIDING <Play size={18}/></button><button className="text-button" onClick={()=>engine.current?.restart()}><RotateCcw size={16}/> Restart run</button><button className="text-button" onClick={home}><ArrowLeft size={16}/> Choose a mountain</button></section></div>}
 </div>;
}
createRoot(document.getElementById('root')!).render(<App/>);
