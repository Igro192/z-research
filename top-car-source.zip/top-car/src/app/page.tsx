import Image from 'next/image';
import Header, { Wordmark } from '@/components/Header';
import Gallery from '@/components/Gallery';
import EnquiryForm from '@/components/EnquiryForm';
import Services from '@/components/Services';
import Reveal from '@/components/Reveal';
import { Arrow, Phone, Pin } from '@/components/Icons';
import { business } from '@/data/business';
import { siteUrl } from '@/lib/site';

export default function Home() {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'AutomotiveBusiness',
    name: business.name,
    telephone: business.phone.e164,
    address: { '@type': 'PostalAddress', streetAddress: business.address.street, addressLocality: business.city, addressCountry: 'KZ' },
    ...(siteUrl ? { url: siteUrl } : {}),
    hasOfferCatalog: {
      '@type': 'OfferCatalog', name: 'Детейлинг автомобиля',
      itemListElement: business.services.map(service => ({ '@type': 'Offer', itemOffered: { '@type': 'Service', name: service.name } })),
    },
  };

  return <>
    <a href="#main" className="skip-link">Перейти к содержанию</a>
    <div id="top" />
    <Header />
    <main id="main">
      <section className="hero" aria-labelledby="hero-title">
        <div className="hero-image" data-motion><div className="motion-layer"><Image src={business.gallery[0].src} alt={business.gallery[0].alt} fill preload sizes="100vw" /></div></div>
        <div className="hero-shade" />
        <div className="hero-content">
          <p className="eyebrow"><span className="accent-line" />TOP CAR DETAILING <span className="eyebrow-separator">/</span> АЛМАТЫ</p>
          <h1 id="hero-title">Детейлинг<br /><span>в Алматы.</span></h1>
          <p className="hero-description">Ваш автомобиль.<br />Всё внимание — деталям.</p>
          <div className="hero-actions"><a href="#enquiry" className="button button-light">Узнать стоимость<Arrow diagonal /></a><a href={business.phone.href} className="text-link">Позвонить<Phone /></a></div>
        </div>
        <div className="hero-bottom"><a href="#intro" className="scroll-link"><span>Листайте вниз</span><span className="scroll-line" /></a><span className="hero-number">01 / TOP CAR</span></div>
      </section>

      <div className="contact-strip">
        <span>Детейлинг-центр <span className="contact-separator">/</span> Алматы</span>
        <a href={business.maps.search} target="_blank" rel="noopener noreferrer"><Pin />{business.address.street}<Arrow diagonal /></a>
        <a href={business.phone.href}><Phone />{business.phone.display}</a>
      </div>

      <section id="intro" className="intro section-shell">
        <div className="section-kicker" data-reveal><span>01</span> О TOP CAR</div>
        <div className="intro-copy" data-reveal>
          <h2>Автомобиль —<br />это <span className="muted">детали.</span></h2>
          <div className="intro-bottom"><p>Свет на кузове. Фактура салона. Ощущение ухоженного автомобиля. Детейлинг начинается с внимания к тому, что важно именно вам.</p><a href="#services" className="text-link">Выбрать задачу<Arrow diagonal /></a></div>
        </div>
      </section>

      <section id="services" className="services section-shell">
        <div className="section-heading" data-reveal><div className="section-kicker"><span>02</span> ДЕТЕЙЛИНГ</div><h2>Снаружи. Внутри.<br /><span className="muted">В каждой детали.</span></h2></div>
        <Services />
      </section>

      <section id="gallery" className="gallery-section section-shell">
        <div className="section-heading gallery-heading" data-reveal><div><div className="section-kicker"><span>03</span> ЭСТЕТИКА АВТОМОБИЛЯ</div><h2>Детали.<br /><span className="muted">В полном масштабе.</span></h2></div><a href="#enquiry" className="text-link gallery-heading-link">Обсудить ваш автомобиль<Arrow diagonal /></a></div>
        <Gallery />
      </section>

      <section id="enquiry" className="enquiry-section section-shell">
        <div className="enquiry-intro" data-reveal>
          <div className="section-kicker"><span>04</span> ВАШ АВТОМОБИЛЬ</div>
          <h2>Начнём<br />с <span className="muted">деталей.</span></h2>
          <p>Расскажите об автомобиле и задаче. Обсудим стоимость и удобное время по телефону.</p>
          <a className="enquiry-phone" href={business.phone.href}>{business.phone.display}<Arrow diagonal /></a>
        </div>
        <EnquiryForm />
      </section>

      <section id="location" className="location-section">
        <div className="location-content section-shell">
          <div className="section-kicker" data-reveal><span>05</span> АЛМАТЫ</div>
          <div className="location-layout">
            <div data-reveal>
              <h2>Увидимся<br /><span className="muted">в TOP CAR.</span></h2>
              <address><span>{business.city}</span>{business.address.street}</address>
              <div className="location-hours"><span>{business.hours.days}</span><span>{business.hours.time}</span></div>
              <div className="location-actions"><a href={business.maps.directions} target="_blank" rel="noopener noreferrer" className="button button-light">Построить маршрут<Arrow diagonal /></a></div>
            </div>
            <div className="location-card" data-reveal>
              <div className="location-card-top"><Pin /><span>{business.address.area.toUpperCase()} / {business.city.toUpperCase()}</span></div>
              <span className="location-card-address">{business.address.streetName},<br />{business.address.building}</span>
              <a href={business.maps.search} target="_blank" rel="noopener noreferrer">Открыть на карте<Arrow diagonal /></a>
              <div className="location-card-bottom"><span>TOP CAR DETAILING</span><span>KAZAKHSTAN</span></div>
            </div>
          </div>
        </div>
      </section>

      <section className="final-cta section-shell" data-reveal><p className="eyebrow">TOP CAR DETAILING</p><h2>Обсудим ваш автомобиль.</h2><a href={business.phone.href} className="button button-light">Позвонить в TOP CAR<Arrow diagonal /></a></section>
    </main>

    <footer className="footer section-shell">
      <div className="footer-main"><a href="#top" className="brand" aria-label="Вернуться к началу"><Wordmark /></a><p>{business.address.display}</p><a href={business.phone.href}>{business.phone.display}</a><a href="#top" className="footer-up">Наверх<Arrow className="arrow-up" /></a></div>
      <div className="footer-bottom"><span>© {new Date().getFullYear()} TOP CAR Detailing</span><span className="footer-concept">Концепт сайта для TOP CAR Detailing. Иллюстрации будут заменены фотографиями TOP CAR при запуске.</span></div>
    </footer>
    <nav className="mobile-actions" aria-label="Быстрые действия"><a href={business.phone.href}><Phone /><span>Позвонить</span></a><a href="#enquiry"><Arrow diagonal /><span>Стоимость</span></a><a href={business.maps.directions} target="_blank" rel="noopener noreferrer"><Pin /><span>Маршрут</span></a></nav>
    <Reveal />
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema).replace(/</g, '\\u003c') }} />
  </>;
}
