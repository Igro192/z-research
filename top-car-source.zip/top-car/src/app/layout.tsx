import type { Metadata, Viewport } from 'next';
import '@fontsource-variable/manrope';
import './globals.css';
import { business } from '@/data/business';
import { indexable, siteUrl } from '@/lib/site';
const title = `${business.name} — детейлинг автомобилей в ${business.city}`;
const description = `${business.name} в ${business.city}. Обсудите детейлинг и стоимость работ для вашего автомобиля. Контактный телефон: ${business.phone.display}. ${business.address.street}.`;
export const metadata: Metadata = {
 metadataBase: new URL(siteUrl ?? 'http://localhost:3000'),
 title, description,
 alternates: siteUrl ? {canonical:siteUrl} : undefined,
 robots: {index:indexable,follow:indexable},
 openGraph: {title,description,locale:'ru_KZ',type:'website',siteName:business.name,...(siteUrl?{url:siteUrl}:{}),images:[{url:'/brand/og-cover.jpg',width:1200,height:630,alt:'TOP CAR Detailing — детейлинг в Алматы'}]},
 twitter: {card:'summary_large_image',title,description,images:['/brand/og-cover.jpg']},
 icons: {icon:'/brand/favicon.svg',apple:'/brand/apple-touch-icon.png'},
};
export const viewport: Viewport = {width:'device-width',initialScale:1,viewportFit:'cover',themeColor:'#111214',colorScheme:'dark'};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>) {return <html lang="ru"><body>{children}</body></html>;}
