/** Only sourced facts belong here. See research.md before adding services/channels. */
export type Service = { id: string; name: string; description: string; price?: string; imageId?: string; source: string };
export type GalleryImage = { id: string; src: string; alt: string; title: string; subtitle: string; kind: 'illustration' | 'business'; width: number; height: number; source: string; };
const address = { street: 'Жулдыз, 107/3', streetName: 'Жулдыз', building: '107/3', city: 'Алматы', country: 'KZ', area: 'Нұр Алатау', display: 'Алматы, Жулдыз, 107/3' };
// This identifies the street address, not a verified TOP CAR business profile.
const addressPlaceId = 'ChIJ3TPtyhFmgzgRe4hG-oE4StQ';
const addressQuery = `${address.city}, ${address.streetName} ${address.building}`;
export const business = {
  name: 'TOP CAR Detailing',
  displayName: 'TOP CAR',
  descriptor: 'DETAILING',
  language: 'ru',
  city: address.city,
  address,
  phone: { display: '+7 778 888 23 28', e164: '+77788882328', href: 'tel:+77788882328' },
  whatsapp: null as string | null,
  hours: { days: 'Пн–Сб', time: '09:00–19:00', source: 'User-confirmed listed schedule, 2026-10-04; UrbanPlaces indexed listing' },
  coordinates: null,
  email: null,
  logo: null,
  socials: [] as { name: string; url: string }[],
  maps: {
    addressPlaceId,
    search: 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(addressQuery) + '&query_place_id=' + addressPlaceId,
    directions: 'https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(addressQuery) + '&destination_place_id=' + addressPlaceId,
    twoGis: 'https://2gis.kz/almaty/search/' + encodeURIComponent(`${address.streetName} ${address.building}`),
  },
  services: [
    { id: 'detailing', name: 'Детейлинг автомобиля', description: 'Внимание к внешнему виду, салону и деталям вашего автомобиля.', source: 'https://urbanplaces.su/kz_almatyi/almatyi/card-172057-top-car-detailing' }
  ] as Service[],
  // Enquiry topics, not a claim that specific procedures or materials are offered.
  focusAreas: [
    { id: 'body', title: 'Кузов', description: 'Внешний вид. Свет. Отражения.' },
    { id: 'interior', title: 'Салон', description: 'Чистота. Фактура. Комфорт.' },
    { id: 'protection', title: 'Защита', description: 'Забота о внешнем виде надолго.' },
    { id: 'care', title: 'Уход', description: 'Внимание к каждой детали.' },
  ],
  gallery: [
    { id: 'form', src: '/gallery/concept-hero.webp', alt: 'Серебристый спортивный автомобиль в тёмной студии', title: 'Чистота формы', subtitle: 'Свет. Линии. Отражения.', kind: 'illustration', width: 1672, height: 941, source: 'AI concept illustration, not TOP CAR work' },
    { id: 'surface', src: '/gallery/concept-surface.webp', alt: 'Световые отражения на графитовом кузове и фаре автомобиля', title: 'Красота поверхности', subtitle: 'Всё внимание — деталям.', kind: 'illustration', width: 1448, height: 1086, source: 'AI concept illustration, not TOP CAR work' },
    { id: 'interior', src: '/gallery/concept-interior.webp', alt: 'Тёмный кожаный салон: сиденье, прострочка и центральная консоль', title: 'Тактильность деталей', subtitle: 'Фактура. Геометрия. Характер.', kind: 'illustration', width: 1448, height: 1086, source: 'AI concept illustration, not TOP CAR work' },
  ] as GalleryImage[],
  reviews: [],
  sources: [
    'https://urbanplaces.su/kz_almatyi/almatyi/card-172057-top-car-detailing',
    'https://www.cybo.com/KZ-biz/top-car-detailing',
  ],
} as const;
