import Image from 'next/image';
import { Arrow } from '@/components/Icons';
import { business } from '@/data/business';

/** These are enquiry topics. Verified service offers remain in business.services. */
export default function Services() {
  const image = business.gallery.find((item) => item.id === 'surface') ?? business.gallery[0];
  return (
    <div className="service-layout">
      <div className="service-visual" data-reveal data-motion>
        <div className="motion-layer"><Image src={image.src} alt={image.alt} fill sizes="(max-width: 800px) 100vw, 45vw" /></div>
        <span className="vertical-caption">FORM / SURFACE / DETAIL</span>
        <span className="service-visual-caption">Всё внимание — деталям.</span>
      </div>
      <div className="service-copy" data-reveal>
        <span className="service-number">TOP CAR <span>/</span> CAR DETAILING</span>
        <h3>Что важно<br/>вашему автомобилю?</h3>
        <p>Выберите, с чего начать разговор.</p>
        <div className="focus-area-grid">
          {business.focusAreas.map((area, index) => (
            <a href="#enquiry" data-enquiry-task={area.id} className="focus-area" key={area.id} aria-label={'Обсудить задачу: ' + area.title}>
              <span className="focus-area-top"><span>{String(index + 1).padStart(2, '0')}</span><Arrow diagonal /></span>
              <h4>{area.title}</h4>
              <p>{area.description}</p>
              <span className="focus-area-cta">Обсудить задачу</span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
