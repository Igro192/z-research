'use client';

import { useEffect } from 'react';

type MotionState = { element: HTMLElement; current: number; range: number };

/** Progressive enhancement: content stays visible when motion or JavaScript is unavailable. */
export default function Reveal() {
  useEffect(() => {
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (!('IntersectionObserver' in window)) return;

    const revealElements = Array.from(document.querySelectorAll<HTMLElement>('[data-reveal]'));
    const motionElements = Array.from(document.querySelectorAll<HTMLElement>('[data-motion]'));
    const revealed = new WeakSet<HTMLElement>();
    const visible = new Set<MotionState>();
    const states = new Map<HTMLElement, MotionState>();
    let revealObserver: IntersectionObserver | null = null;
    let motionObserver: IntersectionObserver | null = null;
    let frame = 0;
    let enabled = false;

    document.querySelectorAll('.conversation-grid, .gallery-grid').forEach((group) => {
      Array.from(group.children).forEach((child, index) => {
        if (child instanceof HTMLElement && child.hasAttribute('data-reveal')) {
          child.style.setProperty('--reveal-delay', `${Math.min(index, 2) * 60}ms`);
        }
      });
    });

    function destination(state: MotionState) {
      const rect = state.element.getBoundingClientRect();
      const progress = (window.innerHeight / 2 - rect.top - rect.height / 2)
        / ((window.innerHeight + rect.height) / 2);
      return Math.max(-1, Math.min(1, progress)) * state.range;
    }

    function animate() {
      frame = 0;
      if (!enabled || document.hidden || reducedMotion.matches) return;

      // Read every position before changing styles; keep the loop out of layout work.
      const targets = Array.from(visible, (state) => ({ state, target: destination(state) }));
      let moving = false;
      targets.forEach(({ state, target }) => {
        const difference = target - state.current;
        state.current = Math.abs(difference) < 0.04 ? target : state.current + difference * 0.18;
        if (Math.abs(target - state.current) >= 0.04) moving = true;
        state.element.style.setProperty('--motion-y', `${state.current.toFixed(2)}px`);
      });
      if (moving) schedule();
    }

    function schedule() {
      if (enabled && !document.hidden && !frame && visible.size) {
        frame = window.requestAnimationFrame(animate);
      }
    }

    function refreshRanges() {
      states.forEach((state) => {
        const range = Number.parseFloat(getComputedStyle(state.element).getPropertyValue('--motion-range'));
        state.range = Number.isFinite(range) ? Math.max(0, range) : 0;
        // A smaller breakpoint also has less overscan: clamp before the next frame.
        state.current = Math.max(-state.range, Math.min(state.range, state.current));
        state.element.style.setProperty('--motion-y', `${state.current.toFixed(2)}px`);
      });
      schedule();
    }

    function stop() {
      enabled = false;
      if (frame) window.cancelAnimationFrame(frame);
      frame = 0;
      revealObserver?.disconnect();
      motionObserver?.disconnect();
      visible.clear();
      states.clear();
      revealElements.forEach((element) => element.classList.remove('reveal-ready', 'is-visible'));
      motionElements.forEach((element) => {
        element.classList.remove('motion-enabled', 'motion-in-view');
        element.style.removeProperty('--motion-y');
      });
    }

    function start() {
      if (enabled || reducedMotion.matches) return;
      enabled = true;
      revealObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const element = entry.target as HTMLElement;
          element.classList.add('is-visible');
          revealed.add(element);
          revealObserver?.unobserve(element);
        });
      }, { threshold: 0.06 });

      revealElements.forEach((element) => {
        // Never hide content that is already in view, including anchor navigation.
        if (revealed.has(element) || element.getBoundingClientRect().top < window.innerHeight) {
          revealed.add(element);
          return;
        }
        element.classList.add('reveal-ready');
        revealObserver?.observe(element);
      });

      motionObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          const element = entry.target as HTMLElement;
          const state = states.get(element);
          if (!state) return;
          element.classList.toggle('motion-in-view', entry.isIntersecting);
          if (entry.isIntersecting) {
            state.current = destination(state);
            element.style.setProperty('--motion-y', `${state.current.toFixed(2)}px`);
            visible.add(state);
          } else visible.delete(state);
        });
        schedule();
      }, { threshold: 0 });

      motionElements.forEach((element) => {
        element.classList.add('motion-enabled');
        states.set(element, { element, current: 0, range: 0 });
      });
      refreshRanges();
      motionElements.forEach((element) => motionObserver?.observe(element));
    }

    function preferenceChanged() {
      if (reducedMotion.matches) stop();
      else start();
    }

    function visibilityChanged() {
      if (document.hidden) {
        if (frame) window.cancelAnimationFrame(frame);
        frame = 0;
      } else schedule();
    }

    start();
    window.addEventListener('scroll', schedule, { passive: true });
    window.addEventListener('resize', refreshRanges, { passive: true });
    document.addEventListener('visibilitychange', visibilityChanged);
    reducedMotion.addEventListener('change', preferenceChanged);

    return () => {
      stop();
      revealElements.forEach((element) => element.style.removeProperty('--reveal-delay'));
      window.removeEventListener('scroll', schedule);
      window.removeEventListener('resize', refreshRanges);
      document.removeEventListener('visibilitychange', visibilityChanged);
      reducedMotion.removeEventListener('change', preferenceChanged);
    };
  }, []);

  return null;
}
