'use client';
import { useEffect, useRef, useState } from 'react';
import Image from 'next/image';
import { business } from '@/data/business';
import { Arrow } from './Icons';
export default function Gallery() {
 const [active,setActive] = useState<number | null>(null);
 const dialog = useRef<HTMLDialogElement>(null);
 const cards = useRef<(HTMLButtonElement | null)[]>([]);
 const last = useRef(0);
 const images = business.gallery;
 useEffect(()=>{if(active!==null){if(!dialog.current?.open) dialog.current?.showModal();}else dialog.current?.close();},[active]);
 function close(){setActive(null);cards.current[last.current]?.focus();}
 function move(n:number){setActive(i=>((i??0)+n+images.length)%images.length);}
 return <>
 <div className="gallery-grid">{images.map((im,i)=><button ref={el=>{cards.current[i]=el;}} key={im.id} className={'gallery-card gallery-card-'+i} onClick={()=>{last.current=i;setActive(i);}} aria-label={'Открыть изображение: '+im.title} data-reveal>
  <div className="gallery-photo" data-motion><div className="motion-layer"><Image src={im.src} alt={im.alt} fill sizes={i===0?'(max-width: 700px) 100vw, 90vw':'(max-width: 700px) 100vw, 45vw'} quality={80}/></div><span className="gallery-open"><Arrow diagonal/></span></div>
  <span className="gallery-caption"><span><strong>{im.title}</strong><small>{im.subtitle}</small></span><small className="gallery-index">0{i+1} / 0{images.length}</small></span>
 </button>)}</div>
 <dialog className="lightbox" ref={dialog} aria-labelledby="lightbox-title" onCancel={close} onClose={()=>{setActive(null);cards.current[last.current]?.focus();}} onClick={e=>{if(e.target===e.currentTarget)close();}} onKeyDown={e=>{if(e.key==='ArrowRight'){e.preventDefault();move(1);} if(e.key==='ArrowLeft'){e.preventDefault();move(-1);}}}>
  {active!==null&&<div className="lightbox-inner"><div className="lightbox-toolbar"><span id="lightbox-title">{images[active].title}<small>{images[active].subtitle}</small></span><button className="icon-button" aria-label="Закрыть изображение" onClick={close}>×</button></div><div className="lightbox-photo"><Image src={images[active].src} alt={images[active].alt} fill sizes="95vw" quality={90}/></div><div className="lightbox-controls"><button className="icon-button" aria-label="Предыдущее изображение" onClick={()=>move(-1)}><Arrow className="arrow-back"/></button><span aria-live="polite">{active+1} / {images.length}</span><button className="icon-button" aria-label="Следующее изображение" onClick={()=>move(1)}><Arrow/></button></div></div>}
 </dialog>
 </>;
}
