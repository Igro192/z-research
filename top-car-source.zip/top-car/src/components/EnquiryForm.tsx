'use client';

import { useEffect, useId, useRef, useState, type FormEvent } from 'react';
import { business } from '../data/business';
import { getEnquiryTaskTitle, getEnquiryText, validateEnquiry, type EnquiryErrors, type EnquiryInput } from '../lib/enquiry';

const emptyInput: EnquiryInput = {
  brand: '',
  model: '',
  task: '',
  message: '',
};

export default function EnquiryForm() {
  const id = useId();
  const [input, setInput] = useState<EnquiryInput>(emptyInput);
  const [errors, setErrors] = useState<EnquiryErrors>({});
  const [brief, setBrief] = useState('');
  const [copyStatus, setCopyStatus] = useState<'idle' | 'copied' | 'manual'>('idle');
  const [isCopying, setIsCopying] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);
  const resultRef = useRef<HTMLHeadingElement>(null);
  const briefRef = useRef<HTMLTextAreaElement>(null);
  const copyAttemptRef = useRef(0);

  useEffect(() => {
    function chooseTask(event: MouseEvent) {
      if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const link = event.target instanceof Element
        ? event.target.closest<HTMLAnchorElement>('a[href="#enquiry"][data-enquiry-task]')
        : null;
      const task = link?.dataset.enquiryTask;
      if (!task || !getEnquiryTaskTitle(task)) return;

      setInput((current) => ({ ...current, task }));
      setErrors((current) => ({ ...current, task: undefined }));
      setBrief('');
      setCopyStatus('idle');
      copyAttemptRef.current += 1;
      setIsCopying(false);
      // Preserve the anchor's native scroll and URL behavior.
    }
    document.addEventListener('click', chooseTask);
    return () => document.removeEventListener('click', chooseTask);
  }, []);

  function update(field: keyof EnquiryInput, value: string) {
    setInput((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
    setBrief('');
    setCopyStatus('idle');
    copyAttemptRef.current += 1;
    setIsCopying(false);
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const validation = validateEnquiry(input);
    setErrors(validation.errors);
    const firstInvalid = (['brand', 'model', 'task', 'message'] as const).find(
      (field) => validation.errors[field],
    );
    if (firstInvalid) {
      const field = formRef.current?.elements.namedItem(firstInvalid);
      if (field instanceof HTMLElement) field.focus();
      return;
    }

    setInput(validation.values);
    setBrief(getEnquiryText(validation.values));
    setCopyStatus('idle');
    copyAttemptRef.current += 1;
    setIsCopying(false);
    requestAnimationFrame(() => {
      const result = resultRef.current;
      if (!result) return;
      result.focus({ preventScroll: true });
      result.closest('section')?.scrollIntoView({
        block: 'start',
        behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
      });
    });
  }

  function selectBrief() {
    briefRef.current?.focus();
    briefRef.current?.select();
  }

  async function copyBrief() {
    const attempt = ++copyAttemptRef.current;
    setIsCopying(true);
    try {
      if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
      await navigator.clipboard.writeText(brief);
      if (attempt === copyAttemptRef.current) setCopyStatus('copied');
    } catch {
      if (attempt !== copyAttemptRef.current) return;
      setCopyStatus('manual');
      selectBrief();
    } finally {
      if (attempt === copyAttemptRef.current) setIsCopying(false);
    }
  }

  return (
    <div className="enquiry-flow">
      <form className="enquiry-form" ref={formRef} onSubmit={submit} noValidate>
        <fieldset className="enquiry-fieldset">
          <legend className="enquiry-legend">Детали автомобиля</legend>
          <p className="enquiry-intro">Марка, модель и задача — начнём с главного.</p>
          <p className="field-note">* — обязательные поля.</p>

          <div className="enquiry-grid">
            <div className="enquiry-field">
              <label htmlFor={`${id}-brand`}>Марка <span className="field-required" aria-hidden="true">*</span></label>
              <input
                id={`${id}-brand`} name="brand" type="text" value={input.brand}
                onChange={(event) => update('brand', event.target.value)}
                placeholder="Например, Toyota" required maxLength={60} autoComplete="off"
                enterKeyHint="next" autoCapitalize="words" spellCheck={false}
                aria-invalid={Boolean(errors.brand)}
                aria-describedby={errors.brand ? `${id}-brand-error` : undefined}
              />
              {errors.brand && <p className="field-error" id={`${id}-brand-error`}>{errors.brand}</p>}
            </div>

            <div className="enquiry-field">
              <label htmlFor={`${id}-model`}>Модель <span className="field-required" aria-hidden="true">*</span></label>
              <input
                id={`${id}-model`} name="model" type="text" value={input.model}
                onChange={(event) => update('model', event.target.value)}
                placeholder="Например, Camry" required maxLength={60} autoComplete="off"
                enterKeyHint="next" autoCapitalize="words" spellCheck={false}
                aria-invalid={Boolean(errors.model)}
                aria-describedby={errors.model ? `${id}-model-error` : undefined}
              />
              {errors.model && <p className="field-error" id={`${id}-model-error`}>{errors.model}</p>}
            </div>

            <div className="enquiry-field enquiry-field-wide">
              <label htmlFor={`${id}-task`}>Что хотите обсудить? <span className="field-required" aria-hidden="true">*</span></label>
              <select
                id={`${id}-task`} name="task" value={input.task}
                onChange={(event) => update('task', event.target.value)} required
                aria-invalid={Boolean(errors.task)}
                aria-describedby={errors.task ? `${id}-task-error` : undefined}
              >
                <option value="" disabled>Выберите задачу</option>
                {business.focusAreas.map((area) => <option key={area.id} value={area.id}>{area.title}</option>)}
                <option value="consultation">Нужна консультация</option>
              </select>
              {errors.task && <p className="field-error" id={`${id}-task-error`}>{errors.task}</p>}
            </div>

            <div className="enquiry-field enquiry-field-wide">
              <label htmlFor={`${id}-message`}>Комментарий <span className="field-optional">Необязательно</span></label>
              <textarea
                id={`${id}-message`} name="message" rows={3} value={input.message}
                onChange={(event) => update('message', event.target.value)} maxLength={500}
                placeholder="Опишите задачу или задайте вопрос"
                aria-invalid={Boolean(errors.message)}
                aria-describedby={`${id}-message-limit${errors.message ? ` ${id}-message-error` : ''}`}
              />
              <span className="field-counter" id={`${id}-message-limit`}>{input.message.length} / 500</span>
              {errors.message && <p className="field-error" id={`${id}-message-error`}>{errors.message}</p>}
            </div>
          </div>
        </fieldset>

        <button className="button button-primary enquiry-submit" type="submit">
          Подготовить запрос <span aria-hidden="true">↗</span>
        </button>
      </form>

      {brief && (
        <section className="enquiry-result" aria-labelledby={`${id}-result-title`}>
          <span className="enquiry-result-label">Ваш следующий шаг</span>
          <h3 id={`${id}-result-title`} ref={resultRef} tabIndex={-1}>Обсудим ваш автомобиль.</h3>
          <p>Позвоните в TOP CAR, чтобы уточнить состав работ, стоимость и удобное время.</p>
          <div className="enquiry-result-actions">
            <a className="button button-primary" href={business.phone.href}>Позвонить в TOP CAR <span aria-hidden="true">↗</span></a>
          </div>
          <label className="brief-label" htmlFor={`${id}-brief`}>Детали для разговора</label>
          <textarea
            className="enquiry-brief" id={`${id}-brief`} ref={briefRef}
            value={brief} readOnly rows={input.message ? 7 : 5}
            aria-describedby={`${id}-copy-status`}
          />
          <div className="enquiry-result-actions">
            <button className="button button-secondary" type="button" onClick={copyBrief} disabled={isCopying}>
              {isCopying ? 'Копирование…' : copyStatus === 'copied' ? 'Текст скопирован' : 'Скопировать текст'}
            </button>
            <button className="enquiry-select" type="button" onClick={selectBrief}>Выделить текст</button>
          </div>
          <p className="copy-status" id={`${id}-copy-status`} role="status">
            {copyStatus === 'copied' ? 'Текст скопирован.' : copyStatus === 'manual'
              ? 'Выделите текст и выберите «Копировать» в меню устройства.'
              : 'Используйте эти детали во время звонка.'}
          </p>
        </section>
      )}
    </div>
  );
}
