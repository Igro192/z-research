'use client';
import { useEffect, useRef, useState } from 'react';
import { business } from '@/data/business';
import { Arrow } from './Icons';
const links = [{href:'#services',label:'Детейлинг'},{href:'#gallery',label:'Галерея'},{href:'#enquiry',label:'Узнать стоимость'},{href:'#location',label:'Контакты'}];
export function Wordmark() { return <span className="wordmark"><span>TOP CAR<span className="wordmark-dot">.</span></span><small>DETAILING</small></span>; }
export default function Header() {
 const [open,setOpen] = useState(false);
 const dialog = useRef<HTMLDialogElement>(null);
 const button = useRef<HTMLButtonElement>(null);
 useEffect(()=> { if(open) dialog.current?.showModal(); else dialog.current?.close(); },[open]);
 return <>
 <header className="header">
  <a href="#top" className="brand" aria-label="TOP CAR Detailing — начало страницы"><Wordmark/></a>
  <nav className="desktop-nav" aria-label="Основная навигация">{links.map(l=><a key={l.href} href={l.href}>{l.label}</a>)}</nav>
  <a className="header-call" href={business.phone.href}>{business.phone.display}<Arrow diagonal/></a>
  <button ref={button} className="menu-toggle" aria-label="Открыть меню" aria-expanded={open} onClick={()=>setOpen(true)}><span/><span/></button>
 </header>
 <dialog ref={dialog} className="mobile-menu" aria-label="Навигация" onCancel={()=>setOpen(false)} onClose={()=>{setOpen(false);button.current?.focus({preventScroll:true});}}>
  <div className="mobile-menu-top"><Wordmark/><button type="button" className="icon-button" aria-label="Закрыть меню" onClick={()=>{dialog.current?.close();setOpen(false);}}>×</button></div>
  <nav aria-label="Мобильная навигация">{links.map((l,i)=><a key={l.href} href={l.href} onClick={()=>{dialog.current?.close();setOpen(false);}}><small>0{i+1}</small>{l.label}<Arrow diagonal/></a>)}</nav>
  <a className="mobile-menu-phone" href={business.phone.href}>{business.phone.display}</a>
  <p>{business.address.display}</p>
 </dialog>
 </>;
}
