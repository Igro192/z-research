const configured = process.env.NEXT_PUBLIC_SITE_URL?.trim()
  || (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : undefined)
  || (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : undefined)
  || 'https://top-car-detailing-almaty-demo.igrothegreat.chatgpt.site';

function parseOrigin(value: string | undefined): string | undefined {
  if (!value) return undefined;
  try {
    const url = new URL(value);
    return ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password
      ? url.origin : undefined;
  } catch {
    return undefined;
  }
}

// The current deployment host keeps preview sharing cards on the correct site.
export const siteUrl = parseOrigin(configured);
export const indexable = process.env.NEXT_PUBLIC_INDEXABLE === 'true' && Boolean(siteUrl);
