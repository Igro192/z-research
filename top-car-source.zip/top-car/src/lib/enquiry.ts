import { business } from '../data/business';

export type EnquiryInput = {
  brand: string;
  model: string;
  task: string;
  message: string;
};

export type EnquiryErrors = Partial<Record<keyof EnquiryInput, string>>;

/** These are customer interests, not a claim that a specific service is offered. */
export function getEnquiryTaskTitle(taskId: string): string | null {
  if (taskId === 'consultation') return 'Нужна консультация';
  return business.focusAreas.find((area) => area.id === taskId)?.title ?? null;
}

export function validateEnquiry(input: EnquiryInput): {
  values: EnquiryInput;
  errors: EnquiryErrors;
} {
  const values: EnquiryInput = {
    brand: input.brand.trim(),
    model: input.model.trim(),
    task: input.task.trim(),
    message: input.message.trim(),
  };
  const errors: EnquiryErrors = {};

  if (!values.brand) errors.brand = 'Укажите марку автомобиля.';
  else if (values.brand.length > 60) errors.brand = 'Не больше 60 символов.';

  if (!values.model) errors.model = 'Укажите модель автомобиля.';
  else if (values.model.length > 60) errors.model = 'Не больше 60 символов.';

  if (!getEnquiryTaskTitle(values.task)) {
    errors.task = 'Выберите, что хотите обсудить.';
  }

  if (values.message.length > 500) errors.message = 'Не больше 500 символов.';

  return { values, errors };
}

/** Creates a local call brief; this helper never sends or stores an enquiry. */
export function getEnquiryText(input: EnquiryInput): string {
  const { values, errors } = validateEnquiry(input);
  if (Object.keys(errors).length) throw new Error('Заполните обязательные поля.');
  return [
    'Здравствуйте! Хочу узнать стоимость детейлинга.',
    '',
    `Автомобиль: ${values.brand} ${values.model}`,
    `Задача: ${getEnquiryTaskTitle(values.task)}`,
    ...(values.message ? [`Комментарий: ${values.message}`] : []),
  ].join('\n');
}
