import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import ts from 'typescript';
function compile(file, dependencies={}) {
 const source=fs.readFileSync(file,'utf8');
 const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;
 const module={exports:{}};
 new Function('require','module','exports',js)(id=>{if(id in dependencies)return dependencies[id];throw new Error('Unexpected import '+id);},module,module.exports);
 return module.exports;
}
const {business}=compile('src/data/business.ts');
assert.equal(business.phone.href,'tel:'+business.phone.e164);
assert.equal(business.phone.e164,'+77788882328');
assert.equal(business.whatsapp,null);
assert.equal(business.hours.days,'Пн–Сб');
assert.equal(business.hours.time,'09:00–19:00');
assert.ok(business.hours.source);
assert.equal(business.coordinates,null);
assert.equal(business.socials.length,0);
assert.equal(business.reviews.length,0);
assert.deepEqual(business.services.map(s=>s.id),['detailing']);
for(const service of business.services){assert.ok(service.source);assert.equal(service.price,undefined);}
for(const im of business.gallery){assert.equal(im.kind,'illustration');assert.ok(fs.existsSync(path.join('public',im.src)));assert.ok(im.alt);assert.ok(!/работ[аы] TOP CAR/i.test(im.alt));assert.match(im.source,/not TOP CAR work/);}
const sourceFiles=[];
function visit(dir){for(const item of fs.readdirSync(dir,{withFileTypes:true})){const file=path.join(dir,item.name);if(item.isDirectory())visit(file);else if(/\.(tsx?|css)$/.test(file))sourceFiles.push(file);}}
visit('src');
for(const file of sourceFiles){const text=fs.readFileSync(file,'utf8');assert.ok(!/href=["']#["']/.test(text),'Empty anchor '+file);assert.ok(!/wa\.me\/|t\.me\/|api\.whatsapp\.com|instagram\.com\//.test(text),'Unverified channel in '+file);assert.ok(!/aggregateRating|reviewCount|ratingValue|openingHours|foundingDate/.test(text),'Unverified schema in '+file);}
assert.deepEqual(business.focusAreas.map(area=>area.id),['body','interior','protection','care']);
const page=fs.readFileSync('src/app/page.tsx','utf8');
const beforeFooter=page.split('<footer ')[0];
assert.ok(!/Демо|Демонстрац|справочник|не фотографии|не отправляются|уточняйте/i.test(beforeFooter),'Research language in main page');
assert.equal((page.match(/className="footer-concept"/g)||[]).length,1);
assert.ok(!/Демо|Демонстрац|справочник|не фотографии|не отправляются|уточняйте/i.test(fs.readFileSync('src/components/EnquiryForm.tsx','utf8')),'Research language in enquiry flow');
console.log('Fact guard passed: verified contact/category/listed schedule, neutral enquiry areas, no unverified channels/prices/reviews; image provenance recorded internally and one footer disclosure.');
