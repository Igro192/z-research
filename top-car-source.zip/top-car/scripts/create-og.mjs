// Reproducible share-card composition. The automotive photo remains a concept asset.
import sharp from 'sharp';
import path from 'node:path';
import fs from 'node:fs';
import ts from 'typescript';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const compiled = ts.transpileModule(fs.readFileSync(path.join(root, 'src/data/business.ts'), 'utf8'), {compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText;
const dataModule = {exports:{}};
new Function('module','exports',compiled)(dataModule,dataModule.exports);
const {business} = dataModule.exports;
const xml = value => String(value).replace(/[&<>]/g, character => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[character]));
const overlay = Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630">
<defs><linearGradient id="shade"><stop offset="0" stop-color="#111214" stop-opacity=".94"/><stop offset=".4" stop-color="#111214" stop-opacity=".7"/><stop offset=".8" stop-color="#111214" stop-opacity="0"/></linearGradient></defs>
<rect width="1200" height="630" fill="url(#shade)"/>
<g fill="#f1efea" font-family="Arial,sans-serif"><text x="60" y="90" font-size="35" font-weight="800" font-style="italic" letter-spacing="-1.7">${xml(business.displayName)}</text><text x="62" y="116" font-size="10" letter-spacing="4">${xml(business.descriptor)} / ${xml(business.city.toUpperCase())}</text>
<text x="57" y="252" font-size="65" letter-spacing="-2.5">Детейлинг</text><text x="57" y="328" font-size="65" letter-spacing="-2.5">в ${xml(business.city)}.</text>
<text x="60" y="548" fill="#b6b7b8" font-size="16">${xml(business.address.street)}</text><text x="60" y="581" font-size="19">${xml(business.phone.display)}</text></g></svg>`);
await sharp(path.join(root, 'public', business.gallery[0].src)).resize(1200,630,{fit:'cover'}).composite([{input:overlay}]).jpeg({quality:88,mozjpeg:true}).toFile(path.join(root,'public/brand/og-cover.jpg'));
console.log('Created branded 1200 × 630 share card from the recorded concept asset.');
