import fs from 'node:fs';
import assert from 'node:assert/strict';
import ts from 'typescript';
function compile(file, dependency){const module={exports:{}};const code=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText;new Function('require','module','exports',code)(()=>dependency,module,module.exports);return module.exports;}
const data=compile('src/data/business.ts');
const {validateEnquiry,getEnquiryText,getEnquiryTaskTitle}=compile('src/lib/enquiry.ts',data);
const good={brand:' Toyota ',model:' Camry ',task:' body ',message:' Уточнить стоимость '};
assert.equal(validateEnquiry(good).values.brand,'Toyota');
assert.equal(Object.keys(validateEnquiry(good).errors).length,0);
assert.match(getEnquiryText(good),/Автомобиль: Toyota Camry/);
assert.match(getEnquiryText(good),/Комментарий: Уточнить стоимость/);
assert.match(getEnquiryText(good),/Задача: Кузов/);
assert.ok(!getEnquiryText(good).includes('Услуга:'));
assert.equal(Object.keys(validateEnquiry({...good,brand:'   ',model:''}).errors).length,2);
assert.ok(validateEnquiry({...good,task:'ceramic'}).errors.task);
assert.ok(validateEnquiry({...good,task:' '}).errors.task);
assert.equal(getEnquiryTaskTitle('consultation'),'Нужна консультация');
assert.equal(getEnquiryTaskTitle('unknown'),null);
assert.equal(Object.keys(validateEnquiry({...good,task:'consultation'}).errors).length,0);
assert.match(getEnquiryText({...good,task:'consultation'}),/Задача: Нужна консультация/);
for(const area of data.business.focusAreas){
 assert.equal(Object.keys(validateEnquiry({...good,task:area.id}).errors).length,0);
 assert.ok(getEnquiryText({...good,task:area.id}).includes(`Задача: ${area.title}`));
}
assert.ok(validateEnquiry({...good,message:'x'.repeat(501)}).errors.message);
assert.ok(validateEnquiry({...good,brand:'x'.repeat(61)}).errors.brand);
assert.ok(validateEnquiry({...good,model:'x'.repeat(61)}).errors.model);
assert.throws(()=>getEnquiryText({...good,model:''}));
assert.ok(!getEnquiryText({...good,message:' '}).includes('Комментарий'));
console.log('Enquiry checks passed: trim, required fields, lengths, allowed customer interests, consultation, faithful call brief.');
