import type { NextConfig } from 'next';
const config: NextConfig = {
  output: 'export',
  poweredByHeader: false,
  // Images are optimized local WebP assets; static Sites needs no image server.
  images: { unoptimized: true },
};
export default config;
